import requests
from datetime import datetime,timezone

datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

dtt=dtt.replace(tzinfo=timezone.utc)

v1=14

v2="content new"
v3="file new"
v4=9

name="name new"

direction=3


data={
    "name":"ntumba dibe",
    "first_name":"ntumba dibe",
    "last_name":"junior dibe",
    "sexe":"Femme",
    "ecole_provenance":"college dibe",
    "percent":"70",
    "phone":"0970494397",
    "classes_id":2,
    "options_id":2,
    "annee_id":2,

    "date_naissance":'2020-05-05',
    "lieu_de_naissance":"mm dibe",
    "nationalite":"congolese dibe",
    "nom_parent":"askyas dibe",
    "postnom_parent":"junior dibe",
    "direction":direction

}

idEleve=13
idUser=9

rep=requests.get('http://127.0.0.1:8000/api/inscription/valide/'+str(idEleve)+'/'+str(idUser)+'/')

if rep.status_code==200:

    etat=True

else:
    etat=False

print(etat)

"""file_path='imgs/echange.jpg'

with open(file_path,'rb') as f:

    file={'file':f}

data={
    "title":v1,
    "content":v2,
    'file':"imgs/echange.jpg",
    "users_id":v4,
    "direction":direction
}

rep=requests.post('http://127.0.0.1:8000/api/communique/create',json=data)
if rep.status_code==200:           

    etat=True

else:
    etat=False

print(etat)

"""
"""name="xxxr"
fistname="xxxr"
lastname="xxxr"
sexe="Homme"
mail="jojojo@gmail.com"
pwd="xxxr"
adress="xxxr"
phone="xxxr"
fonction=1
"""
"""data={

    "name":name,
    "first_name":fistname,
    "last_name":lastname,
    "sexe":sexe,
    "email":mail,
    "password":pwd,
    "address":adress,
    "phone":phone,
    "fonction_id":fonction

}

rep=requests.put('http://127.0.0.1:8000/api/user/edit/'+str(v1),json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False """   

data={
                
    "name":"junior",
    "email":"jose@gmail.com",
    "email_verified_at":"",
    "password":"",
    "remember_token":"",
    "first_name":"",
    "last_name":"",
    "address":"",
    "phone":"",
    "file":"",
    "fonction_id":1

}

rep=requests.post('http://127.0.0.1:8000/api/register',json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False
    
print(etat)

"""data={
    'name':"index new"
}

rep=requests.put('http://127.0.0.1:8000/api/classe/delete/{v1}',json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False

print(etat)
"""
"""fonction=4

mat='El'
classe=14
opt=1
section=1

typp=2

anne=4
direction=3

eleve=2
tranche=1

motif=3

cours=1
periode=2

listinfo=[]
tabinfo=[]
tabval=[]

rep=requests.get('http://127.0.0.1:8000/api/user/all')

if rep.status_code==200:

    data=rep.json()

    data=data.get('user')

    for li in data:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name'] 
        n4=li['last_name'] 
        n5=li['sexe']

        n6=li['address'] 
        n7=li['phone'] 
        n8=li['file'] 
        n9=li['email']

        x=li['fonction'] 
        
        n10=x['name'] 
        
        n11=li['created_at']
        n12=li['updated_at']

        dirr=li['direction']
    
        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,dirr)

        tabval.append(ligne)

        tabvalNew=[li for li in tabval if li[11]==direction] 
        
        listinfo=[]

        for lig in tabvalNew:

            n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,dirr=lig

            ligneNew=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11)

            listinfo.append(ligneNew)

    etat=True
    
print(listinfo)"""

"""tabval=[]

rep=requests.get('http://127.0.0.1:8000/api/inscription')

if rep.status_code==200:           

    data=rep.json()

    data=data['inscriptionEnAttente']

    for li in data:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name']
        n4=li['last_name']

        n5=li['sexe']
        n6=li['ecole_provenance'] 
        n7=li['percent']
        n8=li['phone']

        x=li['classe']
        x1=x['id']
        n9=x['name']

        xx=li['option']
        xx1=xx['id']
        n10=xx['name']

        xxx=li['annee']
        xxx1=xxx['id']
        n11=xxx['name']

        n12=li['date_naissance']
        n13=li['lieu_de_naissance'] 
        n14=li['nationalite']

        n15=li['nom_parent']
        n16=li['postnom_parent'] 
        
        
        n17=li['direction']

        n18=li['created_at']
        n19=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1)

        tabval.append(ligne)

    tabvalNew=[li for li in tabval if v1 == li[0] and li[21]==v2]

    listinfo=[]

    for lig in tabvalNew:

        n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1=lig

        ligneNew=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19)

        listinfo.append(ligneNew)
    
    etat=True
    


print(listinfo)
"""
"""
tabval=[]

rep=requests.get('http://127.0.0.1:8000/api/inscription')

v1=1
v2=4

v3=2

if rep.status_code==200:           

    data=rep.json()

    #print(data)

    data=data['inscriptionEnAttente']
    
    #data=data['data']

    #print(data)

    for li in data:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name']
        n4=li['last_name']

        n5=li['sexe']
        n6=li['ecole_provenance'] 
        n7=li['percent']
        n8=li['phone']

        x=li['classe']
        x1=x['id']
        n9=x['name']

        xx=li['option']
        xx1=xx['id']
        n10=xx['name']

        xxx=li['annee']
        xxx1=xxx['id']
        n11=xxx['name']

        n12=li['date_naissance']
        n13=li['lieu_de_naissance'] 
        n14=li['nationalite']

        n15=li['nom_parent']
        n16=li['postnom_parent'] 
        n17=li['direction']

        n18=li['created_at']
        n19=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1)

        tabval.append(ligne)

    tabvalNew=[li for li in tabval if v1 == li[20] and li[21]==v2]

    listinfo=[]

    for lig in tabvalNew:

        n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1=lig

        ligneNew=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19)


        listinfo.append(ligneNew)

      
    print(listinfo)"""
"""
rep=requests.get('http://127.0.0.1:8000/api/classe/1')


if rep.status_code==200:

    listinfo=rep.json()
    
    listinfo=listinfo.get("classe",[])

    for i in listinfo.values():

        #print(i)
        pass
 


listinfo=[]
tabinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/user/all')

if rep.status_code==200:

    tabval=rep.json()

    tabval=tabval.get('user')

    #tabval=tabval.get('data')
    #print(tabval)
    
    for li in tabval:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name'] 
        n4=li['last_name'] 
        n5=li['sexe']
        n6=li['address'] 
        n7=li['phone'] 
        n8=li['file'] 
        n9=li['email']
 
        x=li['fonction'] 
        n10=x['name'] 
        
        n11=li['created_at']
        n12=li['updated_at']

    
        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12)

        listinfo.append(ligne)
    
    print(listinfo)


else:
    print('vide')

"""    
"""
        n3=x['name']

        xx=li['motif']

        n4=xx['name']

        xk=li['tranche']

        nn4=xk['name']

        xxx=li['eleve']

        n5=xxx['id']
        n6=xxx['name']
        n7=xxx['first_name']
        n8=xxx['last_name']
        n9=xxx['sexe']

        xxxx=xxx['user']

        n10=xxxx['name']
        n11=xxxx['first_name']
        n12=xxxx['last_name']
        n13=xxxx['email']


        xxxxx=li['classe']

        n14=xxxxx['name']

        xxxxxxx=xxx['option']

        n15=xxxxxxx['name']

        xxxxxxxx=xxxxxxx['section']
        
        n16=xxxxxxxx['name']


        xxxxxx=li['annee']

        n17=xxxxxx['name']

        n3=li['first_name']
        n4=li['last_name']
        n5=li['sexe']
        n6=li['ecole_provenance']
        n7=li['percent']
        n8=li['phone']

        x=li['classe']

        n9=x['id']
        n10=x['name']

        xx=li['option']

        n11=xx['id']
        n12=xx['name']

        #xxx=xx['section']

        #n8=xxx['id']
        #n9=xxx['name']

        xxxx=li['annee']

        n13=xxxx['id']
        n14=xxxx['name']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)

       x=li['cour']

        n2=x['id']
        n3=x['name']

        xx=li['user']

        n4=xx['id']
        n5=xx['name']
        n6=xx['email']

        xxx=x['classe']

        n7=xxx['id']
        n8=xxx['name']

        xxxxx=x['option']

        n9=xxxxx['id']
        n10=xxxxx['name']

        xxxxxx=xxxxx['section']

        n11=xxxxxx['id']
        n12=xxxxxx['name']

        xxx=li['annee']

        n13=xxx['id']
        n14=xxx['name']

        n15=li['created_at']
        n16=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)


        tabinfo.append(ligne)
    
    print(tabinfo)

    # essai put sans succes


    data={
    "status":"0"
}


rep=requests.put('http://127.0.0.1:8000/api/classe/delete/{v1}',json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False

print(etat)

"""
       

    
"""
les cours enseignés dans la classe et option

listinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/cours/classe/1/1')

if rep.status_code==200:

    tabval=rep.json()
    
    print(tabval)
"""