import requests
from datetime import datetime,timezone

datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

dtt=dtt.replace(tzinfo=timezone.utc)

v1=3
v2=4

mat='El'
cla=14
opt=2
section=1

anne=4
direction=3

tabval=[]

rep=requests.get('http://127.0.0.1:8000/api/eleve')

if rep.status_code==200:           

    data=rep.json()

    data=data['eleve']
    data=data['data']


    #print(data)
    
    for li in data:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name']
        n4=li['last_name']

        n5=li['sexe']
        n6=li['matricule'] 
        n7=li['description']

        x=li['classe']
        x1=x['id']
        n8=x['name']

        xx=li['option']
        xx1=xx['id']
        n9=xx['name']

        xxx=xx['section']
        xxx1=xxx['id']
        n10=xxx['name']

        xxxx=li['annee']
        xxxx1=xxxx['id']
        n11=xxxx['name']

        n12=li['users_id']

        n13=li['created_at']
        n14=li['updated_at']

        zx=li['direction']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,x1,xx1,xxx1,xxxx1,zx)

        tabval.append(ligne)

    tabvalNew=[li for li in tabval if datetime.strptime(li[13],'%Y-%m-%dT%H:%M:%S.%fZ').replace(tzinfo=timezone.utc) > dtt and section == li[16] and li[17]==anne and li[18]==direction]
    
    listinfo=[]

    for lig in tabvalNew:

        n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,x1,xx1,xxx1,xxxx1,zx=lig

        ligneNew=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14)

        listinfo.append(ligneNew)
        
    etat=True

print(listinfo)
    

"""tabval=[]

rep=requests.get('http://127.0.0.1:8000/api/inscription')

if rep.status_code==200:           

    data=rep.json()

    data=data['inscriptionEnAttente']

    for li in data:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name']
        n4=li['last_name']

        n5=li['sexe']
        n6=li['ecole_provenance'] 
        n7=li['percent']
        n8=li['phone']

        x=li['classe']
        x1=x['id']
        n9=x['name']

        xx=li['option']
        xx1=xx['id']
        n10=xx['name']

        xxx=li['annee']
        xxx1=xxx['id']
        n11=xxx['name']

        n12=li['date_naissance']
        n13=li['lieu_de_naissance'] 
        n14=li['nationalite']

        n15=li['nom_parent']
        n16=li['postnom_parent'] 
        
        
        n17=li['direction']

        n18=li['created_at']
        n19=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1)

        tabval.append(ligne)

    tabvalNew=[li for li in tabval if v1 == li[0] and li[21]==v2]

    listinfo=[]

    for lig in tabvalNew:

        n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1=lig

        ligneNew=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19)

        listinfo.append(ligneNew)
    
    etat=True
    


print(listinfo)
"""
"""
tabval=[]

rep=requests.get('http://127.0.0.1:8000/api/inscription')

v1=1
v2=4

v3=2

if rep.status_code==200:           

    data=rep.json()

    #print(data)

    data=data['inscriptionEnAttente']
    
    #data=data['data']

    #print(data)

    for li in data:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name']
        n4=li['last_name']

        n5=li['sexe']
        n6=li['ecole_provenance'] 
        n7=li['percent']
        n8=li['phone']

        x=li['classe']
        x1=x['id']
        n9=x['name']

        xx=li['option']
        xx1=xx['id']
        n10=xx['name']

        xxx=li['annee']
        xxx1=xxx['id']
        n11=xxx['name']

        n12=li['date_naissance']
        n13=li['lieu_de_naissance'] 
        n14=li['nationalite']

        n15=li['nom_parent']
        n16=li['postnom_parent'] 
        n17=li['direction']

        n18=li['created_at']
        n19=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1)

        tabval.append(ligne)

    tabvalNew=[li for li in tabval if v1 == li[20] and li[21]==v2]

    listinfo=[]

    for lig in tabvalNew:

        n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,x1,xx1,xxx1=lig

        ligneNew=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19)


        listinfo.append(ligneNew)

      
    print(listinfo)"""
"""
rep=requests.get('http://127.0.0.1:8000/api/classe/1')


if rep.status_code==200:

    listinfo=rep.json()
    
    listinfo=listinfo.get("classe",[])

    for i in listinfo.values():

        #print(i)
        pass
 


listinfo=[]
tabinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/user/all')

if rep.status_code==200:

    tabval=rep.json()

    tabval=tabval.get('user')

    #tabval=tabval.get('data')
    #print(tabval)
    
    for li in tabval:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name'] 
        n4=li['last_name'] 
        n5=li['sexe']
        n6=li['address'] 
        n7=li['phone'] 
        n8=li['file'] 
        n9=li['email']
 
        x=li['fonction'] 
        n10=x['name'] 
        
        n11=li['created_at']
        n12=li['updated_at']

    
        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12)

        listinfo.append(ligne)
    
    print(listinfo)


else:
    print('vide')

"""    
"""
        n3=x['name']

        xx=li['motif']

        n4=xx['name']

        xk=li['tranche']

        nn4=xk['name']

        xxx=li['eleve']

        n5=xxx['id']
        n6=xxx['name']
        n7=xxx['first_name']
        n8=xxx['last_name']
        n9=xxx['sexe']

        xxxx=xxx['user']

        n10=xxxx['name']
        n11=xxxx['first_name']
        n12=xxxx['last_name']
        n13=xxxx['email']


        xxxxx=li['classe']

        n14=xxxxx['name']

        xxxxxxx=xxx['option']

        n15=xxxxxxx['name']

        xxxxxxxx=xxxxxxx['section']
        
        n16=xxxxxxxx['name']


        xxxxxx=li['annee']

        n17=xxxxxx['name']

        n3=li['first_name']
        n4=li['last_name']
        n5=li['sexe']
        n6=li['ecole_provenance']
        n7=li['percent']
        n8=li['phone']

        x=li['classe']

        n9=x['id']
        n10=x['name']

        xx=li['option']

        n11=xx['id']
        n12=xx['name']

        #xxx=xx['section']

        #n8=xxx['id']
        #n9=xxx['name']

        xxxx=li['annee']

        n13=xxxx['id']
        n14=xxxx['name']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)

       x=li['cour']

        n2=x['id']
        n3=x['name']

        xx=li['user']

        n4=xx['id']
        n5=xx['name']
        n6=xx['email']

        xxx=x['classe']

        n7=xxx['id']
        n8=xxx['name']

        xxxxx=x['option']

        n9=xxxxx['id']
        n10=xxxxx['name']

        xxxxxx=xxxxx['section']

        n11=xxxxxx['id']
        n12=xxxxxx['name']

        xxx=li['annee']

        n13=xxx['id']
        n14=xxx['name']

        n15=li['created_at']
        n16=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)


        tabinfo.append(ligne)
    
    print(tabinfo)

    # essai put sans succes


    data={
    "status":"0"
}

rep=requests.put('http://127.0.0.1:8000/api/classe/delete/{v1}',json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False

print(etat)

"""
       

    
"""
les cours enseignés dans la classe et option

listinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/cours/classe/1/1')

if rep.status_code==200:

    tabval=rep.json()
    
    print(tabval)
"""