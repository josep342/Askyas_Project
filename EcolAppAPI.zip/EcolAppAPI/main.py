from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.graphics.vertex_instructions import RoundedRectangle
from kivy.metrics import *
from kivy.graphics import *
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.textfield import MDTextField
from kivy.uix.popup import Popup
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivymd.uix.datatables import MDDataTable
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from datetime import datetime
from kivymd.uix.datatables import MDDataTable
from kivy.uix.image import Image
import random


from back import EcoleApp
import mysql.connector 

#Builder.load_file('screenmanangerr.kv')

class EcolAppApp(MDApp):

    def build(self):

        global etatmenu,pagecurrent,cadresetting1,tabsection,btrengistrersection,tintitulesection,tidsection,titresection

        global tidoption,tintituleoption,btrengistrer,taboption,titreann,tidanne,tintituleanne,btrengistreranne,tabanne
        global cadresettingpaiemnt,cadresettinguser,bmenu
        global cadre,cadsettinghaut,men2,cadreTravauxhaut,tabjournEns2
        global cadreAccueil,cadreInscription,cadrePaiement2,cadreTravaux,cadreTravaux1,cadreTravaux2,cadreTravaux3,cadreCote
        global jour,mois,ann,tabjourPersonnel1
        global t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16
        global c1,c2,c3,c4,c5,cc1
        global btsave,tx3,tx2,tx1,tabpaiejourn
        global cadreInscription1,cadreInscription2,cadreInscription3,cadreconnexion,cadrePaiement1,cadrePaiement
        global check1,check2,check2A,check1A,triAZ2,triAZ1,checkpaie2,checkpaie1
        global paiec01,paiec1,paiec2,paiec3,paiec4,paiet1,paiet2,paiet3,paiet4
        global trechPaiement,spinPaiement,tabinstance,ititre,tabtravaux
        global cadreCote1,cadreCote2,checkcote1,checkcote2,checkdelib2,checkdelib1
        global cadreCommunication,cadreCommunication1,cadreCommunication2
        global checkcomm1,checkcomm2,checkcomm3,checkcomm4
        global checkEnseignant1,checkEnseignant2,checkEnseignant3,checkEnseignant4
        global cadreEnseignant1,cadreEnseignant2,cadreEnseignant
        global checkPers1,checkPers2,checkPers3,checkPers4
        global cadrePersonnel,cadrePersonnel1,cadrePersonnel2,tabjournalinscr,tabcoursjourn
        global checkAbonne1,checkAbonne2,checkAbonne3,checkAbonne4
        global cadreAbonne,cadreAbonne1,cadreAbonne2,msg,btclose,btmsg,msg,tabvalEdition,labtitrePersonnel

        global cadreCours,cadreCours1,cadreCours2,checkcours1,checkcours2,checkcours3,checkcours4,btpaie

        global tidoption,tintituleoption,tidsection,tintitulesection,tabsection
        global ann,mois,jour,tabdelib1,ititreTravaux
        global btrengistreroption,btrengistreranne,btrengistrersection,btrengistrerclass,spinsectionId
        global tabclass,tidclass,tintituleclass,tintituleclassA,tabcours0
        global sup1,sup2,sup3,sup4,tabjournalinscription
        global tintitulemotif,tidmotif,tiddevise,tintituledevise,tintituletranche,tidtranche,suppaie1,suppaie2,suppaie3
        global tabmotif,tabdevise,tabtranche,btrengistrermotif,btrengistrerdevise,btrengistrertrache
        global tiduser,tnomunser,tpostnomuser,tprenomuser,tadressuser,tphonuser,tgmailuser,tpwduser,tintituleclass,fonctionuser,photonuser,btrengistreruser,tabuser,sexuser
        global supuser,sepa,supfontion,btrengistrerfontion,tabfontion,cadresettingadmin,tintitulefontion,tidfonction,titrefonction
        global checkeleve3,checkeleve4,checkeleve1,checkeleve2,tabeleve1,tabeleve2
        global ititreTravaux2,tabCommunique,dtanew
        global cadreELeve2,cadreELeve1,cadreEleve,tabfiltre,idCours,codeSecurite,idEdition,idclass,idchfiffre
        global idEleve,idfonction,idmotif,idPeriode,idoption,checktravau2,checktravau1,cadreTravaux1,cadreTravaux2
        global tabtravaux2,checktravau2,checktravau1,checktravauEns1,checktravauEns2,tabCommjourn,tabCommjourn0
        global tablcommuniqueMid
        global cadreEnsignanthaut,tabvalFoctionew,tabjourPersonnelnew1,tabvalFoctionewInstance

        tabvalFoctionew=[]
        tabvalFoctionewInstance=[]

        idEdition=0
        idclass=0
        idchfiffre=0
        idCours=0
        idEleve=0
        idfonction=0
        idmotif=0
        idPeriode=0
        idoption=0

        tabfiltre=[]
        tabCommunique=[]
        codeSecurite="1234"

        pagecurrent='accueilPage'

        etatmenu=0
        tabinstance=[]
        tabvalEdition=[]

        sepa=2
        idcours=None

        dta=datetime.now().strftime('%Y-%m-%d')
        dtaa=str(dta)+' 00:00:00'

        dtanew=datetime.strptime(dtaa,'%Y-%m-%d %H:%M:%S')

        #self.theme_cls.primary_palette = "Darkblue"
        #self.theme_cls.theme_style = "Dark"

        # page principal 

        cadre=FloatLayout()
        # la table d outils 
        # cadreAccueil,cadreInscrption

        btmsg=Builder.load_string('''
Button:
    pos_hint:{'center_x':.5,'center_y':.5}
    size_hint:1,1
    color:'black'

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
''')
        
        btmsg.bind(on_release=lambda x :msg.dismiss())

        # les outils de la page de conneion
        cadreconnexion=Builder.load_string('''

FloatLayout:
    pos_hint:{'center_x':0.5,'y':.1}
    size_hint:.8,.8

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
    ''')
        
        lbtitreconn=Builder.load_string('''
Label:
    text: "Connexion"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'y':0.87}
    size_hint:0.9,0.15
    bold:True
             ''')
        imgconn=Builder.load_string('''   
Image:
    source:'admin.png'
    pos_hint:{'center_x':0.5,'y':0.75}
    size_hint:0.15,0.1
''')
        
        tid=Builder.load_string('''
MDTextField:
    id:tid
    hint_text:"Identifiant"
    pos_hint:{'center_x':.5,'y':.6}
    size_hint:.8,.15
    text_color_normal:"black"
    font_size:'20sp'
    icon_right:'account'
    line_color_normal:'black'
''')
        
        tpwd=Builder.load_string('''
MDTextField:
    id:tpwd
    hint_text:"Pwd"
    pos_hint:{'center_x':.5,'y':.4}
    size_hint:.8,.15
    text_color_normal:"black"
    font_size:'20sp'
    icon_right:'eye'
    password:True
    line_color_normal:'black'
''')
        
        btconnexion=Builder.load_string('''
Button:
    text:"Se Connecter"
    pos_hint:{'x':.45,'y':.15}
    size_hint:.5,.06
    text_color_normal:"black"
    color:'white'
    font_size:'20sp'
    bold:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size

            radius:[15]
''')
        btconnexion.bind(on_release=self.openaccueilPage)
        
        try:
            cadreconnexion.add_widget(tid)
            cadreconnexion.add_widget(tpwd)
            cadreconnexion.add_widget(btconnexion)

            cadreconnexion.add_widget(lbtitreconn)
            cadreconnexion.add_widget(imgconn)
        except:
            pass

        # outils de la page d acceuil

        bmenu=Builder.load_string('''
MDTopAppBar:
    title: "EcolApp"
    pos_hint: {'x': 0,'y': 0.92}
    size_hint:1,.08
    left_action_items: [["menu", lambda x: app.affmenugacuhe(self)]]
    right_action_items: [["dots-vertical", lambda x: app.affmenugacuhe(self)]]
                                  
    md_bg_color: [0,0,1,1]
    elevation:4

''')
        # les menue

        men2=Builder.load_string('''
FloatLayout:
    size_hint:.3,.9
    pos_hint:{'x':0,'y':.01}
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        Rectangle:
            size:self.size
            pos:self.pos

''')

        ic1=Builder.load_string('''    
MDIconButton:
    icon:'home'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.8}
                                
    on_release:app.openacceuil(self)
                                
''')
        ic2=Builder.load_string('''
MDIconButton:
    icon:'file-document'                
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.72}
''')

        ic01=Builder.load_string('''
MDIconButton:
    icon:'bank'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.64}
''')

        ic02=Builder.load_string('''
MDIconButton:
    icon:'bank'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.56}
''')
        

        ic3=Builder.load_string('''
MDIconButton:
    icon:'bank'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.48}
''')
        
        ic4=Builder.load_string('''
MDIconButton:
    icon:'book-account'
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.4}
                                
''')
        ic5=Builder.load_string('''
                    
MDIconButton:
    icon:"delete-variant"
    text_color:'blue'
    theme_text_color:'Custom'
    
    pos_hint:{'x':.01,'y':.32}
                                
''')
        ic6=Builder.load_string('''
MDIconButton:
    icon:"comment-alert"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.24}
''')
        ic7=Builder.load_string('''
MDIconButton:
    icon:"table-chair"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.16}
                                
''')
        ic8=Builder.load_string('''
                    
MDIconButton:
    icon:"face-agent"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.08}
                                
''')
        ic9=Builder.load_string('''
MDIconButton:
    icon:"arrange-bring-to-front"
    text_color:'blue'
    theme_text_color:'Custom'
    pos_hint:{'x':.01,'y':.02}   
''')
        
        try:
            men2.add_widget(ic1)
            men2.add_widget(ic2)
            men2.add_widget(ic01)
            men2.add_widget(ic02)
            men2.add_widget(ic3)
            men2.add_widget(ic4)
            men2.add_widget(ic5)
            men2.add_widget(ic6)
            men2.add_widget(ic7)
            men2.add_widget(ic8)
            men2.add_widget(ic9)
        except:
            pass


        b1=Builder.load_string('''
Button:
    text:"Page Accueil"
    background_normal:''
    pos_hint: {'x':.2,'y': .84}
    size_hint:0.3,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        b1.bind(on_release=self.openaccueilPage)
                
        b2=Builder.load_string('''
Button:
    text:"Gestion d'Inscriptions"
    background_normal:''
    pos_hint: {'x':.2,'y': .74}
    size_hint:0.5,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        b2.bind(on_release=self.inscriptionF) 

        b01=Builder.load_string('''
Button:
    text:"Gestion Eleve"
    background_normal:''
    pos_hint: {'x':.2,'y': .66}
    size_hint:0.5,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        b01.bind(on_release=self.eleveGestionF) 


        b02=Builder.load_string('''
Button:
    text:"Gestion de Cours"
    background_normal:''
    pos_hint: {'x':.2,'y': .58}
    size_hint:0.49,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255

    on_release:app.openGestioncpoursF(self)
    
''')

        b3=Builder.load_string('''
Button:
    text:"Gestion de Paiement"
    background_normal:''
    pos_hint: {'x':.2,'y': .5}
    size_hint:0.49,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255

    on_release:app.openPaimentF(self)
    
''')
        b4=Builder.load_string('''        

Button:
    text:"Gestion de Cote"
    background_normal:''
    pos_hint: {'x':.2,'y': .42}
    size_hint:0.38,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        
        b4.bind(on_release=self.openCotePage)

        b5=Builder.load_string('''

Button:
    text:"Gestion des Travaux"
    background_normal:''
    pos_hint: {'x':.2,'y': .34}
    size_hint:0.5,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255

''')
        b5.bind(on_release=self.openTravauxPage)
            
        b6=Builder.load_string('''
Button:
    text:"Gestion Communicationnelle"
    background_normal:''
    pos_hint: {'x':.2,'y': .26}
    size_hint:0.68,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''') 
        b6.bind(on_release=self.openCommunication)

        b7=Builder.load_string('''
Button:
    text:"Gestion des Personnels"
    background_normal:''
    pos_hint: {'x':.2,'y': .18}
    size_hint:0.6,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')

        b7.bind(on_release=self.openGestionEnseignant)
            
        b8=Builder.load_string('''

Button:
    text:"Gestion des Presences"
    background_normal:''
    pos_hint: {'x':.2,'y': .1}
    size_hint:0.58,0.05
    bold:True
    font_size:'20sp'

    color:'black'
    background_color:202/255,202/255,202/255
''')
        b8.bind(on_release=self.openPersonnelF)
            

        b9=Builder.load_string('''
Button:
    text:"Gestion d'Horaires"
    background_normal:''
    pos_hint: {'x':.2,'y': .02}
    size_hint:0.53,0.05
    bold:True
    font_size:'20sp'
    color:'black'
    background_color:202/255,202/255,202/255
''')
        b9.bind(on_release=self.openAbonneF)
        
        try:
            men2.add_widget(b1)
            men2.add_widget(b2)
            men2.add_widget(b01)
            men2.add_widget(b02)
            men2.add_widget(b3)
            men2.add_widget(b4)
            men2.add_widget(b5)
            men2.add_widget(b6)
            men2.add_widget(b7)
            men2.add_widget(b8)
            men2.add_widget(b9)
        except:
            pass
           

        cadreAccueil=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        titreacc1=Builder.load_string('''
Label:
    text: " Welcome  "
    bold:True
    color:'black'
    font_size:'30sp'
    pos_hint:{'center_x':0.5,'center_y':0.95}
    size_hint:0.8,0.5
    bold:True
''')
        btsetting=Builder.load_string('''
MDIconButton:
    icon:'book-cog'
    pos_hint:{'x':.9,'y': .9}
    size_hint:.1,.1
    text_color:255/255,128/255,0/255
    theme_text_color:'Custom'
    text_color:'black'

    on_release:app.opensetting(self)
        
''')
        
        try:
            cadreAccueil.add_widget(titreacc1)
            cadreAccueil.add_widget(btsetting) 
        except:
            pass

        # ltes outils de la page d inscrption  

        cadreInscription=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadreInscription1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadrehautInscription=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "Page Inscription"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt1=Builder.load_string('''
Button:
    text:"Ajout"
    bold:True
    pos_hint:{'x':0.28,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt1.bind(on_release=self.openinsertion)
        
        ibt2=Builder.load_string('''
Button:
    text:"Mise à Jour"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.openupdate) 
        
        ibt3=Builder.load_string('''
Button:
    text:"Journal"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openjournalinscription)
        
        ibt4=Builder.load_string('''
Button:
    text:"Analyse"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        ibt4.bind(on_release=self.openanalyse)
        
        t1=Builder.load_string('''

MDTextField:
    hint_text:'Identifiant'
    pos_hint:{'x':.025,'y': .85}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
                               ''')

        t2=Builder.load_string('''
MDTextField:
    hint_text:'Nom'
    pos_hint:{'x':.3,'y': .85}
    size_hint:.3,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        t3=Builder.load_string('''
MDTextField:
    hint_text:'POstnom'
    pos_hint:{'x':.65,'y': .85}
    size_hint:.325,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t4=Builder.load_string('''

MDTextField:
    hint_text:'Prenom'
    pos_hint:{'x':.025,'y': .75}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')
        t5=Builder.load_string('''
MDTextField:
    hint_text:'Ecole Provenance'
    pos_hint:{'x':.3,'y': .75}
    size_hint:.1,.12
    text_color:255/255,128/255,0/255
    icon_right:'human-edit'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        t6=Builder.load_string('''
MDTextField:
    hint_text:'Pourcentage Realisé'
    pos_hint:{'x':.45,'y': .75}
    size_hint:.15,.12
    text_color:255/255,128/255,0/255
    icon_right:'sort-numeric-ascending'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t7=Builder.load_string('''
MDTextField:
    hint_text:'Phone'
    pos_hint:{'x':.65,'y': .75}
    size_hint:.325,.12
    text_color:255/255,128/255,0/255
    icon_right:'phone'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        l1=Builder.load_string('''
Label:
    text:'Joindre le Dossier(*.pdf)'
    pos_hint:{'x':.27,'y': .48}
    size_hint:.1,.1
    font_size:'12sp'
    color:"black"
''')
        f1=Builder.load_string('''
MDIconButton:

    icon:'file'
    pos_hint:{'x':.44,'y': .48}
    size_hint:.05,.1
''')
        l2=Builder.load_string('''
MDIcon:
    icon:'bank'
    pos_hint:{'center_x':.5,'y': .6}
    size_hint:.3,.1
    
        ''')
        t8=Builder.load_string('''
                               

MDTextField:
    hint_text:'Lieu de Naissance'
    pos_hint:{'x':.025,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t9=Builder.load_string('''
MDTextField:
    hint_text:'Nationalité'
    pos_hint:{'x':.275,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        t10=Builder.load_string('''
MDTextField:
    hint_text:'Nom Parent(Tutel)'
    pos_hint:{'x':.525,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        t11=Builder.load_string('''
MDTextField:
    hint_text:'Prenom Parent(Tutel)'
    pos_hint:{'x':.775,'y': .62}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        
        lbnaiss=Label(text="Date de Naissane",pos_hint={'center_x':.5,'center_y':.9},color='black',bold=True,size_hint=(.5,.5))

        annup=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.2,'center_y': .7}
    on_release:app.annplus(self)
                                         
        ''')

        ann=Builder.load_string('''
Spinner:
    text:"AAAA"
    color:'red'
    font_size:'15sp'
    pos_hint:{'center_x':.2,'center_y': .4}
    size_hint:.2,.4
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:223/255,223/255,223/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

        
        ''')

        ann.bind(on_release=self.chargeAnne)

        anndown=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.2,'center_y': .1}
    on_release:app.annmoins(self)
                                         
        ''')

        moisup=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.5,'center_y': .7}
    on_release:app.moisplus(self)
                  
        ''')

        mois=Builder.load_string('''
Spinner:
    text:"MM"
    color:'red'
    font_size:'15sp'
    pos_hint:{'center_x':.5,'center_y': .4}
    size_hint:.2,.4
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:223/255,223/255,223/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

        
        ''')
        mois.bind(on_release=self.chargemois)

        moisdown=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.5,'center_y': .1}
    on_release:app.moismoins(self)
                      
        ''')

        jourup=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.8,'center_y': .7}
    on_release:app.jourplus(self)

                                                
        ''')

        jour=Builder.load_string('''
Spinner:
    text:"JJ"
    color:'red'
    font_size:'15sp'
    pos_hint:{'center_x':.8,'center_y': .4}
    size_hint:.2,.4
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:223/255,223/255,223/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        
        ''')
        jour.bind(on_release=self.chargejour)

        jourdown=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.8,'center_y': .1}
    on_release:app.jourmoins(self)
                      
        ''')

        cadredate=Builder.load_string('''

FloatLayout:   
    pos_hint:{'x':.025,'y': .4}
    size_hint:.2,.15

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
''')
        
        try:
            
            cadredate.add_widget(lbnaiss)
            cadredate.add_widget(ann)
            cadredate.add_widget(mois)
            cadredate.add_widget(jour)

            cadredate.add_widget(anndown)
            cadredate.add_widget(annup)
            cadredate.add_widget(moisdown)
            cadredate.add_widget(moisup)
            cadredate.add_widget(jourdown)
            cadredate.add_widget(jourup)
        except:
            pass 

        ttt=Label(text="Sexe",pos_hint={'x':.26,'y': .42},size_hint=(.04,.04),color='black')
        
        cc1=Builder.load_string('''
Spinner: 
    text:"Homme"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.375,'y': .42}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        cc1.bind(on_release=self.chargesexe)

        t14=Builder.load_string('''
MDTextField:
    hint_text:'CREE'
    pos_hint:{'x':.525,'y': .5}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'gmail'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        t15=Builder.load_string('''
MDTextField:
    hint_text:'MODIFIE'
    pos_hint:{'x':.775,'y': .5}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'eye'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        l3=Builder.load_string('''
Label:
    text:"Detail Scolaire"
    bold:True
    pos_hint:{'center_x':.5,'y': .32}
    size_hint:.3,.1
    color:"black"
    font_size:"15sp"
''')
        l4=Builder.load_string('''

Label:
    text:'Option'
    pos_hint:{'x':.3,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c1=Builder.load_string('''
Spinner: 
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.4,'y': .238}
    size_hint:.13,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        #c1.bind(on_release=self.chargeoption)
        #c1.bind(text=self.selectOption)

        

        c1.bind(on_release=self.chargeOptionProx)
        c1.bind(text=self.selectOptionProx)

        l5=Builder.load_string('''
Label:
    text:'Section'
    pos_hint:{'x':.05,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.12,'y': .238}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        

        c2.bind(on_release=self.chargeSection)
        c2.bind(text=self.selectSection)

        l6=Builder.load_string('''
Label:
    text:'Classe'
    pos_hint:{'x':.6,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
        ''')

        c3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.65,'y': .238}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')
        c3.bind(on_release=self.chargeClass)
        c3.bind(text=self.selectClass)

        l7=Builder.load_string('''
Label:
    text:'Edition'
    pos_hint:{'x':.775,'y': .208}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.86,'y': .238}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')
        c4.bind(on_release=self.chargeEdition)
        c4.bind(text=self.selectEdition)

        

        l8=Builder.load_string('''
Label:
    text:'Fonction'
    pos_hint:{'x':.775,'y': .328}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        c5=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.86,'y': .348}
    size_hint:.1,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        c5.bind(on_release=self.chargeFonction)
        c5.bind(text=self.selectFonction)

        t16=TextInput(text="Description",pos_hint={'x':.02,'y':.07},size_hint=(.6,.1))
        t16.bind(focus=self.efface)

        btsave=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    text:"Enregistrer"
    bold:True
    size_hint:(0.16,0.05)
    pos_hint:{'x':0.8,'y':0.06}
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        ''') 

        btsave.bind(on_release=self.operationinscription)   

    #on_release:app.updateinfoperson(self) 
    #l1,l7,t1-t16,c1-c5,

    #,datenaiss,decription

        try:
            cadreInscription1.add_widget(l1)
            cadreInscription1.add_widget(l2)
            cadreInscription1.add_widget(l3)
            cadreInscription1.add_widget(l4)
            cadreInscription1.add_widget(l5)
            cadreInscription1.add_widget(l6)
            cadreInscription1.add_widget(l7)
            cadreInscription1.add_widget(l8)
        except:
            pass
        try:
            
            cadreInscription1.add_widget(cadredate)
        except:
            pass

        try:
            
            cadreInscription1.add_widget(cc1)
            cadreInscription1.add_widget(c1)
            cadreInscription1.add_widget(c2)
            cadreInscription1.add_widget(c3)
            cadreInscription1.add_widget(c4)
            cadreInscription1.add_widget(c5)
        except:
            pass
        try:
            cadreInscription1.add_widget(t1)
            cadreInscription1.add_widget(t2)
            cadreInscription1.add_widget(t3)
            cadreInscription1.add_widget(t4)
            cadreInscription1.add_widget(t5)
            cadreInscription1.add_widget(t6)
            cadreInscription1.add_widget(t7)
            cadreInscription1.add_widget(t8)
            cadreInscription1.add_widget(t9)
            cadreInscription1.add_widget(t10)
            cadreInscription1.add_widget(t11)
            #cadreInscription.add_widget(t12)
            #cadreInscription.add_widget(t13)
            cadreInscription1.add_widget(t14)
            cadreInscription1.add_widget(t15)
        

        except:
            pass

        try:
            cadreInscription1.add_widget(f1)
            cadreInscription1.add_widget(ttt)
        except:
            pass
        try:
            cadreInscription1.add_widget(t16)
        except:
            pass


        try:
            cadreInscription1.add_widget(btsave)
        except:
            pass
            
        try:
            cadrehautInscription.add_widget(ititre)
            cadrehautInscription.add_widget(ibt1)
            cadrehautInscription.add_widget(ibt2)
            cadrehautInscription.add_widget(ibt3)
            cadrehautInscription.add_widget(ibt4)
        except:
            pass
        try:
            cadreInscription.add_widget(cadrehautInscription)
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass

        # outils de la page journal inscription

        cadreInscription2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        check1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        check2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(check1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(check2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spin1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        #check1

        spin1.bind(on_release=self.chargeSection) 
        spin1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval1.bind(on_release=self.affsectionInsc)
        
        

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spin1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spin2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin2.bind(on_release=self.chargeOptionProx)
        spin2.bind(text=self.selectOptionProx)


        #kkk

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affOptionInsc)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spin2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spin3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin3.bind(on_release=self.chargeClass)
        spin3.bind(text=self.selectClass)


        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affClassInsc)

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spin3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par TravID",color='black',bold=True)

        spin4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS RELATIONNEL",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Secton",color="black",bold=True)

        aliack1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Option",color="black",bold=True)

        aliack2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliack1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliack2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="Classe",color="black",bold=True)

        aliack3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="TravID",color="black",bold=True)

        aliack4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2.add_widget(ll3)
            cadres2.add_widget(aliack3)
            cadres2.add_widget(ll4)
            cadres2.add_widget(aliack4)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spin4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabjournalinscription=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("SEXE",dp(30))),
            (("NAISSANCE",dp(40))),
            (("LIEU",dp(40))),
            (("NOM TUTEUR",dp(40))),
            (("PRENOM TUTEUR",dp(40))),
            (("ECOLE PROV",dp(40))),
            (("%",dp(40))),
            (("PHONE",dp(40))),
            (("CLASSE",dp(40))),
            (("OPTION",dp(40))),
            (("SECTION",dp(40))),
            (("EDITION",dp(40))),
            (("NATIONALITE",dp(40))),
            (("FONCTION",dp(40))),
            (("DESCRIPTION",dp(80))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass


        try:
            
            cadreInscription2.add_widget(cadrejj)
            
            cadreInscription2.add_widget(tabjournalinscription)
        except:
            pass


        # outils de la page analyse

        cadreInscription3=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadredessin=Builder.load_string('''
FloatLayout:
    size_hint:.72,.99
    pos_hint:{'x':.0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        try:
            cadreInscription3.add_widget(cadredessin)
        except:
            pass

        cadrejjA=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Simple",color="black",bold=True)

        check1A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifanalyse1(self)
    ''')

        l2=Label(text="Ultra",color="black",bold=True)

        check2A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifanalyse2(self)
    ''')

        try:
            cadresous1A.add_widget(l1)
            cadresous1A.add_widget(check1A)
            cadresous1A.add_widget(l2)
            cadresous1A.add_widget(check2A)
        except:
            pass

        cadresous2A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Diagramme",color='black',bold=True)

        spin1A=Builder.load_string('''
Spinner:
    text:"Baton"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin1A.bind(on_release=self.opendiagramme)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2A.add_widget(l1)
            cadresous2A.add_widget(spin1A)
            cadresous2A.add_widget(btval1)
        except:
            pass
        
        cadresous3A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Equilibreur",color='black',bold=True) 

        spin2A=Builder.load_string('''
Spinner:
    text:"Fixe"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin2A.bind(on_release=self.openaffichage)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3A.add_widget(l2)
            cadresous3A.add_widget(spin2A)
            cadresous3A.add_widget(btval2)
        except:
            pass

        cadresous4A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Lecture",color='black',bold=True)

        spin3A=Builder.load_string('''
Spinner:
    text:"Asynchrone"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size 
            radius:[15]
''')
        
        spin3A.bind(on_release=self.openmodulation)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4A.add_widget(l3)
            cadresous4A.add_widget(spin3A)
            cadresous4A.add_widget(btval3)
        except:
            pass

        cadresous5A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Modulation",color='black',bold=True)

        spin4A=Builder.load_string('''
Spinner:
    text:"Frequence"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15] 
''')
        
        spin4A.bind(on_release=self.openmodulation)
        btval4=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="SETTING",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Legende",color="black",bold=True)

        aliack1A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Marquage",color="black",bold=True)

        aliack2A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1A.add_widget(ll1)
            cadres1A.add_widget(aliack1A)
            cadres1A.add_widget(ll2)
            cadres1A.add_widget(aliack2A)
        except:
            pass        

        cadres2A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="FMI",color="black",bold=True)

        aliack3A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="ORM",color="black",bold=True)

        aliack4A=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2A.add_widget(ll3)
            cadres2A.add_widget(aliack3A)
            cadres2A.add_widget(ll4)
            cadres2A.add_widget(aliack4A)
        except:
            pass

        try:
            cadresous5A.add_widget(l4)
            cadresous5A.add_widget(spin4A)
            cadresous5A.add_widget(btval4)
        except:
            pass

        try:

            cadrejjA.add_widget(cadresous1A)
            cadrejjA.add_widget(cadresous2A) 

            cadrejjA.add_widget(cadresous3A)
            cadrejjA.add_widget(cadresous4A)
            cadrejjA.add_widget(cadresous5A)

            cadrejjA.add_widget(alias)
            cadrejjA.add_widget(cadres1A) 
            cadrejjA.add_widget(cadres2A)

        except:
            pass

        
        try:
            cadreInscription3.add_widget(cadrejjA)
        except:
            pass
        
        # les outils de la page de gestion de eleves 

        cadreEleve=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:0,0,0
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadreCourshaut=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "GESTION DES ELEVES"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt2=Builder.load_string('''
Button:
    text:"Operations"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.openEleve1)
        
        ibt3=Builder.load_string('''
Button:
    text:"Historique"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openEleve2)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        #ibt4.bind(on_release=self.openanalyse)

        try:
            cadreCourshaut.add_widget(ititre)
            cadreCourshaut.add_widget(ibt2)
            cadreCourshaut.add_widget(ibt3)
            cadreCourshaut.add_widget(ibt4)
        except:
            pass


        cadreELeve1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkeleve1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifeleveF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkeleve2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifeleveF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkeleve1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkeleve2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Ajouter Section",color='black',bold=True)

        spincours1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours1.bind(on_release=self.chargeSection)
        spincours1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionELevenow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincours1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spincours2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours2.bind(on_release=self.chargeOptionProx)
        spincours2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionElevenow)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincours2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="AJouter Classe",color='black',bold=True)

        spincours3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincours3.bind(on_release=self.chargeClass)
        spincours3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassElevenow)
        
        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincours3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincours4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincours4.bind(on_release=self.chargeEdition)
        spincours4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincours4)
            cadresous5.add_widget(btval4)
        except:
            pass


        alias=Label(text="OPERATIONS",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        btop1=Builder.load_string('''
Spinner:
    text:"Nouveau"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.21}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop1.bind(on_release=self.openOperationEleve) 
        
        btop2=Builder.load_string('''
Button:
    text:"Mise à jours"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.12}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop2.bind(on_release=self.openOperationEleve)
        
        btop3=Builder.load_string('''
Button:
    text:"Supprimer"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.03}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop3.bind(on_release=self.openOperationCOurs)
        
        try:
            pass
            #cadresous5.add_widget(l4)
            #cadresous5.add_widget(spincours4)
            #cadresous5.add_widget(btval4)
        except:
            pass

        tabeleve1=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("SEXE",dp(40))),
            (("MATRICULE",dp(40))),
            (("DESCRIPTION",dp(80))),
            (("CLASSE",dp(25))),
            (("OPTION",dp(25))),
            (("SECTION",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            
            cadrejj.add_widget(btop1) 
            cadrejj.add_widget(btop2) 
            cadrejj.add_widget(btop3)
        except:
            pass

        try:
            
            cadreELeve1.add_widget(cadrejj)
            cadreELeve1.add_widget(tabeleve1)
        except:
            pass
        
        try:
            cadreEleve.add_widget(cadreCourshaut)

            cadreEleve.add_widget(cadreELeve1)
        except:
            pass

        
        # les outils de la page des ELEVE journal 
        
        cadreELeve2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkeleve3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifeleveF3(self) 
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkeleve4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifeleveF4(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkeleve3)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkeleve4)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spincoursj1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        
        spincoursj1.bind(on_release=self.chargeSection)
        spincoursj1.bind(text=self.selectSection)
        
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionELeve)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincoursj1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spincoursj2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincoursj2.bind(on_release=self.chargeOptionProx)
        spincoursj2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionEleve)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincoursj2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spincoursj3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincoursj3.bind(on_release=self.chargeClass)
        spincoursj3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassEleve)


        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincoursj3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincoursj4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincoursj4.bind(on_release=self.chargeEdition)
        spincoursj4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS ",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="X2",color="black",bold=True)
        

        chkEleve1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    #on_active:app.verifELeve1(self)
    ''')

        ll2=Label(text="X4",color="black",bold=True)

        chkEleve2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    #on_active:app.verifELeve2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(chkEleve1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(chkEleve2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="ORM",color="black",bold=True)

        chkEleve3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    #on_active:app.verifELeve3(self)
    ''')

        ll4=Label(text="KVC",color="black",bold=True)

        chkEleve4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    #on_active:app.verifELeve4(self)
    ''')

        try:
            cadres2.add_widget(ll3)
            cadres2.add_widget(chkEleve3)
            cadres2.add_widget(ll4)
            cadres2.add_widget(chkEleve4)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincoursj4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabeleve2=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("SEXE",dp(40))),
            (("MATRICULE",dp(40))),
            (("DESCRIPTION",dp(80))),
            (("CLASSE",dp(25))),
            (("OPTION",dp(25))),
            (("SECTION",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':.01,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass

        try:
            cadreELeve2.add_widget(tabeleve2)
            cadreELeve2.add_widget(cadrejj)
        except:
            pass

        

        # les outils de,la page de getion de cours 


        cadreCours=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadreCourshaut=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "GESTION DES COURS"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt2=Builder.load_string('''
Button:
    text:"Operations"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.opencourshistoriqueF)
        
        ibt3=Builder.load_string('''
Button:
    text:"Historique"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.opencoursperation)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        #ibt4.bind(on_release=self.openanalyse)

        try:
            cadreCourshaut.add_widget(ititre)
            cadreCourshaut.add_widget(ibt2)
            cadreCourshaut.add_widget(ibt3)
            cadreCourshaut.add_widget(ibt4)
        except:
            pass


        cadreCours1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkcours1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcoursF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkcours2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifcoursF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkcours1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkcours2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Ajouter Section",color='black',bold=True)

        spincours1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours1.bind(on_release=self.chargeSection)
        spincours1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionCournow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincours1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spincours2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours2.bind(on_release=self.chargeOptionProx)
        spincours2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionCoursnow)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincours2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="AJouter Classe",color='black',bold=True)

        spincours3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincours3.bind(on_release=self.chargeClass)
        spincours3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassCoursnow)
        
        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincours3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincours4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincours4.bind(on_release=self.chargeEdition)
        spincours4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="OPERATIONS",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        btop1=Builder.load_string('''
Spinner:
    text:"Nouveau"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.21}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop1.bind(on_release=self.openOperationCOurs)
        
        btop2=Builder.load_string('''
Button:
    text:"Mise à jours"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.12}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop2.bind(on_release=self.openOperationCOurs)
        
        btop3=Builder.load_string('''
Button:
    text:"Supprimer"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.03}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop3.bind(on_release=self.openOperationCOurs)
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincours4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabcours0=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("PONDER..",dp(35)),
            ("CLASSE",dp(35)),
            ("OPTION",dp(35)),
            ("SECTION",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            
            cadrejj.add_widget(btop1) 
            cadrejj.add_widget(btop2) 
            cadrejj.add_widget(btop3)
        except:
            pass

        try:
            
            cadreCours1.add_widget(cadrejj)
            cadreCours1.add_widget(tabcours0)
        except:
            pass
        
        try:
            cadreCours.add_widget(cadreCourshaut)

            cadreCours.add_widget(cadreCours1)
        except:
            pass

        # les outils de la page des cours journal 

        cadreCours2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkcours3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcoursF3(self) 
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkcours4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifcoursF4(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkcours3)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkcours4)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spincoursj1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        
        spincoursj1.bind(on_release=self.chargeSection)
        spincoursj1.bind(text=self.selectSection)
        
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionCour)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincoursj1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spincoursj2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincoursj2.bind(on_release=self.chargeOptionProx)
        spincoursj2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionCours)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincoursj2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spincoursj3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincoursj3.bind(on_release=self.chargeClass)
        spincoursj3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassCours)


        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincoursj3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincoursj4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincoursj4.bind(on_release=self.chargeEdition)
        spincoursj4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS ",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="X2",color="black",bold=True)

        aliackpaie1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="X4",color="black",bold=True)

        aliackpaie2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliackpaie1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliackpaie2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="ORM",color="black",bold=True)

        aliackpaie3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="KVC",color="black",bold=True)

        aliackpaie4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2.add_widget(ll3)
            cadres2.add_widget(aliackpaie3)
            cadres2.add_widget(ll4)
            cadres2.add_widget(aliackpaie4)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincoursj4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabcoursjourn=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("PONDER..",dp(35)),
            ("CLASSE",dp(35)),
            ("OPTION",dp(35)),
            ("SECTION",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':.01,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass

        try:
            cadreCours2.add_widget(tabcoursjourn)
            cadreCours2.add_widget(cadrejj)
        except:
            pass
        

        # les outils de la page de paiement 
        

        cadrePaiement=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')

        cadrehautpaiement=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "Page Paiement"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt1=Builder.load_string('''
Button:
    text:"Ajout"
    bold:True
    pos_hint:{'x':0.28,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        
        ibt1.bind(on_release=self.openinsertion)
        
        ibt2=Builder.load_string('''
Button:
    text:"Versement"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.openpaiement)
        
        ibt3=Builder.load_string('''
Button:
    text:"Journal"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openjournalpaiement)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        ibt4.bind(on_release=self.openanalyse)

        # cadre paiement 1

        cadrePaiement1=Builder.load_string('''
FloatLayout:

    size_hint:1,.9
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        
        

        paiet1=Builder.load_string('''

MDTextField:
    hint_text:'Identifiant'
    pos_hint:{'x':.025,'y': .85}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
                               ''')

        paiet2=Builder.load_string('''
MDTextField:
    hint_text:'Nom'
    pos_hint:{'x':.3,'y': .85}
    size_hint:.3,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        paiet3=Builder.load_string('''
MDTextField:
    hint_text:'POstnom'
    #pos_hint:{'x':.65,'y': .85}
    pos_hint:{'x':.025,'y': .75}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        paiet4=Builder.load_string('''

MDTextField:
    hint_text:'Prenom'
    #pos_hint:{'x':.025,'y': .75}
    pos_hint:{'x':.3,'y': .75}
    size_hint:.3,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')
        
        l01=Builder.load_string('''

Label:
    text:'Sexe'
    pos_hint:{'x':.025,'y': .65}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec01=Builder.load_string('''
Spinner: 
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.1,'y': .67}
    size_hint:.12,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        
        l1=Builder.load_string('''

Label:
    text:'Section'
    pos_hint:{'x':.3,'y': .65}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec1=Builder.load_string('''
Spinner: 
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .67}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        l2=Builder.load_string('''
Label:
    text:'Option'
    pos_hint:{'x':.3,'y': .55}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .57}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

      
        l3=Builder.load_string('''
Label:
    text:'Classe'
    pos_hint:{'x':.3,'y': .45}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
        ''')

        paiec3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .47}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        paiec3.bind(text=self.selectClass)
      
        l4=Builder.load_string('''
Label:
    text:'Edition'
    pos_hint:{'x':.3,'y': .35}
    size_hint:.05,.1
    font_size:'18sp'
    color:"black"
''')
        paiec4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.45,'y': .37}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
        ''')

        tx=Label(text="DETAIL DU VERSEMENT",color='black',bold=True,font_size="20sp",size_hint=(.1,.1),pos_hint={'center_x':.3,'y':.25})

        tx3=Builder.load_string('''
MDTextField:
    hint_text:'TravID'
    pos_hint:{'x':.4,'y': .15}
    size_hint:.2,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        tx2=Builder.load_string('''
MDTextField:
    hint_text:'Montant'
    #pos_hint:{'x':.65,'y': .85}
    pos_hint:{'x':.2,'y': .15}
    size_hint:.18,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')
        tx1=Builder.load_string('''

MDTextField:
    hint_text:'Date Operation'
    #pos_hint:{'x':.025,'y': .75}
    pos_hint:{'x':.025,'y':.15}
    size_hint:.15,.12
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')
        
    
        btpaie=Builder.load_string('''
Button:
    text:"Payer"
    color:'white'
    font_size:'12sp'
    size_hint:(0.1,0.05)
    pos_hint:{'x':0.5,'y':0.03}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
                                   
    
    ''') 

        btpaie.bind(on_release=self.payerVersement)   

    #on_release:app.updateinfoperson(self) 
    #l1,l7,t1-t16,c1-c5,

    #,datenaiss,decription

        try:
            cadrePaiement1.add_widget(l1)
            cadrePaiement1.add_widget(l2)
            cadrePaiement1.add_widget(l3)
            cadrePaiement1.add_widget(l4)

            cadrePaiement1.add_widget(l01)
           
        except:
            pass
        
        try:
            
            cadrePaiement1.add_widget(paiec01)

            cadrePaiement1.add_widget(paiec1)
            cadrePaiement1.add_widget(paiec2)
            cadrePaiement1.add_widget(paiec3)
            cadrePaiement1.add_widget(paiec4)
            
        except:
            pass
        try:
            cadrePaiement1.add_widget(paiet1)
            cadrePaiement1.add_widget(paiet2)
            cadrePaiement1.add_widget(paiet3)
            cadrePaiement1.add_widget(paiet4)
            
        except:
            pass


        try:
            cadrePaiement1.add_widget(btpaie)
        except:
            pass
            
        try:
            cadrehautpaiement.add_widget(ititre)
            #cadrehautpaiement.add_widget(ibt1)
            cadrehautpaiement.add_widget(ibt2)
            cadrehautpaiement.add_widget(ibt3)
            cadrehautpaiement.add_widget(ibt4)
        except:
            pass

        try:
            cadrePaiement1.add_widget(tx)
            cadrePaiement1.add_widget(tx1)
            cadrePaiement1.add_widget(tx2)
            cadrePaiement1.add_widget(tx3)
        except:
            pass

        try:
            cadrePaiement.add_widget(cadrehautpaiement)
            cadrePaiement.add_widget(cadrePaiement1)
        except:
            pass


        cadreGpaie1=Builder.load_string('''
FloatLayout:
    size_hint:.35,.99
    pos_hint:{'x':.65,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.5,.09
    pos_hint:{'x':.1,'y':.83}
    padding:5
    spacing:5

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')

        trechPaiement=Builder.load_string('''

MDTextField:
    hint_text:'Matricule'
    #pos_hint:{'x':.025,'y': .75}
    pos_hint:{'center_y':.5}
    #size_hint:.3,.9
    text_color:255/255,128/255,0/255
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
        ''')

        rechP1=Builder.load_string('''
MDIcon:
    icon:'card-search'
    theme_text_color:'Custom'
    text_color:'red'
    pos_hint:{'center_y':.5}
                                                                         
''')
        
        spinPaiement=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.29,.05
    pos_hint:{'x':.62,'y':.85}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spinPaiement.bind(on_release=self.chargenompaiementF)
        spinPaiement.bind(text=self.affichInfopaiementF)

        try:
            cadreGpaie1.add_widget(spinPaiement)
        except:
            pass

        try:
            
            cadresous1A.add_widget(trechPaiement)
            cadresous1A.add_widget(rechP1)
        except:
            pass


        cadresous2A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.65}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Type Paiement",color='black',bold=True)

        spin1A=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin1A.bind(on_release=self.chargeTypePaie)
        spin1A.bind(text=self.selectTypePaie)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2A.add_widget(l1)
            cadresous2A.add_widget(spin1A)
            cadresous2A.add_widget(btval1)
        except:
            pass
        
        cadresous3A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Type Tranche",color='black',bold=True) 

        spin2A=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spin2A.bind(on_release=self.chargeTranche)
        spin2A.bind(text=self.selectTranche)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3A.add_widget(l2)
            cadresous3A.add_widget(spin2A)
            cadresous3A.add_widget(btval2)
        except:
            pass

        cadresous4A=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.25}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Edition",color='black',bold=True)

        spin3A=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'12sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size 
            radius:[15]
''')
        
        spin3A.bind(on_release=self.chargeEdition)
        spin3A.bind(text=self.selectEdition)


        btval3=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4A.add_widget(l3)
            cadresous4A.add_widget(spin3A)
            cadresous4A.add_widget(btval3)
        except:
            pass


        alias=Label(text="SETTING",color='black',bold=True,pos_hint={'center_x':.5,'y':.15},size_hint=(.1,.1))

        az=Label(text="A-Z",color='black',bold=True,pos_hint={'x':.1,'y':.07},size_hint=(.1,.1),font_size='13sp')
        za=Label(text="Z-A",color='black',bold=True,pos_hint={'x':.75,'y':.07},size_hint=(.1,.1),font_size='13sp')

        triAZ1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    pos_hint:{'x':.25,'y':.09}
    size_hint:.05,.05
    on_active:app.triAZF1(self)
    ''')
        
        triic1=Builder.load_string('''
MDIcon:
    icon:'filter'
    size_hint:.05,.05
    pos_hint:{'x':.12,'y':.05}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        
        
        triAZ2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    pos_hint:{'x':.9,'y':.09}
    size_hint:.05,.05
    on_active:app.triAZF2(self)
    ''')
        
        triic2=Builder.load_string('''
MDIcon:
    icon:'filter'
    size_hint:.05,.05
    pos_hint:{'x':.77,'y':.05}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        
        try:
            cadresous5A.add_widget(l4)
            cadresous5A.add_widget(spin4A)
            cadresous5A.add_widget(btval4)
        except:
            pass

        try:

            cadreGpaie1.add_widget(cadresous1A)
            cadreGpaie1.add_widget(cadresous2A) 

            cadreGpaie1.add_widget(cadresous3A)
            cadreGpaie1.add_widget(cadresous4A)

            cadreGpaie1.add_widget(alias)
            
            cadreGpaie1.add_widget(az)
            cadreGpaie1.add_widget(za)

            cadreGpaie1.add_widget(triAZ1)
            cadreGpaie1.add_widget(triAZ2)  

            cadreGpaie1.add_widget(triic1)
            cadreGpaie1.add_widget(triic2) 

        except:
            pass

        
        try:
            cadrePaiement1.add_widget(cadreGpaie1)
        except:
            pass

        # les optuosld de paiement journal 

        cadrePaiement2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkpaie1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifpaieF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkpaie2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifpaieF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkpaie1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkpaie2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spinpaie1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spinpaie1.bind(on_release=self.chargeSection)
        spinpaie1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionPaiement)
        

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spinpaie1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spinpaie2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spinpaie2.bind(on_release=self.chargeOptionProx)
        spinpaie2.bind(text=self.selectOptionProx)
        
        #selectOptionProx),selectClass

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionPaiement)
        

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spinpaie2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spinpaie3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spinpaie3.bind(on_release=self.chargeClass)
        spinpaie3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassPaiement)

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spinpaie3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par Motif",color='black',bold=True)

        spinpaie4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spinpaie4.bind(on_release=self.chargeMotif)
        spinpaie4.bind(text=self.selectMotif)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval4.bind(on_release=self.affmotifPaiement)

        alias=Label(text="ALIAS RELATIONNEL",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Allow",color="black",bold=True)

        aliackpaie1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Denied",color="black",bold=True)

        aliackpaie2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliackpaie1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliackpaie2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.02}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')


        l4x=Label(text="Trier par Edition",color='black',bold=True)

        spincoursj4x=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincoursj4x.bind(on_release=self.chargeEdition)
        spincoursj4x.bind(text=self.selectEdition)

        btval4x=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadres2.add_widget(l4x)
            cadres2.add_widget(spincoursj4x)
            cadres2.add_widget(btval4x)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spinpaie4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabpaiejourn=MDDataTable(column_data=[
            ("ID",dp(30)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("CLASSE",dp(25))),
            (("OPTION ",dp(25))),
            (("SECTION",dp(25))),
            (("EDITION",dp(25))),
            (("MONTANT",dp(25))),
            (("DEVISE",dp(25))),
            (("MOTIF",dp(25))),
            (("TRANCHE",dp(25))),
            (("DATE",dp(50)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass

        try:
            
            cadrePaiement2.add_widget(cadrejj)

            cadrePaiement2.add_widget(tabpaiejourn)
        except:
            pass

        # les outils de la page de gestion de cote 
        

        cadreCote=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        
        cadrehautCote=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        coteititre=Builder.load_string('''

Label:
    text: "GESTION DE COTE"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        
        coteibt3=Builder.load_string('''
Button:
    text:"Fiche Cotation"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        coteibt3.bind(on_release=self.openseliberationF) 
        
        coteibt4=Builder.load_string('''
Button:
    text:"Analyse"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        coteibt4.bind(on_release=self.openanalysedeliberationF)

        try:
            cadrehautCote.add_widget(coteititre)
            cadrehautCote.add_widget(coteibt3)
            cadrehautCote.add_widget(coteibt4)
        except:
            pass


        cadreCote1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkcote1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcoteF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkcote2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifcoteF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkcote1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkcote2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spincote1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincote1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spincote2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincote2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spincote3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincote3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par Titul..",color='black',bold=True)

        spincote4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ORDRE",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="Croissant A-Z",color="black",bold=True)

        aliackcote1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="Decroissant Z-A",color="black",bold=True)

        aliackcote2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliackcote1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliackcote2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.02}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        l5=Label(text="Trier par Edition",color='black',bold=True)

        spincotee5=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btvall5=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadres2.add_widget(l5)
            cadres2.add_widget(spincotee5)
            cadres2.add_widget(btvall5)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincote4)
            cadresous5.add_widget(btval4)
        except:
            pass
        
        #idCours

        tabcote1=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("COTE",dp(35))),
            (("PERIODE",dp(35))),
            (("COURS",dp(40))),
            (("CLASSE",dp(25))),
            (("OPTION ",dp(25))),
            (("SECTION",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        bexportExcel=Builder.load_string('''
MDIconButton:
    icon:'file-excel'
    pos_hint:{'x':.8,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        bexportPdf=Builder.load_string('''
MDIconButton:
    icon:'file-pdf-box'
    pos_hint:{'x':.9,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass


        try:
            cadreCote1.add_widget(cadrejj)

            cadreCote1.add_widget(bexportExcel)
            cadreCote1.add_widget(bexportPdf)
            cadreCote1.add_widget(tabcote1)

        except:
            pass
        
        try:
            cadreCote.add_widget(cadrehautCote) 
            cadreCote.add_widget(cadreCote1)
        except:
            pass
        
        # les outils de la pade de deliberation 

        cadreCote2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkdelib1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifdelib1F(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkdelib2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifdelib2F(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkdelib1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkdelib2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')


        l1=Label(text="Ajouter Section",color='black',bold=True)

        spindelib1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spindelib1.bind(on_release=self.chargeSection)
        spindelib1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionDelib)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spindelib1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spindelib2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spindelib2.bind(on_release=self.chargeOptionProx)
        spindelib2.bind(text=self.selectOptionProx)
        
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval2.bind(on_release=self.affOptionDelib)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spindelib2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Ajouter Classe",color='black',bold=True)

        spindelib3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spindelib3.bind(on_release=self.chargeClass)
        spindelib3.bind(text=self.selectClass)
        
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affClassDelib)

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spindelib3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Ajouter Periode",color='black',bold=True)

        spindelib4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spindelib4.bind(on_release=self.chargePeriode)
        spindelib4.bind(text=self.selectPeriode)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval4.bind(on_release=self.affPeriodeDelib)
        
        alias=Label(text="CRIA CONGO",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        
        l7=Label(text="Ajouter Cours",color='black',bold=True)

        spindelib7=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spindelib7.bind(on_release=self.chargeCours)
        spindelib7.bind(text=self.selectCours)
        
        btval7=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval7.bind(on_release=self.affCoursDelib)
        # idCours

        try:
            cadres1.add_widget(l7)
            cadres1.add_widget(spindelib7)
            cadres1.add_widget(btval7)
        except:
            pass
        
        
        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.02}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')
        
        l5=Label(text="Ajouter Edition",color='black',bold=True)

        spindelib5=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spindelib5.bind(on_release=self.chargeEdition)
        spindelib5.bind(text=self.selectEdition)

        btvall5=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadres2.add_widget(l5)
            cadres2.add_widget(spindelib5)
            cadres2.add_widget(btvall5)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spindelib4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabdelib1=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("COTE",dp(35))),
            (("PERIODE",dp(35))),
            (("COURS",dp(40))),
            (("CLASSE",dp(25))),
            (("OPTION ",dp(25))),
            (("SECTION",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        tabdelib1.bind(on_check_press=self.affInfoCote)

        bexportExcel=Builder.load_string('''
MDIconButton:
    icon:'file-excel'
    pos_hint:{'x':.8,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')
        bexportPdf=Builder.load_string('''
MDIconButton:
    icon:'file-pdf-box'
    pos_hint:{'x':.9,'y':.01}
    theme_text_color:'Custom'
    text_color:'red'
        
        ''')

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            #cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass


        try:
            cadreCote2.add_widget(cadrejj) 

            cadreCote2.add_widget(bexportExcel)
            cadreCote2.add_widget(bexportPdf)
            cadreCote2.add_widget(tabdelib1)

        except:
            pass


        # mles outils de la page de travaux

        cadreTravaux=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')

        cadreTravauxhaut=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    spacing:10
    padding:10

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        
        cadreTravaux1=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
                    

        
        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.98
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        btchangeTravaux=Builder.load_string('''
MDIconButton:
    icon:'spinner'
    size_hint:.025,.025
    pos_hint:{'x':0.05,'y':0.86} 
    theme_text_color:'Custom'
    text_color:'seagreen'                                             
        
    ''')
        
        btchangeTravaux.bind(on_release=self.changerTrav1)


        ititreTravaux=Builder.load_string('''

Label:
    text: "GESTION DES TRAVAUX"
    bold:True
    color:'black'
    font_size:'14sp'
    pos_hint:{'center_x':0.5,'y':0.9}
    size_hint:0.8,0.06
    bold:True
            ''')

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spintv1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spintv1.bind(on_release=self.chargeSection)
        spintv1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval1.bind(on_release=self.afficheSection)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spintv1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spintv2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spintv2.bind(on_release=self.chargeOptionProx)
        spintv2.bind(text=self.selectOptionProx)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval2.bind(on_release=self.afficheOption) 

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spintv2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spintv3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintv3.bind(on_release=self.chargeClass)
        spintv3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
                                   
    
    ''')
        btval3.bind(on_release=self.afficheClass)

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spintv3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par EDITION",color='black',bold=True)

        spintv4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintv4.bind(on_release=self.chargeEdition)
        spintv4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spintv4)
            cadresous5.add_widget(btval4)
        except:
            pass

        
        btajouttravaux=Builder.load_string('''
Button:
    text:"Ajouter"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.2}
    background_color:[0,0,0,0]
    bold:True
    on_release:app.ajouttypetravail(self)

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        btapdatetravaux=Builder.load_string('''
Button:
    text:"Mise à jour"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.12}
    background_color:[0,0,0,0]
    bold:True
                                            
    on_release:app.updatetypetravail(self)

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        cadresousfin=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.01}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checktravau1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifTrvaux1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checktravau2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifTrvaux2(self)
    ''')

        try:
            cadresousfin.add_widget(l1)
            cadresousfin.add_widget(checktravau1)
            cadresousfin.add_widget(l2)
            cadresousfin.add_widget(checktravau2)
        except:
            pass
        
        tabtravaux=MDDataTable(column_data=[
            ("NOM",dp(50)),
            (("POSTNOM",dp(50))),
            (("PRENOM",dp(35))),

            (("TYPE TRAVAIL",dp(50))),
            (("TITRE",dp(35))),
            (("COURS",dp(40))),
            (("DATE",dp(40))),

            (("CLASSE",dp(25))),
            (("OPTION",dp(40))),
            (("SECTION",dp(40))),
            (("EDITION",dp(40))),
            
            (("CREE",dp(50))),
            (("MODIFIE ",dp(50)))
            
            ], row_data=[],size_hint=(0.72,0.98),pos_hint={'x':0.272,'y':0},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous2)
            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)
            

            cadrejj.add_widget(cadresousfin) 
            #cadrejj.add_widget(cadres2)
        except:
            pass
        
        try:
            cadrejj.add_widget(btchangeTravaux)

            cadrejj.add_widget(ititreTravaux)
            cadrejj.add_widget(btajouttravaux) 
            cadrejj.add_widget(btapdatetravaux)
        except:
            pass

        try:
            cadreTravaux1.add_widget(cadrejj)
            cadreTravaux1.add_widget(tabtravaux)
            
        except:
            pass

        try:
            cadreTravaux.add_widget(cadreTravauxhaut) 
            cadreTravaux.add_widget(cadreTravaux1)
        except:
            pass

        # les outils de la page de gestion de travaux 2

        cadreTravaux2=Builder.load_string('''
FloatLayout:

    size_hint:1,.92
    pos_hint:{'x':0,'y':0}
    canvas:
        Color:
            rgb:1,1,1
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        
        cadrejj2=Builder.load_string('''
FloatLayout:
    size_hint:.26,.98
    pos_hint:{'x':.73,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        btchangeTravaux=Builder.load_string('''
MDIconButton:
    icon:'spinner'
    size_hint:.025,.025
    pos_hint:{'x':0.95,'y':0.88} 
    theme_text_color:'Custom'
    text_color:'seagreen'                                             
        
    ''')

        btchangeTravaux.bind(on_release=self.changerTrav2)

        ititreTravaux2=Builder.load_string('''

Label:
    text: "GESTION DES TRAVAUX"
    bold:True
    color:'black'
    font_size:'14sp'
    pos_hint:{'center_x':0.5,'y':0.85}
    size_hint:0.8,0.05
    bold:True
            ''')

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.743}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spintv1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spintv1.bind(on_release=self.chargeSection)
        spintv1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval1.bind(on_release=self.afficheSectionTrav2)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spintv1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.605}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spintv2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spintv2.bind(on_release=self.chargeOptionProx)
        spintv2.bind(text=self.selectOptionProx)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval2.bind(on_release=self.afficheoptionTrav2) 

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spintv2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.455}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spintv3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintv3.bind(on_release=self.chargeClass)
        spintv3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
                                   
    
    ''')
        btval3.bind(on_release=self.afficheclassTrav2)

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spintv3)
            cadresous4.add_widget(btval3)
        except:
            pass
        
        cadresousS1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.305}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par Cours",color='black',bold=True)

        spintvS1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintvS1.bind(on_release=self.chargeCours)
        spintvS1.bind(text=self.selectCours)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        btval4.bind(on_release=self.affichecoursTrav2EnS)
        
        try:
            cadresousS1.add_widget(l4)
            cadresousS1.add_widget(spintvS1)
            cadresousS1.add_widget(btval4)
        except:
            pass
        
            
        cadresousS2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.155}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier Enseignant",color='black',bold=True)

        spintvS2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintvS2.bind(on_release=self.chargeEdition)
        spintvS2.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadresousS2.add_widget(l4)
            cadresousS2.add_widget(spintvS2)
            cadresousS2.add_widget(btval4)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.1
    pos_hint:{'center_x':.5,'y':.01}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spintv4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spintv4.bind(on_release=self.chargeEdition)
        spintv4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spintv4)
            cadresous5.add_widget(btval4)
        except:
            pass

        
        
        
        cadresousfin=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.92}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checktravauEns1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifTravEnsF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checktravauEns2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifTravEnsF1(self)
    ''')

        try:
            cadresousfin.add_widget(l1)
            cadresousfin.add_widget(checktravauEns1)
            cadresousfin.add_widget(l2)
            cadresousfin.add_widget(checktravauEns2)
        except:
            pass
        
        tabtravaux2=MDDataTable(column_data=[
            ("NOM",dp(50)),
            (("POSTNOM",dp(50))),
            (("PRENOM",dp(35))),

            (("TYPE TRAVAIL",dp(50))),
            (("TITRE",dp(35))),
            (("COURS",dp(40))),
            (("DATE",dp(40))),

            (("CLASSE",dp(25))),
            (("OPTION",dp(40))),
            (("SECTION",dp(40))),
            (("EDITION",dp(40))),
            
            (("CREE",dp(50))),
            (("MODIFIE ",dp(50)))
            
            ], row_data=[],size_hint=(0.72,0.98),pos_hint={'x':0,'y':.01},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj2.add_widget(cadresous2)
            cadrejj2.add_widget(cadresous3)
            cadrejj2.add_widget(cadresous4)
            
            cadrejj2.add_widget(cadresousS1)
            #cadrejj2.add_widget(cadresousS2)

            cadrejj2.add_widget(cadresous5)
            

            cadrejj2.add_widget(cadresousfin) 
            #cadrejj.add_widget(cadres2)
        except: 
            pass
        
        try:
            cadrejj2.add_widget(btchangeTravaux)
            cadrejj2.add_widget(ititreTravaux2)
            #cadrejj2.add_widget(btajouttravaux) 
            #cadrejj2.add_widget(btapdatetravaux)
        except:
            pass

        try:
            cadreTravaux2.add_widget(cadrejj2)
            cadreTravaux2.add_widget(tabtravaux2)

            
        except:
            pass

        # les outils de la page de gestion de communication

        cadreCommunication=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadreCommunicationhaut=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "GESTION COMMUNICATIONNELLE"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt2=Builder.load_string('''
Button:
    text:"Operations"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.openCommuniqueF)
        
        ibt3=Builder.load_string('''
Button:
    text:"Historique"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openjournalComminiquerF)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        #ibt4.bind(on_release=self.openanalyse)

        try:
            cadreCommunicationhaut.add_widget(ititre)
            cadreCommunicationhaut.add_widget(ibt2)
            cadreCommunicationhaut.add_widget(ibt3)
            cadreCommunicationhaut.add_widget(ibt4)
        except:
            pass


        cadreCommunication1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkcomm3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcommF3(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkcomm4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcommF4(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkcomm3)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkcomm4)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spinpaie1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        btval1.bind(on_release=self.affichecommunicationNow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spinpaie1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spinpaie2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spinpaie2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spinpaie3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spinpaie3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par TravID",color='black',bold=True)

        spinpaie4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="OPERATIONS",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        btop1=Builder.load_string('''
Spinner:
    text:"Nouveau Communiqué"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.21}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop1.bind(on_release=self.operationCommunique)
        
        btop2=Builder.load_string('''
Button:
    text:"Modifier Communiqué"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.12}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop2.bind(on_release=self.operationCommunique)
        
        btop3=Builder.load_string('''
Button:
    text:"Desactiver Communiqué"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.03}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btop3.bind(on_release=self.operationCommunique)
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spinpaie4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabCommjourn0=MDDataTable(column_data=[
            ("NOM",dp(35)),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("TITRE",dp(40))),
            (("CONTENU",dp(80))),
            (("FILE",dp(35))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            
            cadrejj.add_widget(btop1) 
            cadrejj.add_widget(btop2) 
            cadrejj.add_widget(btop3)
        except:
            pass

        try:
            
            cadreCommunication1.add_widget(cadrejj)
            cadreCommunication1.add_widget(tabCommjourn0)
        except:
            pass
        
        try:
            cadreCommunication.add_widget(cadreCommunicationhaut)

            cadreCommunication.add_widget(cadreCommunication1)
        except:
            pass

        # les outils de la page communicationnelle journal 

        cadreCommunication2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        checkcomm1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifcommF1(self) 
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkcomm2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifcommF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkcomm1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkcomm2)
        except:
            pass

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Trier par Section",color='black',bold=True)

        spinpaie1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        btval1.bind(on_release=self.affichecommunication)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spinpaie1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Trier par Option",color='black',bold=True)

        spinpaie2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spinpaie2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Trier par Classe",color='black',bold=True)

        spinpaie3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spinpaie3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Trier par TravID",color='black',bold=True)

        spinpaie4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.35,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS ",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        cadres1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.15}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll1=Label(text="X2",color="black",bold=True)

        aliackpaie1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll2=Label(text="X4",color="black",bold=True)

        aliackpaie2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres1.add_widget(ll1)
            cadres1.add_widget(aliackpaie1)
            cadres1.add_widget(ll2)
            cadres1.add_widget(aliackpaie2)
        except:
            pass        

        cadres2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.06
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        ll3=Label(text="ORM",color="black",bold=True)

        aliackpaie3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verif1(self)
    ''')

        ll4=Label(text="KVC",color="black",bold=True)

        aliackpaie4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verif2(self)
    ''')

        try:
            cadres2.add_widget(ll3)
            cadres2.add_widget(aliackpaie3)
            cadres2.add_widget(ll4)
            cadres2.add_widget(aliackpaie4)
        except:
            pass

        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spinpaie4)
            cadresous5.add_widget(btval4)
        except:
            pass

        tabCommjourn=MDDataTable(column_data=[
            ("NOM",dp(35)),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("TITRE",dp(40))),
            (("CONTENU",dp(80))),
            (("FILE",dp(35))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':.01,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        tabCommjourn.bind(on_check_press=self.affinfocommunique)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(alias)
            cadrejj.add_widget(cadres1) 
            cadrejj.add_widget(cadres2)
        except:
            pass

        try:
            cadreCommunication2.add_widget(tabCommjourn)
            cadreCommunication2.add_widget(cadrejj)
        except:
            pass

        # les outils de la pagr de gestion des enseignants

        cadreEnseignant=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadreEnsignanthaut=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'
    padding:10
    spacing:10
                                               
    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')

        ititre=Builder.load_string('''

Label:
    text: "GESTION DES ENSEIGNANTS"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        ibt2=Builder.load_string('''
Button:
    text:"Personnel Enseignant"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.opengestionEnseignant)
        
        ibt3=Builder.load_string('''
Button:
    text:"Attributions"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openAttibutions)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        #ibt4.bind(on_release=self.openanalyse)

        try:
            pass
            #cadreEnsignanthaut.add_widget(ititre)
            #cadreEnsignanthaut.add_widget(ibt2)
            #cadreEnsignanthaut.add_widget(ibt3)
            #cadreEnsignanthaut.add_widget(ibt4)
        except:
            pass


        cadreEnseignant1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        
        checkEnseignant1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifEnseignantF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkEnseignant2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifEnseignantF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkEnseignant1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkEnseignant2)
        except:
            pass
        
        btchargeattribution=Builder.load_string('''
MDIconButton:
    icon:'spinner'
    size_hint:.05,.03
    pos_hint:{'x':.02,'y':.84}
                                                
        ''')

        btchargeattribution.bind(on_release=self.openAttibutions)

        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.09
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        l1=Builder.load_string('''
MDTextField:
    hint_text:'Recherche'
    text_color:255/255,128/255,0/255
    #font_size:'12sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        spin1choixE=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.05
    pos_hint:{'x':.4,'y':.68}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(btval1)
            
        except:
            pass
        
        labtitrePersonnel=Builder.load_string('''

Label:
    text: "GESTION..."
    bold:True
    color:'black'
    pos_hint:{'center_x':.5,'y':.86}
    size_hint:0.8,0.04
    bold:True
            ''')
        
        bt1E=Builder.load_string('''
Button:
    text:"Nouveau"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.8}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        bt1E.bind(on_release=self.openUser)
        

        bt2E=Builder.load_string('''
Button:
    text:"Mise à jour"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.72}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        bt2E.bind(on_release=self.openUser)
        
        bt3E=Builder.load_string('''
Button:
    text:"Supprimer"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.64}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        bt3E.bind(on_release=self.openUser)

        alias=Label(text="ALIAS RELATIONNEL",color='black',bold=True,pos_hint={'center_x':.5,'y':.25},size_hint=(.1,.1))


        cadresousS2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.52}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Choisir Section",color='black',bold=True)

        spin1Ens1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin1Ens1.bind(on_release=self.chargeSection)
        spin1Ens1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.sectionPersonneRech)

        try:
            cadresousS2.add_widget(l1)
            cadresousS2.add_widget(spin1Ens1)
            cadresousS2.add_widget(btval1)
        except:
            pass
        
        cadresousS3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.4}

    canvas.before:
        Color:
            rgb:1,1,1
        Rectangle:
            size:self.size
            pos:self.pos
            
        
        ''')

        l2=Label(text="Choisir Option",color='black',bold=True)

        spin2Ens2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin2Ens2.bind(on_release=self.chargeOptionProx)
        spin2Ens2.bind(text=self.selectOptionProx)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresousS3.add_widget(l2)
            cadresousS3.add_widget(spin2Ens2)
            cadresousS3.add_widget(btval2)
        except:
            pass

        cadresousS4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.27}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l3=Label(text="Choisir Classe",color='black',bold=True)

        spin3Ens3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin3Ens3.bind(on_release=self.chargeClass)
        spin3Ens3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresousS4.add_widget(l3)
            cadresousS4.add_widget(spin3Ens3)
            cadresousS4.add_widget(btval3)
        except:
            pass

        cadresousS5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.14}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l3=Label(text="Choisir Cours",color='black',bold=True)

        spin3Ens3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin3Ens3.bind(on_release=self.chargeCours)
        spin3Ens3.bind(text=self.selectCours)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresousS5.add_widget(l3)
            cadresousS5.add_widget(spin3Ens3)
            cadresousS5.add_widget(btval3)
        except:
            pass


        cadresousS6=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.02}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l3=Label(text="Choisir Edition",color='black',bold=True)

        spin3Ens3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spin3Ens3.bind(on_release=self.chargeEdition)
        spin3Ens3.bind(text=self.selectEdition)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresousS6.add_widget(l3)
            cadresousS6.add_widget(spin3Ens3)
            cadresousS6.add_widget(btval3)
        except:
            pass
        
        
        tabjourPersonnelnew1=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NOM",dp(35)),
            ("POSTNOM ",dp(35)),
            ("PRENOM",dp(35)),
            ("SEXE",dp(35)),
            ("FONCTION",dp(35)),
            ("E-MAIL",dp(35)),
            ("PWD",dp(35)),
            ("ADRESSE",dp(40)),
            ("PHONE",dp(35)),
            ("PHOTO",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)

            cadrejj.add_widget(labtitrePersonnel) 

            cadrejj.add_widget(bt1E)
            cadrejj.add_widget(bt2E)
            cadrejj.add_widget(bt3E)

            cadrejj.add_widget(alias)

            cadrejj.add_widget(cadresousS2) 
            cadrejj.add_widget(cadresousS3)
            cadrejj.add_widget(cadresousS4)

            cadrejj.add_widget(cadresousS5)
            cadrejj.add_widget(cadresousS6)


            #cadrejj.add_widget(spin1choixE)

            cadrejj.add_widget(btchargeattribution)

        except:
            pass


        try:
            
            cadreEnseignant1.add_widget(cadrejj)
            
            cadreEnseignant1.add_widget(tabjourPersonnelnew1)
        except:
            pass

        try:
            cadreEnseignant.add_widget(cadreEnsignanthaut)
            cadreEnseignant.add_widget(cadreEnseignant1) 
        except:
            pass
        

        # Gestion des enseignant attributation

        cadreEnseignant2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        
        checkEnseignant3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifEnseignantF3(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkEnseignant4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifEnseignantF4(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkEnseignant3)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkEnseignant4)
        except:
            pass
        
        btchargeattribution=Builder.load_string('''
MDIconButton:
    icon:'spinner'
    size_hint:.04,.03
    pos_hint:{'x':.95,'y':.84}
                                                
        ''')

        btchargeattribution.bind(on_release=self.opengestionEnseignant)
        
        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Choisir Section",color='black',bold=True)

        spin1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin1.bind(on_release=self.chargeSection)
        spin1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionattribution)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spin1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Choisir Option",color='black',bold=True)

        spin2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin2.bind(on_release=self.chargeOptionProx)
        spin2.bind(text=self.selectOptionProx)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spin2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="Choisir Classe",color='black',bold=True)

        spin3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin3.bind(on_release=self.chargeClass)
        spin3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spin3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l4=Label(text="Choisir Enseignant",color='black',bold=True)

        spin4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin4.bind(on_release=self.chargeClass)
        spin4.bind(text=self.selectClass)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        

        alias=Label(text="ALIAS OPERATIONS",color='black',bold=True,pos_hint={'center_x':.5,'y':.22},size_hint=(.1,.1))


        bt1EAttrib=Builder.load_string('''
Button:
    text:"Attribuer"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.19}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        bt2EAttrib=Builder.load_string('''
Button:
    text:"Desattribuer"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.04
    pos_hint:{'center_x':.5,'y':.12}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spin4)
            cadresous5.add_widget(btval4)
        except:
            pass

        cadresousEdition=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.01}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Choisir Edition",color='black',bold=True)

        spin2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spin2.bind(on_release=self.chargeEdition)
        spin2.bind(text=self.selectEdition)

        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresousEdition.add_widget(l2)
            cadresousEdition.add_widget(spin2)
            cadresousEdition.add_widget(btval2)
        except:
            pass

        tabjournEns2=MDDataTable(column_data=[
            ("ID",dp(30)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("Sexe",dp(30))),
            (("SECTION",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("COURS",dp(25))),
            (("PONDERATION",dp(25))),

            (("EDITION",dp(25))),

            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)
            
            cadrejj.add_widget(cadresousEdition)

            cadrejj.add_widget(alias)

            cadrejj.add_widget(bt1EAttrib) 
            cadrejj.add_widget(bt2EAttrib)

            cadrejj.add_widget(btchargeattribution)

        except:
            pass
        
        

        try:
            
            cadreEnseignant2.add_widget(cadrejj)
            
            cadreEnseignant2.add_widget(tabjournEns2)
        except:
            pass

        # les outils de la page de gestion de personnelle

        #checkPers1,verifPersF1


        cadrePersonnel=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrePersonnelhaut=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "GESTION DE PRESENCES"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        
        ibt2=Builder.load_string('''
Button:
    text:"Activités Now"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt2.bind(on_release=self.opengestionPersonnel2F)
        
        ibt3=Builder.load_string('''
Button:
    text:"Historique"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.opengestionPersonnel1F)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        #ibt4.bind(on_release=self.openanalyse)

        try:
            cadrePersonnelhaut.add_widget(ititre)
            cadrePersonnelhaut.add_widget(ibt2)
            cadrePersonnelhaut.add_widget(ibt3)
            cadrePersonnelhaut.add_widget(ibt4)
        except:
            pass

        #checkPers1,verifPersF1
        cadrePersonnel1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        
        checkPers1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifPersF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkPers2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifPersF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkPers1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkPers2)
        except:
            pass


        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Ajouter Section",color='black',bold=True)

        spincours1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours1.bind(on_release=self.chargeSection)
        spincours1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionCournow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincours1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spincours2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours2.bind(on_release=self.chargeOptionProx)
        spincours2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionCoursnow)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincours2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="AJouter Classe",color='black',bold=True)

        spincours3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincours3.bind(on_release=self.chargeClass)
        spincours3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassCoursnow)
        
        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincours3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincours4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincours4.bind(on_release=self.chargeEdition)
        spincours4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')


        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincours4)
            cadresous5.add_widget(btval4)
        except:
            pass
        
        
        tabpersonnel=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)
            
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)   

        except:
            pass


        try:
            
            cadrePersonnel1.add_widget(cadrejj)
            
            cadrePersonnel1.add_widget(tabpersonnel)
        except:
            pass

        


        # le outils de la page personnel2

        cadrePersonnel2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        
        checkPers3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifPersF3(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkPers4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifPersF4(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkPers3)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkPers4)
        except:
            pass

        
        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Ajouter Section",color='black',bold=True)

        spincours1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours1.bind(on_release=self.chargeSection)
        spincours1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionCournow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincours1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spincours2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours2.bind(on_release=self.chargeOptionProx)
        spincours2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionCoursnow)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincours2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="AJouter Classe",color='black',bold=True)

        spincours3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincours3.bind(on_release=self.chargeClass)
        spincours3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassCoursnow)
        
        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincours3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincours4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincours4.bind(on_release=self.chargeEdition)
        spincours4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')


        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincours4)
            cadresous5.add_widget(btval4)
        except:
            pass


        
        cadresousS2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.08
    pos_hint:{'center_x':.5,'y':.05}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l1=Label(text="Trier par Categorie",color='black',bold=True)

        spin1Pers2=Builder.load_string('''
Spinner:
    text:"Present"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.6
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')

        try:
            cadresousS2.add_widget(l1)
            cadresousS2.add_widget(spin1Pers2)
            cadresousS2.add_widget(btval1)
        except:
            pass
        
        
        tabpersonnel2=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.71,0.9),pos_hint={'x':.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            
            cadrejj.add_widget(cadresous1)
            
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)    

            cadrejj.add_widget(cadresousS2)    

            cadrejj.add_widget(bt1E)
            cadrejj.add_widget(bt2E)
            cadrejj.add_widget(bt3E)

            cadrejj.add_widget(alias)

           
        except:
            pass

        try:
            
            cadrePersonnel2.add_widget(cadrejj)
            
            cadrePersonnel2.add_widget(tabpersonnel2)
        except:
            pass

        try:
            cadrePersonnel.add_widget(cadrePersonnelhaut)
            cadrePersonnel.add_widget(cadrePersonnel2) 
        except:
            pass
        
        # les outils de la page de gestion des abonnees
        
        cadreAbonne=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadreAbonnehaut=Builder.load_string('''
FloatLayout:

    size_hint:1,.1
    pos_hint:{'x':0,'y':.9}
    canvas:
        Color:
            rgb:202/255,202/255,202/255
        
        Rectangle:
            pos:self.pos
            size:self.size
''')
        ititre=Builder.load_string('''

Label:
    text: "GESTION D' Horaires"
    bold:True
    color:'black'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.85}
    size_hint:0.8,0.5
    bold:True
            ''')
        
        
        ibt2=Builder.load_string('''
Button:
    text:"Operation"
    bold:True
    pos_hint:{'x':0.46,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')

        ibt2.bind(on_release=self.openAbonne1F)
        
        ibt3=Builder.load_string('''
Button:
    text:"Historique"
    bold:True
    pos_hint:{'x':0.64,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]

    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
            #1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
''')
        ibt3.bind(on_release=self.openAbonne2F)
        
        ibt4=Builder.load_string('''
Button:
    text:"Systeme"
    bold:True
    pos_hint:{'x':0.82,'y':0.08}
    size_hint:.15,.35
    background_color:[0,0,0,0]
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10]
 ''')
        #ibt4.bind(on_release=self.openanalyse)

        try:
            cadreAbonnehaut.add_widget(ititre)
            cadreAbonnehaut.add_widget(ibt2)
            cadreAbonnehaut.add_widget(ibt3)
            cadreAbonnehaut.add_widget(ibt4)
        except:
            pass

        cadreAbonne1=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        
        checkAbonne1=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifAbonneF1(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkAbonne2=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifAbonneF2(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkAbonne1)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkAbonne2)
        except:
            pass

        
        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Ajouter Section",color='black',bold=True)

        spincours1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours1.bind(on_release=self.chargeSection)
        spincours1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionCournow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincours1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spincours2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours2.bind(on_release=self.chargeOptionProx)
        spincours2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionCoursnow)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincours2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="AJouter Classe",color='black',bold=True)

        spincours3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincours3.bind(on_release=self.chargeClass)
        spincours3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassCoursnow)
        
        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincours3)
            cadresous4.add_widget(btval3)
        except:
            pass

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincours4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincours4.bind(on_release=self.chargeEdition)
        spincours4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')


        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincours4)
            cadresous5.add_widget(btval4)
        except:
            pass
        

        titrealias=Label(text="OPERATIONS",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        btAbonne1=Builder.load_string('''
Button:
    text:"Nouveau"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.15}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        btAbonne2=Builder.load_string('''
Button:
    text:"Mise à jour"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.05}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        tabAbonne=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.71,0.9),pos_hint={'x':.28,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
                       
            cadrejj.add_widget(cadresous1)
            
            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(titrealias)

            cadrejj.add_widget(btAbonne1) 
            cadrejj.add_widget(btAbonne2)            
            
        except:
            pass


        try:
            
            cadreAbonne1.add_widget(cadrejj)
            
            cadreAbonne1.add_widget(tabAbonne)

        except:
            pass

        try:
            cadreAbonne.add_widget(cadreAbonnehaut)
            cadreAbonne.add_widget(cadreAbonne1)
        except:
            pass

        # les outils de la page abonne 2


        cadreAbonne2=Builder.load_string('''
FloatLayout:
    size_hint:1,.9
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
    
        ''')

        cadrejj=Builder.load_string('''
FloatLayout:
    size_hint:.26,.99
    pos_hint:{'x':.74,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        cadresous1=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.07
    pos_hint:{'center_x':.5,'y':.9}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Export",color="black",bold=True)

        
        checkAbonne3=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    on_active:app.verifAbonneF3(self)
    ''')

        l2=Label(text="Graphique",color="black",bold=True)

        checkAbonne4=Builder.load_string('''
MDCheckbox:
    color_active:'blue'
    color_inactive:'black'
    active:True
    on_active:app.verifAbonneF4(self)
    ''')

        try:
            cadresous1.add_widget(l1)
            cadresous1.add_widget(checkAbonne3)
            cadresous1.add_widget(l2)
            cadresous1.add_widget(checkAbonne4)
        except:
            pass
        
        cadresous2=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.75}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l1=Label(text="Ajouter Section",color='black',bold=True)

        spincours1=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours1.bind(on_release=self.chargeSection)
        spincours1.bind(text=self.selectSection)

        btval1=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval1.bind(on_release=self.affsectionCournow)

        try:
            cadresous2.add_widget(l1)
            cadresous2.add_widget(spincours1)
            cadresous2.add_widget(btval1)
        except:
            pass
        
        cadresous3=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.6}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l2=Label(text="Ajouter Option",color='black',bold=True)

        spincours2=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        spincours2.bind(on_release=self.chargeOptionProx)
        spincours2.bind(text=self.selectOptionProx)


        btval2=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval2.bind(on_release=self.affoptionCoursnow)

        try:
            cadresous3.add_widget(l2)
            cadresous3.add_widget(spincours2)
            cadresous3.add_widget(btval2)
        except:
            pass

        cadresous4=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.45}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
        
        ''')

        l3=Label(text="AJouter Classe",color='black',bold=True)

        spincours3=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')

        spincours3.bind(on_release=self.chargeClass)
        spincours3.bind(text=self.selectClass)

        btval3=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        btval3.bind(on_release=self.affclassCoursnow)
        
        try:
            cadresous4.add_widget(l3)
            cadresous4.add_widget(spincours3)
            cadresous4.add_widget(btval3)
        except:
            pass

        

        cadresous5=Builder.load_string('''
BoxLayout:
    oriention:"horizontal"
    size_hint:.8,.12
    pos_hint:{'center_x':.5,'y':.3}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[1,1,10,10]
        
        ''')

        l4=Label(text="Trier par Edition",color='black',bold=True)

        spincours4=Builder.load_string('''
Spinner:
    text:"Choisir"
    color:'white'
    font_size:'13sp'
    size_hint:.5,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        spincours4.bind(on_release=self.chargeEdition)
        spincours4.bind(text=self.selectEdition)

        btval4=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    theme_text_color:'Custom'
    pos_hint:{'center_y':.5}
    text_color:'red'
    
    ''')
        
        try:
            cadresous5.add_widget(l4)
            cadresous5.add_widget(spincours4)
            cadresous5.add_widget(btval4)
        except:
            pass

        titrealias=Label(text="OPERATIONS",color='black',bold=True,pos_hint={'center_x':.5,'y':.2},size_hint=(.1,.1))

        btAbonne1=Builder.load_string('''
Button:
    text:"Nouveau"
    color:'white'
    font_size:'13sp'
    size_hint:.8,.05
    pos_hint:{'center_x':.5,'y':.15}
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        tabAbonne1=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("NOM",dp(35))),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("MATRICULE",dp(40))),
            (("ID_Trav",dp(25))),
            (("OPTION ",dp(25))),
            (("CLASSE",dp(25))),
            (("EDITION",dp(25))),
            (("CREE",dp(25))),
            (("MODIFIE",dp(25)))
            ], row_data=[],size_hint=(0.72,0.9),pos_hint={'x':0,'y':0.08},check=True,rows_num=2000,use_pagination=True)
        
        #tabjournalinscr.bind(on_check_press=self.affravatail)

        try:
            cadrejj.add_widget(cadresous1)

            cadrejj.add_widget(cadresous2) 

            cadrejj.add_widget(cadresous3)
            cadrejj.add_widget(cadresous4)
            cadrejj.add_widget(cadresous5)

            cadrejj.add_widget(titrealias)
            cadrejj.add_widget(btAbonne1)

           
            #cadrejj.add_widget(spin1choixAbonne1)

        except:
            pass


        try:
            
            cadreAbonne2.add_widget(cadrejj)
            
            cadreAbonne2.add_widget(tabAbonne1)

        except:
            pass
       

        # outils de la page setting prince

        cadresetting1=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        #cadsettinghaut, setlab,setic1,setic2,setic3,setic4,setic5,setic6
        
        cadsettinghaut=Builder.load_string('''

FloatLayout:
    pos_hint:{'x':0,'y':.9}
    size_hint:1,.1

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
''')
        setlab=Builder.load_string('''       
Label:
    text: "Parametres"
    bold:True
    color:'white'
    font_size:'25sp'
    pos_hint:{'center_x':0.5,'center_y':0.5}
    size_hint:0.9,0.15
    bold:True
''')
        setic1=Builder.load_string('''
MDIconButton:
    icon:"arrow-left-circle"
    pos_hint:{'x':.02,'center_y':.5}
    text_color:'black'

    on_release:app.retourAccueil(self)
''')
        
        setic2=Builder.load_string('''
MDIconButton:
    icon:"account-edit"
    pos_hint:{'x':.6,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settinguser(self)
''')
        setic3=Builder.load_string('''  
MDIconButton:
    icon:"currency-eur"
    pos_hint:{'x':.65,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settingpaiement(self)
''')
        setic4=Builder.load_string('''
MDIconButton:
    icon:"book-education"
    pos_hint:{'x':.7,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settingprince(self)
''')

        setic5=Builder.load_string('''  
MDIconButton:
    icon:"book-open"
    pos_hint:{'x':.75,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'

    on_release:app.settingadministration(self)
''')
        
        setic6=Builder.load_string('''
MDIconButton:
    icon:"account-card"
    pos_hint:{'x':.8,'y':.05}
    text_color:'red'
    theme_text_color:'Custom'
                                   
    #on_release:app.settingPageUser(self)
''')
        
       
        try:
            cadsettinghaut.add_widget(setic1)
            cadsettinghaut.add_widget(setic2)
            cadsettinghaut.add_widget(setic3)
            cadsettinghaut.add_widget(setic4)
            cadsettinghaut.add_widget(setic5)
            cadsettinghaut.add_widget(setic6)
            cadsettinghaut.add_widget(setlab)
           
        except:
            pass
        
        
        btactivUpdate=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'
    spacing:5
    padding:5
    size_hint:.065,.06
    pos_hint: {'x':.935,'y':.96} 

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1]                                      
''')
        
        labpdateclss=Label(text="Update",bold=True,color='black',font_size='12sp')

        btactivUpdatevrai=Builder.load_string('''
MDCheckbox:
    active_color:'red'
    inactive_color:'black'
                                                                                        
    on_active:app.changemodesetting1(self) 

''')
        
        try:
            btactivUpdate.add_widget(labpdateclss)
            btactivUpdate.add_widget(btactivUpdatevrai)
        except:
            pass
        
        titresection=Label(text="section.",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidsection=MDTextField(hint_text='ID',disabled=True,password=True,text="555",icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulesection=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        

        cadrsup1=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.31,'y':0.93}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l1=Label(text="Sup",color="black",bold=True)

        sup1=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsup1.add_widget(l1)
            cadrsup1.add_widget(sup1)
        except:
            pass
        
        btrengistrersection=Builder.load_string('''

Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.83}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationSectionsetting(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
                                                 
''')
        
        tabsection=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.05,'y':0.52},check=True,rows_num=2000,use_pagination=True)

        tabsection.bind(on_check_press=self.affinfosection)
        
        spinsectionId=Builder.load_string('''
Spinner:
    background_color:[0,0,0,0]
    pos_hint:{'x':.55,'y':.93}
    size_hint:.1,.04
    bold:True
    text:"Section"
    color:"white"
    
    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        spinsectionId.bind(on_release=self.chargeSection)
        spinsectionId.bind(text=self.selectSection)

        titreoption=Label(text="Option",bold=True,color='black',pos_hint={'x':.68,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidoption=MDTextField(hint_text='ID',disabled=True,password=True,text="555",icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintituleoption=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        

        cadrsup2=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.83,'y':0.94}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l2=Label(text="Sup",color="black",bold=True)

        sup2=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsup2.add_widget(l2)
            cadrsup2.add_widget(sup2)
        except:
            pass

        btrengistreroption=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.84}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationOptionsetting(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
                                             
''')
        
        taboption=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("SECTION",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        taboption.bind(on_check_press=self.affinfoption)
        
        titreclass=Label(text="Classe",bold=True,color='black',pos_hint={'x':.15,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidclass=MDTextField(hint_text='ID',disabled=True,password=True,text="555",icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituleclassA=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        
        
        cadrsup3=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.31,'y':0.45}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l3=Label(text="Sup",color="black",bold=True)

        sup3=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsup3.add_widget(l3)
            cadrsup3.add_widget(sup3)
        except:
            pass

        btrengistrerclass=Builder.load_string('''

Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.35}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationsettingClass(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
                                                 
''') 
        
        tabclass=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':.02},check=True,rows_num=2000,use_pagination=True)

        tabclass.bind(on_check_press=self.affinfclasse) 

         
        
        titreann=Label(text="Edition Scolaire",bold=True,color='black',pos_hint={'x':.68,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidanne=MDTextField(hint_text='ID',disabled=True,password=True,text="555",icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituleanne=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.35},size_hint=(.1,.08),text_color_normal='black')

        cadrsup4=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.83,'y':0.45}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l4=Label(text="Sup",color="black",bold=True)

        sup4=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsup4.add_widget(l4)
            cadrsup4.add_widget(sup4)
        except:
            pass

        btrengistreranne=Builder.load_string('''

Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.35}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationsettingAnne(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
                                                 
''') 
        
        tabanne=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.02},check=True,rows_num=2000,use_pagination=True)

        tabanne.bind(on_check_press=self.affinfannee) 

        try:
            pass
            #cadrebtactivUpdate.add_widget(btactivUpdate) 
        except:
            pass

        try:
            pass
            
            #cadre.add_widget(cadsettinghaut)
            #cadre.add_widget(bmenu)
            
        except:
            pass

        try:
    
            cadresetting1.add_widget(cadrsup1)
            cadresetting1.add_widget(cadrsup2)
            cadresetting1.add_widget(cadrsup3)
            cadresetting1.add_widget(cadrsup4)
        except:
            pass
    
        try:
            
            #cadresetting1.add_widget(labpdateclss)
            cadresetting1.add_widget(btactivUpdate)
            cadresetting1.add_widget(titreoption)
            cadresetting1.add_widget(tidoption)
            cadresetting1.add_widget(tintituleoption)
            cadresetting1.add_widget(btrengistreroption) 
            cadresetting1.add_widget(taboption)

            cadresetting1.add_widget(tabsection)
            cadresetting1.add_widget(btrengistrersection)
            cadresetting1.add_widget(tintitulesection)
            cadresetting1.add_widget(tidsection)
            cadresetting1.add_widget(titresection)

            
            cadresetting1.add_widget(tabclass)
            cadresetting1.add_widget(titreclass)
            cadresetting1.add_widget(tidclass)
            cadresetting1.add_widget(tintituleclassA)
            cadresetting1.add_widget(btrengistrerclass) 

            cadresetting1.add_widget(titreann)
            cadresetting1.add_widget(tidanne)
            cadresetting1.add_widget(tintituleanne)
            cadresetting1.add_widget(btrengistreranne)
            cadresetting1.add_widget(tabanne)
        except:
            pass
        
        try:
            cadresetting1.add_widget(spinsectionId)
        except:
            pass

        # setting paiement

        cadresettingpaiemnt=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        btactivUpdate=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'
    spacing:5
    padding:5
    size_hint:.065,.06
    pos_hint: {'x':.935,'y':.96} 

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1]                                      
''')
        
        labpdateclss=Label(text="Update",bold=True,color='black',font_size='12sp')

        btactivUpdatevrai=Builder.load_string('''
MDCheckbox:
    active_color:'red'
    inactive_color:'black'
                                                                                        
    on_active:app.changemodesetting2(self) 

''')
        
        try:
            btactivUpdate.add_widget(labpdateclss)
            btactivUpdate.add_widget(btactivUpdatevrai)
        except:
            pass
        
        
        titremotif=Label(text="Motif",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidmotif=MDTextField(hint_text='ID',disabled=True,password=True,icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulemotif=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        cadrsupai1=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.31,'y':0.94}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l4=Label(text="Sup",color="black",bold=True)

        suppaie1=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsupai1.add_widget(l4)
            cadrsupai1.add_widget(suppaie1)
        except:
            pass

        btrengistrermotif=Builder.load_string('''

Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.84}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationsettingmotif(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]                                                 
''')
        
        tabmotif=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        
        tabmotif.bind(on_check_press=self.affinfmotif)

        titredevise=Label(text="Devise",bold=True,color='black',pos_hint={'x':.68,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tiddevise=MDTextField(hint_text='ID',disabled=True,password=True,icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.55,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintituledevise=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.7,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        cadrsupai2=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.83,'y':0.94}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l4=Label(text="Sup",color="black",bold=True)

        suppaie2=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsupai2.add_widget(l4)
            cadrsupai2.add_widget(suppaie2)
        except:
            pass

        btrengistrerdevise=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.83,'y':0.84}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationsettingdevise(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]                                                 
                                                 
''') 
        
        tabdevise=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.55,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        tabdevise.bind(on_check_press=self.affinfdevise)

        titretranche=Label(text="Tranche",bold=True,color='black',pos_hint={'x':.15,'y':.43},size_hint=(.1,.08),font_size='22sp')
        tidtranche=MDTextField(hint_text='ID',disabled=True,password=True,icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        tintituletranche=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.35},size_hint=(.1,.08),text_color_normal='black')
        

        cadrsupai3=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.31,'y':0.45}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l4=Label(text="Sup",color="black",bold=True)

        suppaie3=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsupai3.add_widget(l4)
            cadrsupai3.add_widget(suppaie3)
        except:
            pass

        btrengistrertrache=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.35}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationsettingtranche(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]                       
                                                 
''')
        
        tabtranche=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':.02},check=True,rows_num=2000,use_pagination=True)

        tabtranche.bind(on_check_press=self.affinftranche)

        try:
            cadresettingpaiemnt.add_widget(tabtranche)
            cadresettingpaiemnt.add_widget(btrengistrertrache)
            cadresettingpaiemnt.add_widget(tintituletranche)
            cadresettingpaiemnt.add_widget(tidtranche)
            cadresettingpaiemnt.add_widget(titretranche)
        
        except:
            pass

        try:
            cadresettingpaiemnt.add_widget(tabdevise)
            cadresettingpaiemnt.add_widget(btrengistrerdevise)
            cadresettingpaiemnt.add_widget(tintituledevise)
            cadresettingpaiemnt.add_widget(tiddevise)
            cadresettingpaiemnt.add_widget(titredevise)
        
        except:
            pass
        try:
            cadresettingpaiemnt.add_widget(titremotif)
            cadresettingpaiemnt.add_widget(tidmotif)
            cadresettingpaiemnt.add_widget(tintitulemotif)
            cadresettingpaiemnt.add_widget(btrengistrermotif)
            cadresettingpaiemnt.add_widget(tabmotif)
        
        except:
            pass

        try:    
            cadresettingpaiemnt.add_widget(cadrsupai1)
            cadresettingpaiemnt.add_widget(cadrsupai2)
            cadresettingpaiemnt.add_widget(cadrsupai3)
        except:
            pass
        
        try:    
            cadresettingpaiemnt.add_widget(btactivUpdate)
        
        except:
            pass
        
        # setting user

        cadresettinguser=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        titreuser=Label(text="Users",bold=True,color='black',pos_hint={'center_x':.5,'y':.9},size_hint=(.3,.12),font_size='22sp')
    
        labchangemode=Label(text="Update",bold=True,color='black',pos_hint={'x':.8,'y':.93},size_hint=(.1,.07),font_size='12sp')
        
        
        btactivUpdate=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'
    spacing:5
    padding:5
    size_hint:.065,.06
    pos_hint: {'x':.935,'y':.96} 

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1]                                      
''')
        
        labpdateclss=Label(text="Update",bold=True,color='black',font_size='12sp')

        btactivUpdatevrai=Builder.load_string('''
MDCheckbox:
    active_color:'red'
    inactive_color:'black'
                                                                                        
    on_active:app.changemodesetting3(self) 

''')
        
        try:
            btactivUpdate.add_widget(labpdateclss)
            btactivUpdate.add_widget(btactivUpdatevrai)
        except:
            pass

        tiduser=MDTextField(hint_text='Identifiant',disabled=True,password=True,text="666",font_size='20sp',bold=True,line_color_normal="black",icon_right="qrcode",pos_hint={'x':.025,'y':.93},size_hint=(.2,.08),text_color_normal='black')
        tnomunser=MDTextField(hint_text='Nom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.025,'y':.83},size_hint=(.2,.1),text_color_normal='black')
        tpostnomuser=MDTextField(hint_text='Postnom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.275,'y':.83},size_hint=(.2,.08),text_color_normal='black')
        tprenomuser=MDTextField(hint_text='Prenom',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.525,'y':.83},size_hint=(.2,.1),text_color_normal='black')

        lbsexe=Label(text="Sexe",pos_hint={'x':.775,'y':.83},size_hint=(.05,.1),color='black',bold=True,)

        sexuser=Builder.load_string('''
Spinner:
    text:"Choisir"
    background_color:[0,0,0,0]
    pos_hint:{'x':.825,'y':.83}
    size_hint:.15,.04
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.chargesexe(self)

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')
        tadressuser=MDTextField(hint_text='Adresse',font_size='20sp',bold=True,line_color_normal="black",icon_right="home",pos_hint={'x':.025,'y':.73},size_hint=(.2,.1),text_color_normal='black')
        tphonuser=MDTextField(hint_text='Phone',icon_right='phone',font_size='20sp',line_color_normal='black',pos_hint={'x':.275,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        tgmailuser=MDTextField(hint_text='E-mail',font_size='20sp',bold=True,line_color_normal="black",icon_right="gmail",pos_hint={'x':.525,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        tpwduser=MDTextField(hint_text='Pwd',icon_right='eye',font_size='20sp',line_color_normal='black',pos_hint={'x':.775,'y':.73},size_hint=(.2,.08),text_color_normal='black')
        
        tintituleclass=MDTextField(hint_text='',font_size='20sp',bold=True,line_color_normal="black",icon_right="gmail",pos_hint={'x':.65,'y':.6},size_hint=(.2,.08),text_color_normal='black')
        
        labfontion=Label(text="Fonction",color='black',pos_hint={'x':.025,'y':.61},size_hint=(.1,.1))
        
        fonctionuser=Builder.load_string('''
Spinner:
    text:"Choisir"
    bold:True
    pos_hint:{'x':.13,'y':.63}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    color:'white'                                                       
                                                                
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        fonctionuser.bind(on_release=self.chargeFonction)
        fonctionuser.bind(text=self.selectFonction)
        
        

        lablph=Label(text="Photo",color='black',pos_hint={'x':.3,'y':.61},size_hint=(.1,.1))

        photonuser=Builder.load_string('''
Spinner:
    text:"Importer fichier"
    color:'white'
    bold:True
    pos_hint:{'x':.45,'y':.63}
    size_hint:.2,.04
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

        cadrsupuser=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.7,'y':0.69}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l2=Label(text="Sup",color="black",bold=True)

        supuser=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrsupuser.add_widget(l2)
            cadrsupuser.add_widget(supuser)
        except:
            pass
        

        btrengistreruser=Builder.load_string('''

Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.63}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationunsersetting(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
                                             
                                             
''')
        
        tabuser=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NOM",dp(35)),
            ("POSTNOM ",dp(35)),
            ("PRENOM",dp(35)),
            ("SEXE",dp(35)),
            ("FONCTION",dp(35)),
            ("E-MAIL",dp(35)),
            ("PWD",dp(35)),
            ("ADRESSE",dp(40)),
            ("PHONE",dp(35)),
            ("PHOTO",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35))
            ], row_data=[],size_hint=(0.95,0.54),pos_hint={'x':0.025,'y':0.025},check=True,rows_num=2000,use_pagination=True)
         
        tabuser.bind(on_check_press=self.affinfuser)

        

        
        btclose=Builder.load_string('''
MDIconButton:
    icon:'content-save'
    pos_hint:{'x':.95,'y':.92}
    theme_text_color:'Custom'
    text_color:'red'
        
''')

        btclose.bind(on_release=lambda x: msg.dismiss())
        
        
        try:
            
            cadresettinguser.add_widget(cadrsupuser)
            cadresettinguser.add_widget(btactivUpdate)
            cadresettinguser.add_widget(labchangemode)
        except:
            pass


        try: 
        
            cadresettinguser.add_widget(tabuser)
            cadresettinguser.add_widget(btrengistreruser)
            cadresettinguser.add_widget(photonuser)
            cadresettinguser.add_widget(lablph)
            cadresettinguser.add_widget(fonctionuser)
            cadresettinguser.add_widget(labfontion)
        except:
            pass

        try:
            cadresettinguser.add_widget(titreuser)
            cadresettinguser.add_widget(tpwduser)
            cadresettinguser.add_widget(tgmailuser)
            cadresettinguser.add_widget(tphonuser)
            cadresettinguser.add_widget(tadressuser)
            cadresettinguser.add_widget(tprenomuser)  
            cadresettinguser.add_widget(tpostnomuser)

            cadresettinguser.add_widget(tnomunser)
            cadresettinguser.add_widget(lbsexe)
            cadresettinguser.add_widget(sexuser) 
            cadresettinguser.add_widget(tiduser) 
            

        except:
            pass
        
        # les outils de la page praetre de admistration

        #supfontion,btrengistrerfontion,tabfontion,cadresettingadmin

        cadresettingadmin=Builder.load_string('''
FloatLayout:
    pos_hint:{'center_x':.5,'y':.0}
    size_hint:(1,.88)
                                          
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size     
''')
        
        cadupdateadmin=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'
    spacing:5
    padding:5
    size_hint:.065,.06
    pos_hint: {'x':.935,'y':.96} 

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1]                                      
''')
        
        labpdateadmin=Label(text="Update",bold=True,color='black',font_size='12sp')

        btactivUpdateadmin=Builder.load_string('''
MDCheckbox:
    active_color:'red'
    inactive_color:'black'
                                                                                        
    on_active:app.changemodesetting4(self)
    #on_active:app.changemodesetting3(self)  

''')
        
        try:
            cadupdateadmin.add_widget(labpdateadmin)
            cadupdateadmin.add_widget(btactivUpdateadmin)
        except:
            pass
        
        
        titreadmin=Label(text="Adminitration",bold=True,color='black',pos_hint={'center_x':.5,'y':.9},size_hint=(.3,.12),font_size='22sp')

        titrefonction=Label(text="Fonction",bold=True,color='black',pos_hint={'x':.15,'y':.93},size_hint=(.1,.08),font_size='22sp')
        tidfonction=MDTextField(hint_text='ID',disabled=True,password=True,icon_right='spider',font_size='20sp',line_color_normal='black',pos_hint={'x':.05,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        tintitulefontion=MDTextField(hint_text='Intitulé',font_size='20sp',bold=True,line_color_normal="black",icon_right="text",pos_hint={'x':.2,'y':.83},size_hint=(.1,.08),text_color_normal='black')
        
        cadrssupadmin=Builder.load_string('''
BoxLayout:
    orientation:"horizontal"
    pos_hint:{'x':0.31,'y':0.94}
    size_hint:(0.12,0.04)
                                                                                                           
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            #radius:[15]
        
''')
        
        l4=Label(text="Sup",color="black",bold=True)

        supfontion=Builder.load_string('''
MDCheckbox:
    active_color:'blue'
    inactive_color:'black'

''')

        try:
            cadrssupadmin.add_widget(l4)
            cadrssupadmin.add_widget(supfontion)
        except:
            pass

        btrengistrerfontion=Builder.load_string('''

Button:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.31,'y':0.84}
    size_hint:(0.12,0.04)
    bold:True
    text:"Sauver"
    text_color:"white"
    
    on_release:app.operationsettingfontion(self)

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]                                                 
''')
        
        tabfontion=MDDataTable(column_data=[
            ("ID",dp(20)),
            (("LIBELLE",dp(30))),
            (("ENREGISTRE ",dp(35))),
            (("MODIFIE",dp(35)))
            ], row_data=[],size_hint=(0.4,0.3),pos_hint={'x':0.03,'y':0.52},check=True,rows_num=2000,use_pagination=True)
        
        tabfontion.bind(on_check_press=self.affinfonction)
        

        try:

            #supfontion,btrengistrerfontion,tabfontion,cadresettingadmin,tintitulefontion,tidfonction,titrefonction

            

            #cadresettingadmin.add_widget(supfontion) 
            cadresettingadmin.add_widget(btrengistrerfontion)
            cadresettingadmin.add_widget(tabfontion)

            cadresettingadmin.add_widget(tintitulefontion) 
            cadresettingadmin.add_widget(tidfonction)
            cadresettingadmin.add_widget(titrefonction)

            
            cadresettingadmin.add_widget(titreadmin)
            cadresettingadmin.add_widget(cadupdateadmin)

            cadresettingadmin.add_widget(cadrssupadmin)
            
        except:
            pass

        
        try:
            #cadre.add_widget(cadreInscription) 
            cadre.add_widget(cadreconnexion)

        except:
            pass
            
        return cadre
    
    def affichInfopaiementF(self,instance,text):
        global tabfiltre,tabfiltrepro,idEleve
        
        tabfiltrepro=[]

        try:

            if tabfiltre:

                tabfiltrepro=[lig for lig in tabfiltre if instance.text == lig[1]]

                for li in tabfiltrepro:

                    a,b,c,d,e,f,g,h,i,j,l,m,n=li

                idEleve=int(a)
                paiec4.text=str(l)
                paiec3.text=str(h)
                paiec2.text=str(i)
                paiec1.text=str(j)

                #paiec01.text=str()

                paiet4.text=str(d)
                paiet3.text=str(c)
                paiet2.text=str(b)
                paiet1.text=str(e)

        except Exception as e: 
            print(e)

        #paiec4,paiec3,paiec2,paiec1, paiec01,paiet4,paiet3,paiet2,paiet1//

    def chargenompaiementF(self,instance):
        global tabfiltre

        instance.values=""
        instance.text=""
        tabfiltre=[]
        
        paiec4.text=""
        paiec3.text=""
        paiec2.text=""
        paiec1.text=""
        paiet4.text=""
        paiet3.text=""
        paiet2.text=""
        paiet1.text=""
        
        try:
            bd=EcoleApp()
            con=self.connecteBD()

            rep=bd.EleveRecherche(con)

            if rep:

                tabinfo=rep[1]
                
                try:
                    tabfiltre=[lig for lig in tabinfo if trechPaiement.text in lig[4]]

                    for li in tabfiltre:

                        a,b,c,d,e,f,g,h,i,j,l,m,n=li

                        instance.values.append(str(b))

                except Exception as e:

                    print(e)

        except:

            pass


        #chargenompaiementF,trechPaiement,spinPaiement

    def saveoperationcours(self,instance):
        global tablcours,libCours,spinponderation,idoption,idclass,msginforeab,msg,idcours

        try:
            msginforeab.dismiss()
        except:
            pass
        
        try:
                
            bd=EcoleApp()
            con=self.connecteBD()

            if instance.text=="Sauver":

                rep=bd.CoursAjout(libCours.text,int(spinponderation.text),idclass,idoption,con)

                if rep==True:
                    
                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
            
                else:
                        
                    btmsg.text="ERROR !! veuillez ressayer plus tard !!"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                    
                
            elif instance.text=="Modifier":

                rep=bd.CoursUpdate(idcours,libCours.text,int(spinponderation.text),con)

                if rep==True:
                    
                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
            
                else:
                        
                    btmsg.text="ERROR !! veuillez ressayer plus tard !!"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

            elif instance.text=="Supprimer":
                
                rep=bd.CoursDelete(idcours,con)

                if rep==True:
                    
                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
            
                else:
                        
                    btmsg.text="ERROR !! veuillez ressayer plus tard !!"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

        except Exception as e:

            print(e)
    
    def chargeinfoMidCours(self,instance_table,current_row):

        global idcours,libCours,spinponderation


        idcours=current_row[0]
        libCours.text=str(current_row[1])
        spinponderation.text=str(current_row[2])


    def closeoperationEleve(seld,instance):
        global msg

        try:
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass

        try:
            msg.dismiss()
        except:
            pass

    def nouveauOP(self,instance):

        btsave.text="Enregistrer"

    def modificationOP(self,instance):
    
        cadx=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
        
        ''')

        t1=Builder.load_string('''
                               
MDTextField:
    hint_text:'Matricule'
    pos_hint:{'x':.05,'center_y': .55}
    size_hint:.4,.22
    text_color:255/255,128/255,0/255
    icon_right:'spider'
    font_size:'15sp'
    line_color_normal:'black'
    text_color_normal:'black'
''')

        sp1=Builder.load_string('''
Spinner:
    text:"Choisir"
    pos_hint:{'x':.55,'center_y':.55}
    size_hint:.4,.1
    background_color:[0,0,0,0]
    bold:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        ''')
        #sp1.bind(on_release=self.nouveauOP)

        ic1=Builder.load_string('''
MDIconButton:
    icon:'spinner'
    size_hint:.025,.03
    pos_hint:{'x':.95,'y':.94}
        
        ''')

        ic1.bind(on_release=lambda x:msg.dismiss())

        try:
            cadx.add_widget(sp1)
            cadx.add_widget(t1)
            cadx.add_widget(ic1)
        except:
            pass

        if instance.text=="Supprimer":
        
            btsave.text="Supprimer"

        elif instance.text=="Mis à jour":

            btsave.text="Modifier"

        try:
            msg=Popup(title="RECHERCHE",content=cadx,size_hint=(.5,.5))
        except:
            pass

        try:
            msg.open()
        except:
            pass
        
    def openOperationEleve(self,instance):
        global cadx,msg

        try:
            cadreInscription.remove_widget(cadreInscription1)
        except:
            pass

        try:
            cadx.remove_widget(cadreInscription1)
        except:
            pass

        cadx=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
        
        ''')

        bt1=Builder.load_string('''
Button:
    text:"Nouveau"
    pos_hint:{'x':.35,'y':.94}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
        ''')
        bt1.bind(on_release=self.nouveauOP)
        
        bt2=Builder.load_string('''
Button:
    text:"Mis à jour"
    pos_hint:{'x':.55,'y':.94}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
        ''')
        bt2.bind(on_release=self.modificationOP)

        bt3=Builder.load_string('''
Button:
    text:"Supprimer"
    pos_hint:{'x':.75,'y':.94}
    size_hint:.15,.04
    background_color:[0,0,0,0]
    bold:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
        ''')    

        bt3.bind(on_release=self.modificationOP)

        btclose=Builder.load_string('''
MDIconButton:
    icon:'spinner'
    size_hint:.025,.03
    pos_hint:{'x':.95,'y':.94}
        
        ''')

        btclose.bind(on_release=self.closeoperationEleve)

        try:
            cadx.add_widget(bt1)
            cadx.add_widget(bt2)
            cadx.add_widget(bt3)
            
            cadx.add_widget(btclose)
        except:
            pass

        try:
            cadx.add_widget(cadreInscription1)
        except Exception as e:
            print(e)

        try:
            msg=Popup(title="OPERATION ELEVE",content=cadx,size_hint=(1,1))
        except:
            pass

        msg.open()

    def operationCommunique(self,instance):
        global tablcommuniqueMid,idcomm,fichier, contenu,titre 

        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

Button:
                                           
    background_color:[0,0,0,0]
    text:"Close"
    bold:True
    pos_hint:{'x':0.75, 'y':.87}
    size_hint:0.2,0.06
    color:'white'
                                           
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]                         
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        btsauver=Builder.load_string('''

Button:
                                     
    color:'white'
    pos_hint:{'x':.75,'y': .77}
    size_hint:.2,.06
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btsauver.bind(on_release=self.saveoperationComminuqe)

        
        idcomm=MDTextField(hint_text='ID',text="20201",password=True,pos_hint={'x':.05,'y':.8},size_hint=(.3,.15),line_color_normal='black',text_color='black',icon_right='text')
  
        labrefresh=Label(text="Refresh",color='black',size_hint=(.1,.1),pos_hint={'x':.1,'y':.73},bold=True)
        
        btrefres=Builder.load_string('''
MDCheckbox:
    size_hint:.03,.03
    pos_hint:{'x':.05,'y':.76}
    active_color:'blue'
    on_release:app.communiquerefresh(self)
                                     
''')
        
        fichier=Builder.load_string('''

Spinner:                             
    color:'white'
    pos_hint:{'x':.4,'y': .84}
    size_hint:.3,.06
    background_color:[0,0,0,0]
    bold:True
    text:"Fichier"

    canvas.before:
        Color:
            rgb:0,0,0
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15,15,1,1]

''')
        fichier.bind(on_release=self.chargemois)

        titre=TextInput(text="Titre",pos_hint={'center_x':.5,'y':.63},size_hint=(.9,.1))
        titre.bind(focus=self.clearTitre)

        contenu=TextInput(text="Contenu",pos_hint={'center_x':.5,'y':.41},size_hint=(.9,.2))
        contenu.bind(focus=self.clearContenu)

        
        
        tablcommuniqueMid=MDDataTable(column_data=[
            ("NOM",dp(35)),
            (("POSTNOM",dp(35))),
            (("PRENOM",dp(40))),
            (("TITRE",dp(40))),
            (("CONTENU",dp(80))),
            (("FILE",dp(35))),
            (("BN CODE",dp(35))),
            (("CREE",dp(40))),
            (("MODIFIE",dp(40)))
            ], row_data=[],size_hint=(0.9,0.36),pos_hint={'center_x':0.5,'y':.03},check=True,rows_num=2000,use_pagination=True)
        
        tablcommuniqueMid.bind(on_check_press=self.chargeinfoMidcomminuque)
        
        
        try:
            cad.add_widget(tablcommuniqueMid)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(idcomm)
            cad.add_widget(btsauver) 

            cad.add_widget(fichier)
            cad.add_widget(titre)
            cad.add_widget(contenu)

        except:
            pass


        if instance.text=="Nouveau Communiqué":

            btsauver.text="Sauver"

            try:
                msginforeab=Popup(title='NOUVEAU COURS',content=cad,size_hint=(.6,.7))
            except:
                pass
            
            try:
                msginforeab.open()
            except:
                pass
            
        elif instance.text=="Modifier Communiqué":

            try:
                cad.add_widget(labrefresh)
                cad.add_widget(btrefres)
            except:
                pass

            
            btsauver.text="Modifier"

            try:
                msginforeab=Popup(title='MISE A JOUR',content=cad,size_hint=(.6,.7))
            except:
                pass
            
            try:
                msginforeab.open()
            except:
                pass

        elif instance.text=="Desactiver Communiqué":

            try:
                cad.add_widget(labrefresh)
                cad.add_widget(btrefres)
            except:
                pass
            
            btsauver.text="Supprimer"

            try:
                msginforeab=Popup(title='SUPRESSION',content=cad,size_hint=(.6,.7))
            except:
                pass
            
            
            try:
                msginforeab.open()
            except:
                pass

            
    def openOperationCOurs(self,instance):
        global msginforeab,tablcours,libCours,spinponderation,msginforeab

        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

Button:
                                           
    background_color:[0,0,0,0]
    text:"Close"
    bold:True
    pos_hint:{'x':0.75, 'y':.87}
    size_hint:(0.2,0.1)
    color:'white'
                                           
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]                         
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        btsauver=Builder.load_string('''

Button:
                                     
    color:'white'
    pos_hint:{'x':.75,'y': .75}
    size_hint:.2,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btsauver.bind(on_release=self.saveoperationcours)

        
        libCours=MDTextField(hint_text='Libelle cours',pos_hint={'x':.05,'y':.8},size_hint=(.3,.15),line_color_normal='black',text_color='black',icon_right='text')

        labpond=Label(text="Pond..",color='black',size_hint=(.1,.1),pos_hint={'x':.37,'y':.8},bold=True)

        
        labpond=Label(text="Pond..",color='black',size_hint=(.1,.1),pos_hint={'x':.37,'y':.8},bold=True)
        
        labrefresh=Label(text="Refresh",color='black',size_hint=(.1,.1),pos_hint={'x':.1,'y':.73},bold=True)
        
        btrefres=Builder.load_string('''
MDCheckbox:
    size_hint:.05,.05
    pos_hint:{'x':.05,'y':.74}
    active_color:'blue'
    on_release:app.coursrefresh(self)
                                     
''')
        
        cadpond=Builder.load_string('''
BoxLayout:
    orientation:'vertical'                                 
    size_hint:.2,.2
    pos_hint:{'x':.5,'y':.75}
    spacing:5
    padding:5
                                    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
    ''')
        
        spinponderation=Builder.load_string('''

Spinner:                             
    color:'white'
    pos_hint:{'center_x':.5,'center_y': .5}
    size_hint:.98,.5
    background_color:[0,0,0,0]
    bold:True
    text:"1"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[5]

''')
        
        spinponderation.bind(on_release=self.chargemois)
        
        btplus=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-up'
    pos_hint:{'center_x':.5,'center_y': .1}
    size_hint:.5,.2
                                   
    on_release:app.ponderationPlus(self)
        
        ''')

        btmoins=Builder.load_string('''
MDIconButton:
    icon:'chevron-double-down'
    pos_hint:{'center_x':.5,'center_y': .1}
    size_hint:.5,.2
                                    
    on_release:app.ponderationmoins(self)
        
        ''')


        tablcours=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("PONDER..",dp(35)),
            ("CLASSE",dp(35)),
            ("OPTION",dp(35)),
            ("SECTION",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35))
            ], row_data=[],size_hint=(0.9,0.7),pos_hint={'center_x':0.5,'y':.03},check=True,rows_num=2000,use_pagination=True)
        
        tablcours.bind(on_check_press=self.chargeinfoMidCours)
        
        try:
            cadpond.add_widget(btplus)
            cadpond.add_widget(spinponderation)
            cadpond.add_widget(btmoins)
        except:
            pass

        try:
            cad.add_widget(tablcours)
            cad.add_widget(cadpond)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(libCours)
            cad.add_widget(btsauver)

            cad.add_widget(labpond)

        except:
            pass


        if instance.text=="Nouveau":

            btsauver.text="Sauver"

            try:
                msginforeab=Popup(title='NOUVEAU COURS',content=cad,size_hint=(.4,.5))
            except:
                pass
            
            msginforeab.open()

            
        elif instance.text=="Mise à jours":

            try:
                cad.add_widget(labrefresh)
                cad.add_widget(btrefres)
            except:
                pass

            
            btsauver.text="Modifier"

            try:
                msginforeab=Popup(title='MISE A JOUR',content=cad,size_hint=(.4,.5))
            except:
                pass
            
            msginforeab.open()
            
        elif instance.text=="Supprimer":

            try:
                cad.add_widget(labrefresh)
                cad.add_widget(btrefres)
            except:
                pass
            
            btsauver.text="Supprimer"

            try:
                msginforeab=Popup(title='SUPRESSION',content=cad,size_hint=(.4,.5))
            except:
                pass
            
            msginforeab.open()    

    def affCoursDelib(self,instance):
        global sepa,idclass,idoption,tabexport,idEdition,idPeriode,idcours

        try:

            tabdelib1.row_datatabeleve1=[]
            
            if checkdelib2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheCours(idoption,idclass,idPeriode,idCours,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabdelib1.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheCours(idoption,idclass,idPeriode,idcours,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabdelib1.row_data=tabexportnew
        except Exception as e:
            print(e)
        
    def affPeriodeDelib(self,instance):

        global sepa,idclass,idoption,tabexport,idEdition,idPeriode

        try:

            tabdelib1.row_datatabeleve1=[]
            
            if checkdelib2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherhePeriode(idoption,idclass,idPeriode,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabdelib1.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherhePeriode(idoption,idclass,idPeriode,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabdelib1.row_data=tabexportnew
        except:
            pass

    def saveoperationComminuqe(self,instance):

        global tablcommuniqueMid,idcomm,fichier, contenu,titre,msg
 

        if instance.text=="Supprimer":
            
            try:

                bd=EcoleApp()
                con=self.connecteBD()

                etat=bd.CommuniqueDelete(int(idcomm.text),con)

                if etat==True:
                    
                    btmsg.text="Effectué !!"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open() 

            except Exception as e:

                pass

        elif instance.text=="Modifier":
            
            try:

                bd=EcoleApp()
                con=self.connecteBD()

                etat=bd.CommuniqueUpdate(int(idcomm.text),titre.text,contenu.text,fichier.text,1101,con)

                if etat==True:
                    
                    btmsg.text="Effectué !!"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open() 

            except Exception as e:

                pass

        elif instance.text=="Sauver":
            
            try:

                bd=EcoleApp()
                con=self.connecteBD()

                etat=bd.CommuniqueAjout(titre.text,contenu.text,fichier.text,1101,con)

                if etat==True:
                    
                    btmsg.text="Effectué !!"

                    try:
                        msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open() 

            except Exception as e:

                pass
    
    def affClassDelib(self,instance):
        global sepa,idclass,idoption,tabexport,idEdition

        try:

            tabdelib1.row_datatabeleve1=[]
            
            if checkdelib2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheClass(idoption,idclass,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabdelib1.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheClass(idoption,idclass,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabdelib1.row_data=tabexportnew
        except:
            pass


    def affOptionDelib(self,instance):
        global sepa,idsection,idoption,tabexport,idEdition

        try:

            tabdelib1.row_datatabeleve1=[]
            
            if checkdelib2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheOption(idoption,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabdelib1.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheOption(idoption,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabdelib1.row_data=tabexportnew
        except:
            pass
    
    def changerTrav1(self,instance):

        try:
            cadreTravaux.remove_widget(cadreTravaux1)
        except:
            pass
        
        try:
            cadreTravaux.add_widget(cadreTravaux2)
        except:
            pass

    def changerTrav2(self,instance):

        try:
            cadreTravaux.remove_widget(cadreTravaux2)
        except:
            pass

        try:
            cadreTravaux.add_widget(cadreTravaux1)
        except:
            pass

    def affsectionDelib(self,instance):
        global sepa,idsection,tabexport,idEdition

        try:

            tabdelib1.row_datatabeleve1=[]
            
            if checkdelib2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheSection(idsection,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabdelib1.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.coteRecherheSection(idsection,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabdelib1.row_data=tabexportnew
        except:
            pass

    def affsectionELeve(self,instance):
        
        global sepa,idsection,tabexport,idEdition

        if checkeleve4.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.sectionRecherheUniqueeleve(idsection,idEdition,ccon)

            if req:

                tabexport=req[1]

                tabeleve2.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.sectionRecherheUniqueeleve(idsection,idEdition,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabeleve1.row_data=tabexportnew


    def affoptionEleve(self,instance):
        
        global sepa,idoption,tabexport,idEdition

        if checkeleve4.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.optionRecherheUniqueeleve(idoption,idEdition,ccon)

            if req:

                tabexport=req[1]

                tabeleve2.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.optionRecherheUniqueeleve(idoption,idEdition,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabeleve2.row_data=tabexportnew


    def affclassEleve(self,instance):

        global sepa,idoption,idclass,tabexport,idEdition

        if checkeleve4.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.classRecherheUniqueeleve(idoption,idclass,idEdition,ccon)

            if req:

                tabexport=req[1]

                tabeleve2.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.classRecherheUniqueeleve(idoption,idclass,idEdition,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabeleve2.row_data=tabexportnew
        

    def affsectionELevenow(self,instance):
        
        global sepa,idsection,tabexport,idEdition

        if checkeleve2.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.sectionRecherheUniqueeleveNow(idsection,idEdition,ccon)

            if req:

                tabexport=req[1]

                tabeleve1.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.sectionRecherheUniqueeleveNow(idsection,idEdition,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabeleve1.row_data=tabexportnew


    def affoptionElevenow(self,instance):
        
        global sepa,idoption,tabexport,idEdition

        if checkeleve2.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.optionRecherheUniqueeleveNow(idoption,idEdition,ccon)

            if req:

                tabexport=req[1]

                tabeleve1.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.optionRecherheUniqueeleveNow(idoption,idEdition,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabeleve1.row_data=tabexportnew


    def affclassElevenow(self,instance):

        global sepa,idoption,idclass,tabexport,idEdition

        if checkeleve2.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.classRecherheUniqueeleveNow(idoption,idclass,idEdition,ccon)

            if req:

                tabexport=req[1]

                tabeleve1.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.classRecherheUniqueeleveNow(idoption,idclass,idEdition,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabeleve1.row_data=tabexportnew
    # fin eleve
    #debut paiement

    def affmotifPaiement(self,instance):
        
        global sepa,idsection,tabexport,idoption,idclass,idmotif,idEdition


        try:
                
            if checkpaie2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.motifRecherhePaiement(idoption,idclass,idmotif,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabpaiejourn.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.motifRecherhePaiement(idoption,idclass,idmotif,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabpaiejourn.row_data=tabexportnew

        except:
            pass
        
    def affclassPaiement(self,instance):
        
        global sepa,idsection,tabexport,idoption,idclass,idEdition

        try:
                
            if checkpaie2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.classRecherhePaiement(idoption,idclass,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabpaiejourn.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.classRecherhePaiement(idoption,idclass,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabpaiejourn.row_data=tabexportnew

        except:
            pass
    
    def affoptionPaiement(self,instance):
        
        global sepa,idsection,tabexport,idoption,idEdition

        try:

            if checkpaie2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.optionRecherhePaiement(idoption,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabpaiejourn.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.optionRecherhePaiement(idoption,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabpaiejourn.row_data=tabexportnew
            
        except:
            pass
    
    def affsectionPaiement(self,instance):
       
        global sepa,idsection,tabexport,idEdition

        try:

            if checkpaie2.active==True:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.sectionRecherhePaiement(idsection,idEdition,ccon)

                if req:

                    tabexport=req[1]

                    tabpaiejourn.row_data=tabexport

            else:

                tabexportnew=[]
                
                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.sectionRecherhePaiement(idsection,idEdition,ccon)


                if req:

                    tabexport=req[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])


                    tabpaiejourn.row_data=tabexportnew
        except:
            pass

    def affsectionCour(self,instance):
        
        global sepa,idsection,tabexport,idEdition

        if checkcours4.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueSection(idsection,ccon)

            if req:

                tabexport=req[1]

                tabcoursjourn.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueSection(idsection,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabcoursjourn.row_data=tabexportnew


    def affoptionCours(self,instance):
        
        global sepa,idoption,tabexport,idEdition

        if checkcours4.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueOption(idoption,ccon)

            if req:

                tabexport=req[1]

                tabcoursjourn.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueOption(idoption,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabcoursjourn.row_data=tabexportnew


    def affclassCours(self,instance):

        global sepa,idoption,idclass,tabexport,idEdition

        if checkcours4.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueClass(idoption,idclass,ccon)

            if req:

                tabexport=req[1]

                tabcoursjourn.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueClass(idoption,idclass,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])
    
                tabcoursjourn.row_data=tabexportnew

    def affsectionCournow(self,instance):
        
        global sepa,idsection,tabexport

        if checkcours2.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueSectionNow(idsection,ccon)

            if req:

                tabexport=req[1]

                tabcours0.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueSectionNow(idsection,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabcours0.row_data=tabexportnew


    def affoptionCoursnow(self,instance):
        
        global sepa,idoption,tabexport

        if checkcours2.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueOptionNow(idoption,ccon)

            if req:

                tabexport=req[1]

                tabcours0.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueOptionNow(idoption,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabcours0.row_data=tabexportnew


    def affclassCoursnow(self,instance):

        global sepa,idoption,idclass,tabexport

        if checkcours2.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueClassNow(idoption,idclass,ccon)

            if req:

                tabexport=req[1]

                tabcours0.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.coursRechercheUniqueClassNow(idoption,idclass,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabcours0.row_data=tabexportnew

        #tabcours0,affclassCours,a,affsectionCour
    def affClassInsc(self,instance):

        global sepa,idclass,idoption,tabexport,tabjournalinscr

        if check1.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.ClassRecherheUnique(idoption,idclass,ccon)

            if req:

                tabexport=req[1]

                tabjournalinscription.row_data=tabexport

               

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.ClassRecherheUnique(idoption,idclass,ccon)

            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabjournalinscription.row_data=tabexportnew
    
    def affOptionInsc(self,instance):

        global sepa,idoption,tabexport,tabjournalinscr

        if check1.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.OptionRecherheUnique(idoption,ccon)

            if req:

                tabexport=req[1]

                tabjournalinscription.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.OptionRecherheUnique(idoption,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabjournalinscription.row_data=tabexportnew

    
    def affsectionInsc(self,instance):

        global sepa,idsection,tabexport

        if check1.active==True:

            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.sectionRecherheUnique(idsection,ccon)

            if req:

                tabexport=req[1]

                tabjournalinscription.row_data=tabexport

        else:

            tabexportnew=[]
            
            bd=EcoleApp()

            ccon=self.connecteBD()

            req=bd.sectionRecherheUnique(idsection,ccon)


            if req:

                tabexport=req[1]

                if len(tabexport)<sepa:

                    tabexportnew=tabexport
                    
                else:

                    for li in range(sepa):

                        tabexportnew.append(tabexport[li])


                tabjournalinscription.row_data=tabexportnew
            
    
    def changemodesetting4(self,instance):

        global sepa

        if instance.active==True:

            btrengistrerfontion.text="Modifier"

            try:
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.FonctionRecherche(ccon)

                tabinfonew=[]

                if rep1:

                    tabinfo=rep1[1]

                    if len(tabinfo)<sepa:

                        tabinfonew=tabinfo

                    else:

                        for i in range(sepa):

                            tabinfonew.append(tabinfo[i])
                    
                    tabfontion.row_data=tabinfonew

            except:
                pass

        else:
            btrengistrerfontion.text="Sauver"
    
    def affsectionattribution(self,instance):
        global idsection

        if checkEnseignant4.active==True:

            req=EcoleApp()
            ccon=self.connecteBD()

            rep1=req.affichAttributionSection(idsection,ccon)

            if rep1:

                tabinfo=rep1[1]

                tabjournEns2.row_data=tabinfo
        
        else:
            pass

    def sectionPersonneRech(self,instance):
        global idfonction,sepa

        tabinfo=[]
        tabinfonew=[]
        tabjourPersonnelnew1.row_data=[]

        if checkEnseignant2.active==True:

            try:
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.affichUserSection(idfonction,ccon)

                if rep1:

                    tabinfo=rep1[1]

                    tabjourPersonnelnew1.row_data=tabinfo

            except:
                pass
        
        else:

            try:
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.affichUserSection(idfonction,ccon)

                tabinfonew=[]

                if rep1:

                    tabinfo=rep1[1]

                    if len(tabinfo)<sepa:

                        tabinfonew=tabinfo

                    else:

                        for i in range(sepa):

                            tabinfonew.append(tabinfo[i])
                    
                    tabjourPersonnelnew1.row_data=tabinfonew

            except:
                pass
        
    def changemodesetting3(self,instance):

        global sepa

        if instance.active==True:

            #tiduser,tnomunser,tpostnomuser,tprenomuser,tadressuser,tphonuser,tgmailuser,tpwduser,tintituleclass,fonctionuser,photonuser,btrengistreruser,tabuser

            btrengistreruser.text="Modifier"

            try:
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.UserRecherche(ccon)

                tabinfonew=[]

                if rep1:

                    tabinfo=rep1[1]

                    if len(tabinfo)<sepa:

                        tabinfonew=tabinfo

                    else:

                        for i in range(sepa):

                            tabinfonew.append(tabinfo[i])
                    
                    tabuser.row_data=tabinfonew

            except:
                pass

        else:
            btrengistreruser.text="Sauver"
        

    def changemodesetting2(self,instance):

        if instance.active==True:

            btrengistrertrache.text="Modifier"
            btrengistrerdevise.text="Modifier"
            btrengistrermotif.text="Modifier"

            try:
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.MotifRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabmotif.row_data=tabinfo

                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.TrancheRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabtranche.row_data=tabinfo
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.DeviseRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabdevise.row_data=tabinfo 
                
            except:

                btmsg.text="ERROR"

                try:
                    msg=Popup(title="OPERATION",content=btmsg,size_hint=(.4,.2))
                except:
                    pass

                msg.open()

        else:
            
            btrengistrertrache.text="Sauver"
            btrengistrerdevise.text="Sauver"
            btrengistrermotif.text="Sauver"


    def changemodesetting1(self,instance):

        if instance.active==True:

            btrengistreroption.text="Modifier"
            btrengistreranne.text="Modifier"
            btrengistrersection.text="Modifier"
            btrengistrerclass.text="Modifier"

            try:
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.SectionRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabsection.row_data=tabinfo

                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.OptionRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    taboption.row_data=tabinfo
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.classRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabclass.row_data=tabinfo 
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.Anne_ScolaireRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabanne.row_data=tabinfo 
            
            except:

                btmsg.text="ERROR"

                try:
                    msg=Popup(title="OPERATION",content=btmsg,size_hint=(.4,.2))
                except:
                    pass

                msg.open()

        else:
            btrengistreroption.text="Sauver"
            btrengistreranne.text="Sauver"
            btrengistrersection.text="Sauver"
            btrengistrerclass.text="Sauver"


    def supprimerSection(self,instance):
        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.SectionDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.SectionRecherche(ccon)

            if req:
                tabinfo=req[1]

                tabsection.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()


    def supprimerOption(self,instance):
        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.OptionDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.OptionRecherche(ccon)

            if req:
                tabinfo=req[1]

                taboption.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

    
    def supprimerClasse(self,instance):
        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.classDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.classRecherche(ccon)

            if req:
                tabinfo=req[1]

                tabclass.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()


    def supprimerAnne(self,instance):
        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.AnnScolaireDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.Anne_ScolaireRecherche(ccon)

            if req:
                tabinfo=req[1]

                tabanne.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()
    
    def supprimermotif(self,instance):
    
        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.MotifDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.MotifRecherche(ccon)

            if req:
                tabinfo=req[1]

                tabmotif.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

    def supprimerdevise(self,instance):

        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.DeviseDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.DeviseRecherche(ccon)

            if req:
                tabinfo=req[1]

                tabdevise.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

    def supprimertranche(self,instance):

        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.TrancheDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.TrancheRecherche(ccon)

            if req:
                tabinfo=req[1]

                tabtranche.row_data=tabinfo

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

    def supprimeruser(self,instance):

        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.UserDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.UserRecherche(ccon)

            tabinfonew=[]

            if req:
                tabinfo=req[1]

                if len(tabinfo)<sepa:
                    tabinfonew=tabinfo
                else:

                    for i in range(sepa):

                        tabinfonew.append(tabinfo[i])
                        

                tabuser.row_data=tabinfonew

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

    def communiquerefresh(self,instance):
        
        global dtanew,tablcommuniqueMid

        try:

            if instance.active==True:

                bd=EcoleApp()
                con=self.connecteBD()

                rep=bd.affichCommuniquenowMid(dtanew,con)

                if rep:

                    tabinfo=rep[1]

                    #tabCommjourn0.row_data=tabinfo

                    tablcommuniqueMid.row_data=tabinfo
        
        except Exception as e:
            print(e)

    def coursrefresh(self,instance):
        global tablcours


        try:

            if instance.active==True:

                bd=EcoleApp()
                con=self.connecteBD()

                rep=bd.CoursRecherche(con)

                if rep:

                    tabinfo=rep[1]

                    tablcours.row_data=tabinfo
        
        except Exception as e:
            print(e)


    def supprimerfontion(self,instance):

        global msg,idsup

        try:
            msg.dismiss()
        except:
            pass

        try:
            idsup=int(idsup)
        except:
            pass

        ccon=self.connecteBD()

        bd=EcoleApp()

        req=bd.FonctionDelete(idsup,ccon)

        bt1=Builder.load_string('''
Button:

    size_hint:.1,1

    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
        bt1.bind(on_release=lambda x:msg.dismiss())

        if req==True:
        
            bt1.text="Effectué avec succes !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

            ccon=self.connecteBD()

            bd=EcoleApp()

            req=bd.FonctionRecherche(ccon)

            tabinfonew=[]

            if req:
                tabinfo=req[1]

                if len(tabinfo)<sepa:
                    tabinfonew=tabinfo
                else:

                    for i in range(sepa):

                        tabinfonew.append(tabinfo[i])
                        

                tabfontion.row_data=tabinfonew

        else:

            bt1.text="ERROR !!!"

            try:
                msg=Popup(title="CONTROLEUR",content=bt1,size_hint=(.4,.2))
            except:
                pass

            msg.open()

    def affinfonction(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        if supfontion.active==True:

            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimerfontion)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass
            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()

        else:
            tidfonction.text=str(current_row[0])
            tintitulefontion.text=str(current_row[1])

    def verifPermission(self,instance):
        global codeSecurite,tcode,msg,idchfiffre

        print(idchfiffre)
        
        try:
                
            if tcode.text==codeSecurite:
            
                try:
                    
                    tabinfo=[]

                    b=""
                    c=""
                    d=""
                    e=""

                    ccon=self.connecteBD()

                    bd=EcoleApp()

                    req=bd.EleveRecherche(ccon)

                    if req:

                        tabinfo=req[1]

                        res=[li for li in tabinfo if li[0]==int(idchfiffre)]

                        print(res)

                        for lign in res:

                            a,b,c,d,e,f,g,h,i,j,k,l,m=lign

                
                except Exception as e:

                    print(e)

                cadd=Builder.load_string('''
Button:
    text:'.'
    size_hint:1,1
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')            
                msg.dismiss()

                cadd.text= str(str(b)+" // "+ str(c)+" // "+ str(d)+ " // "+ e)

                cadd.bind(on_release=lambda x : msg.dismiss())

                try:
                    msg=Popup(title="INFO DU CANDIDAT ",content=cadd,size_hint=(.4,.2))
                except:
                    pass

                msg.open()

                
            
            else:
                tcode.text="Code incorrect !!"
                tcode.password=False

        except Exception as e:
            
            print(e)

    def gestPwd(self,instance,text):

        instance.password=True

    def affInfoCote(self,instance_table,current_row):

        global msg,idsup,tcode,idchfiffre

        idchfiffre=current_row[0]

        cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
        tcode=Builder.load_string('''
MDTextField:
    hint_text:'Confirmer le Code Secret'
    pos_hint:{'center_x':.5,'center_y': .4}
    size_hint:.9,.3
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
    password:True
''')
        tcode.bind(focus=self.gestPwd)
        
        bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.7,'y':.8}
    size_hint:.25,.1

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
        bt1.bind(on_release=self.verifPermission)

        bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.7,'y':.6}
    size_hint:.25,.1

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
        bt2.bind(on_release=lambda x : msg.dismiss())

        try:
            cadd.add_widget(bt1)
            cadd.add_widget(bt2)
            cadd.add_widget(tcode)
        except:
            pass
        
        try:
            msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.4,.4))
        except:
            pass

        msg.open()

    def affinfuser(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        if supuser.active==True:

            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimeruser)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass
            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()

        else:
            tiduser.text=str(current_row[0])
            tnomunser.text=str(current_row[1])
            tpostnomuser.text=str(current_row[2])
            tprenomuser.text=str(current_row[3])
            sexuser.text=str(current_row[4])
            fonctionuser.text=str(current_row[5])
            tgmailuser.text=str(current_row[6])
            tpwduser.text=str(current_row[7])
            tadressuser.text=str(current_row[8])
            tphonuser.text=str(current_row[9])
            photonuser.text=str(current_row[10])
            

    def chargeinfoMidcomminuque(self,instance,curr):

        global idcomm,fichier,contenu,titre

        idcomm.text=str(curr[6])
        fichier.text=str(curr[5])
        contenu.text=str(curr[4])
        titre.text=str(curr[3])


    def affinftranche(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        if suppaie3.active==True:

            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimertranche)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass
            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()
            
        else:

            tidtranche.text=str(current_row[0])
            tintituletranche.text=str(current_row[1])

    def affinfdevise(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        
        if suppaie2.active==True:
            
            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimerdevise)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass

            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()

        else:
                
            tiddevise.text=str(current_row[0])
            tintituledevise.text=str(current_row[1])

    def affinfmotif(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]
        
        
        if suppaie1.active==True:
            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimermotif)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass

            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()

        else:
                
            tidmotif.text=str(current_row[0])
            tintitulemotif.text=str(current_row[1])

    def affinfosection(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        if sup1.active==True:

            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimerSection)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.15,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass
            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()
        
        else:
            tidsection.text=str(current_row[0])
            tintitulesection.text=str(current_row[1])
        

    def affinfoption(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        if sup2.active==True:
            
            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimerOption)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass

            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()
        else:

            spinsectionId.text=str(current_row[2])
            tintituleoption.text=str(current_row[1])
            tidoption.text=str(current_row[0])

        self.selectSectionsimple(str(current_row[2]))

    def affinfclasse(self,instance_table,current_row):

        global msg,idsup

        idsup=current_row[0]

        if sup3.active==True:

            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimerClasse)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass

            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()
        
        else:
                
            tidclass.text=str(current_row[0])
            tintituleclassA.text=str(current_row[1])
        

    def affinfocommunique(self,instance_table,current_row):
        global tabCommunique

        try:
            idfile=current_row[5]
            idupdate=str(current_row[7])

            ligrep=[lin for lin in tabCommunique if lin[5]==idfile and str(lin[7])==idupdate]

            for k in ligrep:
                a,b,c,d,e,f,g,h=k

            cad=Builder.load_string('''
FloatLayout:
    size:1,1
    
    canvas:
        Color:
            rgb:1,1,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
            
            ''')

            l1=Label(pos_hint={'center_x':.5,'y':.8},size_hint=(.95,.2),color='black',bold=True)

            l2=Label(pos_hint={'center_x':.5,'y':.2},size_hint=(.95,.5),color='black')

            deb=0
            calibre=60
            newtitre=""


            l1.text=str(d)
            l2.text=str(e)

            btclose=Builder.load_string('''
Button:
    text:"Close"
    bold:True
    background_color:[0,0,0,0]
    size_hint:.15,.1
    color:'white'
    pos_hint:{'x':.8,'y':.05}                                         

    canvas:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
            
''')
            btclose.bind(on_release=lambda x: msg.dismiss())

            try:
                cad.add_widget(btclose)
                cad.add_widget(l1)
                cad.add_widget(l2)
            except:
                pass

            try:
                msg=Popup(title="INFO COMMUNIQUE",content=cad,size_hint=(.5,.6))
            except:
                pass

            msg.open()
           
        except Exception as e:
            print(e)

    def affinfannee(self,instance_table,current_row):
        
        global msg,idsup

        idsup=current_row[0]

        if sup4.active==True:

            lb=Label(text="Voulez-vous vraiment suprimer cette information : "+str(current_row[1]),color="black",pos_hint={'center_x':.5,'center_y':.5},bold=True)

            cadd=Builder.load_string('''

FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:15,15,1,1

''')
            
            bt1=Builder.load_string('''
Button:
    text:'Valider'
    pos_hint:{'x':.6,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            
            bt1.bind(on_release=self.supprimerAnne)

            bt2=Builder.load_string('''
Button:
    text:'Annuler'
    pos_hint:{'x':.25,'y':.15}
    size_hint:.25,.08

    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
''')
            bt2.bind(on_release=lambda x :msg.dismiss())
            
            try:
                cadd.add_widget(bt1)
                cadd.add_widget(bt2)
                cadd.add_widget(lb)
            except:
                pass
            
            try:
                msg=Popup(title="CONTROLEUR",content=cadd,size_hint=(.5,.5))
            except:
                pass

            msg.open()
        
        
        else:

            tidanne.text=str(current_row[0])
            tintituleanne.text=str(current_row[1])


    def operationsettingfontion(self,instance):
        
        global msg,sepa

        rep=None

        if tintitulefontion.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.FonctionAjout(tintitulefontion.text,ccon)

                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.FonctionUpdate(int(tidfonction.text),tintitulefontion.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    
                    tintituletranche.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.FonctionRecherche(ccon)

                tabinfonew=[]

                if rep1:
                    tabinfo=rep1[1]

                    if len(tabinfo)<sepa:

                        tabinfonew=tabinfo
                    else:

                        for i in range(sepa):

                            tabinfonew.append(tabinfo[i])


                    tabfontion.row_data=tabinfonew

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()

    def operationsettingtranche(self,instance):
        
        global msg

        rep=None

        if tintituletranche.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.TrancheAjout(tintituletranche.text,ccon)

                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.TrancheUpdate(int(tidtranche.text),tintituletranche.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    
                    tintituletranche.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.TrancheRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabtranche.row_data=tabinfo

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()


    def operationsettingdevise(self,instance):
        
        global msg

        rep=None

        if tintituledevise.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.DevisetAjout(tintituledevise.text,ccon)

                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.DeviseUpdate(int(tiddevise.text),tintituledevise.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    
                    tintituledevise.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.DeviseRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabdevise.row_data=tabinfo

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()

    def operationsettingmotif(self,instance):
        
        global msg

        rep=None

        if tintitulemotif.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.MotifAjout(tintitulemotif.text,ccon)

                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.MotifUpdate(int(tidmotif.text),tintitulemotif.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    
                    tintitulemotif.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.MotifRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabmotif.row_data=tabinfo

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()

    def operationsettingClass(self,instance):
        #tabanne,tidanne,tintituleanne,tabclass,tidclass,tintituleclass

        global msg

        rep=None

        if tintituleclassA.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.classAjout(tintituleclassA.text,ccon)

                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.classUpdate(int(tidclass.text),tintituleclassA.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    
                    tintituleclassA.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.classRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabclass.row_data=tabinfo

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()


    def operationsettingAnne(self,instance):
        
        global msg

        rep=None

        if tintituleanne.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.AnneSColaireAjout(tintituleanne.text,ccon)

                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.AnneSColaireUpdate(int(tidanne.text),tintituleanne.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    
                    tintituleanne.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.Anne_ScolaireRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabanne.row_data=tabinfo

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()


    def clearTitre(self,instance,text):

        if instance.text=="Titre":
            
            instance.text=""

    def clearContenu(self,instance,text):

        if instance.text=="Contenu":
            
            instance.text=""

    def operationSectionsetting(self,instance):

        global msg

        rep=None

        if tintitulesection.text !="":

            try:

                if instance.text=="Sauver":
                    
                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.SectionAjout(tintitulesection.text,ccon)
                    
                else:

                    req=EcoleApp()
                    ccon=self.connecteBD()
                    
                    rep=req.SectionUpdate(int(tidsection.text),tintitulesection.text,ccon)
                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    #tidsection.text=""
                    tintitulesection.text=""

                else:
                    btmsg.text="La requete non terminée"

                    try:
                        msg=Popup(title="ERROR",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()
                
                
                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.SectionRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    tabsection.row_data=tabinfo

            except:
                
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass
                
                msg.open()


    def operationOptionsetting(self,instance):
        global msg,idsection

        rep=None

        if tintituleoption.text !="":

            req=EcoleApp()
            ccon=self.connecteBD()

            try:

                if instance.text=="Sauver":

                    rep=req.OptionAjout(tintituleoption.text,idsection,ccon)

                else:
                    rep=req.OptionUpdate(tidoption.text,tintituleoption.text,idsection,ccon)

                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE OPTION",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    tintituleoption.text=""
                    #tidoption.text=""
                

                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.OptionRecherche(ccon)

                if rep1:
                    tabinfo=rep1[1]

                    taboption.row_data=tabinfo

            except:
            
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass

                msg.open()

    def operationunsersetting(self,instance):

        global msg,idsection,idfonction,sepa

        rep=None

        #tiduser.text=,tnomunser.text=,tpostnomuser.text=,prenomuser.text=,sexuser.text=,fonctionuser.text=,tgmailuser.text=,tpwduser.text=,tadressuser.text=,tphonuser.text=,photonuser.text=str(current_row[10])

        if tiduser.text !="" and tnomunser.text !="" and tpostnomuser.text !="" and  tprenomuser.text !="" and sexuser.text !="" and tgmailuser.text !="" and tpwduser.text !="" and tadressuser.text !="" and tphonuser.text !="":

            req=EcoleApp()
            ccon=self.connecteBD()

            
            try:

                if instance.text=="Sauver":

                    rep=req.UserAjout(random.randint(0,1500),tnomunser.text,tgmailuser.text,tpwduser.text,tpostnomuser.text,tprenomuser.text,tadressuser.text,tphonuser.text,photonuser.text,idfonction,sexuser.text,ccon)
            
                else:
                    rep=req.UserUpdate(tiduser.text,tnomunser.text,tgmailuser.text,tpwduser.text,tpostnomuser.text,tprenomuser.text,tadressuser.text,tphonuser.text,photonuser.text,idfonction,sexuser.text,ccon) 

                
                if rep==True:

                    btmsg.text="Effectué"

                    try:
                        msg=Popup(title="OPERATION DE TABLE ",content=btmsg,size_hint=(.4,.2))
                    except:
                        pass

                    msg.open()

                    tiduser.text =""
                    tnomunser.text =""
                    tpostnomuser.text =""
                    tprenomuser.text =""
                    sexuser.text ="Homme"
                    tgmailuser.text =""
                    tpwduser.text =""
                    tadressuser.text =""
                    tphonuser.text =""


                req=EcoleApp()
                ccon=self.connecteBD()

                rep1=req.UserRecherche(ccon)

                tabinfonew=[]

                if rep1:
                    tabinfo=rep1[1]

                    if len(tabinfo)<sepa:
                    
                        tabinfonew=tabinfo

                    else:

                        for i in range(sepa):

                            tabinfonew.append(tabinfo[i])


                    tabuser.row_data=tabinfonew

            except:
            
                btmsg.text="ERROR inconnue"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.2))
                except:
                    pass

                msg.open()

    def opencourshistoriqueF(self,instance):
        
        try:
            cadreCours.add_widget(cadreCours1)
        except:
            pass
        
        try:
            cadreCours.remove_widget(cadreCours2)
        except:
            pass

    def opencoursperation(self,instance):
        
        try:
            cadreCours.add_widget(cadreCours2)
        except:
            pass
        
        try:
            cadreCours.remove_widget(cadreCours1)
        except:
            pass

    def verifcoursF1(self,instance):

        if instance.active==True:

            checkcours2.active=False
    
    def verifcoursF2(self,instance):

        if instance.active==True:

            checkcours1.active=False

    def verifcoursF4(self,instance):

        if instance.active==True:

            checkcours3.active=False
    
    def verifcoursF3(self,instance):

        if instance.active==True:

            checkcours4.active=False

    def verifAbonneF1(self,instance):

        if instance.active==True:

            checkAbonne2.active=False


    def verifAbonneF2(self,instance):

        if instance.active==True:

            checkAbonne1.active=False

    def verifAbonneF3(self,instance):

        if instance.active==True:

            checkAbonne4.active=False

    def verifAbonneF4(self,instance):

        if instance.active==True:

            checkAbonne3.active=False


    def verifPersF1(self,instance):

        if instance.active==True:

            checkPers2.active=False
    
    def verifPersF2(self,instance):

        if instance.active==True:

            checkPers1.active=False
    
    def verifPersF3(self,instance):

        if instance.active==True:

            checkPers4.active=False

    def verifPersF4(self,instance):

        if instance.active==True:

            checkPers3.active=False


    def openAbonne1F(self,instance):

        try:
            cadreAbonne.add_widget(cadreAbonne1)
        except:
            pass
        
        try:
            cadreAbonne.remove_widget(cadreAbonne2)
        except:
            pass
    
    def openAbonne2F(self,instance):

        try:
            cadreAbonne.add_widget(cadreAbonne2)
        except:
            pass
        
        try:
            cadreAbonne.remove_widget(cadreAbonne1)
        except:
            pass


    def opengestionPersonnel1F(self,instance):

        try:
            cadrePersonnel.add_widget(cadrePersonnel1)
        except:
            pass

        try:
            cadrePersonnel.remove_widget(cadrePersonnel2)
        except:
            pass
    
    def opengestionPersonnel2F(self,instance):

        try:
            cadrePersonnel.add_widget(cadrePersonnel2)
        except:
            pass

        try:
            cadrePersonnel.remove_widget(cadrePersonnel1)
        except:
            pass

    
    def openAttibutions(self,instance):

        try:
            cadreEnseignant.remove_widget(cadreEnseignant1)
        except:
            pass

        try:
            cadreEnseignant.add_widget(cadreEnseignant2)
        except:
            pass
    
    def opengestionEnseignant(self,instance):

        try:
            cadreEnseignant.add_widget(cadreEnseignant1)
        except:
            pass

        try:
            cadreEnseignant.remove_widget(cadreEnseignant2)
        except:
            pass


    def verifEnseignantF1(self,instance): 

        if instance.active==True:

            checkEnseignant2.active=False 

    def verifEnseignantF2(self,instance):

        if instance.active==True:

            checkEnseignant1.active=False
        
    def verifEnseignantF3(self,instance):

        if instance.active==True:

            checkEnseignant4.active=False

    def verifEnseignantF4(self,instance):

        if instance.active==True:

            checkEnseignant3.active=False
    #
    def verifcommF1(self,instance):

        if instance.active==True:

            checkcomm2.active=False 

    def verifcommF2(self,instance):

        if instance.active==True:

            checkcomm1.active=False
        
    def verifcommF3(self,instance):

        if instance.active==True:

            checkcomm4.active=False

    def verifcommF4(self,instance):

        if instance.active==True:

            checkcomm3.active=False
        
    def verifdelib1F(self,instance):

        if instance.active==True:

            checkdelib2.active=False

    def verifdelib2F(self,instance):

        if instance.active==True:

            checkdelib1.active=False
    
    def verifcoteF1(self,instance):

        if instance.active==True:

            checkcote2.active=False  

    def verifcoteF2(self,instance):

        if instance.active==True:
            
            checkcote1.active=False

    def openseliberationF(self,instance):

        try:
            cadreCote.remove_widget(cadreCote1)
        except:
            pass

        try:
            cadreCote.add_widget(cadreCote2)
        except:
            pass

    def openanalysedeliberationF(self,instance):
        
        try:
            cadreCote.add_widget(cadreCote1)
        except:
            pass

        try:
            cadreCote.remove_widget(cadreCote2)
        except:
            pass

    
    def afficheClass(self,instance):
        global idclass,idoption,idsection,idtypeTravail,idEdition

        if checktravau1.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.classFaireTravailRecherche(idoption,idclass,idtypeTravail,idEdition,ccon)

                if res:
                    tabtravaux.row_data=res[1]
            
            except Exception as e:
                
                print(e)
        else:

            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.classFaireTravailRecherche(idoption,idclass,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux.row_data=tabexportnew
            
            except:
                pass

        
    def afficheOption(self,instance):
        global idclass,idoption,idsection

        if checktravau1.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                idoption=int(idoption)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.optionFaireTravailRecherche(idoption,idtypeTravail,idEdition,ccon)

                print(res)

                if res:
                    tabtravaux.row_data=res[1]
            
            except Exception as e:
                print(e)
        else:

            try:
                    
                tabtravaux.row_data=[]

                idoption=int(idoption)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.optionFaireTravailRecherche(idoption,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux.row_data=tabexportnew
            
            except:
                pass
        

    def afficheSection(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail


        if checktravau1.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.sectionFaireTravailRecherche(idsection,idtypeTravail,idEdition,ccon)

                if res:
                    tabtravaux.row_data=res[1]
            
            except:
                pass
        else:

            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.sectionFaireTravailRecherche(idsection,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux.row_data=tabexportnew
            
            except:
                pass
    
    def affichecoursTrav2EnS(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail,idCours

        if checktravauEns2.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.coursFaireTravailRechercheEns(idoption,idclass,idCours,idtypeTravail,idEdition,ccon)
                
                if res:

                    tabtravaux2.row_data=res[1]
            
            except:
                pass
        else:

            try:
                    
                tabtravaux.row_data=[]

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.coursFaireTravailRechercheEns(idoption,idclass,idCours,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux2.row_data=tabexportnew
            
            except:
                pass

    def afficheclassTrav2(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail

        if checktravauEns2.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.classFaireTravailRechercheEns(idoption,idclass,idtypeTravail,idEdition,ccon)
                
                if res:

                    tabtravaux2.row_data=res[1]
            
            except:
                pass
        else:

            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.classFaireTravailRechercheEns(idoption,idclass,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux2.row_data=tabexportnew
            
            except:
                pass


    def afficheoptionTrav2(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail

        if checktravauEns2.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.optionFaireTravailRechercheEns(idoption,idtypeTravail,idEdition,ccon)
                
                if res:

                    tabtravaux2.row_data=res[1]
            
            except:
                pass
        else:

            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.optionFaireTravailRechercheEns(idoption,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux2.row_data=tabexportnew
            
            except:
                pass

    
    def affichecommunication(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail,tabCommunique

        tabCommjourn.row_data=[]
        tabCommunique=[]
        tabexportnew=[]
        tabnewcool=[]

        if checkcomm2.active==True:
            
            try:
                    
                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.affichCommunique(ccon)

                if res:

                    tabexportnew=res[1]

                    tabCommunique=res[1]

                    for lik in tabexportnew:

                        a,b,c,d,e,f,g,h=lik

                        d=str(d)
                        e=str(e)

                        if len(d)>20:
                            dd=d[0:19]+"..."
                        else:
                            dd=d

                        if len(e)>40:
                            ee=e[0:39]+"..."
                        else:
                            
                            ee=e

                        newlin=(a,b,c,dd,ee,f,g,h)

                        tabnewcool.append(newlin)

                    tabCommjourn.row_data=tabnewcool

            except Exception as e:
                print(e)
        else:

            try:
                tabnewcool=[]

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.affichCommunique(ccon)

                if res:
                    tabexport=res[1]
                    
                    tabCommunique=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                        for lik in tabexportnew:

                            a,b,c,d,e,f,g,h=lik

                            d=str(d)
                            e=str(e)

                            if len(d)>20:
                                dd=d[0:19]+"..."
                            else:
                                dd=d

                            if len(e)>40:
                                ee=e[0:39]+"..."
                            else:
                                
                                ee=e

                            newlin=(a,b,c,dd,ee,f,g,h)

                            tabnewcool.append(newlin)
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])

                        for lik in tabexportnew:

                            a,b,c,d,e,f,g,h=lik

                            d=str(d)
                            e=str(e)

                            if len(d)>20:
                                dd=d[0:19]+"..."
                            else:
                                dd=d

                            if len(e)>40:
                                ee=e[0:39]+"..."
                            else:
                                
                                ee=e

                            newlin=(a,b,c,dd,ee,f,g,h)

                            tabnewcool.append(newlin)

                    tabCommjourn.row_data=tabnewcool

            except Exception as e:
                print(e)


    def affichecommunicationNow(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail,dtanew

        tabCommjourn0.row_data=[]
        
        tabCommunique=[]
        tabexportnew=[]
        tabnewcool=[]

        if checkcomm4.active==True:
                
            try:
                    
                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.affichCommuniquenow(dtanew,ccon)

                if res:

                    tabexportnew=res[1]

                    tabCommunique=res[1]

                    for lik in tabexportnew:

                        a,b,c,d,e,f,g,h=lik

                        d=str(d)
                        e=str(e)

                        if len(d)>20:
                            dd=d[0:19]+"..."
                        else:
                            dd=d

                        if len(e)>40:
                            ee=e[0:39]+"..."
                        else:
                            
                            ee=e

                        newlin=(a,b,c,dd,ee,f,g,h)

                        tabnewcool.append(newlin)

                    tabCommjourn0.row_data=tabnewcool

            except Exception as e:
                print(e)

        else:

            try:
                tabnewcool=[]

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.affichCommuniquenow(dtanew,ccon)

                if res:
                    tabexport=res[1]
                    
                    tabCommunique=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                        for lik in tabexportnew:

                            a,b,c,d,e,f,g,h=lik

                            d=str(d)
                            e=str(e)

                            if len(d)>20:
                                dd=d[0:19]+"..."
                            else:
                                dd=d

                            if len(e)>40:
                                ee=e[0:39]+"..."
                            else:
                                
                                ee=e

                            newlin=(a,b,c,dd,ee,f,g,h)

                            tabnewcool.append(newlin)
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])

                        for lik in tabexportnew:

                            a,b,c,d,e,f,g,h=lik

                            d=str(d)
                            e=str(e)

                            if len(d)>20:
                                dd=d[0:19]+"..."
                            else:
                                dd=d

                            if len(e)>40:
                                ee=e[0:39]+"..."
                            else:
                                
                                ee=e

                            newlin=(a,b,c,dd,ee,f,g,h)

                            tabnewcool.append(newlin)

                    tabCommjourn0.row_data=tabnewcool

            except Exception as e:
                print(e)


    def afficheSectionTrav2(self,instance):
        global idclass,idoption,idsection,idEdition,idtypeTravail

        if checktravauEns2.active==True:
                
            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.sectionFaireTravailRechercheEns(idsection,idtypeTravail,idEdition,ccon)
                
                if res:

                    tabtravaux2.row_data=res[1]
            
            except:
                pass
        else:

            try:
                    
                tabtravaux.row_data=[]

                idsection=int(idsection)

                req=EcoleApp()

                ccon=self.connecteBD()

                res=req.sectionFaireTravailRechercheEns(idsection,idtypeTravail,idEdition,ccon)

                if res:
                    tabexport=res[1]

                    if len(tabexport)<sepa:

                        tabexportnew=tabexport
                        
                    else:

                        for li in range(sepa):

                            tabexportnew.append(tabexport[li])
        
                    tabtravaux2.row_data=tabexportnew
            
            except:
                pass

    def updatetypetravail(self,instance):
        global ttravupdate,tablup,msginforeab
        
        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''
Button:
    text:"Close."
    color:'white'
    pos_hint:{'x':0.75, 'y':.8}
    size_hint:(0.2,0.1)
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]                                                
   
''')
        btvalquestion2.bind(on_release=self.closeMidCours)

        btupdate=Builder.load_string('''

Button:
    text:"Sauver."
    color:'white'
    pos_hint:{'x':.5,'y': .8}
    size_hint:.2,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btupdate.bind(on_release=self.updatetravail)

        
        ttravupdate=MDTextField(hint_text='Intitulé(Pas d espace)',pos_hint={'x':.05,'y':.8},size_hint=(.4,.15),line_color_normal='black')
        

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailRecherche(ccon)

            tabva=[]

            if res:

                tabva=res[1]

        except:
            pass

        tablup=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35)),
            ("ETAT",dp(40))
            ], row_data=tabva,size_hint=(0.9,0.7),pos_hint={'center_x':0.5,'y':.03},check=True,rows_num=2000,use_pagination=True)
        tablup.bind(on_check_press=self.selectelement)

        try:
            cad.add_widget(tablup)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(ttravupdate)
            cad.add_widget(btupdate)
        except:
            pass

        
        try:

            msginforeab=Popup(title='MISE A JOUR',content=cad,size_hint=(.4,.5))
        except:
            pass
        try:
            msginforeab.open()
        except:
            pass

    def ajouttypetravail(self,instance):
        global ttrav,tabltype,msginforeab

        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

Button:
                                           
    background_color:[0,0,0,0]
    text:"Close"
    bold:True
    pos_hint:{'x':0.75, 'y':.8}
    size_hint:(0.2,0.1)
    color:'white'
                                           
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]                         
   
''')
        btvalquestion2.bind(on_release=self.closeMidCours)

        btsauver=Builder.load_string('''

Button:
    text:"Sauver."
    color:'white'
    pos_hint:{'x':.5,'y': .8}
    size_hint:.2,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        btsauver.bind(on_release=self.savetypetravail)

        
        ttrav=MDTextField(hint_text='Intitulé(Pas d espace)',pos_hint={'x':.05,'y':.8},size_hint=(.4,.15),line_color_normal='black')
        
        tabltype=MDDataTable(column_data=[
            ("ID",dp(20)),
            ("NAME",dp(35)),
            ("CREE ",dp(35)),
            ("MODIFIE",dp(35)),
            ("ETAT",dp(40))
            ], row_data=[],size_hint=(0.9,0.7),pos_hint={'center_x':0.5,'y':.03},check=True,rows_num=2000,use_pagination=True)
        
        
        
        try:
            cad.add_widget(tabltype)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(ttrav)
            cad.add_widget(btsauver)
        except:
            pass

        
        try:
            msginforeab=Popup(title='AJOUT',content=cad,size_hint=(.4,.5))
        except:
            pass
        
        try:
            msginforeab.open()
        except:
            pass
    
    def closeMidCours(self,instance):
        global  tabinstance,tabval,msginforeab

        try:
            msginforeab.dismiss()
        except:
            pass
        
        for li in tabinstance:

            try:
                cadreTravauxhaut.remove_widget(li)
            except:
                pass
        
        tabinstance=[]
        res=[]

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailRecherche(ccon)

        except:

            try:
                msg=Popup(title='EROOR',content=Button(text="Error !!"),size_hint=(.4,.3))
            except:
                pass
            try:
                msg.open()
            except:
                pass

        tabval=[]

        if res:
            tabval=res[1]

            for lig in tabval:

                a,b,c,d,e=lig

                tt=str(b)

                b=Builder.load_string('''
Button:
    bold:True
    size_hint:.15,.4
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10,10,1,1]
''')
                
                b.text=str(tt)
                b.bind(on_release=self.opentypeTravailF)

                tabinstance.append(b)

                try:
                    cadreTravauxhaut.add_widget(b)
                except:
                    pass


    def selectelement(self,instance_table,current_row):
        global ttravupdate,idsel
    
        try:
                
            idsel=int(current_row[0])
            ttravupdate.text=str(current_row[1])
        
        except Exception as e:

            print(e)

    def updatetravail(self,instance):
        global idsel,ttravupdate,tablup

        bt=Builder.load_string('''
Button:
    size_hint:.9,.7
    color:'black'
    bold:True
                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')

        try:

            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailUpdate(idsel,ttravupdate.text,ccon)

            if res==True:

                tabval=[]

                ccon=self.connecteBD()

                res=req.TypeTravailRecherche(ccon)

                if res:

                    tabval=res[1]

                    tablup.row_data=tabval

                bt.text="Effectué !!"

                msg=Popup(title="SYSTEME",content=bt,size_hint=(.4,.2))
                msg.open()
            
        except:

            bt.text="EROOR"

            msg=Popup(title="SYSTEME",content=bt,size_hint=(.4,.2))
            msg.open()

    def savetypetravail(self,instance):
        global ttrav,tabltype

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res1=req.TypeTravailAjout(random.randint(0,100),ttrav.text,ccon)

            if res1==True:

                ccon=self.connecteBD()

                res=req.TypeTravailRecherche(ccon)

                tabva=[]

                if res:

                    tabva=res[1]

                    ttrav.text=""
                
                tabltype.row_data=tabva

        except:
            pass

    def opendevoir(self,instance):
                
        try:
            cadreTravaux.add_widget(cadreTravaux1)

            cadreTravaux.remove_widget(cadreTravaux2)
            cadreTravaux.remove_widget(cadreTravaux3)

        except:
            pass
    
    def openinterro(self,instance):
                
        try:
            cadreTravaux.add_widget(cadreTravaux2)

            cadreTravaux.remove_widget(cadreTravaux1)
            cadreTravaux.remove_widget(cadreTravaux3)

        except:
            pass

    def openexamen(self,instance):

        try:
            cadreTravaux.add_widget(cadreTravaux3)

            cadreTravaux.remove_widget(cadreTravaux2)
            cadreTravaux.remove_widget(cadreTravaux1)

        except:
            pass

    def openjournalpaiement(self,instance):

        try:
            cadrePaiement.add_widget(cadrePaiement2)
        except:
            pass

        try:
            cadrePaiement.remove_widget(cadrePaiement1)
        except:
            pass


    def openpaiement(self,instance):

        try:
            cadrePaiement.remove_widget(cadrePaiement2)
        except:
            pass

        try:
            cadrePaiement.add_widget(cadrePaiement1)
        except:
            pass
    
    def verifTravEnsF2(self,instance): 
        
        if instance.active==True:

            checktravauEns1.active=False

    def verifTravEnsF1(self,instance):
        
        if instance.active==True:

            checktravauEns2.active=False

    def verifTrvaux1(self,instance): 

        if instance.active==True:

            checktravau2.active=False
    
    def verifTrvaux2(self,instance):

        if instance.active==True:

            checktravau1.active=False
    

    def verifpaieF1(self,instance):

        if instance.active==True:

            checkpaie2.active=False

    def verifpaieF2(self,instance):

        if instance.active==True:

            checkpaie1.active=False


    def triAZF1(self,instance):

        if instance.active==True:

            triAZ2.active=False
    
    def triAZF2(self,instance):

        if instance.active==True:

            triAZ1.active=False
    
    def openaccueilPage(self,instance):

        # venant de page de connexion

        try:
            cadre.add_widget(cadreAccueil)
        except:
            pass

        try:
             
            cadre.add_widget(bmenu)

        except:
            pass

        try:
            cadre.remove_widget(cadreconnexion)
        except:
            pass
    
        # en etant dans le programme 

        try:
            cadre.remove_widget(men2)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreInscription) 
        except:
            pass

        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass


        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

    def inscriptionF(self,instance):

        try:
            cadre.remove_widget(men2)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass

        try:
            cadre.add_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

    def eleveGestionF(self,instance):

        try:
            cadre.add_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass


    def openGestioncpoursF(self,instance):

        try:
            cadre.add_widget(cadreCours)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass


        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

    def openPaimentF(self,instance):

        global tabvalClass

        self.chargeClassSimplePaie()

        try:
            cadre.add_widget(cadrePaiement)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass


        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass
    
    def openCotePage(self,instance):

        try:
            cadre.add_widget(cadreCote)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass

    def openTravauxPage(self,instance):
        global tabinstance,tabval

        try:
            cadre.add_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass

        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass


        for li in tabinstance:

            try:
                cadreTravauxhaut.remove_widget(li)
            except:
                pass
        
        tabinstance=[]
        res=[]

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.TypeTravailRecherche(ccon)

        except:
            msg=Popup(title='EROOR',content=Button(text="Error !!"),size_hint=(.4,.3))
            msg.open()
        
        tabval=[]

        if res:
            tabval=res[1]

            for lig in tabval:

                a,b,c,d,e=lig

                tt=str(b)

                b=Builder.load_string('''
Button:
    bold:True
    size_hint:.15,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10,10,1,1]
''')
                
                b.text=str(tt)
                b.bind(on_release=self.opentypeTravailF)

                tabinstance.append(b)

                try:
                    cadreTravauxhaut.add_widget(b)
                except:
                    pass
    
    def openCommunication(self,instance):
        try:
            cadre.add_widget(cadreCommunication)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass


        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass

    def openGestionEnseignant(self,instance):
    
        global tabvalFoctionew,tabvalFoctionewInstance

        try:
            cadre.add_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass


        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass

        for li in tabvalFoctionewInstance:

            try:
                cadreEnsignanthaut.remove_widget(li)
            except:
                pass
        
        tabvalFoctionew=[]

        tabvalFoctionewInstance=[] 

        res=[]

        try:
            req=EcoleApp()

            ccon=self.connecteBD()

            res=req.FonctionRecherche(ccon)

        except:
            msg=Popup(title='EROOR',content=Button(text="Error !!"),size_hint=(.4,.3))
            msg.open()

        if res:
            tabvalFoctionew=res[1]

            for lig in tabvalFoctionew:

                a,b,c,d=lig

                tt=str(b)

                b=Builder.load_string('''
Button:
    bold:True
    size_hint:.1,.5
    pos_hint:{'center_y':.5}
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[10,10,1,1]
''')
                
                b.text=str(tt)
                b.bind(on_release=self.openFonctionF)

                tabvalFoctionewInstance.append(b) 

                try:
                    cadreEnsignanthaut.add_widget(b)
                except:
                    pass

    def openPersonnelF(self,instance):

        try:
            cadre.add_widget(cadrePersonnel)
        except:
            pass

        try:
            cadre.remove_widget(cadreAbonne)
        except:
            pass

        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass

    def openAbonneF(self,instance):

        try:
            cadre.add_widget(cadreAbonne)
        except:
            pass
        
        try:
            cadre.remove_widget(cadreEleve)
        except:
            pass

        try:
            cadre.remove_widget(cadrePersonnel)
        except:
            pass

        try:
            cadre.remove_widget(cadreEnseignant)
        except:
            pass

        try:
            cadre.remove_widget(cadreCommunication)
        except:
            pass

        try:
            cadre.remove_widget(cadreTravaux)
        except:
            pass
        
        try:
            cadre.remove_widget(cadrePaiement)
        except:
            pass

        try:
            cadre.remove_widget(men2)
        except:
            pass

        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadreCote)
        except:
            pass

        try:
            cadre.remove_widget(cadreCours)
        except:
            pass

    def openCommuniqueF(self,instance):

        try:
            cadreCommunication.add_widget(cadreCommunication1)
        except:
            pass
        try:
            cadreCommunication.remove_widget(cadreCommunication2)
        except:
            pass
    
    def openEleve2(self,intance):

        try:
            cadreEleve.remove_widget(cadreELeve1)
        except:
            pass

        try:
            cadreEleve.add_widget(cadreELeve2)
        except:
            pass
        
    def openEleve1(self,intance):

        try:
            cadreEleve.remove_widget(cadreELeve2)
        except:
            pass

        try:
            cadreEleve.add_widget(cadreELeve1)
        except:
            pass


    def openjournalComminiquerF(self,instance):

        try:
            cadreCommunication.remove_widget(cadreCommunication1)
        except:
            pass
        try:
            cadreCommunication.add_widget(cadreCommunication2)
        except:
            pass
    
    def openFonctionF(self,instance):

        global tabvalFoctionew,idfonction

        try:
            lign=[li for li in tabvalFoctionew if li[1]==instance.text]

            for i in lign:
                a,b,c,d=i

            idfonction=int(a)

            b=str(b)

            labtitrePersonnel.text="GESTION  " + b.upper()
            
        except Exception as e:
            
            print(e)

    def opentypeTravailF(self,instance):

        global tabval,idtypeTravail

        try:
            lign=[li for li in tabval if li[1]==instance.text]

            for i in lign:
                a,b,c,d,e=i

            idtypeTravail=int(a)

            ititreTravaux.text="[ELEVE] GESTION  " + b.upper()

            ititreTravaux2.text="[ENSEIG..] GESTION  " + b.upper()

        except Exception as e:
            
            print(e)


    def deconnexion(self,instance):

        try:
                
            cadre.add_widget(cadreconnexion)

            cadre.remove_widget(cadreAccueil)
            cadre.remove_widget(bmenu)
        
        except:
            pass

    def opendiagramme(self,instance):
        instance.values=""

        try:
            lisv=['Baton','Circulaire']

            for i in lisv:
                instance.values.append(i)
        except:
            pass

    def openaffichage(self,instance):
        instance.values=""

        try:
            lisv=['Dynamique','Fixe']

            for i in lisv:
                instance.values.append(i)
        except:
            pass
        
    def openlecturesyncho(self,instance):
        instance.values=""

        try:
            lisv=['Synchrone','Asynchrone']

            for i in lisv:
                instance.values.append(i)
        except:
            pass

    def openmodulation(self,instance):

        instance.values=""

        try:
            lisv=['Frequence','Amplitude']

            for i in lisv:
                instance.values.append(i)
        except:
            pass
    
    def verifeleveF1(self,instance):

        if instance.active==True:
            checkeleve2.active=False
    
    def verifeleveF2(self,instance):

        if instance.active==True:
            checkeleve1.active=False

    def verifeleveF4(self,instance):

        if instance.active==True:
            checkeleve3.active=False

    def verifeleveF3(self,instance):

        if instance.active==True:
            checkeleve4.active=False

    def verifanalyse1(self,instance):
        if instance.active==True:
            check2A.active=False
    
    def verifanalyse2(self,instance):
        if instance.active==True:
            check1A.active=False
            
    def verif1(self,instance):
        if instance.active==True:
            check2.active=False
    
    def verif2(self,instance):
        if instance.active==True:
            check1.active=False

    def chargeClassUP(self): 
        
        global tabvalClass
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.classRecherche(ccon)

            if listval:

                tabvalClass=listval[1]

        except:
            pass
    
    def chargeClassSimplePaie(self): 
        
        global tabvalClass
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.classRecherche(ccon)

            tabvalClass=listval[1]

        except:
            pass

    def chargeClass(self,instance): 
        
        global tabvalClass

        instance.values=""
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.classRecherche(ccon)

            tabvalClass=listval[1]

            for lig in tabvalClass:
                a,b,c,d=lig

                instance.values.append(b)
        except:
            pass

    def selectClass(self,instance,text):

        global tabvalClass,idclass

        try:

            res=[lig for lig in tabvalClass if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idclass=int(a)
        except:
            pass


    def chargeFonctionUP(self):
        
        global tabvalFonction
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.FonctionRecherche(ccon)

            if listval:

                tabvalFonction=listval[1]

        except:
            pass    

    def chargeFonction(self,instance):
        
        global tabvalFonction

        instance.values=""
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.FonctionRecherche(ccon)

            tabvalFonction=listval[1]

            for lig in tabvalFonction:
                a,b,c,d=lig

                instance.values.append(b)
        except:
            pass


    def selectFonction(self,instance,text):

        global tabvalFonction,idfonction

        try:
            res=[lig for lig in tabvalFonction if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idfonction=int(a)
        
        except:
            pass
        
    def chargeEditionUP(self):
        
        global tabvalEdition
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.Anne_ScolaireRecherche(ccon)

            if listval:

                tabvalEdition=listval[1]

        except:
            pass
    

    def chargeCours(self,instance):
        
        global tabvalCours,idoption,idclass

        instance.values=""
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.CoursRechercheProx(idoption,idclass,ccon)

            if listval:
                    
                tabvalCours=listval[1]

                for lig in tabvalCours:
                    a,b,c,d,e,f,g,h=lig

                    instance.values.append(b)

        except Exception as e:
            print(e)
        
    def selectCours(self,instance,text):

        global tabvalCours,idCours

        try:
            res=[lig for lig in tabvalCours if lig[1]==instance.text]

            for li in res:
                a,b,c,d,e,f,g,h=li

            idCours=int(a)
        
        except Exception as e:
            print(e)

    def chargePeriode(self,instance):
        
        global tabvalPeriode

        instance.values=""
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.PeriodeRecherche(ccon)

            if listval:
                    
                tabvalPeriode=listval[1]

                for lig in tabvalPeriode:
                    a,b,c,d=lig

                    instance.values.append(b)

        except:
            pass
        
    def selectPeriode(self,instance,text):

        global tabvalPeriode,idPeriode

        try:
            res=[lig for lig in tabvalPeriode if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idPeriode=int(a)
        
        except:
            pass

    def chargeEdition(self,instance):
        
        global tabvalEdition

        instance.values=""
        
        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.Anne_ScolaireRecherche(ccon)

            if listval:
                    
                tabvalEdition=listval[1]

                for lig in tabvalEdition:
                    a,b,c,d=lig

                    instance.values.append(b)

        except:
            pass
        
    def selectEdition(self,instance,text):

        global tabvalEdition,idEdition

        try:
            res=[lig for lig in tabvalEdition if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idEdition=int(a)
        
        except:
            pass

    def chargeOptionProx(self,instance):

        global tabvalSectionprox,idsection

        try:

            instance.values=""
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.optionProxRecherche(idsection,ccon)

            tabvalSectionprox=listval[1]

            
            for lig in tabvalSectionprox:
                a,b,c,d,e=lig

                instance.values.append(b)
            
        except:
            pass

    def selectOptionProx(self,instance,text):

        global tabvalSectionprox,idoption

        try:

            res=[lig for lig in tabvalSectionprox if lig[1]==instance.text]

            for li in res:
                a,b,c,d,e=li

            idoption=int(a)

        except:
            pass
    

    def chargeSectionUP(self): 
        
        global tabvalSection

        try:
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.SectionRecherche(ccon)

            if listval:

                tabvalSection=listval[1]

        except:
            pass
    

    def chargeTranche(self,instance): 
        
        global tabvalTranche

        try:
            cadrePaiement1.remove_widget(btpaie)
        except:
            pass

        tx3.text=""
        tx2.text=""
        tx1.text=""
            
        try:
                
            instance.values=""
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.TrancheRecherche(ccon)

            if listval:
                tabvalTranche=listval[1]
                
                for lig in tabvalTranche:
                    a,b,c,d=lig

                    instance.values.append(b)
        except:
            pass


    def selectTranche(self,instance,text):

        global tabvalTranche,idTranche,idTypePaie,tabfiltrepro,idEdition

        try:

            res=[lig for lig in tabvalTranche if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idTranche=int(a)

            #btpaie,tabfiltrepro

            if tabfiltrepro:

                for li in tabfiltrepro:
                    a,b,c,d,e,f,g,h,j,k,l,m,n=li

                idEleve=int(a)

                requete=EcoleApp()
                ccon=self.connecteBD()

                
                listval=requete.verifpaiement(idEleve,idTypePaie,idTranche,idEdition,ccon)

                if listval:
                    
                    tabval=listval[1]

                    if tabval:

                        for i in tabval:
                            a,b,c=i

                        tx3.text=str(c)
                        tx2.text=str(a)
                        tx1.text=str(b)                        
                        
                        try:
                            cadrePaiement1.remove_widget(btpaie)
                        except:
                            pass

                    else:

                        try:
                            cadrePaiement1.add_widget(btpaie)
                        except:
                            pass

        except:
            pass
        

    def chargeTypePaie(self,instance): 
        
        global tabvalTypePaie

        try:
                
            instance.values=""
            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.MotifRecherche(ccon)

            if listval:
                tabvalTypePaie=listval[1]
                
                for lig in tabvalTypePaie:
                    a,b,c,d=lig

                    instance.values.append(b)
        except:
            pass
        

    def selectTypePaie(self,instance,text):

        global tabvalTypePaie,idTypePaie

        try:

            res=[lig for lig in tabvalTypePaie if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idTypePaie=int(a)

        except:
            pass


    def chargeMotif(self,instance): 
        
        global tabvalMotif

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.MotifRecherche(ccon)

        if listval:
            tabvalMotif=listval[1]
            
            for lig in tabvalMotif:
                a,b,c,d=lig

                instance.values.append(b)


    def selectMotif(self,instance,text):

        global tabvalMotif,idmotif

        try:

            res=[lig for lig in tabvalMotif if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idmotif=int(a)

        except:
            pass

    def chargeSection(self,instance): 
        
        global tabvalSection

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        listval=requete.SectionRecherche(ccon)

        if listval:
            tabvalSection=listval[1]
            
            for lig in tabvalSection:
                a,b,c,d=lig

                instance.values.append(b)


    def selectSection(self,instance,text):

        global tabvalSection,idsection

        try:

            res=[lig for lig in tabvalSection if lig[1]==instance.text]

            for li in res:
                a,b,c,d=li

            idsection=int(a)

        except:
            pass    
    
    def selectSectionsimple(self,idd):

        global idsection

        try:

            requete=EcoleApp()
            ccon=self.connecteBD()

            listval=requete.SectionRecherche(ccon)
            
            tabvalSection=listval[1]
        

            if tabvalSection:

                res=[lig for lig in tabvalSection if lig[1]==idd]

                for li in res:
                    a,b,c,d=li

                idsection=int(a)

        except:
            pass

    def selectOption(self,instance,text):
        global tabvalOption,idoption

        try:
            res=[lig for lig in tabvalOption if lig[1]==instance.text]

            for li in res:
                a,b,c,d,e=li

            idoption=int(a)

            

        except:
            pass

        
    def chargeoptionUP(self):
        global tabvalOption

        requete=EcoleApp()
        ccon=self.connecteBD()

        try:
            listval=requete.OptionRecherche(ccon)

            tabvalOption=listval[1]

        except:
            pass

    def chargeoption(self,instance):
        global tabvalOption

        instance.values=""
        requete=EcoleApp()
        ccon=self.connecteBD()

        try:
            listval=requete.OptionRecherche(ccon)

            tabvalOption=listval[1]

            for lig in tabvalOption:
                a,b,c,d,e=lig

                instance.values.append(b)
        except:
            pass

    def chargesexe(self,instance):

        instance.values=""

        listS=['Homme','Femme'] 

        try:
            for i in range(len(listS)):
                instance.values.append(listS[i]) 
        except:
            pass

    
    def efface(self,instance,value):

        instance.text=""

    def ponderationPlus(self,instance):
        global spinponderation

        try:
            if int(spinponderation.text)<50:

                spinponderation.text=str(int(spinponderation.text)+1)
        except:
            pass

    def ponderationmoins(self,instance):
        global spinponderation

        try:
            if int(spinponderation.text)>1:

                spinponderation.text=str(int(spinponderation.text)-1)
        except:
            pass

    def jourmoins(self,instance):

        try:
            if int(jour.text)>1:

                jour.text=str(int(jour.text)-1)
        except:
            pass

    def jourplus(self,instance):

        if int(jour.text)<31:
            try:
                jour.text=str(int(jour.text)+1)
            except:
                pass

    def moismoins(self,instance):

        try:
            if int(mois.text)>1:

                mois.text=str(int(mois.text)-1)
        except:
            pass
    

    def moisplus(self,instance):
            
        try:
            if int(mois.text)<12:
                mois.text=str(int(mois.text)+1)
        except:
            pass

    def annmoins(self,instance):
        try:
            ann.text=str(int(ann.text)-1)
        except:
            pass
    
    def annplus(self,instance):
    
        try:
            ann.text=str(int(ann.text)+1)
        except:
            pass 

    def chargejour(self,instance):
        instance.values=""

        for i in range(32):

            instance.values.append(str(i))
    
    def chargemois(self,instance):

        instance.values=""

        for i in range(13):
            
            instance.values.append(str(i))

    def chargeAnne(self,instance):

        instance.values=""

        for i in range(2005,2020):
            
            instance.values.append(str(i))

    
    def openacceuil(self,instance):

        try:
            cadre.add_widget(cadreAccueil)
        except:
            pass
        try:
            cadre.remove_widget(cadreInscription)
        except:
            pass
    
    def operationinscription(self,instance):
        global msg
        
        req=None
        reqqq=None

        iduser=random.randint(0,5000)

        try:

            datee=ann.text+"-"+mois.text+"-"+jour.text

            if instance.text=="Enregistrer":

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.InscriptionAjout(t2.text,t3.text,t4.text,t5.text,t6.text,t7.text,idclass,idoption,idEdition,datetime.strptime(datee,'%Y-%m-%d'),t8.text,t9.text,t10.text,t11.text,ccon)

                if req==True:

                    bd=EcoleApp()

                    ccon=self.connecteBD()

                    reqq=bd.UserAjout(iduser,t2.text,str(random.randint(0,5000)),"-",t3.text,t4.text,"--",t7.text,'rien.png',idfonction,cc1.text,ccon)

                    if reqq==True:

                        bd=EcoleApp()

                        ccon=self.connecteBD()

                        matricule=t2.text[0]+ str(random.randint(0,5000)) +t3.text[2]

                        
                        reqqq=bd.EleveAjout(t2.text,t3.text,t4.text,matricule,t11.text,iduser,idclass,idoption,idEdition,ccon)
            
            elif instance.text=="Supprimer":
                
                pass 

            else:

                bd=EcoleApp()

                ccon=self.connecteBD()

                req=bd.InscriptionUpdate(t1.text,t2.text,t3.text,t4.text,t5.text,t6.text,t7.text,idclass,idoption,idEdition,datetime.strptime(datee,'%Y-%m-%d'),t8.text,t9.text,t10.text,t11.text,ccon)

                if req==True:

                    bd=EcoleApp()

                    ccon=self.connecteBD()

                    reqq=bd.UserUpdate(t1.text,t2.text,str(random.randint(0,5000)),"-",t3.text,t4.text,"--",t7.text,'rien.png',idfonction,cc1.text,ccon)

                    if reqq==True:

                        bd=EcoleApp()

                        ccon=self.connecteBD()

                        matricule=t2.text[0]+ str(random.randint(0,5000)) +t3.text[2]

                        reqqq=bd.ElveUpdate(t1.text,t2.text,t3.text,t4.text,t11.text,idclass,idoption,idEdition,ccon)

            if reqqq==True:

                btmsg.text="Effectué !!"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.3))
                except:
                    pass

                msg.open()

                t1.text=""
                t2.text=""
                t3.text=""
                t4.text=""

                ann.text=""
                mois.text=""
                jour.text=""

                t8.text=""
                t10.text=""
                t11.text=""
                t5.text=""
                t6.text=""
                t7.text=""

                c2.text=""
                c1.text=""
                c3.text=""
                c4.text=""

                c5.text=""

                cc1.text=""
                t9.text=""

                t14.text=""
                t15.text=""

                t16.text=""

                t16.text="Description"
        except:

            btmsg.text="ERROR !!"

            try:
                msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.3))
            except:
                pass

            msg.open()           

    def openinsertion(self,instance):
        global idclass,idoption,idEdition

        btsave.text="Enregistrer"

        try:
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription2)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription3)
        except:
            pass

    
    def confirmerPaie(self,instance):
        global idclass,idTypePaie,idTranche,idEdition,idEleve,msg

        try:
            bd=EcoleApp()
            ccon=self.connecteBD()

            etat=bd.PaiementAjout(10,1,idTypePaie,idEleve,idclass,idTranche,idEdition,1,ccon)

            try:
                msg.dismiss()
            except:
                pass

            if etat==True:

                btmsg.text="Effectué !"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.5,.2))
                except:
                    pass

                try:
                    msg.open()
                except:
                    pass    

            else:

                btmsg.text="ERROR ! Veuillez réssayer plus tard !"

                try:
                    msg=Popup(title="SYSTEME",content=btmsg,size_hint=(.4,.5))
                except:
                    pass

                try:
                    msg.open()
                except:
                    pass


        except Exception as e:
            print(e)


    def payerVersement(self,instance):
        global msg

        if paiec4.text=="Choisir":

            pass
        
        else:

            cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
        
    ''')
        
            btvalquestion2=Builder.load_string('''

Button:
    text:"Annuler"
    color:'white'
    pos_hint:{'x':.65,'y': .8}
    size_hint:.3,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]                                              
   
''')
            btvalquestion2.bind(on_release=lambda x:msg.dismiss())

            btpayer=Builder.load_string('''

Button:
    text:"Confirmer"
    color:'white'
    pos_hint:{'x':.65,'y': .6}
    size_hint:.3,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
            btpayer.bind(on_release=self.confirmerPaie)

            tdetail=Label(text="NET : "+" 50000 USD",pos_hint={'center_x':.4,'center_y':.5},size_hint=(.3,.1),color='black',bold=True)

            try:
                cad.add_widget(tdetail)
                cad.add_widget(btpayer)
                
                cad.add_widget(btvalquestion2)
                
            except:
                pass

            try:
                msg=Popup(title="PAIEMENT SCOLAIRE",content=cad,size_hint=(.4,.5))
            except:
                pass

            try:
                msg.open()
            except:
                pass

    def chargerechupdate(self,instance,text):
        global tabinfoupdate

        
        try:

            res=[li for li in tabinfoupdate if li[1]==instance.text]

            for lign in res:
                a,b=lign

                bd=EcoleApp()
                ccon=self.connecteBD()

                rep=bd.InscriptionRechercheMatricule(a,ccon)

                if rep:
                    tabinfo=rep[1]

                    for lin in tabinfo:

                        i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19,i20,i21=lin

                        t1.text=str(i1)
                        t2.text=str(i2)
                        t3.text=str(i3)
                        t4.text=str(i4)

                        dat=str(i5)
                        dat=dat.split("-")

                        ann.text=dat[0]
                        mois.text=dat[1]
                        jour.text=dat[2]

                        t8.text=str(i6)
                        t10.text=str(i7)
                        t11.text=str(i8)
                        t5.text=str(i9)
                        t6.text=str(i10)
                        t7.text=str(i11)

                        c2.text=str(i20)
                        c1.text=str(i13)
                        c3.text=str(i12)
                        c4.text=str(i14)

                        c5.text=str(i19)

                        cc1.text=str(i18)

                        t9.text=str(i17)

                        t14.text=str(i15)
                        t15.text=str(i16)

                        t14.disabled=True
                        t15.disabled=True

                        t16.text=str(i21)
                        
                        
                        #idclass
                        #idoption
                        #idEdition
                        #datetime.strptime(datee,'%Y-%m-%d')
                        
                        
                        
                        #c2,c1,c3,c4//sexe cc1// ann,mois,jour//c5 fontion

                        

        except:
            
            pass

        
    def rechupdate(self,instance):
        global idsection,idoption,idclass,tabinfoupdate,idrech
        
        instance.values=""

        try:
            bd=EcoleApp()
            conn=self.connecteBD()

            rep=bd.rechupdateInscription(idoption,idclass,idrech.text,conn)

            if rep:

                tabinfoupdate=rep[1]

                for li in tabinfoupdate:

                    a,b=li

                    instance.values.append(str(b))

        except:
            pass

        

    def openupdate(self,instance):
        global msginforeab,idrech,tabvalSection,tabvalOption,tabvalClass,tabvalFonction,tabvalEdition

        
        self.chargeSectionUP()
        self.chargeoptionUP()
        self.chargeClassUP()
        
        self.chargeEditionUP()
        self.chargeFonctionUP()

        btsave.text="Modifier"

        try:
            cadreInscription.add_widget(cadreInscription1)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription2)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription3)
        except:
            pass


        cad=Builder.load_string('''
FloatLayout:
                                    
    size_hint:1,1

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
    
        
    ''')
        
        btvalquestion2=Builder.load_string('''

Button:
    text:"Close"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.75,'center_y': .2}
    size_hint:.2,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
                                                
   
''')
        btvalquestion2.bind(on_release=lambda x:msginforeab.dismiss())

        section=Builder.load_string('''

Spinner:
    text:"Section"
    color:'white'
    pos_hint:{'x':.07,'center_y': .7}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]

''')
        section.bind(on_release=self.chargeSection)
        section.bind(text=self.selectSection)

        option=Builder.load_string('''

Spinner:
    text:"Option"
    color:'white'
    pos_hint:{'x':.37,'center_y': .7}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        #option.bind(on_release=self.chargeoption)

        option.bind(on_release=self.chargeOptionProx)
        option.bind(text=self.selectOptionProx)

        classe=Builder.load_string('''

Spinner:
    text:"Classe"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.7,'center_y': .7}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]
''')
        
        classe.bind(on_release=self.chargeClass)
        classe.bind(text=self.selectClass)

        idrech=MDTextField(hint_text='Rechercher par ID',pos_hint={'x':.05,'center_y':.4},size_hint=(.4,.15),line_color_normal='black')
        
        comborech=Builder.load_string('''

Spinner:
    text:"Choisir"
    color:'white'
    font_size:'15sp'
    pos_hint:{'x':.5,'center_y': .4}
    size_hint:.45,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15]


''')
        comborech.bind(on_release=self.rechupdate)

        comborech.bind(text=self.chargerechupdate)
        
        try:
            cad.add_widget(classe)
            cad.add_widget(option)
            cad.add_widget(section)
            
            cad.add_widget(btvalquestion2)
            cad.add_widget(idrech)
            cad.add_widget(comborech)
        except:
            pass

        
        try:
            msginforeab=Popup(title='RECHERCHE',content=cad,size_hint=(.4,.5))
        except:
            pass

        msginforeab.open()


    def openUser(self,instance):
        global msg,btclose,cadv

        try:
            cadv.remove_widget(btclose)
        except:
            pass
    
        try:
            cadv.remove_widget(cadresettinguser)
        except:
            pass


        cadv=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        Rectangle:
            size:self.size
            pos:self.pos
''')
        
        try:
            cadv.add_widget(btclose)
        except:
            pass
    
        try:
            cadv.add_widget(cadresettinguser)
        except:
            pass
        try:
            msg=Popup(title="USER",content=cadv,size_hint=(1,1))
        except:
            pass

        msg.open()

    def openjournalinscription(self,instance):

        try:
            cadreInscription.add_widget(cadreInscription2)
        except:
            pass

        try:
            cadreInscription.remove_widget(cadreInscription1)
        except:
            pass

        try:
            cadreInscription.remove_widget(cadreInscription3)
        except:
            pass


    def openanalyse(self,instance):

        try:
            cadreInscription.add_widget(cadreInscription3)
        except:
            pass

        try:
            cadreInscription.remove_widget(cadreInscription1)
        except:
            pass
        try:
            cadreInscription.remove_widget(cadreInscription2)
        except:
            pass

    def on_start(self):

        try:
            #self.root.ids.cadregauche.parent.remove_widget(self.root.ids.cadregauche)
            etatmenu=1
        except:
            pass
    
    def retourAccueil(self,instance):
        
        try:
            cadre.add_widget(bmenu)
        except:
            pass
        try:
            cadre.add_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
           
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
           
            cadre.remove_widget(cadsettinghaut)
        except:
            pass

    def opensetting(self,instance):
        try:
            cadre.remove_widget(bmenu)
        except:
            pass
        try:
            cadre.remove_widget(cadreAccueil)
        except:
            pass

        try:
            cadre.add_widget(cadresetting1)
        except:
            pass

        try:
           
            cadre.add_widget(cadsettinghaut)
        except:
            pass

    def settinguser(self, instance):

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
           
            cadre.add_widget(cadresettinguser)
        except:
            pass

        try:
            cadre.remove_widget(cadresettingadmin)
        except:
            pass

    def settingprince(self,instance):

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
            cadre.add_widget(cadresetting1)
        except:
            pass
        
        try:
            cadre.remove_widget(cadresettingadmin)
        except:
            pass

    def settingpaiement(self,instance): 

        try:
           
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
           
            cadre.add_widget(cadresettingpaiemnt)
    
        except:
            pass

        try:
            cadre.remove_widget(cadresettingadmin)
        except:
            pass

    def settingadministration(self,instance):

        try:
           
            cadre.remove_widget(cadresettinguser)
        except:
            pass

        try:
            cadre.remove_widget(cadresetting1)
        except:
            pass

        try:
            cadre.remove_widget(cadresettingpaiemnt)
        except:
            pass

        try:
            cadre.add_widget(cadresettingadmin)
        except:
            pass

    def affmenugacuhe(self,instance):
        global etatmenu

        if etatmenu==0:

            #men2.size_hint=(.3,.8)
            try:
                cadre.add_widget(men2)
            except:
                pass
            

            etatmenu=1
        else:
            #men2.size_hint=(0,0)

            try:
                cadre.remove_widget(men2)
            except:
                pass

            etatmenu=0

        pass
    
    def affmenu(self, instance):
        pass
    
    def connecteBD(self):

        con=True

        return con

if __name__=="__main__":

    EcolAppApp().run()