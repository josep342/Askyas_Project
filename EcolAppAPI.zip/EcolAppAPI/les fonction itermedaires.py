 # les fonction itermedaires

def affichAttributionSection(self,v1,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,sections.name,options.name,classes.name,cours.name,cours.ponderation,anne_scolaires.name,cour_enseigners.created_at,cour_enseigners.updated_at from users,options,sections,cour_enseigners,cours,anne_scolaires,classes where cours.classes_id=classes.id and cours.id=cour_enseigners.cours_id and cour_enseigners.annee_id=anne_scolaires.id and options.id=cours.options_id and options.section_id=sections.id and cour_enseigners.users_id=users.id and sections.id=%s order by users.name ASC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def affichUserSection(self,v1,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,fonctions.name,users.email,users.password,users.address,users.phone,users.file,users.created_at,users.updated_at from users,fonctions where fonctions.id=users.fonction_id and fonctions.id=%s and users.status='1' order by users.updated_at DESC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=False

    return etat,listinfo

def affichCommuniquenowMid(self,dat,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.id,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.updated_at>=%s and communiques.status='1' order by communiques.updated_at DESC",(dat,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def affichCommuniquenow(self,dat,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.updated_at>=%s and communiques.status='1' order by communiques.updated_at DESC",(dat,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def affichCommunique(self,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.status='1' order by communiques.updated_at DESC")
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo


def coursFaireTravailRechercheEns(self,v1,v2,v3,v4,v5,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and classes.id=%s and travails.cours_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,v4,v5,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def classFaireTravailRechercheEns(self,v1,v2,v3,v4,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and classes.id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,v4,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def optionFaireTravailRechercheEns(self,v1,v2,v3,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def sectionFaireTravailRechercheEns(self,v1,v2,v3,con):

    try:
        cursor=con.cursor()
        cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.section_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def classFaireTravailRecherche(self,v1,v2,v3,v4,con):

    try:
        cursor=con.cursor()
        cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and eleves.options_id=%s and eleves.classes_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,v4,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def optionFaireTravailRecherche(self,v1,v2,v3,con):

    try:
        cursor=con.cursor()
        cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and eleves.options_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def sectionFaireTravailRecherche(self,v1,v2,v3,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and options.section_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo


def coteRecherheCours(self,v1,v2,v3,v4,v5,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.periode_id=%s and cotes.cours_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,v4,v5,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def coteRecherhePeriode(self,v1,v2,v3,v4,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.periode_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,v4,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def coteRecherheClass(self,v1,v2,v3,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def coteRecherheOption(self,v1,v2,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def coteRecherheSection(self,v1,v2,con):

    try:

        cursor=con.cursor()
        cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def motifRecherhePaiement(self,v1,v2,v3,v4,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.classes_id=%s and paiements.motifs_id=%s and paiements.annee_id=%s and paiements.classes_id=classes.id order by paiements.updated_at DESC",(v1,v2,v3,v4,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def classRecherhePaiement(self,v1,v2,v3,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.classes_id=%s and paiements.annee_id=%s and paiements.classes_id=classes.id order by paiements.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def optionRecherhePaiement(self,v1,v2,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and  paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.annee_id=%s order by paiements.updated_at DESC",(v1,v2,))
        #cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.updated_at from paiements,eleves,users,classes,options,anne_scolaires,sections where paiements.eleves_id=eleves.id and users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def sectionRecherhePaiement(self,v1,v2,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and  paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and paiements.annee_id=%s order by paiements.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo


def recupMontant(self,v1,v2,con):

    try:
        cursor=con.cursor()
        cursor.execute("select montant,updated_at,users_id from paiements where eleves_id=%s and motifs_id=%s and tranches_id=%s and annee_id=%s",(v1,v2))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def verifpaiement(self,v1,v2,v3,v4,con):

    try:
        cursor=con.cursor()
        cursor.execute("select montant,updated_at,users_id from paiements where eleves_id=%s and motifs_id=%s and tranches_id=%s and annee_id=%s",(v1,v2,v3,v4))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo


def coursRechercheUniqueSectionNow(self,v1,con):

    datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

    dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

    try:
        cursor=con.cursor()
        cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and sections.id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,dtt,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def coursRechercheUniqueOptionNow(self,v1,con):

    datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

    dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

    try:
        cursor=con.cursor()
        cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,dtt,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def coursRechercheUniqueClassNow(self,v1,v2,con):

    datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

    dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

    try:
        cursor=con.cursor()
        cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.classes_id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,v2,dtt,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

# now fin

def coursRechercheUniqueSection(self,v1,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and sections.id=%s order by cours.updated_at DESC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def coursRechercheUniqueOption(self,v1,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s order by cours.updated_at DESC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def coursRechercheUniqueClass(self,v1,v2,con):

    try:
        cursor=con.cursor()
        cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.classes_id=%s order by cours.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def classRecherheUniqueeleveNow(self,v1,v2,v3,con):

    datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

    dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,v3,dtt,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def optionRecherheUniqueeleveNow(self,v1,v2,con):

    datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

    dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,dtt,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def sectionRecherheUniqueeleveNow(self,v1,v2,con):

    datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

    dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,dtt,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def classRecherheUniqueeleve(self,v1,v2,v3,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,v3,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def optionRecherheUniqueeleve(self,v1,v2,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def sectionRecherheUniqueeleve(self,v1,v2,con):

    try:

        cursor=con.cursor()
        cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def ClassRecherheUnique(self,v1,v2,con):

    try:
        cursor=con.cursor()
        cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and inscriptions.options_id=%s and inscriptions.classes_id=%s order by inscriptions.updated_at DESC",(v1,v2,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def OptionRecherheUnique(self,v1,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and inscriptions.options_id=%s order by inscriptions.updated_at DESC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def sectionRecherheUnique(self,v1,con):

    try:
        cursor=con.cursor()
        cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and sections.id=%s order by inscriptions.updated_at DESC",(v1,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e
    
    return etat,listinfo

def InscriptionRechercheMatricule(self,v1,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,anne_scolaires.name,inscriptions.created_at,inscriptions.updated_at,inscriptions.nationalite,users.sexe,fonctions.name,sections.name,eleves.description from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.matricule='"+v1+"'")
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=False

    return etat,listinfo

def rechupdateInscription(self,opt,cla,mat,con):

    try:
        cursor=con.cursor()
        cursor.execute("select matricule,name from eleves where status=%s and options_id=%s and classes_id=%s and matricule like'%"+mat+"%' order by name ASC",('1',opt,cla,))
        listinfo=cursor.fetchall()
        con.close()

        etat=True

    except Exception as e:
        listinfo=[]
        etat=e

    return etat,listinfo

def  optionProxRecherche(self,v1,con):

    try:
        cursor=con.cursor()
        cursor.execute("select options.id,options.name,sections.name,options.created_at,options.updated_at from options,sections where options.status='1' and options.section_id=sections.id and sections.status=%s and options.section_id=%s order by updated_at DESC",('1',v1,))     
        listinfo=cursor.fetchall()   
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def TravailRechercheIntIdClass(self,v1,v2,v3,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s and cours.options_id=%s and cours.classes_id=%s",(v1,v2,v3,))     
        listinfo=cursor.fetchall()   
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def TravailRechercheIntIdOption(self,v1,v2,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s and cours.options_id=%s",(v1,v2,))     
        listinfo=cursor.fetchall()   
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo

def TravailRechercheIntIdSection(self,v1,con):
    
    try:
        cursor=con.cursor()
        cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s",(v1,))     
        listinfo=cursor.fetchall()   
        con.close()

        etat=True

    except:
        listinfo=[]
        etat=False

    return etat,listinfo
