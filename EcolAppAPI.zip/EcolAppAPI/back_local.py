import mysql.connector
from datetime import datetime

class EcoleApp:

    def __init__(self):
        
        pass
    
    # les fonction itermedaires

    def affichAttributionSection(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,sections.name,options.name,classes.name,cours.name,cours.ponderation,anne_scolaires.name,cour_enseigners.created_at,cour_enseigners.updated_at from users,options,sections,cour_enseigners,cours,anne_scolaires,classes where cours.classes_id=classes.id and cours.id=cour_enseigners.cours_id and cour_enseigners.annee_id=anne_scolaires.id and options.id=cours.options_id and options.section_id=sections.id and cour_enseigners.users_id=users.id and sections.id=%s order by users.name ASC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def affichUserSection(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,fonctions.name,users.email,users.password,users.address,users.phone,users.file,users.created_at,users.updated_at from users,fonctions where fonctions.id=users.fonction_id and fonctions.id=%s and users.status='1' order by users.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def affichCommuniquenowMid(self,dat,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.id,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.updated_at>=%s and communiques.status='1' order by communiques.updated_at DESC",(dat,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def affichCommuniquenow(self,dat,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.updated_at>=%s and communiques.status='1' order by communiques.updated_at DESC",(dat,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def affichCommunique(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.status='1' order by communiques.updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    

    def coursFaireTravailRechercheEns(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and classes.id=%s and travails.cours_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,v4,v5,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def classFaireTravailRechercheEns(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and classes.id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def optionFaireTravailRechercheEns(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def sectionFaireTravailRechercheEns(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.section_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def classFaireTravailRecherche(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and eleves.options_id=%s and eleves.classes_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo

    def optionFaireTravailRecherche(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and eleves.options_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def sectionFaireTravailRecherche(self,v1,v2,v3,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and options.section_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    

    def coteRecherheCours(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.periode_id=%s and cotes.cours_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,v4,v5,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def coteRecherhePeriode(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.periode_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def coteRecherheClass(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def coteRecherheOption(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def coteRecherheSection(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def motifRecherhePaiement(self,v1,v2,v3,v4,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.classes_id=%s and paiements.motifs_id=%s and paiements.annee_id=%s and paiements.classes_id=classes.id order by paiements.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def classRecherhePaiement(self,v1,v2,v3,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.classes_id=%s and paiements.annee_id=%s and paiements.classes_id=classes.id order by paiements.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def optionRecherhePaiement(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and  paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.annee_id=%s order by paiements.updated_at DESC",(v1,v2,))
            #cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.updated_at from paiements,eleves,users,classes,options,anne_scolaires,sections where paiements.eleves_id=eleves.id and users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherhePaiement(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and  paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and paiements.annee_id=%s order by paiements.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    
    def recupMontant(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select montant,updated_at,users_id from paiements where eleves_id=%s and motifs_id=%s and tranches_id=%s and annee_id=%s",(v1,v2))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def verifpaiement(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select montant,updated_at,users_id from paiements where eleves_id=%s and motifs_id=%s and tranches_id=%s and annee_id=%s",(v1,v2,v3,v4))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo


    def coursRechercheUniqueSectionNow(self,v1,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and sections.id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def coursRechercheUniqueOptionNow(self,v1,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def coursRechercheUniqueClassNow(self,v1,v2,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.classes_id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,v2,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    # now fin

    def coursRechercheUniqueSection(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and sections.id=%s order by cours.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def coursRechercheUniqueOption(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s order by cours.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def coursRechercheUniqueClass(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.classes_id=%s order by cours.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def classRecherheUniqueeleveNow(self,v1,v2,v3,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,v3,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def optionRecherheUniqueeleveNow(self,v1,v2,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherheUniqueeleveNow(self,v1,v2,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def classRecherheUniqueeleve(self,v1,v2,v3,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def optionRecherheUniqueeleve(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherheUniqueeleve(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def ClassRecherheUnique(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and inscriptions.options_id=%s and inscriptions.classes_id=%s order by inscriptions.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def OptionRecherheUnique(self,v1,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and inscriptions.options_id=%s order by inscriptions.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherheUnique(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and sections.id=%s order by inscriptions.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def InscriptionRechercheMatricule(self,v1,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,anne_scolaires.name,inscriptions.created_at,inscriptions.updated_at,inscriptions.nationalite,users.sexe,fonctions.name,sections.name,eleves.description from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.matricule='"+v1+"'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=False

        return etat,listinfo

    def rechupdateInscription(self,opt,cla,mat,con):

        try:
            cursor=con.cursor()
            cursor.execute("select matricule,name from eleves where status=%s and options_id=%s and classes_id=%s and matricule like'%"+mat+"%' order by name ASC",('1',opt,cla,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def  optionProxRecherche(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select options.id,options.name,sections.name,options.created_at,options.updated_at from options,sections where options.status='1' and options.section_id=sections.id and sections.status=%s and options.section_id=%s order by updated_at DESC",('1',v1,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def TravailRechercheIntIdClass(self,v1,v2,v3,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s and cours.options_id=%s and cours.classes_id=%s",(v1,v2,v3,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TravailRechercheIntIdOption(self,v1,v2,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s and cours.options_id=%s",(v1,v2,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def TravailRechercheIntIdSection(self,v1,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s",(v1,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    

    # fontions principales

    def UserAjout(self,iduser,v2,gmail,v4,v6,v7,v8,v9,v10,v11,v12,con):
        
        try:
            cursor=con.cursor()
            query="insert into users(id,name,email,email_verified_at,password,remember_token,created_at,updated_at,first_name,last_name,address,phone,file,fonction_id,status,sexe) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(iduser,v2,gmail,"0000-00-00",v4,"",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v6,v7,v8,v9,v10,v11,1,v12)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except Exception as e:
            etat=False

        return etat
    

    def UserRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,fonctions.name,users.email,users.password,users.address,users.phone,users.file,users.created_at,users.updated_at from users,fonctions where fonctions.id=users.fonction_id and users.status='1' order by users.updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def UserUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,con):

        try:
            cursor=con.cursor()
            query="update users set name=%s,email=%s,password=%s,updated_at=%s,first_name=%s,last_name=%s,address=%s,phone=%s,file=%s,fonction_id=%s,sexe=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v5,v6,v7,v8,v9,v10,v11,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def UserDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update users set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def TypeTravailAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into type_travails(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa) 
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TypeTravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from type_travails where status='1' order by type_travails.created_at ASC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TypeTravailUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update type_travails set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TypeTravailDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update type_travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def TravailAjout(self,v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="insert into travails(id,title,description,date_de_remise,cours_id,type_travails_id,annee_id,created_at,updated_at,file,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TravailUpdate(self,v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="update travails set title=%s,description=%s,date_de_remise=%s,cours_id=%s,type_travails_id=%s,annee_id=%s,updated_at=%s,file=%s where id=%s"
            dataa=(v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TravailDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def TrancheAjout(self,v1,con):

        try:
            cursor=con.cursor()
            query="insert into tranches(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v1,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TrancheRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from tranches where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TrancheUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update tranches set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TrancheDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update tranches set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def SectionAjout(self,v2,con):

        try:
            cursor=con.cursor()
            query="insert into sections(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def SectionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from sections where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def SectionUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update sections set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def SectionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update sections set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def PeriodeAjout(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into periodes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def PeriodeRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from periodes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PeriodeUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update periodes set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def PeriodeDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update periodes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat




    def PaiementAjout(self,v2,v3,v4,v5,v6,v7,v8,v9,con):
        
        try:
            cursor=con.cursor()
            query="insert into paiements(montant,devises_id,motifs_id,eleves_id,classes_id,tranches_id,annee_id,created_at,updated_at,users_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v2,v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def PaiementRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from paiements")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PaiementUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,con):

        try:
            cursor=con.cursor()
            query="update paiements set montant=%s,devises_id=%s,motifs_id=%s,eleves_id=%s,classes_id=%s,tranches_id=%s,annee_id=%s,updated_at=%s,users_id=%s where id=%s"
            dataa=(float(v2),v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    
    def OptionAjout(self,v2,v3,con):

        try:
            cursor=con.cursor()
            query="insert into options(name,section_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def OptionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select options.id,options.name,sections.name,options.created_at,options.updated_at from options,sections where options.status='1' and options.section_id=sections.id and sections.status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def OptionUpdate(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="update options set name=%s,section_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def OptionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update options set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat




    def MotifAjout(self,v1,con):

        try:
            cursor=con.cursor()
            query="insert into motifs(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v1,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def MotifRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from motifs where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def MotifUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update motifs set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def MotifDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update motifs set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def InscriptionAjout(self,v2,v3,v4,v5,v6,v7,v8,v9,v10,datenaiss,v12,v13,v14,v15,con):

        try:
            cursor=con.cursor()
            query="insert into inscriptions(name,first_name,last_name,ecole_provenance,percent,phone,classes_id,options_id,annee_id,created_at,updated_at,status,date_naissance,lieu_de_naissance,nationalite,nom_parent,postnom_parent) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1,datenaiss,v12,v13,v14,v15)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def InscriptionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from inscriptions where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def InscriptionUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,con):
        try:
            cursor=con.cursor()
            query="update inscriptions set name=%s,first_name=%s,last_name=%s,ecole_provenance=%s,percent=%s,phone=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s,date_naissance=%s,lieu_de_naissance=%s,nationalite=%s,nom_parent=%s,postnom_parent=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v11,v12,v13,v14,v15,int(v1))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def InscriptionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update inscriptions set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def HoraireAjout(self,v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="insert into horaires(id,title,image,classes_id,options_id,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def HoraireRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from horaires where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def HoraireUpdate(self,v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="update horaires set title=%s,image=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def HoraireDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update horaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def FonctionAjout(self,v1,con):

        try:
            cursor=con.cursor()
            query="insert into fonctions(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v1,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def FonctionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from fonctions where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FonctionUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update fonctions set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def FonctionDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update fonctions set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def FaireTravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from faire_travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FaireTravailDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update faire_travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def EleveAjout(self,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="insert into eleves(name,first_name,last_name,matricule,description,users_id,classes_id,options_id ,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def EleveRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,eleves.description,users.name,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def ElveUpdate(self,v1,v2,v3,v5,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="update eleves set name=%s,first_name=%s,last_name=%s,description=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v5,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def EleveDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update eleves set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def DeviseRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from devises where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def DeviseUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update devises set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def DeviseDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update devises set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def DevisetAjout(self,v1,con):

        try:
            cursor=con.cursor()
            query="insert into devises(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v1,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    



    def CoursEnseignantRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cour_enseigners")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursEnseignantUpdate(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="update cour_enseigners set cours_id=%s,users_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursEnseignantAjout(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="insert into cour_enseigners(id,cours_id,users_id,annee_id,created_at,updated_at) values(%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat

    def CoursRechercheProx(self,v1,v2,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.options_id=%s and cours.classes_id=%s and cours.status='1' order by cours.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' order by cours.updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursUpdate(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="update cours set name=%s,ponderation=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update cours set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CoursAjout(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="insert into cours(name,ponderation,classes_id,options_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat


    def CommuniqueRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from communiques where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CommuniqueUpdate(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update communiques set title=%s,content=%s,file=%s,users_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CommuniqueDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update communiques set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CommuniqueAjout(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="insert into communiques(title,content,file,users_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat



    def Anne_ScolaireRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from anne_scolaires where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def AnneSColaireUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def AnnScolaireDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def AnneSColaireAjout(self,v1,con):

        etat=1

        try:
            cursor=con.cursor()
            query="insert into anne_scolaires(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v1,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),etat)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from classes where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
        


    def classAjout(self,v1,con):

        etat=1

        try:
            cursor=con.cursor()
            query="insert into classes(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            dataa=(v1,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),etat)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update classes set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def classDelete(self,v1,con):

        try:
            cursor=con.cursor()
            query="update classes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def connecteBD():

        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con

        except:
            pass
