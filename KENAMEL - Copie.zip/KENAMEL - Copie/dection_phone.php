<?php
function isMobileDevice() {
    // Récupérer le User-Agent de la requête HTTP
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
   
    // Liste des mots-clés pour identifier les appareils mobiles
    $mobileKeywords = array(
        'Mobile', 'Android', 'Silk/', 'Kindle', 'BlackBerry', 'Opera Mini', 'IEMobile', 'Windows Phone'
    );
   
    // Vérifier si le User-Agent contient l'un des mots-clés
    foreach ($mobileKeywords as $keyword) {
        if (stripos($userAgent, $keyword) !== false) {
            return true; // C'est un appareil mobile
        }
    }
   
    return false; // C'est probablement une machine
}

// Exemple d'utilisation
if (isMobileDevice()) {
    echo "Vous utilisez un appareil mobile.";
} else {
    echo "Vous utilisez un ordinateur.";
}
?>