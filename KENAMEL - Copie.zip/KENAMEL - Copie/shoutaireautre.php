<?php

if(isset($_POST['clossession'])){
	
}
	

 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<form actio="" method="POST">
	<br><br>
	<hr style="border: 10px solid tomato; box-shadow: 8px 6px 4px black">
	<div style="width: 100%; height: 300px; background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))">
		<br>
		<table style="margin-left: 3%">
			<tr>
				<td style="width: 500px; height: 80px">
				<a href="" style="font-size: 35px">Services Systemes</a>		
				</td>
			
				<td>
					<a href="" style="font-size: 35px">Parametres Généraux</a>
				</td>
			</tr>

			<tr>
				<td style="width: 500px; height: 80px">
				<a href="" style="font-size: 35px">Criptographie Unicole</a>		
				</td>
			
				<td>
					<a href="" style="font-size: 35px">Crackage Ultra simplexe</a>
				</td>
			</tr>

			<tr>
				<td style="width: 500px; height: 80px">
				<a href="" style="font-size: 35px"> Robustesse asynchrone</a>		
				</td>
			
				<td>
					<input type="submit" name="clossession" value=" ?" style="font-size: 35px;border-left: none; border-top: none; border-right: none; border-color: Indigo; background-color:rgba(0,0,0,0); color:Indigo">
				</td>
			</tr>
		</table>
		
	</div>
</form>

</body>
</html>