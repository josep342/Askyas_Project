<?php 
$idd=($_GET['ident']);

$idprod="";
$nm="";
$model="";
$type="";
$pu="";
$stock="";

include("conn.php");

if (isset($_POST['retour'])) 
{
	header('location:commandeadmin.php?ident='.$idd.'');

}

if(isset($_POST['aff'])) 
{
	$nom=($_POST['nomprod']);
	
	$sql1=mysql_query("select id_prod,nom,model,type,stock_initial,stock_courant from produit where nom='".$nom."'");


     while ($ligne=mysql_fetch_array($sql1)) 
     	{
        	$idprod=$ligne['id_prod'];
        	$nm=$ligne['nom'];
        	$model=$ligne['model'];
        	$type=$ligne['type'];
        	$pu=$ligne['stock_courant'];
        	$stock=$ligne['stock_initial'];

		}
	}
			       

if(isset($_POST['ravitaillement'])) 
{
	$idprod=($_POST['idpromodif']);

	$nom=($_POST['nom']);
	$model=($_POST['modele']);
	$type=($_POST['typee']);
	
	$idprod=($_POST['idpromodif']);
	$stockkinitial=($_POST['stock']);
	$stockcourant=($_POST['pu']);

	$qtajout=($_POST['qtajour']);

	$ann=($_POST['annees']);
	$moiss=($_POST['moiss']);
	$jjosur=($_POST['jourr']);

	$datnew=$ann."-".$moiss."-".$jjosur;

	try
	{
		$stockkinitial= $stockkinitial+$qtajout;
		$stockcourant= $stockcourant+$qtajout;

		if($stockkinitial=="" || $stockcourant==""||$qtajout==""||$ann=="" ||$moiss=="" ||$jjosur=="")
			{
				echo '<script>alert("il faut remplir tous les champs")</script>';	

				$idprod=$idprod;
				$nm=$nom;
				$model=$model;
				$type=$type;
				$stock=$stockkinitial;
				$pu=$stockcourant;
				
			}
			else
			{
				$dattime=date('Y-m-d H:m:s');

				$sqlmod=mysql_query("update produit set stock_initial='".$stockkinitial."',stock_courant='".$stockcourant."',date_exp='".$datnew."' where id_prod='".$idprod."'");
			
			    if($sqlmod)
			    {
			    	echo '<script>alert("La mise à jour effectuée avec succes")</script>';

			    }
			    else
			    {
			    	echo '<script>alert(ERROR!!,veuillez reessayer plus tard ")</script>';
			    }
				
			}

	}
	catch(Execption $ex)
	{
		echo '<script>alert("Calcul impossible, il faut respecter la casse de donnees")</script>';
	}

	

}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body><!--onload="ouverture()"--!-->

	<div style="width: 100%; height: 1700px; background-color: aliceblue">
		<center>
			<H1 style="background-color: tomato; color:white; font-size: 50px; box-shadow: 5px 13px 5px gray;" >RAVITAILLEMENT DE PRODUITS</H1>
			<form action="" method="POST">

				<input type="submit" name="retour" value="Retour" onclick="retourconnexion()" style=" font-size: 45px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue; margin-left: 80%;text-shadow: black 1px 2px 1px"><br><br><br>
			</form>	

		<form action="" method="POST">

			<input type="text" value="<?php echo $idprod; ?>" name="idpromodif" style="font-size: 40px ; font-weight: bold;box-shadow: 1px 2px 1px gray; text-shadow: 1px 1px 1px ; width: 150px; height: 80px; margin-left: 0%; border-top: none; border-bottom: none; border-left: none; border-right: none;background-color: aliceblue">

			<input type="submit" name="aff" value="Afficher" style="width: 200px; height: 60px;color:white;background-color: black; font-size: 18px; margin-left: 46%">
			<br><br><br>

			<input type="text" name="tprod" placeholder="Rechercher" value="" style=" font-size: 40px; border-right: none; border-top: none; border-left:none;background-color: aliceblue;text-shadow: black 1px 2px 1px; width: 25%;border-top-color: black;box-shadow: 1px 2px 1px gray">
			<input type="submit" name="chargeridpro" value="Rechercher" style="width: 10%; height: 50px;color:white;background-color: black; font-size: 18px">

			<select id="nomprod" name="nomprod" style=" font-size: 40px; width:40%; border-color: tomato;margin-left: 5%" > 
				<option> Choisir</option>


			<?php 
			
			if(isset($_POST['chargeridpro'])) 
			{
				$nom=($_POST['tprod']);
				try
				{
					$sql1=mysql_query("select nom from produit where nom like'%".$nom."%'");

				     while ($ligne=mysql_fetch_array($sql1)) 
				     	{
				        	$idprod=$ligne['nom'];

							echo '<option>'.$idprod.'</option>';
						}

					echo '<script>alert("Chargement reussi!")</script>';

				}
				catch(Execption $ex)
				{

					echo '<script>alert("Une erreur inattendue !!")</script>';

				}

			}	


		?>

			</select>
			

			<br><br><br><br><br>

		<input type="text" id="nom" value="<?php echo $nm; ?>" name="nom" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Nom du produit ">

			<br><br><br><br><br>
			
		<input type="text" id="modele" value="<?php echo $model;?>" name="modele" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Modele(Facultatif)">

			<br><br><br><br><br>

			<table style="margin-left: 10%">
				<tr>
					<td style=" font-size: 45px;font-weight: bold;">Type</td>
					<td style="width: 100px"></td>
					<td>
						<select id="typee"  name="typee" style=" font-size: 45px; width: 450px; border-color: tomato" > 
							<option><?php echo $type; ?></option>
							<option>Lotion</option>
							<option>Pomade</option>
							<option>Autres</option>

						</select>
					</td>
				</tr>
			</table>


			<br><br><br><br><br>

		<input type="text"  id="pu" value="<?php echo $pu; ?>" name="pu" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Stock courant">

			<br><br><br><br><br>

		<input type="text" id="stock" value="<?php echo $stock; ?>" name="stock" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Stock initial ">

		<br><br>
		<input type="text" name="qtajour" placeholder="Qte" style="width: 10%; margin-left: 70%; border-top: none; border-left: none; border-right: none;font-size: 30px;border-color:tomato">
		<br><br><br> 

		<h3 style="background-color: gray; color:blue; text-shadow: 1px 2px 1px white;font-size: 45px">Expiration</h3>

		<b style="font-weight: bold;font-size: 25px; text-shadow: 1px 2px 1px gray">Annee</b>
		<select id="annees" name="annees" style=" font-size: 40px;font-weight: bold; width: 100px; border-color: tomato" > 
				<option> </option>
				<option>2024</option>
				<option>2025</option>
				<option>2026</option>
				<option>2027</option>
		</select>
		
		<b style="font-weight: bold;font-size: 25px; text-shadow: 1px 2px 1px gray">Mois</b>
		<select id="moiss" name="moiss" style=" font-size: 40px;font-weight: bold; width: 100px; border-color: tomato" > 
				<option> </option>
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
				<option>5</option>
				<option>6</option>
				<option>7</option>
				<option>8</option>
				<option>9</option>
				<option>10</option>
				<option>11</option>
				<option>12</option>
		</select>
		<b style="font-weight: bold;font-size: 25px; text-shadow: 1px 2px 1px gray">Jour</b>
		<select name="jourr" id="jourr" style=" font-size: 40px;font-weight: bold; width: 100px; border-color: tomato">
			<option></option>
				<option>1</option>
				<option>15</option>
				<option>30</option>
		</select>
			<br><br><br><br><br>


		<input type="submit" name="ravitaillement" value="Ravitaillez-en" style="font-size:50px; border-color: tomato; margin-left: 45%; background-color: tomato; color:white; font-weight: bold; box-shadow: 3px 8px 2px gray">	
		<br><br><br><br><br><br>	

 </form>

</center>
		
	</div>

<script>	
	var iddd=document.getElementById('idd');
	var nom=document.getElementById('nom');
	var prenom=document.getElementById('prenom');
	var sexe=document.getElementById('sexe');
	var tel=document.getElementById('tel');
	var ville=document.getElementById('ville');
	var pays=document.getElementById('pays');
	var sej=document.getElementById('sejour');

	function ouverture(){
		alert("Veuillez repondre correctement aux différentes questions \n Afin de pouvoir nous permettre de décider si c'est réellement ton compte\n \n NB Veuillez vous rassurer si c'est bien répondu avant d'envisager passer à la suivante question ");
	}
	function desactive1(){
		iddd.disabled = true;
	}
	function desactive2(){
		nom.disabled = true;
	
	}
	function desactive3(){
		prenom.disabled = true;
	
	}
	function desactive4(){
		sexe.disabled = true;
	
	}
	function desactive5(){
		tel.disabled = true;
	
	}
	function desactive6(){
		ville.disabled = true;
	
	}
	function desactive7(){
		pays.disabled = true;
	
	}
	

</script>

</body>
</html>