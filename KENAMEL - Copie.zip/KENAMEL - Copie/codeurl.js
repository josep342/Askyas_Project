//function popup(){
//	window.open('index.php','nul','width=800, height=800,toolbar=no,scrollbars=no,location=no,resizable=no');
//}
const { createPool } = require('mysql');
const pool = createPool({
	host: 'localhost', 
	user: 'askyas', 
	password: 'askyas',
	database: 'hotel', 
	connectionLimit:10
})
pool.query('select * from session',(err, result,fields)=>{
	if(err){ 
		return console.log(err);
		throw err;
	}
	console.log(result);

})
