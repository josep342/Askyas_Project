<?php 
$idcliendisp="";

include("conn.php");

if (isset($_POST['envoyer'])) {
	
	$nom=($_POST['nom']);
	$prenom=($_POST['prenom']);
	$sexe=($_POST['sexe']);
	$tel=($_POST['tel']);

	$adresse=($_POST['adresse']);

	$idd=($_POST['idd']);
	$pwd=($_POST['pwd']);
    $pwd1=($_POST['pwd1']);

    $idclien=$idd;

	if($pwd!="" && $pwd1!="" && $idd!=""&& $adresse!=""&&$tel!="" &&$sexe!=""&&$prenom!=""&&$nom!=""){

		if($pwd==$pwd1){
        	try{
				$datee=date('Y-m-d');
		        mysql_query("insert into client values ('$idd','$nom','$prenom','$sexe','$tel','$adresse','$datee')");

		        mysql_query("insert into compte values ('$idd','$pwd','user')");

		        echo'<script> alert("compte créé et activé avec succes ")</script>';

		        $idcliendisp=$idd;

				
			    }
		    catch(Exception $e){

				echo'<script> alert("Erreur survenue , veuillez ressayer plus tard !! ")</script>';
		    	
			    }
    	}
    	else{
        	echo'<script> alert("PWD non conforme")</script>';
					    	
    }


	}
	else{
		 echo'<script> alert("Aucun champ ne peut etre vide")</script>';
	}

	}

	?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body><!--onload="ouverture()"--!-->

	<div style="width: 100%; height: 1700px; background-color: aliceblue">
		<center>
			<H1 style="background-color: tomato; color:white; font-size: 50px; box-shadow: 5px 13px 5px gray;" >CREATION DU COMPTE UTILISATEUR</H1>

				<input type="button" name="" value="Retour" onclick="retourconnexion()" style=" font-size: 45px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue; margin-left: 80%;text-shadow: black 1px 2px 1px"><br><br><br>
						

			<br><br><br><br><br>
<form action="" method="POST">

		<input type="text" id="nom" name="nom" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Veuillez inserer ton nom">

			<br><br><br><br><br>
			
		<input type="text" id="prenom" name="prenom" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Veuillez inserer ton prenom">

			<br><br><br><br><br>

			<table style="margin-left: 48%">
				<tr>
					<td style=" font-size: 45px;font-weight: bold;">Sexe</td>
					<td style="width: 100px"></td>
					<td>
						<select id="sexe" name="sexe" style=" font-size: 45px;font-weight: bold; width: 100px; border-color: tomato" > 
							<option> </option>
							<option>M</option>
							<option>F</option>

						</select>
					</td>
				</tr>
			</table>


			<br><br><br><br><br>

		<input type="text"  id="tel" name="tel" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Tel (ex: +243 970494397)">

			<br><br><br><br><br>

		<input type="text" id="adresse" name="adresse" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Adresse(ex:Lemba,UNIKIN..)">

		<br><br><br><br><br> 

		<input type="text" name="idd" id="idd" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="E-mail(akyas2001@gmail.com)">

			<br><br><br><br><br>

		<input type="text" id="pwd" name="pwd" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Password">

			<br><br><br><br><br>

        <input type="text" id="pwd1" name="pwd1" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Repetez ici">

			<br><br><br><br><br><br>

		<input type="submit" name="envoyer" value="Soumettez-en" style="font-size:50px; border-color: tomato; margin-left: 45%; background-color: tomato; color:white; font-weight: bold; box-shadow: 3px 8px 2px gray">		
</form>

<?php 

	if(isset($_POST['env']))
	{
		echo $idclien;

		
	}

	if(isset($_POST['textt']) && isset($_FILES['imgpub']))
	{
		$idclien=$_POST["textt"];

		$imgnom=$_FILES["imgpub"]["name"];
		$imgcontenu=$_FILES["imgpub"]["tmp_name"];
		$imgtaill=$_FILES["imgpub"]["size"];

		$sqllo1=mysql_query("select MAX(date_acquis) from produit");

	     while ($ligne=mysql_fetch_array($sqllo1)) {
	        $maxtime=$ligne[0];
		} 

		if($sqllo1)
		{
			$noo=$idclien.".jpeg";

			if ($imgtaill<=500000)
				{
					if($imgtaill==0)
					{
						echo '<script> alert("fichier vide ou corrompu !!")</script>';

						$idcliendisp=$idclien;

					}
					else
					{
						copy($imgcontenu,"hotimG\PhoClient\\".$noo);

						echo '<script> alert("absolu !!")</script>';
					}
					 
				}
				else
				{
					echo '<script> alert("Cet image trop!! veuillez choisir une image dont la taille est inférieure à 300ko")</script>';

					$idcliendisp=$idclien;

				}
		}
		
		
	}
?>

<form action="" method="POST" enctype="multipart/form-data">

	<input type="file" id="imgpub" name="imgpub" value="Photo" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold">
	<br><br><br><br><br><br>
	
	<input type="submit" value="Export photo" style="font-size:50px; border-color: tomato; margin-left: 45%; background-color: tomato; color:white; font-weight: bold; box-shadow: 3px 8px 2px gray">

	<input type="text" value="<?php echo $idcliendisp; ?>" name="textt" >
	
</form>
		</center>
		
	</div>

<script>	
	var iddd=document.getElementById('idd');
	var nom=document.getElementById('nom');
	var prenom=document.getElementById('prenom');
	var sexe=document.getElementById('sexe');
	var tel=document.getElementById('tel');
	var ville=document.getElementById('ville');
	var pays=document.getElementById('pays');
	var sej=document.getElementById('sejour');

	function ouverture(){
		alert("Veuillez repondre correctement aux différentes questions \n Afin de pouvoir nous permettre de décider si c'est réellement ton compte\n \n NB Veuillez vous rassurer si c'est bien répondu avant d'envisager passer à la suivante question ");
	}
	function desactive1(){
		iddd.disabled = true;
	}
	function desactive2(){
		nom.disabled = true;
	
	}
	function desactive3(){
		prenom.disabled = true;
	
	}
	function desactive4(){
		sexe.disabled = true;
	
	}
	function desactive5(){
		tel.disabled = true;
	
	}
	function desactive6(){
		ville.disabled = true;
	
	}
	function desactive7(){
		pays.disabled = true;
	
	}
	function retourconnexion(){
		window.location.href = 'index.php';
	}
	

</script>

</body>
</html>