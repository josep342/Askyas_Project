<?php 
$idd=($_GET['ident']);
//$iddd=($_GET['ident'])
include("conn.php");
$etat="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$eta="";
$sql1=mysql_query("select Nom,Prenom from client where id_client ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql1)) {
        $nom=$ligne['Nom'];
        $prenom=$ligne['Prenom'];
	}


	
$sql2=mysql_query("select detail,etat,dat from avertissement where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql2)) {
        $message=$ligne['detail'];
        $etat=$ligne['etat'];
        $datt=$ligne['dat'];
	}
	if($etat=="1"){
		$etat=" +1";
		$ff="2326147.png";
	}
	else{
		$etat="";
	}

	$sqls2=mysql_query("select Etatt from notification where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sqls2)) {
        $ettats=$ligne['Etatt'];
	}
	if($ettats=="1"){
		$etatt=" +1";
		$ff="2326147.png";
	}
	else{
		
		$etatt="";
	}

	if (isset($_POST['ouvrircoupon'])) {
		header('location:tableau.php?ident='.$idd.'');
	}

	if (isset($_POST['acceuil'])) {
		header('location:accueil.php?ident='.$idd.'');
	}

	if (isset($_POST['tableau'])) {
		header('location:tableau.php?ident='.$idd.'');
	}

	if (isset($_POST['notification'])) {
		header('location:notification.php?ident='.$idd.'');
	}

	if (isset($_POST['aide'])) {
		header('location:aide.php?ident='.$idd.'');
	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notification.php?ident='.$idd.'');
	} 
	if (isset($_POST['btnconfimer'])) {
		
		$recupidpro=($_POST['affidproo']);
		
		$sqlmod=mysql_query("update commande set Etat=1 where id_com='".$recupidpro."'");
		if($sqlmod){
			echo '<script>alert("La commande a ete confirmee avec succes")</script>';
		}
		else{
			echo '<script>alert("Une erreur inattendue a ete capturee, veuillez reessayer plus tard")</script>';
		}


	} 
	if (isset($_POST['btn'])) 
	{
		$iddprod=($_POST['idpprod']);
		$qqts=($_POST['qtts']);
		try
		{
			if($qqts>0)
			{

				if($qqts !="")
				{
					
				    $ddat=date('Y-m-d');

				    try
					    {
							$sqlinsert=mysql_query("insert into preforma values ('$iddprod','$idd','$qqts','$ddat')");

							echo'<script>alert("Produit a été ajouté avec succès ");</script>';
						}
					catch(Exception $e)
						{

							echo'<script>alert("Error!! ");</script>';
							
						}

				}
				else
				{
					echo'<script>alert("La quantite ne doit pas etre vide ");</script>';
				}
			}
			else
			{
				echo'<script>alert("La quantite ne doit etre qu un chiffre ");</script>';
			}
		}
		catch(Exception $ex)
		{
			echo'<script>alert("quantite doit entre superieur 0");</script>';

		}

		

	

		//setcookie('cookqt', NULL,1);
		//unset($_COOKIE['cookqt']);
			//document.cookie="cookqt="+qtt;
		//$qttt=$_COOKIE['cookqt'];
		//echo $qttt;
		//$qtttautre=$_COOKIE['cookqt'];
		//echo $qtttautre;
		

		/*$iddprod=($_POST['idpprod']);

		echo'<script>
		var qtt=prompt("veuillez saisir la quantité voulue pour  le produit ");
		document.cookie="cookqtt="+qtt;
		</script>';

		echo '<script>
		var rep=prompt("voulez-vous vraiment confirmer la commande du produit pour une quantité de "+qtt+"?  (oui/non)");
		</script>';
		

		//if(isset($_COOKIE['cookq'])) {
    		$maVariable = $_COOKIE['cookqtt'];
    		echo $maVariable * $maVariable;
    	//}


		
		/*$repp='<script> document.write(rep);</script>';
		$qqtt='<script> document.write(qtt);</script>';
		$repp=(string)$repp;

		if($repp=='oui'){
			echo'<script>alert("absolu")</script>';
		}
		else{
			echo $qqtt*$qqtt;
			echo $qqtt;
			echo'<script>alert("commande rejettée")</script>';
		}*/
		



		 
	} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>E-commerce</title>
		<link rel="stylesheet" type="text/css" href="beaute.css">
</head>
<body onload="ouverture()" style="background-color: aliceblue">
<div style="width:100%; height:100% background-color:aliceblue; border-radius:1%; "> 
	<div style=" width: 100%;height:300px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">
		<script type="text/javascript">
			prompt("veuillez saisir la quantité voulue pour  le produit "+..);
		</script>

	    <form method="POST" action="">	
			
			<div style="width: 78%; height: 300px; display: inline-block;">
				<?php

					include("tete.php");
					$phot="hotimG\PhoClient\\".$idd.".JPEG";

			    ?>

			
			</div>
				<div style="width: 20%; height: 300px; display: inline-block;">
						
						 <div style="width: 100%; height: 250px">
						 	 <img src="<?php echo $phot ?>" style="width: 100%; height: 80%; border-radius:60%"> <br>
						 	 <center>
						 	 	<input type="submit" name="notificationhaute" style="width: 50px;height: 50px;background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));background-image: url(<?php echo $ff;?>);border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%;" value="">

						 	 	<b style="color: white; font-size: 35px; background-color: red; border-radius: 50%;"> <?php echo $etat.$etatt.$dats ; ?>  </b>
						 	 </center>
						 		 	
						 </div>
			
				</div>
		
		</form>
	</div>

		
	<!-- les diffent bouton de menue-->

		<div style="width:0px; height: 100%;background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))" id="tire">
			<div id="haut" style="width: 83%; height: 10%; display: inline-block;background-color: black; box-shadow: 3px 4px 2px blue; opacity: 80%"><br>
				<b id="etiquettemenu" style="margin-left: 30%; color: white; font-size: 70px">
					
				</b><br><br>
				
				
			</div>

			<div style="width: 15%; height: 10%; display: inline-block;">
				<input id="btrepl" type="button" name="" text="ici" onclick="replier()" style="width: 0px; height: 0px; background-image: url(c1.PNG); border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%">	
			</div><br><br><br>

	<form action="" method="POST">

			<img id="photacceuil" style="width:0px; height:0px;margin-left: 5%" src="images\house_115210.png">

			<input type="submit" name="acceuil" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="accueil"> 
			<br><br><br><br>

			<img id="photcommander" style="width:0px; height:0px;margin-left: 5% " src="images\platt.jpg">

			<input type="submit" name="commande" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="commande">
			<br><br><br><br>

			<img id="phottableau" style="width:0px; height:0px;margin-left: 5% " src="images\statistique.png">

			<input type="submit" name="tableau" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="tableau"> 

			<br><br><br><br>

			<img id="photnot" style="width:0px; height:0px;margin-left: 5% " src="images\1592461.png">

			<input type="submit" name="notification" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="notification">
			<br><br><br><br>

			<img id="photaide" style="width:0px; height:0px;margin-left: 5%" src="images\admin.png">

			<input type="submit" name="aide" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="aide">
			<br>
	</form>

			
		</div>
	<!-- fin des diffent bouton de menue-->



<form action="" method="POST">
		<div style="width: 100%; height: 20%; background-color: rgba(0,0,0,0)">
			<div style="width:15%; height: 100%; display: inline-block; ">
				<input id="btntirer" type="button" name="" text="ici" onclick="tire()" style="width: 100px; height: 100px; background-image: url(c1.PNG); background-repeat: no-repeat;background-size: 100%; border-top: none;border-right: none; border-left: none; border-bottom: none;">

			</div>
			<div style="width: 80%; height: 100% ;display: inline-block;">
				<b id="welcom" style="text-align: center; text-shadow: 1px 2px 1px rgba(120,120,150,100);font-size:30px; margin-left: 5%" > <?php echo   $prenom ?>  ,Veuillez passer vos commandes
  </b> <br><br>
				
			</div>
			
		</div>
</form>
<hr style="box-shadow:2px 3px 2px gray ">
	

<center>
	<div style="width: 500px; height: 400px; background-image: url(plat.jpg); background-size: 100%; background-repeat: no-repeat;"> <br><br>
		<b style="font-size:25px;color:blue;text-shadow: 2px 2px 1px gray "> <i style="font-size: 40px; color:tomato;text-shadow: 2px 2px 2px gray">Q</i>uelques soient vos <i style="font-size: 40px; color:tomato;text-shadow: 2px 2px 2px gray">P</i>roblèmes</b><br><br><br><br>

		<b style="font-size:25px;color:blue;text-shadow: 2px 2px 1px gray "> <i style="font-size: 40px; color:tomato;text-shadow: 2px 2px 2px gray; margin-left:45% ">C</i>ommandes</b> <br><br><br>

		<b style="font-size:25px;color:blue;text-shadow: 2px 2px 1px gray ; margin-left: 60%"> d'<i style="font-size: 40px; color:tomato;text-shadow: 2px 2px 2px gray">A</i>bord</b>
		
	</div>

	<h1 style="font-size:35px;color:white;text-shadow: 2px 2px 1px gray; background-color: tomato "><i style="font-size: 55px; color:blue;text-shadow: 2px 2px 2px white">P</i>roduits Disponibles</h1>

	<br><br>

	<form action="" method="POST">

		<select id="sexe" name="typerech" style=" font-size: 35px;font-weight: bold; width: 50%; border-color: tomato; margin-left: 40%" > 
			<option> Chosir</option>
			<?php 

				$type="";

				$sql1=mysql_query("select distinct type from produit");
			    while ($ligne=mysql_fetch_array($sql1)) 
			    {
			       $type=$ligne['type']; 
			?>

			<option> <?php echo $type; ?></option>

			<?php 

				}

			?>

		</select>

		<input type="submit" name="trier" value="Trier" style="font-size: 30px;text-shadow: 1px 2px 1px gray">

	</form>

	

	<br><br>

<?php

	$ddatss=date('Y-m-d');
	
	if(isset($_POST['trier'])) 
	{
		$typ=($_POST['typerech']);

		$sql1=mysql_query("select id_prod,nom,model,type,CEILING(pu*tauxx) as puu,stock_courant,date_acquis from produit,taux where num='1' and (stock_courant*100)/stock_initial>10 and type='".$typ."'");
	
	}
	else
	{

		$sql1=mysql_query("select id_prod,nom,model,type,CEILING(pu*tauxx) as puu,stock_courant,date_acquis from produit,taux where num='1' and (stock_courant*100)/stock_initial>10");
	}

     while ($ligne=mysql_fetch_array($sql1)) {
        $idprod=$ligne['id_prod'];
        $nnom=$ligne['nom'];
        $bbase=$ligne['model'];
        $ddetail=$ligne['type'];
        $ppu=$ligne['puu'];
        $stockin=$ligne['stock_courant'];
        $phot=$ligne['date_acquis'];

        $phot=str_replace(":", "_", $phot);

		$pho='hotimG\ProdimG\\'.$phot.'.jpeg';
 		
	 ?>
<form action="" method="POST">
	 <table>
	<th colspan="5" style="font-size: 40px; text-shadow: 2px 2px 1px gray; color:blue"> <?php echo "ID PRODUIT: ". $idprod." [< ".$stockin." ]"; ?></th>
		<tr>
			<td colspan="5" style="width: 600px; height: 400px">
				<img style="width:100%; height: 100%" src='<?php echo $pho;?>'>
			</td>
			
		</tr>
		<tr>
			<td> <b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">N</i>om</b></td>

			<td> <i style="font-size: 30px;"> <?php  echo  ":".$nnom; ?> </i></td>
			<td style="width: 20px"></td>
			<td>
				
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">M</i>odel</b>

			</td>
			<td> <i style="font-size: 30px;"><?php echo ":".$bbase; ?> </i></td>
		</tr>
		<tr>
			<td><input type="text" style="width: 0px; height: 0px; border-top: none; border-bottom: none; border-right: none; border-left: none" value="<?php echo $idprod; ?>" name="idpprod"></td>
			<td></td>
			<td></td>
			<td>
				
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">P</i>.U</b>

			</td>
			<td> <i style="font-size: 30px;"> <?php echo ":".$ppu."Fc"; ?> </i></td>
		</tr>
		
		<tr>
			<td>
				
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">T</i>ype</b>

			</td>
			<td colspan="4" style="width: 700px"> <i style="font-size: 30px;"> <?php echo ":".$ddetail; ?></i></td>
			
		</tr>
		<tr>
			<td style="height: 20px">
				
			</td>
			
		</tr>
		<tr>
			<td colspan="4"> <b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">Q</i>uantité</b> <input type="text" name="qtts" style="width:100px; height: 40px; border-color: tomato; font-size: 30px"></td>

			<td> <input type="submit" name="btn" value="Souscrire" style="background-color: tomato; color:white; font-size: 40px; font-weight: bold; text-shadow: 2px 2px 2px gray; margin-left: 30%"></td>
			
		</tr>
	</table>
</form>
<hr style="box-shadow: 4px 4px 4px gray">
	<br><br>
	
<?php 
}

?>

<form action="" method="POST">

	<?php

		$sqldel=mysql_query("delete from preforma where id_client='".$idd."' and date<'".date('Y-m-d')."'");

		$nbrcoup=0;
		$sql2=mysql_query("select count(idpro) from preforma where id_client='".$idd."' and date='".date('Y-m-d')."'");

	    while ($ligne=mysql_fetch_array($sql2)) 
	    {
	        $nbrcoup=$ligne[0];
	    }

	    if($nbrcoup>0)
	    {

	 ?>

	<input type="submit" name="ouvrircoupon" value="" style="background-image: url(panier.jpg);width: 125px; height: 135px;background-size: 100%;background-color: aliceblue; border-top: none; border-left: none;border-right: none; border-bottom: none; margin-left: 60%">
	<b style="font-size: 30px; text-shadow: 1px 2px 1px red;width: 125px; height: 125px; border-radius: 40%;background-color:black; color:white">
		 <?php echo " +".$nbrcoup;?>
	</b>

	<?php 

		}

	?>
</form>

<h1 style="font-size:35px;color:white;text-shadow: 2px 2px 1px gray; background-color: tomato "><i style="font-size: 55px; color:blue;text-shadow: 2px 2px 2px white">V</i>os commandes en attente</h1>
<br><br>
<div style="width: 600px; height: 500px; background-image: url(find_102325.ico);background-size: 100%">
	<b style="font-size: 40px; text-shadow: 2px 2px 1px gray"><i style="font-size: 50px; color:blue">C</i>ommandes sous </b> <br><br>
	<b style="font-size: 40px; text-shadow: 2px 2px 1px gray"><i style="font-size: 50px; color:blue">T</i>raitement </b>
	
</div>


<?php 
	$tab=[];

	$nbr=0;
	$dataujour=date('Y-m-d');
	$sqls1=mysql_query("select distinct id_com from commande where commande.id_client='".$idd."' and commande.etat=0");
	    while ($ligne=mysql_fetch_array($sqls1)) 
	    {
		 	$list=$ligne['id_com'];

		 	array_push($tab, $list);

		 	$affidp="";
		    $affqt="";
		    $affpu="";
		    $affpt="";
		    $affdat="";


		    $rien1="";
		    $rien2="";
		    $rien3="";
		    $rien4="";

		    $affheure="";
		    $affph="\hotimG\ProdimG\\".$affidp.".JPEG"; 
		    $nbr=$nbr+1;

		}

		for($i=0; $i< count($tab);$i++)
	    {

    	?>
    	<br><br><br>

    	<form action="" method="POST">
			<table>

				<th colspan="5" style="font-size: 40px; text-shadow: 2px 2px 1px gray; color:white; background-color: blue"> <?php echo " Ref Commande : ".$tab[$i]; ?></th>

    	<?php 
	    	
	    	$sqls1=mysql_query("select client.id_client as cli,commande.id_prod as prid,produit.nom as nom,pu,qt,pt,date_tim,date_acquis from commande,produit,client where id_com='".$tab[$i]."' and commande.id_client=client.id_client and commande.id_prod=produit.id_prod and commande.id_client='".$idd."'");
		    while ($ligne=mysql_fetch_array($sqls1)) 
		    {
			 	$idclient=$ligne['cli'];
			 	$idprod=$ligne['prid'];
			 	$nom=$ligne['nom'];
			 	$puc=$ligne['pu'];
			 	$qtc=$ligne['qt'];
			 	$ptc=$ligne['pt'];
			 	$datec=$ligne['date_tim'];
			 	$phot=$ligne['date_acquis'];

			 	$ph=str_replace(":", "_", $phot);

				$pho='hotimG\ProdimG\\'.$ph.'.jpeg';

	?>
		<tr>
			<td colspan="5" style="height: 35px">
				
			</td>
		</tr>
		<tr>
			<td colspan="5" style="font-size: 40px; text-shadow: 2px 2px 1px gray; color:white; background-color: gray">

				<?php echo "ID PRODUIT : ".$idprod; ?>
				
			</td>
			
		</tr>

		<tr>
			<td colspan="5" style="width: 600px; height: 400px">
				<img style="width:100%; height: 100%" src='<?php echo  $pho; ?>' >
			</td>
			
		</tr>
		<tr>
			<td> <b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">Q</i>uantité</b></td>

			<td> <i style="font-size: 30px;"> <?php  echo  ":".  $qtc; ?> </i></td>
			<td style="width: 20px"></td>
			<td>
				
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">D</i>ate</b>
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">H</i>eure</b>

			</td>
			<td> <i style="font-size: 30px;"><?php echo "le ".$datec; ?> </i></td>
		</tr> 
		<tr>
			<td>
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">P</i>rix unitaire</b> 
		    </td>
			<td> <i style="font-size: 30px;"> <?php echo " :".$puc."fc"; ?>  </i></td>
			<td></td>
			<td>
				
				

			</td>
			<td> </td>
		</tr>
		
		<tr>
			<td>
				
			<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">P</i>rix total</b>

			</td>
			<td colspan="4" style="width: 700px"> <i style="font-size: 30px;"> <?php echo ":".$ptc."fc" ; ?></i></td>
			
		</tr>
		<tr>
			<td style="height: 20px">
	
				
			</td>
			
		</tr>


<?php 

	}

	?>

		<tr>
			<td colspan="4">

				<input type="text" style="width: 0px; height: 0px; border-top: none; border-bottom: none; border-right: none; border-left: none" value="<?php echo $tab[$i]; ?>" name="affidproo">
			</td>

			<td> 
				<input type="submit" name="btnconfimer" value="Confirmer la reception" style="background-color: red; color:white; font-size: 40px; font-weight: bold; text-shadow: 2px 2px 2px gray">
			</td>
			
		</tr>
	</table>
	

</form>

<?php 

	}

?>


<hr style="box-shadow: 3px 4px 2px gray">
<br><br>

<br><br>

<div style="width: 600px; height: 600px; background-image: url(notexist.jpg); background-size: 100%; border-radius: 45%">
	
</div>

</center>
		
	</div>

<script>
	//let temps=20;
	var tirerr=document.getElementById('tire');
	var btreplier=document.getElementById('btrepl'); 
	var bttirer=document.getElementById('btntirer'); 

	var etiquemenuu=document.getElementById('etiquettemenu'); 
	var welcom=document.getElementById('welcom'); 


	var acc=document.getElementById('accueil');
	var command=document.getElementById('commande');
	var tableau=document.getElementById('tableau');
	var notification=document.getElementById('notification');
	var aide=document.getElementById('aide'); 
	var photacceuil=document.getElementById('photacceuil'); 
	var photcomm=document.getElementById('photcommander'); 
	var phottableaub=document.getElementById('phottableau'); 
	var photnotif=document.getElementById('photnot'); 
	var photaidee=document.getElementById('photaide'); 





	function tire(){	
	tirerr.style.width=60+"%";
	tirerr.style.height=1000+"px";
	welcom.innerText="";

	btreplier.style.width=100+"px"
	btreplier.style.height=100+"px"
	bttirer.style.width=0+"px";
	bttirer.style.height=0+"px";

	photacceuil.style.height=50+"px";
	photacceuil.style.width=60+"px";

	photcomm.style.height=50+"px";
	photcomm.style.width=60+"px";

	phottableaub.style.height=50+"px";
	phottableaub.style.width=60+"px";

	photnotif.style.height=60+"px";
	photnotif.style.width=60+"px";

	photaidee.style.height=60+"px";
	photaidee.style.width=70+"px";



	acc.value="Acceuil"
	command.value="Commande ";
	tableau.value="Tableau de Bord";
	notification.value="Notification";
	aide.value="Aide ?";
	etiquemenuu.innerText="MENU";
	}
	function replier(){	
		//style="width: 70px; height: 55px; 
	btreplier.style.width=0+"%"
	btreplier.style.height=0+"%"

	bttirer.style.width=100+"px";
	bttirer.style.height=100+"px";
	var nom='<?php echo $prenom ?>';

	welcom.innerText= nom + "  Veuillez passer vos commandes " ;
	acc.value="";
	command.value="";
	tableau.value="";
	notification.value="";
	aide.value="";
	etiquemenuu.innerText="";



	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";

	photacceuil.style.height=0+"px";
	photacceuil.style.width=0+"px";

	photcomm.style.height=0+"px";
	photcomm.style.width=0+"px";

	phottableaub.style.height=0+"px";
	phottableaub.style.width=0+"px";

	photnotif.style.height=0+"px";
	photnotif.style.width=0+"px";

	photaidee.style.height=0+"px";
	photaidee.style.width=0+"px";
	
	}
	function ouverture(){
	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";

	}

	
</script>

<?php 
include("footeur.php");
?>

</body>
</html>