<?php 

include("conn.php");

if (isset($_POST['envoyer'])) {
	
	$iddd=($_POST['idd']);
	$nom=($_POST['nom']);
	$prenom=($_POST['prenom']);
	$sexe=($_POST['sexe']);
	$tel=($_POST['tel']);
	$adress=($_POST['adressee']);

	$sql1=mysql_query("select nom,prenom,sexe,tel,adresse,pwd from client,compte where id_client ='".$iddd."' and id=id_client");

      while ($ligne=mysql_fetch_array($sql1)) {
        	$vnom=$ligne['nom'];
        	$vprenom=$ligne['prenom'];
        	$vsexe=$ligne['sexe'];
        	$vtel=$ligne['tel'];
        	$vadres=$ligne['adresse'];
        	$vpwd=$ligne['pwd'];
	}
	if(strtolower($vnom)==strtolower($nom) && strtolower($vprenom)==strtolower($prenom) && strtolower($vsexe)== strtolower($sexe) && strtolower($vtel)== strtolower($tel) && strtolower($vadres)==strtolower($adress)){
		echo'<script> alert(" Felicitation tu viens de recuperer votre mot de passe qui est  '.$vpwd.'")</script>';

		}
	else{
		echo'<script> alert("Ces informations ne correspondent à aucun compte utilisateur ! \n Tu peux recommencer si ce ne pas le cas !!\n Et si cela persiste Il faut consulter l administrateur ")</script>';
	}
}

	?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body onload="ouverture()">
	<div style="width: 100%; height: 1700px; background-color: aliceblue">
		<center>
			<H1 style="background-color: tomato; color:white; font-size: 50px; box-shadow: 5px 13px 5px gray;" >LA RECUPERATION DU COMPTE UTILISATEUR</H1>

			<br><br><br><br><br>
<form action="" method="POST"> 

		<input type="text" id="nom" name="nom" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Veuillez inserer ton nom ?">

			<br><br><br><br><br>
			
		<input type="text" id="prenom" name="prenom" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Veuillez inserer ton prenom ?">

			<br><br><br><br><br>

			<table style="margin-left: 48%">
				<tr>
					<td style=" font-size: 45px;font-weight: bold;">Sexe</td>
					<td style="width: 100px"></td>
					<td>
						<select id="sexe" name="sexe" style=" font-size: 45px;font-weight: bold; width: 100px; border-color: tomato" > 
							<option> </option>
							<option>M</option>
							<option>F</option>

						</select>
					</td>
				</tr>
			</table>

			<br><br><br><br><br>

		<input type="text"  id="tel" name="tel" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Numero de téléphone ?">

			<br><br><br><br><br>

		<input type="text" id="adressee" name="adressee" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Ville Residentielle ?">

			<br><br><br><br><br>

		<input type="text" id="idd" name="idd" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Identifiant ">

			
			<br><br><br><br><br><br>

		<input type="submit" name="envoyer" value="Soumettre son recours" style="font-size:50px; border-color: tomato; margin-left: 28%; background-color: tomato; color:white; font-weight: bold; box-shadow: 3px 8px 2px gray">		
</form>
		</center>
		<a href="adressemac.php">ess</a>

		
	</div>

<script>	
	var iddd=document.getElementById('idd');
	var nom=document.getElementById('nom');
	var prenom=document.getElementById('prenom');
	var sexe=document.getElementById('sexe');
	var tel=document.getElementById('tel');
	var ville=document.getElementById('ville');
	var pays=document.getElementById('pays');
	var sej=document.getElementById('sejour');

	function ouverture(){
		alert("Veuillez repondre correctement aux différentes questions \n Afin de pouvoir nous permettre de décider si c'est réellement ton compte\n \n NB Veuillez vous rassurer si c'est bien répondu avant d'envisager passer à la suivante question ");
	}
	function desactive1(){
		iddd.disabled = true;
	}
	function desactive2(){
		nom.disabled = true;
	
	}
	function desactive3(){
		prenom.disabled = true;
	
	}
	function desactive4(){
		sexe.disabled = true;
	
	}
	function desactive5(){
		tel.disabled = true;
	
	}
	function desactive6(){
		ville.disabled = true;
	
	}
	function desactive7(){
		pays.disabled = true;
	
	}
	

</script>

</body>
</html>