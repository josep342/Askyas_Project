<?php


	$con=mysql_connect('localhost','askyas','askyas') or die("Impossible de rejoindre le server");
	mysql_select_db('kenamel',$con) or die("Impossible de rejoindre le server");


?>