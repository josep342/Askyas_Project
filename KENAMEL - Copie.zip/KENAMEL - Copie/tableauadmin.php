<?php 
$idd=($_GET['ident']);
//$iddd=($_GET['ident'])
include("conn.php");
$etat="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$eta="";
try{
	$sql1=mysql_query("select Nom,Prenom from client where id_client ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql1)) {
        $nom=$ligne['Nom'];
        $prenom=$ligne['Prenom'];
	}

    $sejprev="";
    $sejeff="";    

 	$ff="calendar.png";
	$dats="+1";
 	$dats="+1";
	$ff="calendar.png";
 	$dats="";
	 

$sql2=mysql_query("select detail,etat,dat from avertissement where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql2)) {
        $message=$ligne['detail'];
        $etat=$ligne['etat'];
        $datt=$ligne['dat'];
	}
	if($etat=="1"){
		$etat=" +1";
		$ff="2326147.png";
	}
	else{
		$etat="";
	}

	$sqls2=mysql_query("select Etatt from notification where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sqls2)) {
        $ettats=$ligne['Etatt'];
	}
	if($ettats=="1"){
		$etatt=" +1";
		$ff="2326147.png";
	}
	else{
		
		$etatt="";
	}

}
catch (Exception $e){
	echo '<script>alert("Erreur inattendue");</script';

}

	if (isset($_POST['commande'])) {
		header('location:commande.php?ident='.$idd.'');
	}

	if (isset($_POST['acceuil'])) {
		header('location:accueil.php?ident='.$idd.'');
	}

	if (isset($_POST['notification'])) {
		header('location:notificationadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['aide'])) {
		$idd=$idd.",rien";
		header('location:aideadmin.php?ident='.$idd.'');
	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notification.php?ident='.$idd.'');
	} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion Hotel</title>
		<link rel="stylesheet" type="text/css" href="beaute.css">
</head>
<body onload="ouverture()" style="background-color: aliceblue">
<div style="width:100%; height:100% background-color:aliceblue; border-radius:1%; "> 
	<div style=" width: 100%;height:300px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">

	    <form method="POST" action="">	
			
			<div style="width: 78%; height: 300px; display: inline-block;">
				<?php

					include("tete.php");
					//$phot="hotimG\PhoClient\\".$idd.".JPEG";
					$phot="adminn.png";

			    ?>

			
			</div>
				<div style="width: 20%; height: 300px; display: inline-block;">
						
						 <div style="width: 100%; height: 250px">
						 	 <img src="<?php echo $phot ?>" style="width: 100%; height: 80%; border-radius:60%"> <br>
						 	 <center>
						 	 	<input type="submit" name="notificationhaute" style="width: 50px;height: 50px;background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));background-image: url(<?php echo $ff;?>);border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%;" value="">

						 	 	<b style="color: white; font-size: 35px; background-color: red; border-radius: 50%;"> <?php echo $etat.$etatt.$dats ; ?>   </b>
						 	 </center>
						 		 	
						 </div>
			
				</div>
		
		</form>
	</div>
		

		
	<!-- les diffent bouton de menue-->

		<div style="width:0px; height: 0%;background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))" id="tire">
			<div id="haut" style="width: 83%; height: 10%; display: inline-block;background-color: black; box-shadow: 3px 4px 2px blue; opacity: 80%"><br>
				<b id="etiquettemenu" style="margin-left: 30%; color: white; font-size: 70px">
					
				</b><br><br>
				
				
			</div>

			<div style="width: 15%; height: 10%; display: inline-block;">
				<input id="btrepl" type="button" name="" text="ici" onclick="replier()" style="width: 0px; height: 0px; background-image: url(c1.PNG); border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%">	
			</div><br><br><br>

	<form action="" method="POST">

			<img id="photacceuil" style="width:0px; height:0px;margin-left: 5%" src="images\house_115210.png">

			<input type="submit" name="acceuil" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="accueil"> 
			<br><br><br><br>

			<img id="photcommander" style="width:0px; height:0px;margin-left: 5% " src="images\platt.jpg">

			<input type="submit" name="commande" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="commande">
			<br><br><br><br>

			<img id="phottableau" style="width:0px; height:0px;margin-left: 5% " src="images\statistique.png">

			<input type="submit" name="tableau" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="tableau"> 

			<br><br><br><br>

			<img id="photnot" style="width:0px; height:0px;margin-left: 5% " src="images\1592461.png">

			<input type="submit" name="notification" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="notification"> 
			<br><br><br><br>

			<img id="photaide" style="width:0px; height:0px;margin-left: 5%" src="images\admin.png">

			<input type="submit" name="aide" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="aide"> 
			<br>
	</form>

			
		</div>
	<!-- fin des diffent bouton de menue-->



<form action="" method="POST">
		<div style="width: 100%; height: 20%; background-color: rgba(0,0,0,0)">
			<div style="width:15%; height: 100%; display: inline-block; ">
				<input id="btntirer" type="button" name="" text="ici" onclick="tire()" style="width: 100px; height: 100px; background-image: url(c1.PNG); background-repeat: no-repeat;background-size: 100%; border-top: none;border-right: none; border-left: none; border-bottom: none;">

			</div>
			<div style="width: 80%; height: 100% ;display: inline-block;">
				<b id="welcom" style="text-align: center; text-shadow: 1px 2px 1px rgba(120,120,150,100);font-size:40px; margin-left: 5%" > <?php echo   $prenom ?>  ,Voilà Nos statistiques  </b> <br><br>
				
			</div>
			
		</div>
</form>
<hr style="box-shadow: 3px 3px 3px gray">

<center>
	<div style="width: 450px; height:350px; background-image: url(stat.jpg);background-repeat: no-repeat;background-size: 100%; box-shadow: 4px 10px 8px gray"><br><br>
		<b style="text-shadow: 2px 2px 2px black; font-size: 35px">Show </b><br><br>
		<b style="text-shadow: 2px 2px 2px tomato;color:tomato; margin-left: 40%;font-size: 35px">Statistic </b><br><br>
		<b style="text-shadow: 2px 2px 2px black; margin-left: 65%;font-size: 35px">New  </b>

	</div>

	<h1 style="background-color: black;color:white; font-size: 45px; box-shadow: 4px 5px 3px gray"><b style="text-shadow: 1px 2px 2px gray"> TABLEAU DE CONTROLE </b></h1>

</center>
	
	<i style="font-size: 20px; font-weight: bold;text-shadow: 1px 2px 1px gray">
		Tri par nom
	</i>
	
	<hr style="box-shadow: 1px 2px 1px gray">
	
	<br><br>

	<form action="" method="POST">

		<table>

			<tr>
				<td style="width: 20%">
					<b style="font-size: 35px; text-shadow: 1px 2px 1px gray; margin-left: 5%">
						Nom
					</b>
				</td>
				<td style="width: 30%">
					<input type="text" placeholder="Rechercher"  name="nocli" style="font-size: 40px;text-shadow: 1px 2px 1px gray; width: 250px; border-color: gray;border-top: none;border-right: none;border-left: none">
				</td>
				
				<td style="width: 10%">
					<input type="submit" value=""  style="background-image: url(rech.png);width: 70px; height: 70px; background-size: 100%; border-top:none; border-bottom: none; border-right: none; border-left: none">
				</td>

				<td style="width: 30%">
					<select name="combnocl" style="font-size: 40px;text-shadow: 1px 2px 1px gray; width: 300px; border-color: gray">

						<option>Chosir</option>

				<?php 

					if(isset($_POST['nocli'])) 
					{
						$nomcll=($_POST['nocli']);

						$sqlschalike=mysql_query("select distinct id_client from commande where commande.etat=1 and id_client LIKE'%".$nomcll."%'");
					    while ($ligne=mysql_fetch_array($sqlschalike)) 
					    {
						 	$noncl=$ligne['id_client'];
				?>				

						<option><?php echo $noncl; ?></option>

				<?php 

						}
					}

				?>

					</select>
				</td>

				<td style="width: 10%">
					<input type="submit" value="" name="" style="background-image: url(rech.jpg);width: 70px; height: 70px; background-size: 100%; border-top:none; border-bottom: none; border-right: none; border-left: none;margin-bottom: -1%">
				</td>
			</tr>
		</table>

		
	</form>
	<br><br>

	<i style="font-size: 20px; font-weight: bold;text-shadow: 1px 2px 1px gray">
		Tri par Date
	</i>
		
	<hr style="box-shadow: 1px 2px 1px gray">

	<br><br>

	<form action="" method="POST">

		<table>

			<tr>
				<td style="width: 20%">
					<b style="font-size: 35px; text-shadow: 1px 2px 1px gray; margin-left: 5%">
						Date
					</b>
				</td>
				<td style="width: 70%">
					<select name='dattee' style="font-size: 40px;text-shadow: 1px 2px 1px gray; width: 700px; border-color: gray">

						<option>Chosir</option>

						<?php 

							$sqlscharg=mysql_query("select distinct datee from commande where commande.etat=1");

						    while ($ligne=mysql_fetch_array($sqlscharg)) 
						    {
							 	$dat=$ligne['datee'];
							

						?>

						<option> <?php echo $dat;?></option>

						<?php 

							}

						?>

					</select>
				</td>
				<td style="width: 10%">
					<input type="submit" value="" name="" style="background-image: url(rech.jpg);width: 70px; height: 70px; background-size: 100%; border-top:none; border-bottom: none; border-right: none; border-left: none;margin-bottom: -1%">
				</td>
			</tr>
		</table>

	</form>
	<br><br>
	
	<hr style="box-shadow: 1px 2px 1px gray">

<center>

	<?php 

	$tab=[];

	$nbr=0;
	$dataujour=date('Y-m-d');

	if(isset($_POST['dattee'])) 
	{
		$dat=($_POST['dattee']);	
		$sqls1=mysql_query("select distinct id_com from commande where commande.etat=1 and datee='".$dat."'");	
	}
	elseif(isset($_POST['combnocl']))
	{
		$idcl=($_POST['combnocl']);
		$sqls1=mysql_query("select distinct id_com from commande where commande.etat=1 and id_client='".$idcl."'");

	}
	else
	{
		$sqls1=mysql_query("select distinct id_com from commande where commande.etat=1");

	}
	    while ($ligne=mysql_fetch_array($sqls1)) 
	    {
		 	$list=$ligne['id_com'];

		 	array_push($tab, $list);

		 	$affidp="";
		    $affqt="";
		    $affpu="";
		    $affpt="";
		    $affdat="";

		    $rien1="";
		    $rien2="";
		    $rien3="";
		    $rien4="";

		    $affheure="";
		    $affph=""; 
		    $nbr=$nbr+1;

		}

		for($i=0; $i< count($tab);$i++)
	    {
	    	$sqlsn=mysql_query("select commande.id_client as idccl,client.nom as nomcli,client.prenom as pren from client,commande where commande.id_client=client.id_client and commande.id_com='".$tab[$i]."'");
		    while ($ligne=mysql_fetch_array($sqlsn)) 
		    {
		    	$iddclien=$ligne['idccl'];
		    	$nomclien=$ligne['nomcli'];
		    	$prenc=$ligne['pren'];

		    }

    	?>
    	<br><br><br>

    	<form action="" method="POST">
			<table>

				<th colspan="5" style="font-size: 40px; text-shadow: 2px 2px 1px gray; color:white; background-color: blue"> <?php echo " Ref Commande : ".$tab[$i]; ?></th>
				<tr>
					<td colspan="5" style="font-size: 30px; text-shadow: 2px 2px 1px gray; color:white; background-color: blue">
						<?php echo "Client:".$nomclien."-".$prenc."[".$iddclien."]"; ?>
					</td>
				</tr>

    	<?php 
	    	
	    	$sqls1=mysql_query("select client.id_client as cli,commande.id_prod as prid,produit.nom as nom,pu,qt,pt,date_tim,date_acquis from commande,produit,client where id_com='".$tab[$i]."' and commande.id_client=client.id_client and commande.id_prod=produit.id_prod");
		    while ($ligne=mysql_fetch_array($sqls1)) 
		    {
			 	$idclient=$ligne['cli'];
			 	$idprod=$ligne['prid'];
			 	$nom=$ligne['nom'];
			 	$puc=$ligne['pu'];
			 	$qtc=$ligne['qt'];
			 	$ptc=$ligne['pt'];
			 	$datec=$ligne['date_tim'];
			 	$phot=$ligne['date_acquis'];

			 	$ph=str_replace(":", "_", $phot);

				$pho='hotimG\ProdimG\\'.$ph.'.jpeg';

	?>
		<tr>
			<td colspan="5" style="height: 35px">
				
			</td>
		</tr>
		<tr>
			<td colspan="5" style="font-size: 40px; text-shadow: 2px 2px 1px gray; color:white; background-color: gray">

				<?php echo "ID PRODUIT : ".$idprod; ?>
				
			</td>
			
		</tr>

		<tr>
			<td colspan="5" style="width: 600px; height: 400px">
				<img style="width:100%; height: 100%" src='<?php echo  $pho; ?>' >
			</td>
			
		</tr>
		<tr>
			<td> <b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">Q</i>uantité</b></td>

			<td> <i style="font-size: 30px;"> <?php  echo  ":".  $qtc; ?> </i></td>
			<td style="width: 20px"></td>
			<td>
				
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">D</i>ate</b>
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">H</i>eure</b>

			</td>
			<td> <i style="font-size: 30px;"><?php echo "le ".$datec; ?> </i></td>
		</tr> 
		<tr>
			<td>
				<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">P</i>rix unitaire</b> 
		    </td>
			<td> <i style="font-size: 30px;"> <?php echo " :".$puc; ?>  </i></td>
			<td></td>
			<td>
				
				

			</td>
			<td> </td>
		</tr>
		
		<tr>
			<td>
				
			<b style="font-size: 30px;text-shadow: 2px 2px 1px black"><i style="color:tomato; text-shadow: 2px 2px 1px gray; font-size: 40px">P</i>rix total</b>

			</td>
			<td colspan="4" style="width: 700px"> <i style="font-size: 30px;"> <?php echo ":".$ptc; ?></i></td>
			
		</tr>
		<tr>
			<td style="height: 20px">
	
				
			</td>
			
		</tr>


<?php 

	}

	$netpayerr=0;

	$sqlsom=mysql_query("select SUM(pt) from commande where commande.id_com='".$tab[$i]."'");
	    while ($ligne=mysql_fetch_array($sqlsom)) 
	    {
		 	$netpayerr=$ligne[0];
		}

	?>
		<tr>
			
			<td colspan="5">
				<b style="font-size: 30px;text-shadow: 1px 2px 1px gray;font-weight: bold;margin-left: 60%">
					<?php echo "NET :".$netpayerr."Fc"; ?>
				</b>
			</td>
		</tr>

		<tr>
			<td colspan="4">

				<input type="text" style="width: 0px; height: 0px; border-top: none; border-bottom: none; border-right: none; border-left: none" value="<?php echo $tab[$i]; ?>" name="affidproo">
			</td>

			<td> 
				
			</td>
			
		</tr>
	</table>
	<hr style="box-shadow: 2px 2px 1px gray">
	

</form>

<?php 

	}

?>


<hr style="box-shadow: 3px 4px 2px gray">
<br><br>

	
</center>

		
</div>

<script>
	//let temps=20;
	var tirerr=document.getElementById('tire');
	var btreplier=document.getElementById('btrepl'); 
	var bttirer=document.getElementById('btntirer'); 

	var etiquemenuu=document.getElementById('etiquettemenu'); 
	var welcom=document.getElementById('welcom'); 


	var acc=document.getElementById('accueil');
	var command=document.getElementById('commande');
	var tableau=document.getElementById('tableau');
	var notification=document.getElementById('notification');
	var aide=document.getElementById('aide'); 
	var photacceuil=document.getElementById('photacceuil'); 
	var photcomm=document.getElementById('photcommander'); 
	var phottableaub=document.getElementById('phottableau'); 
	var photnotif=document.getElementById('photnot'); 
	var photaidee=document.getElementById('photaide'); 





	function tire(){	
	tirerr.style.width=60+"%";
	tirerr.style.height=1000+"px";
	welcom.innerText="";

	btreplier.style.width=100+"px"
	btreplier.style.height=100+"px"
	bttirer.style.width=0+"px";
	bttirer.style.height=0+"px";

	photacceuil.style.height=50+"px";
	photacceuil.style.width=60+"px";

	photcomm.style.height=50+"px";
	photcomm.style.width=60+"px";

	phottableaub.style.height=50+"px";
	phottableaub.style.width=60+"px";

	photnotif.style.height=60+"px";
	photnotif.style.width=60+"px";

	photaidee.style.height=60+"px";
	photaidee.style.width=70+"px";



	acc.value="Acceuil"
	command.value="Commande ";
	tableau.value="Tableau de Bord";
	notification.value="Notification";
	aide.value="Aide ?";
	etiquemenuu.innerText="MENU";
	}
	function replier(){	
		//style="width: 70px; height: 55px; 
	btreplier.style.width=0+"%"
	btreplier.style.height=0+"%"

	bttirer.style.width=100+"px";
	bttirer.style.height=100+"px";
	var nom='<?php echo $prenom ?>';

	welcom.innerText= nom + ", Voilà vos statistiques" ;
	acc.value="";
	command.value="";
	tableau.value="";
	notification.value="";
	aide.value="";
	etiquemenuu.innerText="";



	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";

	photacceuil.style.height=0+"px";
	photacceuil.style.width=0+"px";

	photcomm.style.height=0+"px";
	photcomm.style.width=0+"px";

	phottableaub.style.height=0+"px";
	phottableaub.style.width=0+"px";

	photnotif.style.height=0+"px";
	photnotif.style.width=0+"px";

	photaidee.style.height=0+"px";
	photaidee.style.width=0+"px";
	
	}
	function ouverture(){
	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";
	}

	
</script>

<?php 
include("footeur.php");
?>

</body>
</html>