<!DOCTYPE html>
<html>
<head>
  <title>Récupérer la longitude du client</title>
  <script>
    function getLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
      } else {
        alert("La géolocalisation n'est pas prise en charge par ce navigateur.");
      }
    }

    function showPosition(position) {
      var longitude = position.coords.longitude;
      document.getElementById("longitude").value = longitude;

      // Envoyer le formulaire avec la longitude à votre script PHP côté serveur
      document.getElementById("geoForm").submit();
    }
  </script>
</head>
<body>

<form id="geoForm" action="votre_script_php.php" method="post">
  <input type="hidden" id="longitude" name="longitude">
  <input type="button" value="Récupérer la longitude" onclick="getLocation()">
</form>

</body>
