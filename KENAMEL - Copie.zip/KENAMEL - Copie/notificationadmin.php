<?php 
$idd=($_GET['ident']);
//$iddd=($_GET['ident'])
include("conn.php");
$etat="";
$ecritbtn="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$eta="";

$sql1=mysql_query("select Nom,Prenom from client where id_client ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql1)) {
        $nom=$ligne['Nom'];
        $prenom=$ligne['Prenom'];
	}

        $sejprev=0;
        $sejeff=0;   
	 	$sejreste= $sejprev-$sejeff;
	 	$msgg=";";
	 	$titre="RAPPEL";
		$ff="calendar.png";
		$dats="";
	 	$titre="RAPPEL";
	 	$dats="";
		$ff="";
	 	$msgg="";
	 	$titre="";
	 	$dats="";
	 	

$sql2=mysql_query("select detail,etat,dat from avertissement where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql2)) {
        $message=$ligne['detail'];
        $eta=$ligne['etat'];
        $datt=$ligne['dat'];
	}
	if($eta=="1"){
		$etat="+1";
		$ff="2326147.png";
	}
	else{
		
	}


	$sql2=mysql_query("select Etatt from notification where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql2)) {
        $ettats=$ligne['Etatt'];
	}
	if($ettats=="1"){
		$etatt=" +1";
		$ff="2326147.png";
	}
	else{
		
		$etatt="";
		
	}


	if (isset($_POST['commande'])) {
		header('location:commandeadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['tableau'])) {
		header('location:tableauadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['acceuil'])) {
		header('location:accueiladmin.php?ident='.$idd.'');
	}

	if (isset($_POST['aide'])) {
		$idd=$idd.",rien";
		header('location:aideadmin.php?ident='.$idd.'');
	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notification.php?ident='.$idd.'');
	} 
	if (isset($_POST['confirmelect2'])) {

		$sqllss=mysql_query("update notification set Etatt= '0' where id='".$idd."'");
		 if($sqllss){
		 	echo '<script> alert("La confirmation réalisée avec succes")</script>';
		 }
		 else{
		 		echo '<script> alert(" Erreur inattendue ")</script>';
		 }

		$sqlls2=mysql_query("select Etatt from notification where id ='".$idd."'");

	    while ($ligne=mysql_fetch_array($sqlls2)) {
	        $ettats=$ligne['Etatt'];
		}
		if($ettats=="1"){
			$ettats="/+1";
		}
		else{
			$ettats="";
		}
		
	}

	if (isset($_POST['confirmelecture'])) {
		$i=0;
		$sqlls=mysql_query("update avertissement set etat= '".$i."' where id='".$idd."'");

		 if($sqlls){
		 	echo '<script> alert("La confirmation réalisée avec succes")</script>';

		 	$sqll21=mysql_query("select etat from avertissement where id ='".$idd."'");

		     while ($ligne=mysql_fetch_array($sqll21)) {
		        $eta=$ligne['etat'];
			}

			if($eta=="1"){
				$etat=" +1";
			}
			else{
				$etat="";
			}

		 }

	} 



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion Hotel</title>
		<link rel="stylesheet" type="text/css" href="beaute.css">
</head>
<body onload="ouverture()" style="background-color: aliceblue">
<div style="width:100%; height:100% background-color:aliceblue; border-radius:1%; "> 
	<div style=" width: 100%;height:300px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">

	    <form method="POST" action="">	
			
			<div style="width: 78%; height: 300px; display: inline-block;">
				<?php

					include("tete.php");
					//$phot="hotimG\PhoClient\\".$idd.".JPEG";
					$phot="adminn.png";

			    ?>

			
			</div>
				<div style="width: 20%; height: 300px; display: inline-block;">
						
						 <div style="width: 100%; height: 250px">
						 	 <img src="<?php echo $phot ?>" style="width: 100%; height: 80%; border-radius:60%"> <br>
						 	 <center>
						 	 	<input type="submit" name="notificationhaute" style="width: 60px;height: 60px;background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));background-image: url(<?php echo $ff;?>);border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%;" value="">

						



						 	 	<b style="color: white; font-size: 35px; background-color: red; border-radius: 50%;"> <?php echo $etat.$etatt.$dats ; ?>  </b>
						 	 </center>
						 		 	
						 </div>
			
				</div>
		
		</form>
	</div>

		
	<!-- les diffent bouton de menue-->

	<div style="width:0px; height: 0%;background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))" id="tire">
			<div id="haut" style="width: 83%; height: 10%; display: inline-block;background-color: black; box-shadow: 3px 4px 2px blue; opacity: 80%"><br>
					<b id="etiquettemenu" style="margin-left: 30%; color: white; font-size: 70px">
						
					</b><br><br>
					
					
			</div>

			<div style="width: 15%; height: 10%; display: inline-block;">
					<input id="btrepl" type="button" name="" text="ici" onclick="replier()" style="width: 0px; height: 0px; background-image: url(c1.PNG); border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%">	
			</div>
			 		<br><br><br>

		<form action="" method="POST">

				<img id="photacceuil" style="width:0px; height:0px;margin-left: 5%" src="images\house_115210.png">

				<input type="submit" name="acceuil" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="accueil"> 
				<br><br><br><br>

				<img id="photcommander" style="width:0px; height:0px;margin-left: 5% " src="images\platt.jpg">

				<input type="submit" name="commande" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="commande"> 
				<br><br><br><br>

				<img id="phottableau" style="width:0px; height:0px;margin-left: 5% " src="images\statistique.png">

				<input type="submit" name="tableau" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="tableau">

				<br><br><br><br>

				<img id="photnot" style="width:0px; height:0px;margin-left: 5% " src="images\1592461.png">

				<input type="submit" name="notification" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="notification"> 
				<br><br><br><br>

				<img id="photaide" style="width:0px; height:0px;margin-left: 5%" src="images\admin.png">

				<input type="submit" name="aide" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="aide">
				<br>
		</form>

			
	</div>
	<!-- fin des diffent bouton de menue-->

	<form action="" method="POST">
			<div style="width: 100%; height: 20%; background-color: rgba(0,0,0,0)">
				<div style="width:15%; height: 100%; display: inline-block; ">
					<input id="btntirer" type="button" name="" text="ici" onclick="tire()" style="width: 100px; height: 100px; background-image: url(c1.PNG); background-repeat: no-repeat;background-size: 100%; border-top: none;border-right: none; border-left: none; border-bottom: none;">

				</div>
				<div style="width: 80%; height: 100% ;display: inline-block;">
					<b id="welcom" style="text-align: center; text-shadow: 1px 2px 1px rgba(120,120,150,100);font-size:40px; margin-left: 5%" > Admin <?php echo "  ". $prenom; ?>  , Vous avez des Nouvelles  </b> <br><br>
					
				</div>
				
			</div>
	</form>
	<hr style="box-shadow: 3px 2px 2px gray">
<br><br><br>
	<!-- debut de contenu !-->
	<div style="width: 100%; height: auto;">
		<center>
			<table>
				<tr>
					<td><img src="images\jj.png" style="width: 150px; height: 100px"></td>
					<td> <b style="font-size: 35px">Notre Entité est là pour:</b>
						<ol style="font-size: 30px">
							<li> Vous protéger</li>
							<li> vous Servir</li>
						</ol>
					</td>
				</tr>
				
			</table>
		</center>
		<h1 style="background-color: tomato; color: white; text-align: center; font-size: 40px"> New's sur votre sécurité</h1>
<center>
	<table>

		<?php 
		$sqll1=mysql_query("select detail,dat from avertissement where id ='".$idd."' order by dat DESC");

	     while ($ligne=mysql_fetch_array($sqll1)) {
	        $detaill=$ligne['detail'];
	        $datts=$ligne['dat'];
		?>

		
			<tr>
				<td>
					<img src="images\adminn.png" style="border-radius: 60%">
					
				</td>
				<td style="width: 300px; border-radius: 22%; background-color:white; box-shadow: 6px 3px 2px black">
					<?php echo $detaill ; ?>
					
				</td>
			</tr>
			<tr>
				<td>
					
				</td>
				<td style="color : red; text-align: right;">
					<?php echo $datts; ?>
					
				</td>
			</tr>

		<?php
		 }
		?>
	</table>
			<div style="width: 400px; height: 300px; background-image: url(welcome_people_icon_176891.png); background-size: 100%; background-repeat: no-repeat; background-color: gray; box-shadow: 6px 5px 2px blue">
				<b style="text-shadow: 2px 2px 2px white; color:blue; font-size: 25px">Mbote</b> <br><br>
				<b style="text-shadow: 2px 2px 2px white; color:blue; font-size: 25px; margin-left: 30%">Djambo</b><br><br>
				<b style="text-shadow: 2px 2px 2px white; color:blue; font-size: 25px; margin-left: 60%">Moyo</b>
				

			</div>
<form action="" method="POST">
	<input type="submit" name="confirmelecture" value="Confimez la lecture" style="margin-left: 80%; background-color: blue; color: white; border-top:none; border-bottom: none; border-left: none; border-right: none; font-size: 20px ">
</form>

<hr style="box-shadow: 3px 3px 2px gray; ">
<div style="width: 600px; height: 300px; border-radius: 12%; box-shadow: 3px 4px 2px gray; color:black;" id="messsej">
	<br><br>
	<b style="font-size: 30px; text-shadow: 2px 2px 1px gray"> <?php echo $titre; ?></b>

	<br><br>
	
	<i style="font-size: 30px; text-shadow: 2px 2px 1px gray;color:black"> <?php echo $msgg;?></i>
</div>

     <h1 style="background-color: tomato; color: white; text-align: center; font-size: 40px"> New's Provenant du Gestionnaire </h1>
        <br>
<form action="" method="POST">
	
<table>
        <?php 
		$sqll1=mysql_query("select mess,dat,heuree from notification where id ='".$idd."' order by dat DESC");

	     while ($ligne=mysql_fetch_array($sqll1)) {
	        $mess=$ligne['mess'];
	        $dattt=$ligne['dat'];
	        $heurr=$ligne['heuree'];
		?>

		
			<tr>
				<td>
					<img src="images\adminn.png" style="border-radius: 60%">
					
				</td>
				<td style="width: 400px; border-radius: 22%; background-color:white; box-shadow: 6px 3px 2px black">
					<?php echo $mess ; ?>
					
				</td>
			</tr>
			<tr>
				<td>
					
				</td>
				<td style="color : red; text-align: right;">
					<?php echo $dattt."  à  ".$heurr ; ?>
					
				</td>
			</tr>

		<?php
		 }
		?>
</table>
<br>
<input type="submit" name="confirmelect2" value="Confimez la lecture" style="margin-left: 80%; background-color: blue;text-shadow: 1px 2px 2px gray; color: white; border-top:none; border-bottom: none; border-left: none; border-right: none; font-size: 20px ">
<br>
</form>

			<div style="width: 400px; height: 300px; background-image: url(n.png); background-size: 100%; background-repeat: no-repeat; box-shadow: 6px 5px 2px red">
				<br><br>
							<b style="text-shadow: 2px 2px 2px red; color:white; font-size: 25px">Kinshasa</b> <br><br><br>
							<b style="text-shadow: 2px 2px 2px red; color:white; font-size: 25px; margin-left: 50%">Drc</b><br><br><br>
							<b style="text-shadow: 2px 2px 2px red; color:white; font-size: 25px; margin-left: 75%">Africa</b>			

			</div>

</center>
		
	</div>
		
	</div>

<script>
	//let temps=20;
	var tirerr=document.getElementById('tire');
	var btreplier=document.getElementById('btrepl'); 
	var bttirer=document.getElementById('btntirer'); 

	var etiquemenuu=document.getElementById('etiquettemenu'); 
	var welcom=document.getElementById('welcom'); 


	var acc=document.getElementById('accueil');
	var command=document.getElementById('commande');
	var tableau=document.getElementById('tableau');
	var notification=document.getElementById('notification');
	var aide=document.getElementById('aide'); 
	var photacceuil=document.getElementById('photacceuil'); 
	var photcomm=document.getElementById('photcommander'); 
	var phottableaub=document.getElementById('phottableau'); 
	var photnotif=document.getElementById('photnot'); 
	var photaidee=document.getElementById('photaide'); 

	function tire(){	
	tirerr.style.width=60+"%";
	tirerr.style.height=1000+"px";
	welcom.innerText="";

	btreplier.style.width=100+"px"
	btreplier.style.height=100+"px"
	bttirer.style.width=0+"px";
	bttirer.style.height=0+"px";

	photacceuil.style.height=50+"px";
	photacceuil.style.width=60+"px";

	photcomm.style.height=50+"px";
	photcomm.style.width=60+"px";

	phottableaub.style.height=50+"px";
	phottableaub.style.width=60+"px";

	photnotif.style.height=60+"px";
	photnotif.style.width=60+"px";

	photaidee.style.height=60+"px";
	photaidee.style.width=70+"px";



	acc.value="Acceuil"
	command.value="Commande ";
	tableau.value="Tableau de Bord";
	notification.value="Notification";
	aide.value="Aide ?";
	etiquemenuu.innerText="MENU";
	}
	function replier(){	
		//style="width: 70px; height: 55px; 
	btreplier.style.width=0+"%"
	btreplier.style.height=0+"%"

	bttirer.style.width=100+"px";
	bttirer.style.height=100+"px";
	var nom='<?php echo $prenom ?>';

	welcom.innerText=nom +", Vous avez  des Nouvelles " ;
	acc.value="";
	command.value="";
	tableau.value="";
	notification.value="";
	aide.value="";
	etiquemenuu.innerText="";



	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";

	photacceuil.style.height=0+"px";
	photacceuil.style.width=0+"px";

	photcomm.style.height=0+"px";
	photcomm.style.width=0+"px";

	phottableaub.style.height=0+"px";
	phottableaub.style.width=0+"px";

	photnotif.style.height=0+"px";
	photnotif.style.width=0+"px";

	photaidee.style.height=0+"px";
	photaidee.style.width=0+"px";
	
	}
	function ouverture(){
	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";
	}

	
</script>


<?php 
include("footeur.php");
?>

</body>
</html>