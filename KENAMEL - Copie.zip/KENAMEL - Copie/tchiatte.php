<?php 
//$idd=($_GET['ident'];
//$iddd=($_GET['ident'])
$idmess="";
$nom="";
$pren="";
$phot="";
$eti="";
$messagee="Message";
$commande="Commande";
$etacompare="";
$etacommande="";
$ddatss=date('Y-m-d');

include("conn.php");

 $sqqlsl=mysql_query("select etat from messagess where etat='0'");

   		while ($ligne=mysql_fetch_array($sqqlsl)) {
       			 $etacompare=$ligne['etat']; 
		}
		if($etacompare=="0"){
			$messagee="Message"." (1)";
		}

 $sqqlssl=mysql_query("select Etat from commande where Etat='0' and Dates='".$ddatss."'");////////////////

   		while ($ligne=mysql_fetch_array($sqqlssl)) {
       		$etacommande=$ligne['Etat']; 
		}
		if($etacommande=="0"){
			$commande="Commande"." (1)";
		} 
if (isset($_POST['ferm'])) {
	
}
if (isset($_POST['btnn1'])) {

	    $tt1=($_POST['t1']);
	    $dats=($_POST['dats']);

	    $sql2=mysql_query("update messagess set etat='1' where id_mes='".$tt1."'");
		header('location:tchiat.php?ident='.$tt1.'');
	}
if (isset($_POST['btnn2'])) {

	    $tt2=($_POST['t2']);

	    $sql2=mysql_query("update messagess set etat='1' where id_mes='".$tt2."'");

		header('location:tchiat.php?ident='.$tt2.'');
	}
	if(isset($_POST['Stat'])){
		header('location:statistique1.php');
	}

	if (isset($_POST['actualiser'])) {

	    $sqqlsl=mysql_query("select etat from messagess where etat='0'");

   		while ($ligne=mysql_fetch_array($sqqlsl)) {
       			 $etacompare=$ligne['etat']; 
		}
		if($etacompare=="0"){
			$messagee="Message"." (1)";
		}

		$sqqlssl=mysql_query("select Etat from commande where Etat='0'");

   		while ($ligne=mysql_fetch_array($sqqlssl)) {
       		$etacommande=$ligne['Etat']; 
		}
		if($etacommande=="0"){
			$commande="Commande"." (1)";
		}
	}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<center>
	<div style="width: 98%; height: auto;background-color: aliceblue">
		<div style="width: 100%; height: 165px; position: fixed;">
				<div style="width: 100%; height:78%; background-color: black;">
					<?php
					include("tete.php");
					 ?>
				</div>
	<form action="" method="POST">
				<div style="width: 100%; height: 21%; background-color: tomato;">
					<img src="msgg.png" style="width:30px; height: 27px;margin-left: 40%; border-radius: 30%">
					<input type="submit" name="" value="<?php echo $messagee; ?>" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="2326147.png" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="Notification" value="Notification" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="logiciel-statistiques.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="Stat" value="Statistique" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="images\fast.png" style="width:30px; height: 27px;border-radius: 30%">
					<input type="submit" name="" value="<?php echo $commande; ?>" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="images\refresh_arrow_1546.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="actualiser" value="Actualiser" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">					

				</div>

	</form>
		</div>
		<br><br><br><br><br><br><br><br><br><br><br>

		<div style="width:15%; height: 180px ; display: inline-block;background-image: url(danger.jpg); background-size: 95%; background-repeat: no-repeat;"></div>

		<div style="width:35%; height: 180px; display: inline-block; font-size: 25px; text-shadow: 1px 1px gray; text-align: justify;">
			<i> <span style="font-size: 30px; color:tomato; text-shadow: 1px 2px 2px gray">B</span>ienvenu sur l'espace tchiatte admin, En effet ce dernier est dédié à la <span style="color:blue; border: 2px tomato dashed;box-shadow: 2px 2px 2px gray; border-left: none; border-right: none; border-top:none; ">rancontre des besoins </span> de tous les clients ayant des lacunes vis-à-vis de la gestion utilisée, sur ce, vous etes prié de répondre à toutes les préocutions si importante afin de vouloir donner une solution pour la gestion future.<br></i>
		</div>


		<h2 style="font-size: 40px ; color:white; background-color: tomato; text-shadow: 2px 2px 2px black"> Tchiombo na Tchiombo </h2>
		<?php 

		$sql1=mysql_query("select distinct id_mes,Nom,Prenom from messagess,client where id_mes=Id and etat='0'");
			//);
		   	while ($ligne=mysql_fetch_array($sql1)) {
		        $idmess=$ligne['id_mes'];
		        $nom=$ligne['Nom'];
		        $pren=$ligne['Prenom']; 

		        $phot="\hotimG\\".$idmess.".JPEG"; 
		        $eti="Vous avez un nouveau message de sa part";  

		?>
	<form action="" method="POST">
		<table>
			<tr>
				<td rowspan="2" style="width: 300px; height: 300px">
					<img style="background-size: 100%; width: 300px; height: 270px; border-radius: 60%" src=<?php echo  $phot; ?>>
					
				</td>
				<td style="width: 500px; height: 50px">
					<b style="font-size: 25px; text-shadow: 1px 1px 1px gray; box-shadow: 2px 2px 2px gray">
						<?php echo  $nom ."  ". $pren ?>	
					</b>
					
				</td>
			</tr>

			<tr>
				<td style="width: 500px; height: 200px">
					<i style="font-size: 30px "> <?php echo $eti; ?></i>
					
				</td>
			</tr>
		</table>
		<input type="text" style="width: 0px; height: 0px; background-color:aliceblue; border-top: none; border-bottom: none; border-right: none; border-left: none" name="t1" value="<?php echo $idmess; ?>">
		<input type="submit" name="btnn1" value="Afficher" style="background-color: blue; font-size: 20px; text-shadow: 1px 1px 1px gray; color:white; width: 150px; border-top: none; border-right: none; border-bottom: none; border-left: none; margin-left: 40%">

	</form>
	<hr style="box-shadow: 2px 3px 2px gray">

		<?php
		} 
		?>
		<hr style="border-color:tomato;box-shadow: 2px 2px 2px gray">

		<?php

		$sqlls1=mysql_query("select distinct id_mes,Nom,Prenom from messagess,client where id_mes=Id and etat='1'");
		   	while ($ligne=mysql_fetch_array($sqlls1)) {
		        $idmess=$ligne['id_mes'];
		        $nom=$ligne['Nom'];
		        $pren=$ligne['Prenom']; 
		        

		        $phot="\hotimG\\".$idmess.".JPEG";

		        $messes="Historiques "; 
		          

		?>

		<form action="" method="POST">
		<table>
			<tr>
				<td rowspan="2" style="width: 300px; height: 300px">
					<img style="background-size: 100%; width: 300px; height: 270px; border-radius: 60%" src=<?php echo  $phot; ?>>
					
				</td>
				<td style="width: 500px; height: 50px">
					<b style="font-size: 25px; text-shadow: 1px 1px 1px gray; box-shadow: 2px 2px 2px gray">
						<?php echo  $nom ."  ". $pren ?>	
					</b>
					
				</td>
			</tr>

			<tr>
				<td style="width: 500px; height: 200px">
					<i style="font-size: 30px; color:tomato; text-shadow: 1px 2px 1px gray "> <?php echo $messes; ?></i>
					
				</td>
			</tr>
		</table>
		<input type="text" style="width: 0px; height: 0px; background-color:aliceblue; border-top: none; border-bottom: none; border-right: none; border-left: none" name="t2" value="<?php echo $idmess; ?>">
		<input type="submit" name="btnn2" value="Consulter" style="background-color: tomato; font-size: 20px; text-shadow: 1px 1px 1px gray; color:white; width: 150px; border-top: none; border-right: none; border-bottom: none; border-left: none; margin-left: 40%">
	</form>
	<hr style="box-shadow: 2px 3px 2px gray">

<?php
}
 ?>	

 <?php
include("shoutaireautre.php");
 ?>
	</div>
</center>

</body>
</html>