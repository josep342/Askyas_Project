
<?php
$type="";

function isMobileDevice() 
{
    // Récupérer le User-Agent de la requête HTTP
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
   
    // Liste des mots-clés pour identifier les appareils mobiles
    $mobileKeywords = array(
        'Mobile', 'Android', 'Silk/', 'Kindle', 'BlackBerry', 'Opera Mini', 'IEMobile', 'Windows Phone'
    );
   
    // Vérifier si le User-Agent contient l'un des mots-clés
    foreach ($mobileKeywords as $keyword) {
        if (stripos($userAgent, $keyword) !== false) {
            return true; // C'est un appareil mobile
        }
    }
   
    return false; // C'est probablement une machine
}

// Exemple d'utilisation
if (isMobileDevice()) {
	$type="phone";
    //echo "Vous utilisez un appareil mobile.";
} else {
	$type="machine";
    //echo "Vous utilisez un ordinateur.";
}
?>

<?php 
$idd="";
//($_GET['ident']);

//$iddd=($_GET['ident'])
include("conn.php");
$etat="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$notif="";
$testlike="";
$nbrjaim=0;
$detest=0;


$sql1=mysql_query("select Nom,Prenom from client where id_client ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql1)) {
        $nom=$ligne['Nom'];
        $prenom=$ligne['Prenom'];
	}  

	$sejreste= "";
	 
	
 	$dats="+1";
	$ff="calendar.png";
	 
	$dats="";

	if (isset($_POST['commande'])) {
		//header('location:commande.php?ident='.$idd.'');
		echo'<script> alert("Promotion  ou marché assisté cad dans le cas où un commissionnaire a apporté un marché dans l entreprise, dans ce cas on travaille comme passerelle d affaire ");</script>';

	}

	if (isset($_POST['tableau'])) {
		
		echo'<script> alert(" Tableau de produit en venté avec tout détail cad qualité, dimension, taille, et localisation ......ici j vais inserer la localisation GPS si nessaire ");</script>';

	}

	if (isset($_POST['notification'])) {

		echo'<script> alert("Statistique ou historique d affaire d un commissionaire  avec détail possible ");</script>';

		//header('location:notification.php?ident='.$idd.'');
	}

	if (isset($_POST['aide'])) {
		//header('location:aide.php?ident='.$idd.'');
		echo'<script> alert("Service client.... on va programmer un nombre de BOT pour servir aux questions de cliens en attendant.... ");</script>';


	} 
	if (isset($_POST['power'])) {
		//header('location:aide.php?ident='.$idd.'');
		echo'<script> alert("Fermeture de la session");</script>';

	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notification.php?ident='.$idd.'');
	}   
	if (isset($_POST['btnjaime'])) {
		$pubid=($_POST['idpub']);

		
		$sqlrechlike=mysql_query("select etat from likes where id_pub='".$pubid."' and id_client='".$idd."'");

	     while ($ligne=mysql_fetch_array($sqlrechlike)) {
	        $testlike=$ligne['etat'];
		}
		if($testlike=="1"){
		echo'<script> alert("Le Gestionnaire systeme remarque que tu as une fois deja liker cette pub, \n NB: Chaque personne ne peut liker qu une seule fois ");</script>';

		}
		else if($testlike=="0"){

		$sqlpubrech1=mysql_query("select jaime,detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech1)) {
	        $nbrjaim=$ligne['jaime'];
	        $detest=$ligne['detester'];
		}
		$nbrjaim=$nbrjaim+1;
		$detest= $detest-1;

		$sqlpubmod1=mysql_query("update pub set jaime='$nbrjaim',detester='$detest' where id='".$pubid."'");

		$sqlmodlike1=mysql_query("update likes set etat='1' where id_pub='".$pubid."' and id_client='".$idd."'");

		if($sqlpubmod1 && $sqlmodlike1){

			echo'<script> alert("Le like a ete signalee à la pub avec succes");</script>';

		}
		else{

			echo'<script> alert("Erreur inattendue");</script>';

		}

		}
		else{

		$sqlinserlike=mysql_query("insert into likes values('$idd','$pubid','1')");

		$sqlpubrech=mysql_query("select jaime from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech)) {
	        $nbrjaim=$ligne['jaime'];
		}
		$nbrjaim=$nbrjaim+1;

		$sqlpubmod=mysql_query("update pub set jaime='$nbrjaim' where id='".$pubid."'");
		
		
		

		}

	} 

	if (isset($_POST['btndetester'])) {

		$pubid=($_POST['idpub']);

		$sqlrechlike=mysql_query("select etat from likes where id_pub='".$pubid."' and id_client='".$idd."'");

	     while ($ligne=mysql_fetch_array($sqlrechlike)) {
	        $testlike=$ligne['etat'];
		}
		if($testlike=="0"){
			echo'<script> alert("Le Gestionnaire systeme remarque que tu as une fois deja Detester cette pub, \n NB: Chaque personne ne peut Detester qu une seule fois ");</script>';

		}
		else if($testlike=="1"){

		$sqlpubrech1=mysql_query("select jaime,detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech1)) {
	        $nbrjaim=$ligne['jaime'];
	        $detest=$ligne['detester'];
		}
		$nbrjaim=$nbrjaim-1;
		$detest= $detest+1;

		$sqlpubmod1=mysql_query("update pub set jaime='$nbrjaim',detester='$detest' where id='".$pubid."'");

		$sqlmodlike1=mysql_query("update likes set etat='0' where id_pub='".$pubid."' and id_client='".$idd."'");

		if($sqlpubmod1 && $sqlmodlike1){

			echo'<script> alert("La detestation a ete signalee à la pub correctement");</script>';

		}
		else{

			echo'<script> alert("Erreur inattendue");</script>';

		}

		}
		else{

		$sqlinserlike=mysql_query("insert into likes values('$idd','$pubid','0')");

		$sqlpubrech=mysql_query("select detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech)) {
	        $detest=$ligne['detester'];
		}
		$detest=$detest+1;

		$sqlpubmod=mysql_query("update pub set detester='$detest' where id='".$pubid."'");
		
		if($sqlpubmod){

			$notif="Detester par vous et autres  personnes";
			echo'<script> alert("La detestation a ete signalee à la pub avec correctement");</script>';
		}
		else{
			echo'<script> alert("Erreur inattendue");</script>';
		}
		

		}
		


	} 

	

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>KENAMEL BUSINESS</title>
		
		<link rel="stylesheet" href="styl.css">
		<link rel="stylesheet" href="animation1.css">
		
</head>
<body onload="ouverture()" style="background-color: aliceblue">
	<div style="width: 80%; height: auto;margin-left: 10%">

		<div style=" width: 100%;height:100px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">

	    <form method="POST" action="">	
			
			<div style="width: 100%; height: 100px">
				<?php

					include("tete.php");
					$phot="hotimG\PhoClient\\".$idd.".JPEG";

			    ?>

			
			</div>
		</form>

			<div style="width: 100%; height: 60px; background-color: black">
				<a href="accueil.php" style="font-size: 25px; text-decoration: none; color: white;margin-left:45% ">Accueil</a>
				<a href="activite.php" style="font-size: 25px; text-decoration: none; color: white;margin-left:3%">Activités</a>
				<a href="" style="font-size: 25px; text-decoration: none; color: white;margin-left:3%">Annonce</a>
				<a href="aidekenamel.php" style="font-size: 25px; text-decoration: none; color: white;margin-left:3%">Aide ?</a>
			</div>

			
		</div>

		<br><br> <br>

		<h1 style="text-align: center">Annonces</h1>

		<div class="souscadre">

		</div>

		<div class="souscadre1">

		</div>

		


		<?php 
			include("footeur.php");
		?>
		
	</div>

<script>
	//let temps=20; 
	
	var tirerr=document.getElementById('tire');
	var btreplier=document.getElementById('btrepl'); 
	var bttirer=document.getElementById('btntirer'); 

	var etiquemenuu=document.getElementById('etiquettemenu'); 
	var welcom=document.getElementById('welcom'); 


	var acc=document.getElementById('accueil');
	var command=document.getElementById('commande');
	var tableau=document.getElementById('tableau');
	var notification=document.getElementById('notification');
	var aide=document.getElementById('aide'); 
	var photacceuil=document.getElementById('photacceuil'); 
	var photcomm=document.getElementById('photcommander'); 
	var phottableaub=document.getElementById('phottableau'); 
	var photnotif=document.getElementById('photnot'); 
	var photaidee=document.getElementById('photaide');

	var photpower=document.getElementById('photopower'); 


	function tire(){	

	

	tirerr.style.width=60+"%";
	tirerr.style.height=1000+"px";
	welcom.innerText="";

	btreplier.style.width=100+"px"
	btreplier.style.height=100+"px"
	bttirer.style.width=0+"px";
	bttirer.style.height=0+"px";

	photacceuil.style.height=50+"px";
	photacceuil.style.width=60+"px";

	photcomm.style.height=50+"px";
	photcomm.style.width=60+"px";

	phottableaub.style.height=50+"px";
	phottableaub.style.width=60+"px";

	photnotif.style.height=60+"px";
	photnotif.style.width=60+"px";

	photaidee.style.height=60+"px";
	photaidee.style.width=70+"px";

	photpower.style.height=60+"px";
	photpower.style.width=70+"px";

	acc.value="Actualité"
	command.value="Annonce ";
	tableau.value="Full Marché";
	notification.value="Tableau de Bord";
	aide.value="Aide ?";
	etiquemenuu.innerText="MENU";
	}
	function replier(){	
		 
	btreplier.style.width=0+"%"
	btreplier.style.height=0+"%"

	bttirer.style.width=100+"px";
	bttirer.style.height=100+"px";
	var nom='<?php echo $nom ."  ".$prenom ?>';

	welcom.innerText="Welcome Mr/Mlle "+nom ;
	acc.value="";
	command.value="";
	tableau.value="";
	notification.value="";
	aide.value="";
	etiquemenuu.innerText="";



	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";
	

	photacceuil.style.height=0+"px";
	photacceuil.style.width=0+"px";

	photcomm.style.height=0+"px";
	photcomm.style.width=0+"px";

	phottableaub.style.height=0+"px";
	phottableaub.style.width=0+"px";

	photnotif.style.height=0+"px";
	photnotif.style.width=0+"px";

	photaidee.style.height=0+"px";
	photaidee.style.width=0+"px";

	photpower.style.height=0+"px";
	photpower.style.width=0+"px";

	
	}
	function ouverture(){
	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";
	}

	
</script>

</body>
</html>