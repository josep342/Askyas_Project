<?php 
$id1="";
$nom1="";
$postnom1="";
$prenom1="";
$sexe1="";
$idchamb="";
$prixx="";
$sejourtot="";
$sejoureff="";
$ptts="";
$decison="";
$datea=""; 
$selecteur="";
$idmois="";
$etiquette="";

include("conn.php");

if(isset($_POST['stat2'])){
	header('location:statistique2.php');	
} 
if(isset($_POST['Stat3'])){
	header('location:statistique3.php');	
}
if(isset($_POST['env'])){
	$idmois=($_POST['mois']);
	$etiquette=$idmois;
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<div style="width:98%; height: auto;background-color: aliceblue ">
	<div style="width: 100%; height:78%; background-color: black;">
					<?php
					include("tete.php");
					 ?>
	</div>

	<form action="" method="POST">
				<div style="width: 100%; height: 21%; background-color: tomato;">
					<img src="bedroom_icon-icons.com_63554.png" style="width:30px; height: 27px;margin-left: 40%; border-radius: 30%">
					<input type="submit" name="stat1" value="Statistique Chambre" style="font-size: 22px; border-top: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black;">

					<img src="plats.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="stat2" value="Statistique Restauration" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="statt.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="Stat3" value="Statistique Pub's" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">				

				</div>

	</form>

	<br><br><br>
	<center>

		<div style="width: 20%; height: 300px; background-image: url(home_243.png);background-size: 90%; background-repeat: no-repeat; display: inline-block;">
			
		</div>
		<div style="width: 40%; height: 300px;display: inline-block;text-align: justify;">
			<i style="font-size: 40px; text-shadow: 1px 2px 1px gray;">Bienvenu dans l'éditeur de Performance, ce dernier vous permet d'exécuter toutes les requetes importantes sur les activités réalisées concernant le <span style="color:blue">Logement </span> </i>
			<br><br>
		</div>


		<h2 style="background-color: tomato; color:white; text-shadow: 1px 2px 1px black; font-size: 35px">Analyseur</h2>


		<form action="" method="POST">

		<div style="width: 20%;height: 80px; border: solid 2px gray; font-size: 25px; text-shadow: 1px 2px 1px gray;display: inline-block;">
			<br>
			Mois 

			<select style="width: 120px" name="mois">
				<option> </option>
				<option>Tous</option>

	<?php 

		$sql1=mysql_query("select daatt from dispodatee");

    	 while ($ligne=mysql_fetch_array($sql1)) {
        	$ddat=$ligne['daatt'];
	?>
				
				<option><?php echo $ddat; ?> </option>
	<?php 
	}
	?>

			</select>
			

		</div>

		
		<input type="submit" name="env" value="Rechercher" style="display: inline-block;">
		<br>

		<br>

	<h2 style="background-color: tomato; color:white; text-shadow: 1px 2px 1px black; font-size: 35px"> <?php echo  "Les activités de ".$etiquette." en USD"; ?></h2>
		<br>

	<table style="background-color: white">
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px; border:solid 1px gray; background-color: blue;color:white">ID Client</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">Nom</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px black;  background-color: blue; color:white">Postnom</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">Prenom</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray;  background-color: blue; color:white">Sexe</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">ID Produit</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">Nom</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">PU</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">Quantité</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray;  background-color: blue; color:white">PT</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray; background-color: blue; color:white">Date</th>
		<th style="text-shadow: 1px 2px 1px black; font-size: 25px;border:solid 1px gray;  background-color: blue; color:white">Heure</th>

		 <tr>
		    	<td colspan="12"> <h2 style="background-color: blue; color:white; text-shadow: 1px 2px 1px black; font-size: 30px; text-align: center;">Les Client ayant Correctement Liquidés</h2></td>
		    </tr>
		

		<?php
		if($idmois==""){
		
		}
		else if($idmois=="Tous"){
			$sqll1=mysql_query("select client.Id as ids,client.Nom as nm,Postnom,Prenom,Sexe,Id_chambre,Prix,Sejour,reglement.Datte-client.Datte as sej,reglement.Total as pt,Decision,reglement.Datte as datefin from client,chambre,unitule,reglement,historique where client.Id=reglement.IId and client.Id=historique.id and historique.Id_chamb=chambre.Id_chambre and Decision='ok'");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$id1=$ligne['ids'];
	        	$nom1=$ligne['nm'];
	        	$postnom1=$ligne['Postnom'];
	        	$prenom1=$ligne['Prenom'];
	        	$sexe1=$ligne['Sexe'];
	        	$idchamb=$ligne['Id_chambre'];
	        	$prixx=$ligne['Prix'];
	        	$sejourtot=$ligne['Sejour'];
	        	$sejoureff=$ligne['sej'];
	        	$ptts=$ligne['pt'];
	        	$decison=$ligne['Decision'];
	        	$datea=$ligne['datefin']; 
	        ?>

	        <tr>
	        	<td style="font-size: 20px;border:solid 1px blue;text-shadow: 1px 1px gray"> <?php echo $id1;?></td>
	        	<td style="font-size: 20px"> <i><?php echo $nom1;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i> <?php echo $postnom1;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $prenom1;?></i></td>
	        	<td style="font-size: 20px"> <?php echo $sexe1;?></td>
	        	<td style="font-size: 20px;border:solid 1px blue; text-shadow: 1px 1px gray"> <?php echo $idchamb;?></td>
	        	<td style="font-size: 20px"><i> <?php echo $prixx;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i><?php echo $sejourtot;?></i></td>
	        	<td style="font-size: 20px"> <i> <?php echo $sejoureff;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $ptts;?></i></td>
	        	<td style="font-size: 20px;text-shadow: 1px 1px 1px black; background-color: blue; color:white"> <?php echo $decison;?></td>
	        	<td style="font-size: 20px"> <?php echo $datea;?></td>

	        </tr>
	        

		   <?php 
		    }

		    $sqll1=mysql_query("select sum(Total) as somm from reglement where Decision='ok'");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$tot1=$ligne['somm'];
	        }
		    ?>

		    <tr>
		    	<td style="height: 40px"></td>
		    	
		    </tr>
		     <tr>
		    	<td colspan="9"> <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: blue">TOTAL</b></td>
		    	
		    	<td > <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: blue"> <?php echo $tot1; ?></b></td>
		    	<td ></td>
		    	<td ></td>
		    </tr>
		    <tr>
		    	<td style="height: 30px"></td>
		    </tr>

		     <tr>
		    	<td colspan="12"> <h2 style="background-color: seagreen; color:white; text-shadow: 1px 2px 1px black; font-size: 30px; text-align: center;"> Les Client dont les comptes encours</h2></td>
		    </tr>


		<?php
				$sqll1=mysql_query("select client.Id as ids,client.Nom as nm,Postnom,Prenom,Sexe,Id_chambre,Prix,Sejour,unitule.dat-client.Datte as sej,Prix* (unitule.dat-client.Datte) as pt,Decision,reglement.Datte as datefin from client,chambre,unitule,reglement where client.Id=reglement.IId  and Decision='-' and client.Id=chambre.Id_client");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$id1=$ligne['ids'];
	        	$nom1=$ligne['nm'];
	        	$postnom1=$ligne['Postnom'];
	        	$prenom1=$ligne['Prenom'];
	        	$sexe1=$ligne['Sexe'];
	        	$idchamb=$ligne['Id_chambre'];
	        	$prixx=$ligne['Prix'];
	        	$sejourtot=$ligne['Sejour'];
	        	$sejoureff=$ligne['sej'];
	        	$ptts=$ligne['pt'];
	        	$decison=$ligne['Decision'];
	        	$datea=$ligne['datefin']; 
			?>

			  <tr>
	        	<td style="font-size: 20px;border:solid 1px blue;text-shadow: 1px 1px gray"> <?php echo $id1;?></td>
	        	<td style="font-size: 20px"> <i><?php echo $nom1;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i> <?php echo $postnom1;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $prenom1;?></i></td>
	        	<td style="font-size: 20px"> <?php echo $sexe1;?></td>
	        	<td style="font-size: 20px;border:solid 1px blue; text-shadow: 1px 1px gray"> <?php echo $idchamb;?></td>
	        	<td style="font-size: 20px"><i> <?php echo $prixx;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i><?php echo $sejourtot;?></i></td>
	        	<td style="font-size: 20px"> <i> <?php echo $sejoureff;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $ptts;?></i></td>
	        	<td style="font-size: 20px;text-shadow: 1px 1px 1px black; background-color: blue; color:white"> <?php echo $decison;?></td>
	        	<td style="font-size: 20px"> <?php echo $datea;?></td>

	        </tr>

		<?php
		}

		 $sqll1=mysql_query("select sum(Prix* (unitule.dat-client.Datte)) as somm from client,chambre,unitule,reglement where client.Id=reglement.IId  and Decision='-' and client.Id=chambre.Id_client");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$tot1=$ligne['somm'];
	        }
		?>

		 	<tr>
		    	<td style="height: 30px"></td>
		    </tr>
		     <tr>
		    	<td colspan="9"> <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: seagreen">TOTAL</b></td>
		    	
		    	<td > <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: seagreen"> <?php echo $tot1; ?></b></td>
		    	<td ></td>
		    	<td ></td>
		    </tr>

		<?php 
		}
		else{

			$sqll1=mysql_query("select client.Id as ids,client.Nom as nm,Postnom,Prenom,Sexe,Id_chambre,Prix,Sejour,reglement.Datte-client.Datte as sej,reglement.Total as pt,Decision,reglement.Datte as datefin from client,chambre,unitule,reglement,historique where reglement.Datte='".$idmois."' and client.Id=reglement.IId and client.Id=historique.id and historique.Id_chamb=chambre.Id_chambre and Decision='ok'");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$id1=$ligne['ids'];
	        	$nom1=$ligne['nm'];
	        	$postnom1=$ligne['Postnom'];
	        	$prenom1=$ligne['Prenom'];
	        	$sexe1=$ligne['Sexe'];
	        	$idchamb=$ligne['Id_chambre'];
	        	$prixx=$ligne['Prix'];
	        	$sejourtot=$ligne['Sejour'];
	        	$sejoureff=$ligne['sej'];
	        	$ptts=$ligne['pt'];
	        	$decison=$ligne['Decision'];
	        	$datea=$ligne['datefin']; 
	        ?>

	        <tr>
	        	<td style="font-size: 20px;border:solid 1px blue;text-shadow: 1px 1px gray"> <?php echo $id1;?></td>
	        	<td style="font-size: 20px"> <i><?php echo $nom1;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i> <?php echo $postnom1;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $prenom1;?></i></td>
	        	<td style="font-size: 20px"> <?php echo $sexe1;?></td>
	        	<td style="font-size: 20px;border:solid 1px blue; text-shadow: 1px 1px gray"> <?php echo $idchamb;?></td>
	        	<td style="font-size: 20px"><i> <?php echo $prixx;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i><?php echo $sejourtot;?></i></td>
	        	<td style="font-size: 20px"> <i> <?php echo $sejoureff;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $ptts;?></i></td>
	        	<td style="font-size: 20px;text-shadow: 1px 1px 1px black; background-color: blue; color:white"> <?php echo $decison;?></td>
	        	<td style="font-size: 20px"> <?php echo $datea;?></td>

	        </tr>
	        

		   <?php 
		    }

		     $sqll1=mysql_query("select sum(Total) as somm from reglement where Decision='ok' and reglement.Datte='".$idmois."'");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$tot1=$ligne['somm'];
	        }

	        ?>
	     	<tr>
		    	<td style="height: 40px"></td>
		    	
		    </tr>
		     <tr>
		    	<td colspan="9"> <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: blue">TOTAL</b></td>
		    	
		    	<td > <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: blue"> <?php echo $tot1; ?></b></td>
		    	<td ></td>
		    	<td ></td>
		    </tr>

		    <tr>
		    	<td style="height:30px"> </td>
		    </tr>
		     <tr>
		    	<td colspan="12"> <h2 style="background-color: seagreen; color:white; text-shadow: 1px 2px 1px black; font-size: 30px; text-align: center;"> Les Commandes non servies</h2></td>
		    </tr>

	   <?php 
	  $sqll1=mysql_query("select client.Id as ids,client.Nom as nm,Postnom,Prenom,Sexe,Id_chambre,Prix,Sejour,unitule.dat-client.Datte as sej,reglement.Total as pt,Decision,reglement.Datte as datefin from client,chambre,unitule,reglement,historique where reglement.Datte='".$idmois."' and client.Id=reglement.IId and client.Id=historique.id and historique.Id_chamb=chambre.Id_chambre and Decision='-'");
	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$id1=$ligne['ids'];
	        	$nom1=$ligne['nm'];
	        	$postnom1=$ligne['Postnom'];
	        	$prenom1=$ligne['Prenom'];
	        	$sexe1=$ligne['Sexe'];
	        	$idchamb=$ligne['Id_chambre'];
	        	$prixx=$ligne['Prix'];
	        	$sejourtot=$ligne['Sejour'];
	        	$sejoureff=$ligne['sej'];
	        	$ptts=$ligne['pt'];
	        	$decison=$ligne['Decision'];
	        	$datea=$ligne['datefin']; 
	       
	   	?>

	   	 	 <tr>
	        	<td style="font-size: 20px;border:solid 1px blue;text-shadow: 1px 1px gray"> <?php echo $id1;?></td>
	        	<td style="font-size: 20px"> <i><?php echo $nom1;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i> <?php echo $postnom1;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $prenom1;?></i></td>
	        	<td style="font-size: 20px"> <?php echo $sexe1;?></td>
	        	<td style="font-size: 20px;border:solid 1px blue; text-shadow: 1px 1px gray"> <?php echo $idchamb;?></td>
	        	<td style="font-size: 20px"><i> <?php echo $prixx;?></i></td>
	        	<td style="font-size: 20px; background-color: black; color:white"> <i><?php echo $sejourtot;?></i></td>
	        	<td style="font-size: 20px"> <i> <?php echo $sejoureff;?></i></td>
	        	<td style="font-size: 20px"> <i><?php echo $ptts;?></i></td>
	        	<td style="font-size: 20px;text-shadow: 1px 1px 1px black; background-color: blue; color:white"> <?php echo $decison;?></td>
	        	<td style="font-size: 20px"> <?php echo $datea;?></td>

	        </tr>
	   	
	    <?php 
	   
			}
			$sqll1=mysql_query("select sum(Prix* (unitule.dat-client.Datte)) as somm from client,chambre,unitule,reglement where client.Id=reglement.IId and Decision='ok' and client.Id=chambre.Id_client and reglement.Datte='".$idmois."'");

	     	while ($ligne=mysql_fetch_array($sqll1)) {
	        	$tot1=$ligne['somm'];
	        }
		?>
			<tr>
		    	<td style="height: 40px"></td>
		    	
		    </tr>
		    <tr>
		    	<td colspan="9"> <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: seagreen">TOTAL</b></td>
		    	
		    	<td > <b style="font-size: 30px ; text-shadow: 1px 2px 1px gray;color:white;background-color: seagreen"> <?php echo $tot1; ?></b></td>
		    	<td ></td>
		    	<td ></td>
		    </tr>



		<?php
			}
		?>
	</table>

		 
</form>


	</center>
</div>

</body>
</html>