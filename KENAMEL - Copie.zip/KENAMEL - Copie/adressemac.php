<?php
$adresseIP = $_SERVER['REMOTE_ADDR'];
echo "L'adresse IP de l'utilisateur est : " . $adresseIP;
?>