<?php 
include("conn.php");

if(isset($_POST['stat2'])){
	header('location:statistique2.php');	
} 
if(isset($_POST['stat1'])){
	header('location:statistique1.php');	
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<div style="width: 99%; height: auto;background-color: aliceblue">
	<div style="width: 100%; height:78%; background-color: black;">
					<?php
					include("tete.php");
					 ?>
	</div>

	<form action="" method="POST">
				<div style="width: 100%; height: 21%; background-color: tomato;">
					<img src="bedroom_icon-icons.com_63554.png" style="width:30px; height: 27px;margin-left: 40%; border-radius: 30%">
					<input type="submit" name="stat1" value="Statistique Chambre" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black;">

					<img src="plats.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="stat2" value="Statistique Restauration" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="statt.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="Stat3" value="Statistique Pub's" style="font-size: 22px; border-top: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">				

				</div>

	</form>
	<center>
		<div style="width: 20%; height: 300px; background-image: url(welcome_people_icon_176891-1.png);background-size: 90%; background-repeat: no-repeat; display: inline-block;">
			
		</div>
		<div style="width: 40%; height: 300px;display: inline-block;text-align: justify;">
			<i style="font-size: 40px; text-shadow: 1px 2px 1px gray;">Bienvenu dans l'éditeur de Performance, ce dernier vous permet voir quel projet sera rentable de lancer en fonction de vos <span style="color:blue">Clients actifs</span> </i>
			<br><br>
		</div>


		<h2 style="background-color: tomato; color:white; text-shadow: 1px 2px 1px black; font-size: 35px">Analyseur</h2>

	
	<?php 
	$id_mess="";
	$dets="";
	$jaim=0;
	$dats="";
	$heurr="00:00:00";
	$heurnow=date('H:i:s');
	$datnoww=date('Y-m-d');
	$compheur="00:00:00";
	$det="";
	$etatst="";
	
	$sqlis=mysql_query("select id,detail,dates,heures,jaime,detester from pub,likes where likes.id_pub=pub.id order by dates ASC");

     while ($ligne=mysql_fetch_array($sqlis)) {
        $id_mess=$ligne['id'];
        $dets=$ligne['detail'];
        $dats=$ligne['dates'];
        $heurr=$ligne['heures'];
        $nbrjaim=$ligne['jaime'];
        $detest=$ligne['detester'];
        //$etatst=$ligne['ets'];

        $compheur= ($heurnow+1)-$heurr;

        if($compheur<=0 && $datnoww==$dats){
        	$det="Il y'a quelques min";
        }
        else if($compheur<=23 && $datnoww==$dats){
        	$det="Il y'a ".$compheur." h";

        }else{
        	$det="Depuis ".$dats;

        }

        	$phtaim="jaime.jpg";
        	$phtnoaim="7ceffba2b05699e30b9bb45b0bc18767.jpg";

        $photpub="\hotimG\Pubimg\\".$id_mess.".JPEG";
        
        ?>

<form action="" method="POST">
        <table>
        	<tr>
        		<td style="width: 75%">
        			
        		</td>
        		<td style="width: 15%; background-color: blue; color:white; text-shadow: 2px 2px 2px gray; border-radius: 40%; box-shadow: 2px 2px 2px gray">
        			<?php echo $det; ?>	
        		</td>
      
        	</tr>

        	<tr>
        		<td colspan="2" style="text-shadow: 1px 1px 1px gray; font-size: 30px; "> 
        			<i><?php echo $dets; ?></i>
        			
        		</td>
        	</tr>
        	
        	<tr>
        		<td colspan="2" style="width:100px; height: 300px; text-align: center">
        			<img style="width: 60%; height: 100%;" src=<?php echo $photpub;?>>
        			
        		</td>
        		
        	</tr>
        	<tr>
        		<td colspan="2" style="box-shadow: 1px 1px 1px gray">      				
        			
        		</td>
        		
        	</tr>
        	<tr style="box-shadow: 2px 2px 1px gray">
        		<td>
        			<center>
        				
        				<div type="submit" name="btndetester" value="" style="background-image: url(<?php echo $phtnoaim; ?>);width: 90px; height: 90px; background-size: 90%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;background-color: aliceblue"></div>

        				 <i style="font-size:45px; "> <?php echo $detest; ?></i>
        			</center>
        			
        		</td>

        		<td>
        			<div type="submit" name="btnjaime" value="" style="background-image: url(<?php echo $phtaim; ?>);width: 80px; height: 70px; background-size: 100%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;">
        			</div>

        				<i style="font-size:45px; "> <?php echo $nbrjaim; ?></i>
 
        			
        		</td>
        	</tr>
        	
        </table>
        <input type="text" style="width: 0px;height: 0px; background-color: aliceblue;border-top: none; border-bottom: none; border-right: none; border-left: none" name="idpub"  value="<?php echo $id_mess; ?>"> 
 </form>
 <hr style="box-shadow: 3px 3px 3px gray">

     <?php 
	}
	?>
	<h2 style="background-color: tomato; color:white; text-shadow: 1px 2px 1px black; font-size: 35px">Sans Reaction</h2>

	<?php 

	$id_mess="";
	$dets="";
	$jaim=0;
	$dats="";
	$heurr="00:00:00";
	$heurnow=date('H:i:s');
	$datnoww=date('Y-m-d');
	$compheur="00:00:00";
	$det="";
	$etatst="";
	
	$sqlis=mysql_query("select id,detail,dates,heures,jaime,detester from pub where id NOT IN (select id_pub from likes order by dates DESC)");

     while ($ligne=mysql_fetch_array($sqlis)) {
        $id_mess=$ligne['id'];
        $dets=$ligne['detail'];
        $dats=$ligne['dates'];
        $heurr=$ligne['heures'];
        $nbrjaim=$ligne['jaime'];
        $detest=$ligne['detester'];
        //$etatst=$ligne['ets'];

        $compheur= ($heurnow+1)-$heurr;

        if($compheur<=0 && $datnoww==$dats){
        	$det="Il y'a quelques min";
        }
        else if($compheur<=23 && $datnoww==$dats){
        	$det="Il y'a ".$compheur." h";

        }else{
        	$det="Depuis ".$dats;

        }

        	$phtaim="jaime.jpg";
        	$phtnoaim="7ceffba2b05699e30b9bb45b0bc18767.jpg";

        $photpub="\hotimG\Pubimg\\".$id_mess.".JPEG";
        
        ?>

<form action="" method="POST">
        <table>
        	<tr>
        		<td style="width: 75%">
        			
        		</td>
        		<td style="width: 15%; background-color: blue; color:white; text-shadow: 2px 2px 2px gray; border-radius: 40%; box-shadow: 2px 2px 2px gray">
        			<?php echo $det; ?>	
        		</td>
      
        	</tr>

        	<tr>
        		<td colspan="2" style="text-shadow: 1px 1px 1px gray; font-size: 30px; "> 
        			<i><?php echo $dets; ?></i>
        			
        		</td>
        	</tr>
        	
        	<tr>
        		<td colspan="2" style="width:100px; height: 300px; text-align: center">
        			<img style="width: 60%; height: 100%;" src=<?php echo $photpub;?>>
        			
        		</td>
        		
        	</tr>
        	<tr>
        		<td colspan="2" style="box-shadow: 1px 1px 1px gray">      				
        			
        		</td>
        		
        	</tr>
        	<tr style="box-shadow: 2px 2px 1px gray">
        		<td>
        			<center>
        				
        				<div type="submit" name="btndetester" value="" style="background-image: url(<?php echo $phtnoaim; ?>);width: 90px; height: 90px; background-size: 90%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;background-color: aliceblue"></div>

        				 <i style="font-size:45px; "> <?php echo $detest; ?></i>
        			</center>
        			
        		</td>

        		<td>
        			<div type="submit" name="btnjaime" value="" style="background-image: url(<?php echo $phtaim; ?>);width: 80px; height: 70px; background-size: 100%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;">
        			</div>

        				<i style="font-size:45px; "> <?php echo $nbrjaim; ?></i>
 
        			
        		</td>
        	</tr>
        	
        </table>
        <input type="text" style="width: 0px;height: 0px; background-color: aliceblue;border-top: none; border-bottom: none; border-right: none; border-left: none" name="idpub"  value="<?php echo $id_mess; ?>"> 
 </form>
 <hr style="box-shadow: 3px 3px 3px gray">


    <?php 
	}

	?>

	</center>
</div>

</body>
</html>