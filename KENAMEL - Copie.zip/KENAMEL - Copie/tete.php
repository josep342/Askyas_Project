<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>


		@media (min-width: 576px) {

			.t1{
				font-size: 65px;color:white ; text-shadow: 1px 1px black
			}
			.t2{
				color:red; font-size: 90px
			}

		}
		
		@media (min-width: 1200px) { 
			.t1{
				font-size: 35px;color:white ; text-shadow: 1px 1px black
			}
			.t2{
				color:red; font-size: 50px
			}

			
		}
		


	</style>
</head>
<body>

</body>
</html>


<div style="width:100%;height:100%; background-color: blue;">
	
	<center>
		<br>
		<b class="t1">
			<span class="t2">K</span>ENAMEL  <span class="t2">G</span><span style="border:1px solid red">roup<span>
		</b>	
	</center>
				
</div>