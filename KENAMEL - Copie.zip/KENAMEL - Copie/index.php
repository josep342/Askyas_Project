<?php

// la redirection

$idd="askyas2001@gmail.com";

header('location:accueil.php');



if (isset($_POST['btn1'])) {

	$idd=($_POST['identifiant']);
	$mot=($_POST['pass']);

	$motvrai="vide";
	$typee='';

		if($idd !="" && $mot !="")
		{
			
				include("conn.php");

				$sql1=mysql_query("select pwd,type from compte where id ='".$idd."'");

			        while ($ligne=mysql_fetch_array($sql1)) {
			        	$motvrai=$ligne['pwd'];
			        	$typee=$ligne['type'];

				}
				if($typee=='user')
				{

					if($mot==$motvrai)
					{
						
						$testsession='';
						$sql1=mysql_query("select identifiant from session where id ='".$idd."'");
				        while ($ligne=mysql_fetch_array($sql1)) 
				        	{
				        		$testsession=$ligne['identifiant'];
							}

						$idphonew = $_SERVER['HTTP_USER_AGENT'];
						$idphonew=substr($idphonew ,0,45);

						if($testsession=='')
						{
							$userAgent = $_SERVER['HTTP_USER_AGENT'];
							$userAgent=substr($userAgent ,0,45);
							
							try
							{
								$datee=date('Y-m-d H:m:s');

						        mysql_query("insert into session values ('$idd','$datee','$userAgent')");

								header('location:accueil.php?ident='.$idd.'');
								
							}
						    catch(Exception $e)
						    {

								echo'<script> alert("Erreur survenue , veuillez ressayer plus tard !! ")</script>';	
						    }
						        
						}
						elseif($testsession== $idphonew)
						{

							header('location:accueil.php?ident='.$idd.'');

						}
						else
						{
							$datee=date('Y-m-d');
							$idphon = $_SERVER['HTTP_USER_AGENT'];
							$idphon=substr($idphon ,0,45);
							$sep=time();
							$detail=" Un utilisateur inconnu a essayé de se connecter avec votre identifiant et sa connexion a été barrée avec succès, son réf: ".$idphon .$sep;

							mysql_query("insert into avertissement values ('$idd','$detail','1','$datee')");

							echo'<script> alert("Désolé, Cette session est déjà ouverte dans un autre appareil! \n Il semble que quelqu un est connecté avec cet identifiant et pour des raisons de sécurité, nous avons limité l accès \n\n NB: si cela n est pas le cas, vérifier si tu n as pas laissé  la session ouverte dans un autre appareil au cas contraire il faut consulter l admin ")</script>';
							
						}
					}

				else
				{
					echo'<script> alert("Mot de passe incorrect,  Essayer ultérieurement ")</script>';
				}
				
			}

			elseif($typee=='admin')
			{
				if($mot==$motvrai)
				{
					$testsession='';
					$sql1=mysql_query("select identifiant from session where id ='".$idd."'");
			        while ($ligne=mysql_fetch_array($sql1)) 
			        	{
			        		$testsession=$ligne['identifiant'];
						}

						$idphonew = $_SERVER['HTTP_USER_AGENT'];
						$idphonew=substr($idphonew ,0,45);

					if($testsession=='')
					{
						$userAgent = $_SERVER['HTTP_USER_AGENT'];
						$userAgent=substr($userAgent ,0,45);
						
						try{
							$datee=date('Y-m-d H:m:s');

					        mysql_query("insert into session values ('$idd','$datee','$userAgent')");

							header('location:accueiladmin.php?ident='.$idd.'');
							
							}
					    catch(Exception $e){

							echo'<script> alert("Erreur survenue , veuillez ressayer plus tard !! ")</script>';
					    	
					    	}
					}
					elseif($testsession== $idphonew)
					{

						header('location:accueiladmin.php?ident='.$idd.'');

					}
					else
					{
						$datee=date('Y-m-d');
						$idphon = $_SERVER['HTTP_USER_AGENT'];
						$idphon=substr($idphon ,0,45);
						$sep=time();
						$detail=" Un utilisateur inconnu a essayé de se connecter avec votre identifiant et sa connexion a été barrée avec succès, son réf: ".$idphon .$sep;

						mysql_query("insert into avertissement values ('$idd','$detail','1','$datee')");

						echo'<script> alert("Désolé, Cette session est déjà ouverte dans un autre appareil! \n Il semble que quelqu un est connecté avec cet identifiant et pour des raisons de sécurité, nous avons limité l accès \n\n NB: si cela n est pas le cas, vérifier si tu n as pas laissé  la session ouverte dans un autre appareil au cas contraire il faut consulter l admin ")</script>';
						
					}
				}

				else
				{
					echo'<script> alert("Mot de passe incorrect,  Essayer ultérieurement ")</script>';
				}

			}

			
		}
	
		else{
				echo'<script> alert(" Tous les champs doivent etre remplis")</script>';

			}
	}

	?>

<!DOCTYPE html>
<html>
<head >
	<meta charset="UTF-8">
	<title></title>

	<style>
		
		input[type="search"]{
			display:none;
		}
	</style>
</head>

<body style="background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))" onload="">
	
<form action="" method="POST">
		<center>
			<br><br>
			<div style="width: 95%; height: 1700px; background-color:aliceblue;">
				<br><br><br><br><br>
				<h1 style="background-color: tomato;  color:white;font-size: 100px">Connectez-vous</h1>
				<br><br><br><br><br><br><br><br><br>

			<input type="text" name="identifiant" style="font-size: 30px; border-right: none; border-top: none; border-left: none; background-color: aliceblue;border-color: tomato; font-size: 60px" placeholder=" Saisissez votre Identifiant">
				<br><br><br><br><br><br><br><br><br><br><br><br>
			<input id="passs" type="Password" name="pass" style="font-size: 30px ; border-right: none; border-top: none; border-left: none;background-color: aliceblue; border-color: tomato;font-size: 60px" placeholder="Saisissez votre Password"><br>

			<input id="btnvue" type="button" name="" style="width: 50px; height: 50px;background-image: url(oeil.png); background-size: 100%; border-bottom: none; border-top: none; border-left: none; border-right: none;margin-left: 55%" onclick="voir()">

			<input id="btscache" type="button" name="" style="width: 0px; height: 0px;background-image: url(cacheoeil.jpg); background-size: 100%; border-bottom: none; border-top: none; border-left: none; border-right: none;margin-left: 55%" onclick="coder()">



			<br><br><br><br><br><br><br><br><br><br><br><br>
			<input type="submit" name="btn1" value="   Connection   " style="font-size: 70px; margin-left: 40%; color:tomato; border-color: tomato; font-weight: bold" >

			<br><br><br><br><br><br><br><br><br>

				<center>
					<input type="button" onclick="oublier()" name="" value="Mot de pass oublie ?" style=" font-size: 60px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue"><br><br><br>
					<input type="button" name="" value="Aides ?" onclick="aidess()" style=" font-size: 60px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue"><br><br><br>
					<input type="button" name="" value="Sign Up?" style="font-size: 60px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue;color:aliceblue"> <input type="button" name="" value="Sign Up?" style=" font-size: 60px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue;color:aliceblue"><input type="button" name="" value="Sign Up?" onclick="creationcompte()" style=" font-size: 40px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue;text-shadow: black 1px 2px 1px; font-weight: bold">
				</center>
				
			</div>

		</center>
</form>
<script>
	var tirerr=document.getElementById('passs');
	var btnvuee=document.getElementById('btnvue');
	var btncachee=document.getElementById('btscache'); 
	var essaie=document.getElementById('ess');

function voir(){
	tirerr.type="text";
	btncachee.style.width=50+"px";
	btncachee.style.height=50+"px";

	btnvuee.style.width=0+"px";
	btnvuee.style.height=0+"px";

}
function coder(){
	tirerr.type="Password";

	btncachee.style.width=0+"px";
	btncachee.style.height=0+"px";

	btnvuee.style.width=50+"px";
	btnvuee.style.height=50+"px";
}
function aidess(){
	alert("1. Veuillez inserer votre identifiant dans la première cellule\n 2. En suite le mot de pass dans le deuxieme enfin valider sur la connexion\n\n NB: Ces informations vous ont ete fournies lors de ton enregistrement");
}
function creationcompte(){
	window.location.href = 'creationcompte.php';
}
function oublier(){
	 window.location.href = 'recuperation.php';   
}
function popup(){
	window.open('index.php','nul','width=800, height=800,toolbar=no,scrollbars=no,location=no,resizable=no');
}
function verf(){
	var prod="maisss";
	var qqt="50";
	prompt("voulez-vous vraiment confirmer la commande de "+prod+ "  pour une quantité de "+qqt );
}

</script>

</body>
</html>