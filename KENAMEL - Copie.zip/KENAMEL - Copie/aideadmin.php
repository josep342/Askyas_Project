<?php 

$iddd=($_GET['ident']);

$iddd=explode(',', $iddd);

$idd=$iddd[0];

$idclient=$iddd[1];

include("conn.php");
$etat="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$eta="";
$sql1=mysql_query("select Nom,Prenom from client where id_client ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql1)) {
        $nom=$ligne['Nom'];
        $prenom=$ligne['Prenom'];
	}

		$sejprev=$ligne['Sejour'];
        $sejeff=$ligne['sejefff'];    
	 	$sejreste= $sejprev-$sejeff;
		$ff="";
		$dats="";
	 	$dats="";
		$ff="";
	 	$dats="";

$sql2=mysql_query("select detail,etat,dat from avertissement where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql2)) {
        $message=$ligne['detail'];
        $etat=$ligne['etat'];
        $datt=$ligne['dat'];
	}
	if($etat=="1"){
		$etat=" +1";
		$ff="2326147.png";
	}
	else{
		$etat="";
	}

	$sqls2=mysql_query("select Etatt from notification where id ='".$idd."'");

     while ($ligne=mysql_fetch_array($sqls2)) {
        $ettats=$ligne['Etatt'];
	}
	if($ettats=="1"){
		$etatt=" +1";
		$ff="2326147.png";
	}
	else{
		
		$etatt="";
	}

	if (isset($_POST['commande'])) {
		header('location:commandeadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['tableau'])) {
		header('location:tableauadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['notification'])) {
		header('location:notificationadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['acceuil'])) {
		header('location:accueiladmin.php?ident='.$idd.'');
	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notificationadmin.php?ident='.$idd.'');
	} 
	if (isset($_POST['envoiis'])) 
	{
		$messs=($_POST['mess']);
		$datss=date('Y-m-d H:i:s');

		if($messs=="")
		{
			echo '<script> alert("Impossible d envoyer le message vide ")</script>';
		}
		else
		{
			$tail=strlen($messs);
			if($tail<100){
				$sql2=mysql_query("insert into messagess values('$idd','$messs','','0','$datss','0')");
			if($sql2){
				echo '<script> alert("Message envoye avec succes")</script>';

			}
			else{
				echo '<script> alert("Erreur inattendue, veuillez ressayer plus tard")</script>';
			}

			}
			else{
				echo '<script> alert("Erreur, le message doit contenir les caracteres  inferieur à 100")</script>';
			}
	
		}
	
	} 

if (isset($_POST['ouvrirtchaitte'])) 
{
	$dconcerne=$_POST['idcll'];

	$sqlmod=mysql_query("update messagess set etat='1' where id_mes='".$dconcerne."'");

	if($sqlmod)
	{
		$idd=$idd.",".$dconcerne;

		header('location:tchatadmin.php?ident='.$idd.'');

	}
	else
	{
		echo '<script>alert("ERROR !!")</script>';

	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion E-commerce</title>
		<link rel="stylesheet" type="text/css" href="beaute.css">
</head>
<body onload="ouverture()" style="background-color: aliceblue">
<div style="width:100%; height:100% background-color:aliceblue; border-radius:1%; "> 
	<div style=" width: 100%;height:300px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">

	    <form method="POST" action="">	
			
			<div style="width: 78%; height: 300px; display: inline-block;">
				<?php

					include("tete.php");
					$phot="adminn.png"
					//"hotimG\PhoClient\\".$idd.".JPEG";

			    ?>

			
			</div>
				<div style="width: 20%; height: 300px; display: inline-block;">
						
						 <div style="width: 100%; height: 250px">
						 	 <img src="<?php echo $phot ?>" style="width: 100%; height: 80%; border-radius:60%"> <br>
						 	 <center>
						 	 	<input type="submit" name="notificationhaute" style="width: 50px;height: 50px;background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));background-image: url(<?php echo $ff;?>);border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%;" value="">

						 	 	<b style="color: white; font-size: 35px; background-color: red; border-radius: 50%;"> <?php echo $etat.$etatt.$dats ; ?>  </b>
						 	 </center>
						 		 	
						 </div>
			
				</div>
		
		</form>
	</div>

		
	<!-- les diffent bouton de menue-->

		<div style="width:0px; height: 100%;background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))" id="tire">
			<div id="haut" style="width: 83%; height: 10%; display: inline-block;background-color: black; box-shadow: 3px 4px 2px blue; opacity: 80%"><br>
				<b id="etiquettemenu" style="margin-left: 30%; color: white; font-size: 70px">
					
				</b><br><br>
				
				
			</div>

			<div style="width: 15%; height: 10%; display: inline-block;">
				<input id="btrepl" type="button" name="" text="ici" onclick="replier()" style="width: 0px; height: 0px; background-image: url(c1.PNG); border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%">	
			</div><br><br><br>

	<form action="" method="POST">

			<img id="photacceuil" style="width:0px; height:0px;margin-left: 5%" src="images\house_115210.png">

			<input type="submit" name="acceuil" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="accueil"> 
			<br><br><br><br>

			<img id="photcommander" style="width:0px; height:0px;margin-left: 5% " src="images\platt.jpg">

			<input type="submit" name="commande" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="commande">
			<br><br><br><br>

			<img id="phottableau" style="width:0px; height:0px;margin-left: 5% " src="images\statistique.png">

			<input type="submit" name="tableau" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="tableau"> 

			<br><br><br><br>

			<img id="photnot" style="width:0px; height:0px;margin-left: 5% " src="images\1592461.png">

			<input type="submit" name="notification" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="notification">
			<br><br><br><br>

			<img id="photaide" style="width:0px; height:0px;margin-left: 5%" src="images\admin.png">

			<input type="submit" name="aide" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="aide"> 
			<br>
	</form>

			
		</div>
	<!-- fin des diffent bouton de menue-->



<form action="" method="POST">
		<div style="width: 100%; height: 20%; background-color: rgba(0,0,0,0)">
			<div style="width:15%; height: 100%; display: inline-block; ">
				<input id="btntirer" type="button" name="" text="ici" onclick="tire()" style="width: 100px; height: 100px; background-image: url(c1.PNG); background-repeat: no-repeat;background-size: 100%; border-top: none;border-right: none; border-left: none; border-bottom: none;">

			</div>
			<div style="width: 80%; height: 100% ;display: inline-block;">
				<b id="welcom" style="text-align: center; text-shadow: 1px 2px 1px rgba(120,120,150,100);font-size:30px; margin-left: 5%" > <?php echo   $prenom ?>  , Veuillez accompagner nos clients   </b> <br><br>
				
			</div>
			
		</div>
		<hr style="box-shadow: 4px 2px 2px gray;">
</form>
<br><br>
<center>
	<div style="width: 800px; height: 500px; background-image:url(message.jpg); background-size: 100%;background-repeat: no-repeat;"> <br>
		<b style="font-size: 60px; text-shadow: 2px 2px 2px gray; color:black"> T<i style="color:tomato; font-size:50px">shombo</i></b><br>

		<i style="font-size: 60px; text-shadow: 2px 2px 2px gray; color:black; margin-left: 35%"> 
		na </i><br>

		<b style="font-size: 60px; text-shadow: 2px 2px 2px gray; color:black;  margin-left: 75%"> T<i style="color:tomato; font-size:50px ;">shombo</i></b>
		
	</div>
	<br><br>
	<table>
		<tr>
			<td style="width: 33%; height: 400px">
				<img src="images\adminn.png" style="width: 100%; height: 80%">
			</td>
			<td style="width: 67%; height: 300px">
				<i style="font-size: 35px; text-align: justify;">
					<span style="font-size: 60px; color:tomato; text-shadow: 3px 2px 2px gray">C</span>her(e) client(e), notre Entreprise a l'honneur de vous avoir comme client(e), sur ce, une équipe est à votre disposition afin de prendre vos <span style="border: 3px tomato solid; box-shadow: 2px 2px 2px gray; border-top: none; border-left: none; border-right: none;">besoins</span>, <span style="border: 3px tomato solid; box-shadow: 2px 2px 2px gray; border-top: none; border-left: none; border-right: none;">suggestions </span> et <span style="border: 3px tomato solid; box-shadow: 2px 2px 2px gray; border-top: none; border-left: none; border-right: none;">remarques </span> dans le but d'améliorer de temps en temps pour que nos services vous soient satisfaisant !  
				</i>
				
			</td>
		</tr>
	</table>
	<br><br>
	<h1 style="background-color: tomato; color:white; text-shadow: 2px 2px 1px gray;font-size: 55px;">Tchat Tsho na Tsho</h1>
	<br>

<?php 

$colorr="aliceblue";

$listeidclient=[""];
$phots="";
$pht2="images\adminn.png";

$sqqlsl=mysql_query("select distinct id_mes from messagess order by dats DESC");
   	while ($ligne=mysql_fetch_array($sqqlsl)) {

   		array_push($listeidclient, $ligne['id_mes']);

   	}

   	$i=0;
   	for($i=0;$i<count($listeidclient);$i++)
   	{
   		$idindex= $listeidclient[$i];

		$sqqlsl=mysql_query("select id_mes,mess,repp,etat,dats,nom,prenom from messagess,client where id_mes='".$idindex."' and id_mes=id_client and selecteur='0' order by dats DESC LIMIT 1");
		   	while ($ligne=mysql_fetch_array($sqqlsl)) {

		   		$idclient=$ligne['id_mes'];
		        $msgg=$ligne['mess'];
		        $reps=$ligne['repp']; 
		        $eeta=$ligne['etat'];
		        $dtes=$ligne['dats']; 

		        $nomcl=$ligne['nom']; 
		        $prencl=$ligne['prenom']; 

		        $phots="hotimG\PhoClient\\".$idclient.".jpeg";

		        if($eeta=='1'){
		        	$stat="Vu";
		        } 
		        else{
		        	$stat="Envoyé";
		        }

		        if($reps==""){
		        	$pht2="";
		        	$hauteur="0px";
		        	$colorr="aliceblue";
		        }
		        else{
		        	$pht2="images\adminn.png";
		        	$hauteur="auto";
		        	$colorr="gray";
		        }

?>
<table>
	<tr>
		<td colspan="2" style="font-size: 35px;text-shadow: 1px 2px 1px gray;font-weight: bold">
			<?php echo $nomcl." - ".$prencl; ?>
			
		</td>

	</tr>
	
	<tr>
		<td style="width: 20%; height:auto;">
			<img style="width: 100%; height: 80%; border-radius: 60%" src='<?php echo $phots ;?>'>
		
		</td>
		<td style="width: 60%; height: auto;background-color:blue; color: white; border-radius: 12%">
			<span style="font-size: 35px; text-shadow: 2px 1px 1px gray;  "> <?php echo $msgg; ?></span>
			
		</td>
		<td style="width: 20%"></td>

	</tr>

	<tr>
		<td style="width: auto; height:30px">
		
		</td>
		<td style="width: auto; height: 30px">
			<i style="font-size: 20px; margin-left: 50%"><?php echo $stat." ".$dtes; ?></i>
			
		</td>
		
	</tr>

</table>

<form action="" method="POST">
	

	<table>
		<tr>
			<td style="width: 20%;height: auto;"></td>

			<td style="width: 20%; height: auto">
				<img style="width: 100%; height: <?php echo $hauteur; ?>; border-radius: 60%" src="<?php echo $pht2;?>">
			
			</td>

			<td style="width: 60%; height: auto;background-color:<?php echo $colorr; ?>; color: white; border-radius: 12%">
				<span style="font-size: 35px; text-shadow: 2px 1px 1px black;margin-left:5%;"> <?php echo $reps; ?></span>
				
			</td>
			

		</tr>
		
		<tr>
			<td style="height: 25px">
		</tr>

		<tr>
				<td colspan="2">
					<input type="text" name="idcll" value="<?php echo $idclient; ?>" style="border-bottom: none; border-left: none; border-right: none;border-top: none;background-color: aliceblue;color:aliceblue;width: 0px" >

				
					<input type="submit" name="ouvrirtchaitte" value="Open Tchat" style="margin-left: 90%;font-size: 35px;color:white;background-color: tomato;text-shadow: 1px 2px 1px gray;">
				</td>
		</tr>
	</table>

</form>


<br><br>

<hr style="box-shadow: 1px 2px 1px gray">

<br><br>



<?php 

	}
}

?>

	<br><br><br>

</center>
		
	</div>

<script>
	//let temps=20;
	var tirerr=document.getElementById('tire');
	var btreplier=document.getElementById('btrepl'); 
	var bttirer=document.getElementById('btntirer'); 

	var etiquemenuu=document.getElementById('etiquettemenu'); 
	var welcom=document.getElementById('welcom'); 


	var acc=document.getElementById('accueil');
	var command=document.getElementById('commande');
	var tableau=document.getElementById('tableau');
	var notification=document.getElementById('notification');
	var aide=document.getElementById('aide'); 
	var photacceuil=document.getElementById('photacceuil'); 
	var photcomm=document.getElementById('photcommander'); 
	var phottableaub=document.getElementById('phottableau'); 
	var photnotif=document.getElementById('photnot'); 
	var photaidee=document.getElementById('photaide'); 





	function tire(){	
	tirerr.style.width=60+"%";
	tirerr.style.height=1000+"px";
	welcom.innerText="";

	btreplier.style.width=100+"px"
	btreplier.style.height=100+"px"
	bttirer.style.width=0+"px";
	bttirer.style.height=0+"px";

	photacceuil.style.height=50+"px";
	photacceuil.style.width=60+"px";

	photcomm.style.height=50+"px";
	photcomm.style.width=60+"px";

	phottableaub.style.height=50+"px";
	phottableaub.style.width=60+"px";

	photnotif.style.height=60+"px";
	photnotif.style.width=60+"px";

	photaidee.style.height=60+"px";
	photaidee.style.width=70+"px";



	acc.value="Acceuil"
	command.value="Commande ";
	tableau.value="Tableau de Bord";
	notification.value="Notification";
	aide.value="Aide ?";
	etiquemenuu.innerText="MENU";
	}
	function replier(){	
		//style="width: 70px; height: 55px; 
	btreplier.style.width=0+"%"
	btreplier.style.height=0+"%"

	bttirer.style.width=100+"px";
	bttirer.style.height=100+"px";
	var nom='<?php echo $prenom ?>';

	welcom.innerText=nom +",  Nous t'accompagnons " ;
	acc.value="";
	command.value="";
	tableau.value="";
	notification.value="";
	aide.value="";
	etiquemenuu.innerText="";



	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";

	photacceuil.style.height=0+"px";
	photacceuil.style.width=0+"px";

	photcomm.style.height=0+"px";
	photcomm.style.width=0+"px";

	phottableaub.style.height=0+"px";
	phottableaub.style.width=0+"px";

	photnotif.style.height=0+"px";
	photnotif.style.width=0+"px";

	photaidee.style.height=0+"px";
	photaidee.style.width=0+"px";
	
	}
	function ouverture(){
	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";
	}

	
</script>

<?php 
include("footeur.php");
?>

</body>
</html>