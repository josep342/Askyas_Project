
<?php
$type="";

include("conn.php");

if (isset($_POST['envoyer'])){

	$mail=$_POST['gmail'];
	$msg=$_POST['message'];

	$dat=date('Y-m-d');

	$datheure=date('Y-m-d H:m:s');

	if(strlen($mail)>=10){

		$gmailcorre=substr($mail, strlen($mail)-10,10);

		if($gmailcorre=="@gmail.com"){

			if($msg==""){

				echo'<script> alert("Error Message Vide !!");</script>';

			}
			else{

				$sqlinserlike=mysql_query("insert into commentaires values('$datheure','$mail','$msg','$dat')");

				if($sqlinserlike){

					echo'<script> alert("Succeful!!");</script>';

				}
				else{
					echo'<script> alert("Error!!");</script>';
				}

			}

		}
		else{
				echo'<script> alert("Error!! Uniquement les adresse Gmail sont autorisés");</script>';
			}

	}
}


if (isset($_POST['activitepc'])){
	//header('location=activite.php');
	header('location:activite.php');
}

function isMobileDevice() 
{
    // Récupérer le User-Agent de la requête HTTP
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
   
    // Liste des mots-clés pour identifier les appareils mobiles
    $mobileKeywords = array(
        'Mobile', 'Android', 'Silk/', 'Kindle', 'BlackBerry', 'Opera Mini', 'IEMobile', 'Windows Phone'
    );
   
    // Vérifier si le User-Agent contient l'un des mots-clés
    foreach ($mobileKeywords as $keyword) {
        if (stripos($userAgent, $keyword) !== false) {
            return true; // C'est un appareil mobile
        }
    }
   
    return false; // C'est probablement une machine
}

// Exemple d'utilisation
if (isMobileDevice()) {
	$type="phone";
    //echo "Vous utilisez un appareil mobile.";
} else {
	$type="machine";
    //echo "Vous utilisez un ordinateur.";
}
?>

<?php 
$idd="";

$etat="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$notif="";
$testlike="";
$nbrjaim=0;
$detest=0;


    $nom="";
    $prenom="";


	$sejreste= "";
	 
	
 	$dats="+1";
	$ff="calendar.png";
	 
	$dats="";

	if (isset($_POST['commande'])) {
		//header('location:commande.php?ident='.$idd.'');
		echo'<script> alert("Promotion  ou marché assisté cad dans le cas où un commissionnaire a apporté un marché dans l entreprise, dans ce cas on travaille comme passerelle d affaire ");</script>';

	}

	if (isset($_POST['tableau'])) {
		
		echo'<script> alert(" Tableau de produit en venté avec tout détail cad qualité, dimension, taille, et localisation ......ici j vais inserer la localisation GPS si nessaire ");</script>';

	}

	if (isset($_POST['notification'])) {

		echo'<script> alert("Statistique ou historique d affaire d un commissionaire  avec détail possible ");</script>';

		//header('location:notification.php?ident='.$idd.'');
	}

	if (isset($_POST['aide'])) {
		//header('location:aide.php?ident='.$idd.'');
		echo'<script> alert("Service client.... on va programmer un nombre de BOT pour servir aux questions de cliens en attendant.... ");</script>';


	} 
	if (isset($_POST['power'])) {
		//header('location:aide.php?ident='.$idd.'');
		echo'<script> alert("Fermeture de la session");</script>';

	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notification.php?ident='.$idd.'');
	}   
	if (isset($_POST['btnjaime'])) {
		$pubid=($_POST['idpub']);

		
		$sqlrechlike=mysql_query("select etat from likes where id_pub='".$pubid."' and id_client='".$idd."'");

	     while ($ligne=mysql_fetch_array($sqlrechlike)) {
	        $testlike=$ligne['etat'];
		}
		if($testlike=="1"){
		echo'<script> alert("Le Gestionnaire systeme remarque que tu as une fois deja liker cette pub, \n NB: Chaque personne ne peut liker qu une seule fois ");</script>';

		}
		else if($testlike=="0"){

		$sqlpubrech1=mysql_query("select jaime,detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech1)) {
	        $nbrjaim=$ligne['jaime'];
	        $detest=$ligne['detester'];
		}
		$nbrjaim=$nbrjaim+1;
		$detest= $detest-1;

		$sqlpubmod1=mysql_query("update pub set jaime='$nbrjaim',detester='$detest' where id='".$pubid."'");

		$sqlmodlike1=mysql_query("update likes set etat='1' where id_pub='".$pubid."' and id_client='".$idd."'");

		if($sqlpubmod1 && $sqlmodlike1){

			echo'<script> alert("Le like a ete signalee à la pub avec succes");</script>';

		}
		else{

			echo'<script> alert("Erreur inattendue");</script>';

		}

		}
		else{

		$sqlinserlike=mysql_query("insert into likes values('$idd','$pubid','1')");

		$sqlpubrech=mysql_query("select jaime from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech)) {
	        $nbrjaim=$ligne['jaime'];
		}
		$nbrjaim=$nbrjaim+1;

		$sqlpubmod=mysql_query("update pub set jaime='$nbrjaim' where id='".$pubid."'");
		
		
		

		}

	} 

	if (isset($_POST['btndetester'])) {

		$pubid=($_POST['idpub']);

		$sqlrechlike=mysql_query("select etat from likes where id_pub='".$pubid."' and id_client='".$idd."'");

	     while ($ligne=mysql_fetch_array($sqlrechlike)) {
	        $testlike=$ligne['etat'];
		}
		if($testlike=="0"){
			echo'<script> alert("Le Gestionnaire systeme remarque que tu as une fois deja Detester cette pub, \n NB: Chaque personne ne peut Detester qu une seule fois ");</script>';

		}
		else if($testlike=="1"){

		$sqlpubrech1=mysql_query("select jaime,detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech1)) {
	        $nbrjaim=$ligne['jaime'];
	        $detest=$ligne['detester'];
		}
		$nbrjaim=$nbrjaim-1;
		$detest= $detest+1;

		$sqlpubmod1=mysql_query("update pub set jaime='$nbrjaim',detester='$detest' where id='".$pubid."'");

		$sqlmodlike1=mysql_query("update likes set etat='0' where id_pub='".$pubid."' and id_client='".$idd."'");

		if($sqlpubmod1 && $sqlmodlike1){

			echo'<script> alert("La detestation a ete signalee à la pub correctement");</script>';

		}
		else{

			echo'<script> alert("Erreur inattendue");</script>';

		}

		}
		else{

		$sqlinserlike=mysql_query("insert into likes values('$idd','$pubid','0')");

		$sqlpubrech=mysql_query("select detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech)) {
	        $detest=$ligne['detester'];
		}
		$detest=$detest+1;

		$sqlpubmod=mysql_query("update pub set detester='$detest' where id='".$pubid."'");
		
		if($sqlpubmod){

			$notif="Detester par vous et autres  personnes";
			echo'<script> alert("La detestation a ete signalee à la pub avec correctement");</script>';
		}
		else{
			echo'<script> alert("Erreur inattendue");</script>';
		}
		

		}
		


	} 

	

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>KENAMEL BUSINESS</title>
		
		<!--<link rel="stylesheet" href="styl.css">
		<link rel="stylesheet" href="animation1.css">--!-->

		<link rel="icon" href="logg.ico" type="image/x-icon">

		<style>


		.accueilpc:hover{
		        background-color: red;
		        padding-right: 60px;
		        padding-left:60px;
		        transition: 0.8s all;

		}
		.activitepc:hover{
		        background-color: red;
		        padding-right: 60px;
		        padding-left:60px;
		        transition: 0.8s all;

		}
		.annoncepc:hover{
		        background-color: red;
		        padding-right: 60px;
		        padding-left:60px;
		        transition: 0.8s all;

		}
		.aidepc:hover{
		        background-color: red;
		        padding-right: 60px;
		        padding-left:60px;
		        transition: 0.8s all;

		}
		.contactpc:hover{
		        background-color: red;
		        padding-right: 60px;
		        padding-left:60px;
		        transition: 0.8s all;

		}

		
		p{
			font-size: 20px;
		}
		

		
			
		@media (min-width: 576px) {

			.btpluswelcom1
			{
			    display: inline-block;
			    width: 20%;
			    height: 50px;
			    border-radius: 7%;
			    background-color: red;
			    
			    box-shadow: 5px 0px 4px 10px rgba(219, 215, 215, 0.829);
				cursor: pointer;
				font-family: Century Gothic;   
				color: white;
				font-weight: bold;
				font-size:40px;

			}

			.cad0{
				width: 99%; height: auto;margin-left: 0.5%;background-image: url(body-bg.gif);
			}

			.cad0tete{
				width: 97%;height:100px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));position: fixed;

			}
			.cad0menu{
				background-color: black;display: none
			}
			.cad0menuandroid{

				width: 100%; height: 0px; background-color: white;display: none;

			}
			.sepa{
				width: 100%; height: 5px; background-color: black;
			}
			.btmenuandroid{
				background-image: url(rech.jpg);background-size: cover;height: 60px; width: 60px;border-top:none; border-left:none; border-right:none;border-bottom: none;display: black;
			}
			.imgacceuil{
				width: 0px;height: 0px;margin-top: 5%;margin-left: 10%;visibility: hidden;

			}
			.imgactivite{
				width: 0px;height: 0px;margin-top: 5%;margin-left: 10%;

			}

			.imgannonce{
				width: 0px;height: 0px;margin-top: 5%;margin-left: 10%;

			}

			.imgaide{
				width: 0px;height: 0px;margin-top: 5%;margin-left: 10%;

			}

			.imgcontact{
				width: 0px;height: 0px;margin-top: 5%;margin-left: 10%;

			}


			.accueil{
				background-color:white;font-size: 20px;font-weight: bold;border-top:none;border-bottom: none;border-left: none;border-right: none; margin-top: 5%;margin-left: 3%;
				
			}
			.activite{
				background-color:gray;font-size: 20px;font-weight: bold;border-top:none;border-bottom: none;border-left: none;border-right: none; margin-top: 5%;margin-left: 3%;
			}
			.annonce{
				background-color:gray;font-size: 20px;font-weight: bold;border-top:none;border-bottom: none;border-left: none;border-right: none; margin-top: 5%;margin-left: 3%;
			}
			.aide{
				background-color:gray;font-size: 20px;font-weight: bold;border-top:none;border-bottom: none;border-left: none;border-right: none; margin-top: 5%;margin-left: 3%;
			}
			.contact{
				background-color:gray;font-size: 20px;font-weight: bold;border-top:none;border-bottom: none;border-left: none;border-right: none; margin-top: 5%;margin-left: 3%;
			}
			.detail{
				font-size: 40px
			}

			.cad01{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 98%;
				height: 550px;
				
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 10%;
				border-radius: 5%; 
				font-size: 35px
			}
			.cad02{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 98%;
				height: 550px;
				
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%;
				font-size: 35px 
			}

			.cad03{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 98%;
				height: 550px;
				
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%; 
				font-size: 35px
			}
			.cad04{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 98%;
				height: 550px;
				
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%; 
				font-size: 35px
			}

			.cadtete{
				width: 100%; height: 120px;background-color: red
			}

			.titrecommentaire{
				margin-top: 3%;
				font-size: 40px;
			}

			.divcommentaire{
				width: 90%;height:350px;margin-left: 5%;background-color: white;box-shadow: 5px 15px 15px gray;border-radius: 1%

			}

			.messagcommentaire{
				font-size: 40px;
			}

			.titrcomm{
				margin-left: 5%;
				font-size: 30px
			}
			.tgmail{
				width: 70%;height: 50px;border-color: black;border-radius: 2%;margin-left: 4%;font-size: 35px;font-weight: bold;box-shadow: 2px 10px 15px black
			}
			.tmessage{
				box-shadow: 2px 10px 15px black;width: 92%;height: 200px;border-color: black;margin-top: 2%;margin-left: 4%;font-size: 25px
			}

			.btnenvoyer{
				color:white;background-color: red;font-weight: bold;font-size: 35px;margin-left: 82%;border-radius: 2%; margin-top: 1%; box-shadow: 2px 10px 15px gray
			}
			.datecom{
				margin-left:70%;color:gray;font-size: 30px
			}
		}

		/* */
		
		@media (min-width: 1200px) {

			.datecom{
				margin-left:65%;color:gray;
				font-size: 20px;
			}

			.btnenvoyer{
				color:white;background-color: red;font-weight: bold;font-size: 20px;margin-left: 82%;border-radius: 2%; margin-top: 1%; box-shadow: 2px 10px 15px gray
			}

			.tmessage{
				box-shadow: 2px 10px 15px black;width: 92%;height: 140px;border-color: black;margin-top: 2%;margin-left: 4%;font-size: 25px
			} 

			.tgmail{
				width: 40%;height: 40px;border-color: black;border-radius: 2%;margin-left: 4%;font-size: 15px;font-weight: bold;box-shadow: 2px 10px 15px black
			}

			.titrcomm{
				margin-left: 5%;
				font-size: 25px
			}

			.messagcommentaire{
				font-size: 23px;
			}

			.titrecommentaire{
				margin-top: 2%;

				font-size: 30px;
			}

			.cadtete{
				width: 100%; height: 70px;
			}

			.btpluswelcom1
			{
			    display: inline-block;
			    width: 20%;
			    height: 30px;
			    border-radius: 7%;
			    background-color: red;
			    
			    box-shadow: 5px 0px 4px 10px rgba(219, 215, 215, 0.829);
				cursor: pointer;
				font-family: Century Gothic;   
				color: white;
				font-weight: bold;

				font-size:20px;

			}

			.newletter{

				width: 100%; height: 300px;border-radius:2%;background-image: url(body-bg.gif);


			}
			.let1{
				width: 46%; height: 100%;display: inline-block;background-color: white;box-shadow: 2px 10px 15px gray;border-radius: 2%;margin-left: 53%

			}
			.let2{
				width: 46%; height: 100%;margin-left: 2%;display:none;background-color: white;box-shadow: 2px 10px 15px gray;border-radius: 2%;

			}

			.cad0{
				width: 96%; height: auto;margin-left: 2%;background-image: url(body-bg.gif);
			}
			.cad0tete{
				width: 95%;height:100px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));

			}
			.sepa{
				width: 100%; height: 5px; background-color: black;

			}

			.btmenuandroid{
				background-image: url(rech.jpg);background-size: cover;display: none;border-top:none; border-left:none; border-right:none;border-bottom: none
			}
			.cad0menu{
				width: 100%; height: 40px; background-color: black;display: block
			}



			.accueilpc{
				background-color: black;font-size: 25px; color: white;margin-left:50%;width: 150px;border-radius: 5%;

			}
			.activitepc{  

				background-color: black;font-size: 25px;  color: white;margin-left:2%;width: 150px;border-radius: 5%;

			}
			.annoncepc{
				background-color: black;font-size: 25px;  color: white;margin-left:2%;width: 150px;border-radius: 5%;

			}
			.aidepc{
				background-color: black;font-size: 25px;  color: white;margin-left:2%;width: 170px;border-radius: 5%;

			}
			.contactpc{
				background-color: black;font-size: 25px;  color: white;margin-left:2%;width: 150px;border-radius: 5%;

			}
			.divcommentaire{
				width: 50%;height:200px;margin-left: 25%;background-color: white;box-shadow: 5px 15px 15px gray;border-radius: 1%

			}

			.detail{
				font-size: 20px
			}

			.cad01{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 48%;
				height: 230px;
				display: inline-block;
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%; 
				font-size: 20px
			}
			.cad02{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 48%;
				height: 230px;
				display: inline-block;
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%; 
				font-size: 20px
			}

			.cad03{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 48%;
				height: 230px;
				display: inline-block;
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%;
				font-size: 20px 
			}
			.cad04{
				box-shadow: 10px 0px 15px rgb(61, 60, 60) 2px; 
				width: 48%;
				height: 230px;
				display: inline-block;
				background-image: url(box-1-bg.gif);
				text-align: center;
				margin-right: 5px;
				margin-left: 1%;
				margin-top: 5%;
				border-radius: 5%; 
				font-size: 20px
			}

			


		 }

		</style>
		
</head>
<body  style="background-color: white" onload="//ouverturepage()">
	<div class="cad0">

		<div class="cad0tete");">

	    <form method="POST" action="">	
			
			<div class="cadtete">
				<?php

					include("tete.php");
					$phot="hotimG\PhoClient\\".$idd.".JPEG";

			    ?>

			
			</div>
		</form>
			<div class="sepa">
				
			</div>

			<form method="POST">

				<div class='cad0menu'> 

					<input type="submit" value="Accueil" name="accueilpc" id="accueilpc" class="accueilpc">

					<input type="submit" value="Activités" name="activitepc" id="activitepc" class="activitepc">
					
					<input type="submit" value="Annonces" name="annoncepc" id="annoncepc" class="annoncepc">
					
					<input type="submit" value="contacts" name="contactpc" id="contactpc" class="contactpc">


					
				</div>
			</form>	

			<input type="button" value="" class="btmenuandroid" onclick="tirehautcadre()" >

			<div id='cad0menuandroid' class="cad0menuandroid">

				<form method="POST">

					<img src="accueil.png" class="imgacceuil" id="imgacceuil">

					<input type="submit" value="" name="accueil" id="accueil" class="accueil">
					<br>

					<img src="accueil.png" class="imgactivite" id="imgactivite">

					<input type="submit" value="" name="activitepc" id="activite" class="activite">
					<br>

					<img src="accueil.png" class="imgannonce" id="imgannonce">
					<input type="submit" value="" name="annonce" id="annonce" class="annonce">
					<br>

					<img src="accueil.png" class="imgaide" id="imgaide">
					<input type="submit" value="" name="aide" id="aide" class="aide">
					<br>

					<img src="accueil.png" class="imgcontact" id="imgcontact">
					<input type="submit" value="" name="contact" id="contact" class="contact">
				</form>
					
			</div>

			
		</div>

		<br><br><br>
		<div class="cad01">

			<h3>C'est quoi <br> staff KENAMEL</h3>
				
				<p class="detail" style="text-align: justify;margin-left: 5px;margin-right:5px">Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique...[  ]
				</p>
				<center>

					<input type="button" value="Voir plus" name="" class="btpluswelcom1">

				</center>

		</div>

		<div class="cad02">

			<h3>Pourquoi <br> Cette Organisation</h3>
				
				<p class="detail" style="text-align: justify;margin-left: 5px;margin-right:5px">Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique...[  ]
				</p>
				<center>

					<input type="button" value="Voir plus" name="" class="btpluswelcom1">

				</center>

		</div>

		<div class="cad03">

			<h3>Objectifs Poursuivis <br>staff KENAMEL</h3>
				
				<p class="detail" style="text-align: justify;margin-left: 5px;margin-right:5px">Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique...[  ]
				</p>
				<center>

					<input type="button" value="Voir plus" name="" class="btpluswelcom1">

				</center>

		</div>

		<div class="cad04" id="niv1">

			<h3>Enjeux <br> Socio Environnemtal</h3>
				
				<p class="detail" style="text-align: justify;margin-left: 5px;margin-right:5px">Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique Vivamus henderit Mauris ut dui.  Gravida ut vivera lectus tincidun.  Cras mattis tempor eros net  tristique...[  ]
				</p>
				<center >

					<input type="button" value="Voir plus" name="" class="btpluswelcom1">

				</center>

		</div>
		

		<form method="POST" action="#niv1">

		<h1 class="titrecommentaire" style="color:white;background-color: black;text-align: center">Commentaires</h1>

		<?php 

			$sqlpubrech1=mysql_query("select * from commentaires order by id_com DESC limit 10");

		     while ($ligne=mysql_fetch_array($sqlpubrech1)) {
		        $datime=$ligne['id_com'];
		        $gmail=$ligne['gmail'];
		        $msgg=$ligne['contenu'];

		?>

		<div class="divcommentaire">
			<div style="width: 100%;height: 20%;">
				<br>

				<b class="titrcomm"><?php echo $gmail;?></b>
				
			</div>
			<div style="height: 70%;width: 100%">

				<div style="height: 100%;width: 20%;display: inline-block;"> <img src="user.ico"></div>

				<div style="height: 100%;width: 75%;display: inline-block;"> <p class="messagcommentaire" style="text-align: justify;"> <?php echo $msgg; ?></p> </div>
			</div>

			<div style="width: 100%;height: 10%;">

				<i class="datecom">Fait, le <?php echo $datime;?></i>
				
			</div>
			
		</div>
		<bR>


		<?php

			}
			
		?>
		<br>
		
		<center>
			<input type="button" value="Voir plus" name="" class="btpluswelcom1">
		</center>

		<br>


		<h1 style="color:white;background-color: black;text-align: center">Vos suggestions</h1>

		<div class="newletter">

			<div class="let2">

				
				
			</div>
			

			<div class="let1">

				<h2 style="background-color: black;color:white;font-weight: bold;text-shadow: 1px 2px 1px black;margin-left: 2%;width: 96%">Newsleter</h2>

				<input type="text" name="gmail" placeholder="E-Mail**" class="tgmail">

				<textarea placeholder="Message (150 lettres au plus)" name="message" class="tmessage"></textarea>


				<input type="submit" name="envoyer" value="Envoyer" class="btnenvoyer">

				</form>
				
			</div>
			
			

		</div>

		<br><BR>
		

		<h2 style="background-color: black;color:white;font-weight: bold;text-shadow: 1px 2px 1px black;margin-left: 2%;width: 96%;text-align: center">Rejoinez nous en Live</h2>

				<center>
					<i style="font-size: 20px; color:black">
					Id.Nat : 01-G4701-N40437A<br>
					RCCM: KNG/RCCM/23-A-09083<br>
					Tél: +243  906410575  - 8187796637<br>
					23, Munongo, Q. / Mama-Yemo, C./ Mont-Ngafula <br>
					</i>
				
				</center>


		<br>

		
		


		<?php 
			include("footeur.php");
		?>
		
	</div>

<script>

	var cadmenue=document.getElementById('cad0menuandroid');

	var btaccueil=document.getElementById('accueil')
	var btactivite=document.getElementById('activite')
	var btannonce=document.getElementById('annonce')
	var btaide=document.getElementById('aide')
	var btcontact=document.getElementById('contact')

	var imgbtaccueil=document.getElementById('imgacceuil') 
	var imgactivite=document.getElementById('imgactivite')
	var imgannonce=document.getElementById('imgannonce')
	var imgaide=document.getElementById('imgaide')
	var imgcontact=document.getElementById('imgcontact')

	var accueilpc=document.getElementById('accueilpc')
	var activitepc=document.getElementById('activitepc')
	var annoncepc=document.getElementById('annoncepc')
	var aidepc=document.getElementById('aidepc')
	var contactpc=document.getElementById('contactpc')


	var etat=0

	function ouverturepage(){

		//widd=screen.width;
		widd=window.innerWidth;

		if(widd>=1200){
			accueilpc.value="Accueil"
			activitepc.value="Activités"
			annoncepc.value="Annonces"
			aidepc.value="Aides"
			contactpc.value="Contats"
		}


	}

	function tirehautcadre(){

		//alert('jose');

		if (etat==0){

			cadmenue.style.height=700+ "px";
			cadmenue.style.display="block";

			btaccueil.value='Accueil';
			btactivite.value='Activités Organisées';
			btannonce.value='Annonce Opportunité';
			btaide.value='Service Client';
			btcontact.value='Mes contacts';



			btaccueil.style.backgroundColor="rgb(220,255,220)";//198,255,198)";

			btactivite.style.backgroundColor="rgb(220,255,220)";
			btannonce.style.backgroundColor="rgb(220,255,220)";
			btaide.style.backgroundColor="rgb(220,255,220)";
			btcontact.style.backgroundColor="rgb(220,255,220)";

			imgbtaccueil.style.width=30+"px";
			imgbtaccueil.style.height=30+"px";
			imgbtaccueil.style.visibility="visible"

			imgactivite.style.width=30+"px";
			imgactivite.style.height=30+"px";

			imgannonce.style.width=30+"px";
			imgannonce.style.height=30+"px";

			imgaide.style.width=30+"px";
			imgaide.style.height=30+"px";

			imgcontact.style.width=30+"px";
			imgcontact.style.height=30+"px";



			etat=1;
		}
		else{

			cadmenue.style.height=0+ "px";
			cadmenue.style.display="none";

			btaccueil.value='';
			btactivite.value='';
			btannonce.value='';
			btaide.value='';
			btcontact.value='';

			btaccueil.style.backgroundColor="white";//198,255,198)";

			btactivite.style.backgroundColor="white";
			btannonce.style.backgroundColor="white";
			btaide.style.backgroundColor="white";
			btcontact.style.backgroundColor="white";

			imgbtaccueil.style.width=0+"px";
			imgbtaccueil.style.height=0+"px";

			imgbtaccueil.style.width=0+"px";
			imgbtaccueil.style.height=0+"px";

			imgactivite.style.width=0+"px";
			imgactivite.style.height=0+"px";

			imgannonce.style.width=0+"px";
			imgannonce.style.height=0+"px";

			imgaide.style.width=0+"px";
			imgaide.style.height=0+"px";

			imgcontact.style.width=0+"px";
			imgcontact.style.height=0+"px";



			etat=0
		}


	}
	
</script>

</body>
</html>
