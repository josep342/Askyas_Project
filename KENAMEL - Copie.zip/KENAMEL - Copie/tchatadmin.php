<?php 


$iddd=($_GET['ident']);
$prenomcli="";

$iddd=explode(',', $iddd);

$idd=$iddd[0];

$idclient=$iddd[1];


include("conn.php");

$sqqlsl=mysql_query("select prenom from client where id_client='".$idclient."'");
while ($ligne=mysql_fetch_array($sqqlsl)) 
{

	$prenomcli=$ligne['prenom'];

}


if (isset($_POST['retouraide'])) 
{
	$idd=$idd.",rien";

	header('location:aideadmin.php?ident='.$idd.'');
}

if (isset($_POST['envoiis'])) 
{
	$messs=($_POST['mess']);
	$datss=date('Y-m-d H:i:s');
	$datplafon="";

	if($messs=="")
	{
		echo '<script> alert("Impossible d envoyer le message vide ")</script>';
	}
	else
	{
		$sql1=mysql_query("select dats from messagess where id_mes='".$idclient."' order by dats DESC LIMIT 1");

     	while ($ligne=mysql_fetch_array($sql1)) 
     	{
        	$datplafon=$ligne['dats'];

        }

		$tail=strlen($messs);

		if($tail<100){

			$sql2=mysql_query("update messagess set repp='".$messs."' where id_mes='".$idclient."' and dats='".$datplafon."'");

		if($sql2){
			echo '<script> alert("Message envoye avec succes")</script>';

		}
		else{
			echo '<script> alert("Erreur inattendue, veuillez ressayer plus tard")</script>';
		}

		}
		else{
			echo '<script> alert("Erreur, le message doit contenir les caracteres  inferieur à 100")</script>';
		}
			
	}
		
} 

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Gestion E-commerce</title>
	<title></title>
</head>
<body style="background-color: aliceblue">

	<div style=" width: 100%;height:300px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">

	    <form method="POST" action="">	
			
			<div style="width: 78%; height: 300px; display: inline-block;">
				<?php

					include("tete.php");


			    ?>

			
			</div>
				<div style="width: 20%; height: 300px; display: inline-block;">
						
						 <div style="width: 100%; height: 250px">
						 	 					
						 		 	
						 </div>
			
				</div>
		
		</form>
	</div>



<form action="" method="POST">
	<input type="submit" name="retouraide" value="" style="background-image: url(undoarrow_undo_1534.ico);background-size: 100%; width: 85px; height: 85px;margin-left: 90%;border-top: none; border-left:none; border-right: none; border-bottom: none; background-color: aliceblue">
</form>

<h1 style="background-color: aliceblue; color:black; text-shadow: 2px 2px 1px gray;font-size: 55px;text-align: center"> <?php echo $prenomcli ;?></h1>

<h1 style="background-color: tomato; color:white; text-shadow: 2px 2px 1px gray;font-size: 55px;text-align: center">Tchombo na Tshombo</h1>

<br><br>

<?php 

$colorr="aliceblue";

$sqqlsl=mysql_query("select mess,repp,etat,dats from messagess where id_mes='".$idclient."' and selecteur='0' order by dats ASC");
   	while ($ligne=mysql_fetch_array($sqqlsl)) {
        $msgg=$ligne['mess'];
        $reps=$ligne['repp']; 
        $eeta=$ligne['etat'];
        $dtes=$ligne['dats'];

        $phot="hotimG\PhoClient\\".$idclient.".JPEG"; 

        if($eeta=='1'){
        	$stat="Vu";
        } 
        else{
        	$stat="Envoyé";
        }

        if($reps==""){
        	$pht2="";
        	$hauteur="0px";
        	$colorr="aliceblue";
        }
        else{
        	$pht2="images\adminn.png";
        	$hauteur="auto";
        	$colorr="gray";
        }

?>
<table>
	
	<tr>
		<td style="width: 20%; height:auto;">
			<img style="width: 100%; height: 80%; border-radius: 60%" src="<?php echo $phot ;?>">
		
		</td>
		<td style="width: 60%; height: auto;background-color:blue; color: white; border-radius: 12%">
			<span style="font-size: 35px; text-shadow: 2px 1px 1px gray;  "> <?php echo $msgg; ?></span>
			
		</td>
		<td style="width: 20%"></td>

	</tr>

	<tr>
		<td style="width: auto; height:30px">
		
		</td>
		<td style="width: auto; height: 30px">
			<i style="font-size: 20px; margin-left: 50%"><?php echo $stat." ".$dtes; ?></i>
			
		</td>
		
	</tr>

</table>


<table>
	<tr>
		<td style="width: 20%;height: auto;"></td>

		<td style="width: 20%; height: auto">
			<img style="width: 100%; height: <?php echo $hauteur; ?>; border-radius: 60%" src="<?php echo $pht2;?>">
		
		</td>

		<td style="width: 60%; height: auto;background-color:<?php echo $colorr;?>; color: white; border-radius: 12%">
			<span style="font-size: 35px; text-shadow: 2px 1px 1px black;margin-left:5%;"> <?php echo $reps; ?></span>
			
		</td>
		

	</tr>
</table>



<?php 
}
?>
<br><br><br>

<form action="" method="POST">
	<table>
		<tr>
			<td style="width: 80%; height: 155px;">

				<label style="font-size: 30px; font-weight: bold; margin-left: -0%; text-shadow: 1px 2px 1px gray">Nouveau Message [100 caracteres au plus]</label>
				<textarea name="mess" style="background-color: white; width: 80%; height: 50%;font-size: 50px; color:black; height: 100%; width: 100%; box-shadow: 2px 3px 2px gray"></textarea>
			</td>
			<td style="width: 15%; height: 155px;">
				<input type="submit" name="envoiis" value="" style="background-image: url(3814505.png);background-size: 85%; background-repeat: no-repeat;width: 90%; height: 90%; background-color: aliceblue; border-top: none; border-bottom: none; border-left: none; border-right: none;margin-left: 10%; margin-top: 5%">
				
			</td>
		</tr>
	</table>
</form>

<?php 
include("footeur.php");
?>

</body>
</html>

