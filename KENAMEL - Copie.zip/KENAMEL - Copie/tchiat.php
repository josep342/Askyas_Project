<?php 
$idd=($_GET['ident']);
$idmess="";
$nom="";
$pren="";
$phot="";
$eti="";
$datss="";
$ddatss=date('Y-m-d');

$messagee="Message";
$commande="Commande";
$etacompare="";
$etacommande="";


include("conn.php");
$phot="\hotimG\\".$idd.".JPEG";

$sqqlsl=mysql_query("select etat from messagess where etat='0'");

   		while ($ligne=mysql_fetch_array($sqqlsl)) {
       			 $etacompare=$ligne['etat']; 
		}
		if($etacompare=="0"){
			$messagee="Message"." (1)";
		}
		
 $sqqlssl=mysql_query("select Etat from commande where Etat='0' and Dates='".$ddatss."'");

   		while ($ligne=mysql_fetch_array($sqqlssl)) {
       		$etacommande=$ligne['Etat']; 
		}
		if($etacommande=="0"){
			$commande="Commande"." (1)";
		}


if (isset($_POST['retour'])) {
	header('location:tchiatte.php');
}

if (isset($_POST['actualiser'])) {

	    $sqqlsl=mysql_query("select etat from messagess where etat='0'");

   		while ($ligne=mysql_fetch_array($sqqlsl)) {
       			 $etacompare=$ligne['etat']; 
		}
		if($etacompare=="0"){
			$messagee="Message"." (1)";
		}

		$sqqlssl=mysql_query("select Etat from commande where Etat='0'");

   		while ($ligne=mysql_fetch_array($sqqlssl)) {
       		$etacommande=$ligne['Etat']; 
		}
		if($etacommande=="0"){
			$commande="Commande"." (1)";
		}
}

if (isset($_POST['envoiis'])) {

		$messs=($_POST['mess']);
		$dates=($_POST['dt']);
		if($messs==""){
			echo '<script> alert("Impossible d envoyer le message vide ")</script>';
		}
		else{
			$tail=strlen($messs);
			if($tail<100){

				$sql2=mysql_query("update messagess set repp='$messs' where dats='".$dates."'");
				if($sql2){
					echo '<script> alert("Message envoye avec succes")</script>';
				}
				else{
					echo '<script> alert("Erreur inattendue, veuillez ressayer plus tard")</script>';
				}

			}
			else{
				echo '<script> alert("Erreur, le message doit contenir les caracteres  inferieur à 100")</script>';
			}
			
	}
		
	} 

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<center>
	<div style="width: 98%; height: auto;background-color: aliceblue">
		<div style="width: 100%; height: 165px; position: fixed;">
				<div style="width: 100%; height:78%; background-color: black;">
					<?php
					include("tete.php");
					 ?>
				</div>
	<form action="" method="POST">
				<div style="width: 100%; height: 21%; background-color: tomato;">
					<img src="msgg.png" style="width:30px; height: 27px;margin-left: 40%; border-radius: 30%">
					<input type="submit" name="" value="<?php echo $messagee; ?>" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="images\fast.png" style="width:30px; height: 27px;border-radius: 30%">
					<input type="submit" name="" value="<?php echo $commande; ?>" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="images\refresh_arrow_1546.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="actualiser" value="Actualiser" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato;text-shadow: 1px 1px 1px black">

					<img src="images\question_help_17841.jpg" style="width:30px; height: 27px;border-radius: 50%">
					<input type="submit" name="retour" value="Retour" style="font-size: 22px; border-top: none; border-bottom: none; border-left: none; border-right: none; background-color: tomato; text-shadow: 1px 1px 1px black">
					

				</div>

	</form>
		</div>
		<br><br><br><br><br><br><br><br><br><br><br>

		<?php 

		$sqqlsl=mysql_query("select mess,repp,etat,dats from messagess where id_mes='".$idd."' and selecteur='0' order by dats ASC");
   	while ($ligne=mysql_fetch_array($sqqlsl)) {
        $msgg=$ligne['mess'];
        $reps=$ligne['repp']; 
        $eeta=$ligne['etat'];
        $dtes=$ligne['dats']; 

         if($reps==""){
        	$pht2="";
        	$hauteur="0px";
        }
        else{
        	$pht2="images\adminn.png";
        	$hauteur="auto";
        }

		
		?>

		<table>
		<tr>
			<td style="width: 20%; height: auto">
				<img style="width: 100%; height: 70%; border-radius: 60%" src="<?php echo $phot ;?>">
			
			</td>
			<td style="width: 60%; height: auto;">
				<div style="background-color:blue; color: white; border-radius: 12%; width: 100%; height: 200px">
					<br><br>
					<span style="font-size: 35px; text-shadow: 2px 1px 1px gray;  "> <?php echo $msgg; ?></span>
				</div>
				
			</td>
			<td style="width: 20%"></td>

		</tr>

	<tr>
		<td style="width: auto; height:30px">
		
		</td>
		<td style="width: auto; height: 30px">
			<i style="font-size: 20px; margin-left: 50%"><?php echo $dtes; ?></i>
			
		</td>
		
	</tr>

</table>


<table>
	<tr>
		<td style="width: 20%;height: auto;"></td>

		<td style="width: 20%; height: auto">
			<img style="width: 100%; height: <?php echo $hauteur; ?>; border-radius: 60%" src="<?php echo $pht2;?>">
		
		</td>

		<td style="width: 60%; height: auto;background-color:gray; color: white; border-radius: 12%">
			<span style="font-size: 35px; text-shadow: 2px 1px 1px black;margin-left:5%;"> <?php echo $reps; ?></span>
			
		</td>
		

	</tr>
</table>

		<?php 
			}

			$sqls1=mysql_query("select MAX(dats) as mx from messagess where id_mes='".$idd."'");
		   	while ($ligne=mysql_fetch_array($sqls1)) {
		        $mxx=$ligne['mx'];
		    }

		?>
</div>


<form action="" method="POST">
	<table>
		<tr>
			<td style="width: 80%; height: 155px;">

				<label style="font-size: 30px; font-weight: bold; margin-left: -0%; text-shadow: 1px 2px 1px gray">Nouveau Message [100 caracteres au plus]</label>
				<textarea name="mess" style="background-color: white; width: 80%; height: 50%;font-size: 30px; color:black; height: 100%; width: 100%; box-shadow: 2px 3px 2px gray"></textarea>
			</td>
			<td style="width: 15%; height: 155px;">
				<input type="submit" name="envoiis" value="" style="background-image: url(3814505.png);background-size: 85%; background-repeat: no-repeat;width: 90%; height: 90%; background-color: white; border-top: none; border-bottom: none; border-left: none; border-right: none;margin-left: 10%; margin-top: 5%">
				
			</td>
		</tr>
	</table>
	<input type="text" style="width: 0px; height: 0px; background-color:aliceblue; border-top: none; border-bottom: none; border-right: none; border-left: none" name="dt" value="<?php echo  $mxx; ?>">
</form>


<?php
include("shoutaireautre.php");
 ?>

</body>
</html>