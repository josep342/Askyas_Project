<?php 
$idd=($_GET['ident']);
//$iddd=($_GET['ident'])
include("conn.php");
$etat="";
$ff="";
$dats="";
$ettats="";
$sejreste=4;
$notif="";
$testlike="";
$nbrjaim=0;
$detest=0;
$messs="";

if(isset($_POST['mess']) && isset($_FILES["imgpub"]))
{
	$messs=($_POST['mess']);

	$imgnom=$_FILES["imgpub"]["name"];
	$imgcontenu=$_FILES["imgpub"]["tmp_name"];
	$imgtaill=$_FILES["imgpub"]["size"];

	$dates=date('Y-m-d');
	$heure=date('H:m:s');
	$idpub=date('Y-m-d H:m:s');

	if($messs=="")
	{
		echo '<script> alert("Impossible d enregistrer les zones vides ")</script>';
	}
	else
	{
		$tail=strlen($messs);
		if($tail<210)
		{
			$noo=str_replace(':', "_", $idpub);
			$noo=$noo.".jpeg";

			if ($imgtaill<=500000)
				{
					if($imgtaill==0)
					{
						echo '<script> alert("fichier vide ou corrompu !!")</script>';
						$messs=$messs;

					}
					else
					{
						
						try
						{
							$sql2=mysql_query("insert into pub values('$idpub','$messs','$dates','$heure','1',0,0)");
							copy($imgcontenu,"hotimG\Pubimg\\".$noo);

							echo '<script> alert("Pub enregistre et diffusé avec succes")</script>';
							$messs="";
						}
						
						catch(Exception $ex)
						{
							echo '<script> alert("Erreur inattendue, veuillez ressayer plus tard")</script>';
							$messs=$messs;

						}

							
					}
					
				}
				else
				{
					echo '<script> alert("Cette  image est trop volumineuse!! veuillez choisir une image dont la taille est inférieure à 500ko")</script>';
					$messs=$messs;

				}
				 
			}

			else
			{
				echo '<script> alert("Erreur, le message doit contenir les caracteres  inferieur à 210")</script>';
				$messs=$messs;
			}
				
		}
		
	}
	
if(isset($_POST['desactivepub'])) 
{
	$idpubactif=($_POST['idpub']);
	$datenew=date('Y-m-d');
	$heurnew=date('H:m:s');

	$sqlmod=mysql_query("update pub set dates='".$datenew."',heures='".$heurnew."', etat='1',jaime=0,detester=0 where id='".$idpubactif."'");
	if($sqlmod)
	{
		echo '<script> alert("La pub a éte réactivé avec succes")</script>';
	}
}

if (isset($_POST['activerpub'])) 
{
	$idpubactif=($_POST['idpub']);

	$sqlmod=mysql_query("update pub set etat='0' where id='".$idpubactif."'");
	if($sqlmod)
	{
		try
		{
			$sqsuprim=mysql_query("delete from likes where id_pub ='".$idpubactif."'");
		}
		catch(Exception $ex)
		{

		}
		if($sqsuprim)
		{
			echo '<script> alert("La pub a été retiré avec succes")</script>';

		}
		
	}
	else
	{
		echo '<script> alert("Error!!, veuillez reéssayer plus tard")</script>';

	}


}
	
if (isset($_POST['envoiis'])) 
{
	echo "";
	
		
} 


$sql1=mysql_query("select Nom,Prenom from client where id_client ='".$idd."'");

     while ($ligne=mysql_fetch_array($sql1)) {
        $nom=$ligne['Nom'];
        $prenom=$ligne['Prenom'];
	}  

	$sejreste= "";
	 
	
 	$dats="+1";
	$ff="calendar.png";
	 
	$dats="";

	if (isset($_POST['commande'])) {
		header('location:commandeadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['tableau'])) {
		header('location:tableauadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['notification'])) {
		header('location:notificationadmin.php?ident='.$idd.'');
	}

	if (isset($_POST['aide'])) {
		$idd=$idd.",rien";
		header('location:aideadmin.php?ident='.$idd.'');
	} 
	if (isset($_POST['notificationhaute'])) {
		header('location:notification.php?ident='.$idd.'');
	}   
	if (isset($_POST['btnjaime'])) {
		$pubid=($_POST['idpub']);

		
		$sqlrechlike=mysql_query("select etat from likes where id_pub='".$pubid."' and id_client='".$idd."'");

	     while ($ligne=mysql_fetch_array($sqlrechlike)) {
	        $testlike=$ligne['etat'];
		}
		if($testlike=="1"){
		echo'<script> alert("Le Gestionnaire systeme remarque que tu as une fois deja liker cette pub, \n NB: Chaque personne ne peut liker qu une seule fois ");</script>';

		}
		else if($testlike=="0"){

		$sqlpubrech1=mysql_query("select jaime,detester from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech1)) {
	        $nbrjaim=$ligne['jaime'];
	        $detest=$ligne['detester'];
		}
		$nbrjaim=$nbrjaim+1;
		$detest= $detest-1;

		$sqlpubmod1=mysql_query("update pub set jaime='$nbrjaim',detester='$detest' where id='".$pubid."'");

		$sqlmodlike1=mysql_query("update likes set etat='1' where id_pub='".$pubid."' and id_client='".$idd."'");

		if($sqlpubmod1 && $sqlmodlike1){

			echo'<script> alert("Le like a ete signalee à la pub avec succes");</script>';

		}
		else{

			echo'<script> alert("Erreur inattendue");</script>';

		}

		}
		else{

		$sqlinserlike=mysql_query("insert into likes values('$idd','$pubid','1')");

		$sqlpubrech=mysql_query("select jaime from pub where id='".$pubid."'");

	     while ($ligne=mysql_fetch_array($sqlpubrech)) {
	        $nbrjaim=$ligne['jaime'];
		}
		$nbrjaim=$nbrjaim+1;

		$sqlpubmod=mysql_query("update pub set jaime='$nbrjaim' where id='".$pubid."'");
		

		}

	} 

	

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>E-commerce</title>
		<link rel="stylesheet" type="text/css" href="beaute.css">
</head>
<body onload="ouverture()" style="background-color: aliceblue">
<div style="width:100%; height:100% background-color:aliceblue; border-radius:1%; "> 
	<div style=" width: 100%;height:300px; background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));">

	    <form method="POST" action="">	
			
			<div style="width: 78%; height: 300px; display: inline-block;">
				<?php

					include("tete.php");
					//$phot="hotimG\PhoClient\\".$idd.".JPEG";
					$phot="adminn.png";

			    ?>

			
			</div>
				<div style="width: 20%; height: 300px; display: inline-block;">
						
						 <div style="width: 100%; height: 250px">
						 	 <img src="<?php echo $phot ?>" style="width: 100%; height: 80%; border-radius:60%"> <br>
						 	 <center>
						 	 	<input type="submit" name="notificationhaute" style="width: 50px;height: 50px;background:linear-gradient(rgba(120,120,150,100),rgba(0,0,0,0));background-image: url();border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%; " value="">

						 	 	<b style="color: white; font-size: 35px; background-color: red; border-radius: 50%;">  </b>
						 	 </center>
						 		 	
						 </div>
			
				</div>
		
		</form>
	</div>

		

		
	<!-- les diffent bouton de menue-->

		<div style="width:0px; height: 100%;background:linear-gradient(rgba(0,0,0,0),rgba(120,120,150,100))" id="tire">
			<div id="haut" style="width: 83%; height: 10%; display: inline-block;background-color: black; box-shadow: 3px 4px 2px blue; opacity: 80%"><br>
				<b id="etiquettemenu" style="margin-left: 30%; color: white; font-size: 70px">
					
				</b><br><br>
				
				
			</div>

			<div style="width: 15%; height: 10%; display: inline-block;">
				<input id="btrepl" type="button" name="" text="ici" onclick="replier()" style="width: 0px; height: 0px; background-image: url(c1.PNG); border-top: none;border-right: none; border-left: none; border-bottom: none; background-repeat: no-repeat;background-repeat: no-repeat;background-size: 100%">	
			</div><br><br><br>

	<form action="" method="POST">

			<img id="photacceuil" style="width:0px; height:0px;margin-left: 5%" src="images\house_115210.png">

			<input type="submit" name="acceuil" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="accueil"> 
			<br><br><br><br>

			<img id="photcommander" style="width:0px; height:0px;margin-left: 5% " src="images\platt.jpg">

			<input type="submit" name="commande" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="commande"> 
			<br><br><br><br>

			
			<img id="phottableau" style="width:0px; height:0px;margin-left: 5% " src="images\statistique.png">

			<input type="submit" name="tableau" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="tableau">  

			<br><br><br><br>

			<img id="photnot" style="width:0px; height:0px;margin-left: 5% " src="images\1592461.png">

			<input type="submit" name="notification" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="notification">  
			<br><br><br><br>

			<img id="photaide" style="width:0px; height:0px;margin-left: 5%" src="images\admin.png">

			<input type="submit" name="aide" value="" style="color: tomato; font-weight: bold;text-decoration: none; font-size: 50px;background-color:rgba(0,0,0,0);border-top: none; border-bottom: none; border-left: none; border-right: none; margin-left: 10%" id="aide"> 
			<br>
	</form>

			
		</div>
	<!-- fin des diffent bouton de menue-->



<form action="" method="POST">
		<div style="width: 100%; height: 20%; background-color: rgba(0,0,0,0)">
			<div style="width:15%; height: 100%; display: inline-block; ">
				<input id="btntirer" type="button" name="" text="ici" onclick="tire()" style="width: 100px; height: 100px; background-image: url(c1.PNG); background-repeat: no-repeat;background-size: 100%; border-top: none;border-right: none; border-left: none; border-bottom: none;">

			</div>
			<div style="width: 80%; height: 100% ;display: inline-block;">
				<b id="welcom" style="text-align: center; text-shadow: 1px 2px 1px rgba(120,120,150,100);font-size:40px; margin-left: 1%" > Welcome Mr/Mlle Admin<?php echo "  ". $nom ."  ".$prenom ?>  </b> <br><br>
				
			</div>
			
		</div>
</form>
<hr style="box-shadow: 3px 3px 3px gray">

<center>
	<br><br>
	<div style="width: 27%; height: 350px; display: inline-block;">
		<img src="images\mon logoo.jpg" style="width: 90%; height: 100%; border-radius: 60%; margin-left: 10%"><br><br><br><br><br><br>
	</div>
	<div style="width: 70%; height: 350px; display: inline-block;">
		<i style="font-size: 35px; text-shadow: 1px 1px 1px gray">
			<p style="text-align: justify;"> <span style="font-size: 40px; color:tomato; text-shadow: 2px 2px 2px gray">B</span>ienvenu(e) Monsieur/Madame<span style="font-size: 35px; color:tomato; text-shadow: 1px 2px 1px gray"></span> Bon retrouvail cher(e) admin, sentez-vous precieux car c'est par votre biais que tous nos clients bénéficieront nos services de qualité.</p><p style="text-align: justify;">Il sied de vous rapppeler, cette dernière oblige une vigillance approfondue du fait de satisfaire nos clients pour bénéficier une marge de <span style="font-size: 35px; color:tomato; text-shadow: 2px 2px 2px gray">crédibilité </span> et surtout vus qu'on est dans le marché concurrenciel où chaque entreprise vise à méfier l'autre</p> Du reste <span style="font-size: 35px; color:tomato; text-shadow: 2px 2px 2px gray">Bon application ! </span>  </i>
		
	</div>

	<hr style="box-shadow: 3px 3px 3px gray">

		<h2 style="font-size: 30px; text-shadow: 2px 2px 2px gray "> Fourcette Horaire</h2>
		
		<table>
			<th style="width: 130px"></th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">L</span>undi</th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">M</span>ardi</th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">M</span>ercredi</th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">J</span>eudi</th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">V</span>endredi</th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">S</span>amedi</th>
			<th style="font-size: 30px; text-shadow: 1px 1px gray;box-shadow: 2px 2px 2px black;border-radius: 85%"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:tomato">D</span>imanche</th>
			<tr>
				<td style="font-size: 30px; text-shadow: 1px 1px gray"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:blue">D</span>ébut
				</td>

				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 1px 2px 1px black;text-align: center">00:00</td>
				
			</tr>

			<tr>
				<td style="font-size: 20px; text-shadow: 1px 1px gray"><span style="font-size: 35px; text-shadow: 1px 2px gray; color:blue">F</span>in
				</td>

				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				<td style="font-size: 30px;font-weight: bold;text-shadow: 1px 2px 1px gray;box-shadow: 2px 2px 2px black;text-align: center">22:59</td>
				
			</tr>
		</table>
	
		<h1 style="font-size: 30px; text-shadow: 2px 2px 2px gray "> Proprièté </h2>
				

<br>
<hr style="box-shadow: 3px 3px 3px gray">
<br>
	<div style="width:50%; height:300px;background-image: url(bienven.jpg); background-size: 100%; background-repeat: no-repeat;">

		<b style="font-size:50px; margin-left: 50%; text-shadow: 1px 2px 1px gray; color:tomato">H<span style="font-size: 40px; color:blue">over</span></b>
		<br><br><br><br><br><br><br><br>

		<i style="font-size: 45px; color:tomato; text-shadow: 2px 2px 2px gray;margin-left: 50%"> 24 <span style="font-size: 60px; color:blue; text-shadow: 2px 2px 2px gray;">H/</span>24</i>
									
	</div>
	<hr style="box-shadow: 3px 3px 3px gray">
	<br><br>
	<h1 style="font-size:35px;color:white;text-shadow: 2px 2px 1px gray; background-color: tomato "><i style="font-size: 55px; color:blue;text-shadow: 2px 2px 2px white">E</i>space  Pub's actifs</h1>


 <?php 

	
	$id_mess="";
	$dets="";
	$jaim=0;
	$dats="";
	$heurr="00:00:00";
	$heurnow=date('H:i:s');
	$datnoww=date('Y-m-d');
	$compheur="00:00:00";
	$det="";
	$etatst="";
	
	$sqlu2=mysql_query("select id,detail,dates,heures,jaime,detester,likes.etat as ets from pub,likes where pub.etat='1' and likes.id_pub=pub.id order by id DESC");
     while ($ligne=mysql_fetch_array($sqlu2)) {
        $id_mess=$ligne['id'];
        $dets=$ligne['detail'];
        $dats=$ligne['dates'];
        $heurr=$ligne['heures'];
        $nbrjaim=$ligne['jaime'];
        $detest=$ligne['detester'];
        $etatst=$ligne['ets'];

        $compheur= ($heurnow+1)-$heurr;

        if($compheur<=0 && $datnoww==$dats){
        	$det="Il y'a quelques min";
        }
        else if($compheur<=23 && $datnoww==$dats){
        	$det="Il y'a ".$compheur." h";

        }else{
        	$det="Depuis ".$dats;

        }

        if($id_mess==""){
        	
        	$phtaim="";
        	$phtnoaim="";

        }
        else{
        	
        	$phtaim="jaime.jpg";
        	$phtnoaim="7ceffba2b05699e30b9bb45b0bc18767.jpg";

        }

        $noopho=str_replace(':', "_", $id_mess);
		$noopho=$noopho.".jpeg";

        $photpub="hotimG\Pubimg\\".$noopho;

        if($etatst=="1"){
        	$notif=" Vous et d'autres personnes ont Liké cette pub";
        }
        else if($etatst=="0"){
        	$notif=" Vous et d'autres personnes ont Detesté cette pub";
        }

        ?>

<form action="" method="POST">
        <table style="width: 850px; height:500px;">
        	<tr>
        		<td style="width: 70%">
        			
        		</td>
        		<td style="width: 25%; background-color: blue; color:white; text-shadow: 2px 2px 2px gray; border-radius: 40%; box-shadow: 2px 2px 2px gray;font-size: 25px">
        			<?php echo $det; ?>	
        		</td>
      
        	</tr>

        	<tr>
        		<td colspan="2" style="text-shadow: 1px 1px 1px gray;font-size: 35px;"><i> <?php echo $dets; ?></i>
        			
        		</td>
        	</tr>
        	
        	<tr>
        		<td colspan="2" style="width:600px; height: 700px">
        			<img style="width: 100%; height: 100%;" src='<?php echo $photpub;?>'>
        			
        		</td>
        		
        	</tr>
        	<tr>
        		<td colspan="2" style="box-shadow: 1px 1px 1px gray">
        				<i style="color:gray;margin-left: 10%;font-size: 30px"><?php echo $notif; ?></i>
        				
        			
        		</td>
        		
        	</tr>
        	<tr style="box-shadow: 2px 2px 1px gray">
        		<td>
        			<center>
        				
        				<input type="button" name="btndetester" value="" style="background-image: url(<?php echo $phtnoaim; ?>);width: 90px; height: 90px; background-size: 90%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;background-color: aliceblue"> <i style="font-size:45px; "> <?php echo $detest; ?></i>
        			</center>
        			
        		</td>

        		<td>
        			<input type="button" name="btnjaime" value="" style="background-image: url(<?php echo $phtaim; ?>);width: 80px; height: 70px; background-size: 100%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;"><i style="font-size:45px; "> <?php echo $nbrjaim; ?></i>
 
        			
        		</td>
        	</tr>
        	
        </table>
        <br>

 </form>
 <form action="" method="POST">
 	<input type="text" style="width: 0px;height: 0px; background-color: aliceblue;border-top: none; border-bottom: none; border-right: none; border-left: none" name="idpub"  value="<?php echo $id_mess; ?>"> 

      <input type="submit" style="width: 150px;height: 40px;margin-left: 75%;border-radius: 40%; font-size:25px;text-shadow: 1px 2px 1px gray;font-weight: bold;color:white; background-color: red; border-top: none; border-bottom: none; border-right: none; border-left: none" name="activerpub"  value="Desactiver"> 

 </form>
 <br><br>
 <hr style="box-shadow: 3px 3px 3px gray">
 <br>

    <?php 
	}

	$sqlu21=mysql_query("select id,detail,dates,heures,jaime,detester from pub where id NOT IN (select id_pub from likes) and pub.etat='1' order by id
	 DESC");

     while ($ligne=mysql_fetch_array($sqlu21)) {
        $id_mess=$ligne['id'];
        $dets=$ligne['detail'];
        $dats=$ligne['dates'];
        $heurr=$ligne['heures'];
        $nbrjaim=$ligne['jaime'];
        $detest=$ligne['detester'];

        $compheur= ($heurnow+1)-$heurr;

        if($compheur<=0 && $datnoww==$dats){
        	$det="Il y'a quelques min";
        }
        else if($compheur<=23 && $datnoww==$dats){
        	$det="Il y'a ".$compheur." h";

        }else{
        	$det="Depuis ".$dats;

        }

        if($id_mess==""){
        	
        	$phtaim="";
        	$phtnoaim="";

        }
        else{
        	
        	$phtaim="jaime.jpg";
        	$phtnoaim="7ceffba2b05699e30b9bb45b0bc18767.jpg";

        }

        $noopho=str_replace(':', "_", $id_mess);
		$noopho=$noopho.".jpeg";

        $photpub="hotimG\Pubimg\\".$noopho;
        
	?>
	<form action="" method="POST">
        <table style="width: 850px; height:500px;">
        	<tr>
        		<td style="width: 70%">
        			
        		</td>
        		<td style="width: 25%; background-color: blue; color:white; text-shadow: 2px 2px 2px gray; border-radius: 40%; box-shadow: 2px 2px 2px gray;font-size: 25px">
        			<?php echo $det; ?>	
        		</td>
      
        	</tr>

        	<tr>
        		<td colspan="2" style="text-shadow: 1px 1px 1px gray;font-size: 35px;"><i> <?php echo $dets; ?></i>
        			
        		</td>
        	</tr>
        	
        	<tr>
        		<td colspan="2" style="width:600px; height: 700px">
        			<img style="width: 100%; height: 100%;" src='<?php echo $photpub;?>'>
        			
        		</td>
        		
        	</tr>
        	<tr>
        		<td colspan="2" style="box-shadow: 1px 1px 1px gray">
        				<i style="color:gray;margin-left: 10%;font-size: 30px"><?php echo $notif; ?></i>
        				
        			
        		</td>
        		
        	</tr>
        	<tr style="box-shadow: 2px 2px 1px gray">
        		<td>
        			<center>
        				
        				<input type="button" name="btndetester" value="" style="background-image: url(<?php echo $phtnoaim; ?>);width: 90px; height: 90px; background-size: 90%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;background-color: aliceblue"> <i style="font-size:45px; "> <?php echo $detest; ?></i>
        			</center>
        			
        		</td>

        		<td>
        			<input type="button" name="btnjaime" value="" style="background-image: url(<?php echo $phtaim; ?>);width: 80px; height: 70px; background-size: 100%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;"><i style="font-size:45px; "> <?php echo $nbrjaim; ?></i>
 
        			
        		</td>
        	</tr>
        	
        </table>
        <br>
        
 </form>

 <form action="" method="POST">
 	<input type="text" style="width: 0px;height: 0px; background-color: aliceblue;border-top: none; border-bottom: none; border-right: none; border-left: none" name="idpub"  value="<?php echo $id_mess; ?>"> 

      <input type="submit" style="width: 150px;height: 40px;margin-left: 75%;border-radius: 40%; font-size:25px;text-shadow: 1px 2px 1px gray;font-weight: bold;color:white; background-color: red; border-top: none; border-bottom: none; border-right: none; border-left: none" name="activerpub"  value="Desactiver"> 

 </form>
 <br><br>

 <hr style="box-shadow: 3px 3px 3px gray">
 <br>
 <?php 
}
 ?>

 <h1 style="font-size:35px;color:white;text-shadow: 2px 2px 1px gray; background-color: tomato "><i style="font-size: 55px; color:blue;text-shadow: 2px 2px 2px white">E</i>space  Pub's Inactifs</h1>

 <?php 

	$sqlu21=mysql_query("select id,detail,dates,heures,jaime,detester from pub where  pub.etat='0' order by dates DESC");
	//id NOT IN (select id_pub from likes) and

     while ($ligne=mysql_fetch_array($sqlu21)) {
        $id_mess=$ligne['id'];
        $dets=$ligne['detail'];
        $dats=$ligne['dates'];
        $heurr=$ligne['heures'];
        $nbrjaim=$ligne['jaime'];
        $detest=$ligne['detester'];

        $compheur= ($heurnow+1)-$heurr;

        if($compheur<=0 && $datnoww==$dats){
        	$det="Il y'a quelques min";
        }
        else if($compheur<=23 && $datnoww==$dats){
        	$det="Il y'a ".$compheur." h";

        }else{
        	$det="Depuis ".$dats;

        }

        if($id_mess==""){
        	
        	$phtaim="";
        	$phtnoaim="";

        }
        else{
        	
        	$phtaim="jaime.jpg";
        	$phtnoaim="7ceffba2b05699e30b9bb45b0bc18767.jpg";

        }

        $noopho=str_replace(':', "_", $id_mess);
		$noopho=$noopho.".jpeg";

        $photpub="hotimG\Pubimg\\".$noopho;
	?>
	<form action="" method="POST">
        <table style="width: 850px; height:500px;">
        	<tr>
        		<td style="width: 60%">
        			
        		</td>
        		<td style="width: 40%;font-size: 30px; background-color: blue; color:white; text-shadow: 2px 2px 2px gray; border-radius: 40%;text-align: center; box-shadow: 2px 2px 2px gray">
        			<?php echo $det; ?>	
        		</td>
      
        	</tr>

        	<tr>
        		<td colspan="2" style="text-shadow: 1px 2px 1px gray;font-size: 30px"> <?php echo $dets; ?>
        			
        		</td>
        	</tr>
        	
        	<tr>
        		<td colspan="2" style="width:600px; height: 700px">
        			<img style="width: 100%; height: 100%;" src='<?php echo $photpub;?>'>
        			
        		</td>
        		
        	</tr>
        	<tr>
        		<td colspan="2">
        				
        				
        			
        		</td>
        		
        	</tr>
        	<tr style="box-shadow: 2px 2px 1px gray">
        		<td>
        			<center>
        				
        				<input type="button" name="btndetester" value="" style="background-image: url(<?php echo $phtnoaim; ?>);width: 90px; height: 90px; background-size: 90%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;background-color: aliceblue"> <i style="font-size:45px; "> <?php echo $detest; ?></i>
        			</center>
        			
        		</td>

        		<td>
        			<input type="button" name="btnjaime" value="" style="background-image: url(<?php echo $phtaim; ?>);width: 80px; height: 70px; background-size: 100%; background-repeat: no-repeat;border-top: none;border-right: none; border-left: none;border-bottom: none;"><i style="font-size:45px; "> <?php echo $nbrjaim; ?></i>
 
        			
        		</td>
        	</tr>
        	
        </table> 
        <br>

 </form>

 <form action="" method="POST">
 	
        <input type="text" style="width: 0px;height: 0px; background-color: aliceblue; border-top: none; border-bottom: none; border-right: none; border-left: none" name="idpub"  value="<?php echo $id_mess; ?>"> 

        <input type="submit" style="width: 150px;height: 40px;margin-left: 75%;border-radius: 40%; font-size:25px;text-shadow: 1px 2px 1px gray;font-weight: bold;color:white; background-color: red; border-top: none; border-bottom: none; border-right: none; border-left: none" name="desactivepub"  value="Réactiver">
 </form>
 <br><br>

 <hr style="box-shadow: 3px 3px 3px gray">
<br>
 <?php 
}
 ?>
 <br><br>

 <form action="" method="POST" enctype="multipart/form-data">
	<table>
		<tr>
			<td style="width: 80%; height: 155px;">

				<label style="font-size: 30px; font-weight: bold; margin-left: -0%; text-shadow: 1px 2px 1px gray">Nouvelle Pub [100 caracteres au plus]</label>
				<textarea name="mess" style="background-color: white; width: 80%; height: 50%;font-size: 30px; color:black; height: 100%; width: 100%; box-shadow: 2px 3px 2px gray">
					<?php echo $messs; ?>
					
				</textarea>
			</td>
			<td style="width: 15%; height: 165px">
				<input type="submit" value="" style="background-image: url(3814505.png);background-size: 85%; background-repeat: no-repeat;width: 90%; height: 90%; background-color: white; border-top: none; border-bottom: none; border-left: none; border-right: none;margin-left: 10%; margin-top: 5%">
				
			</td>
		</tr>
		<tr>
			<td></td>
			
			<td></td>
		</tr>
	</table>

	<input type="text" style="width: 0px; height: 0px; background-color:aliceblue; border-top: none; border-bottom: none; border-right: none; border-left: none" name="dt" value="">
<!--</form>!-->

<h1 style="font-size:35px;color:white;text-shadow: 2px 2px 1px gray; background-color: tomato "><i style="font-size: 55px; color:blue;text-shadow: 2px 2px 2px white">Anne</i>xe visuel</h1>


<!--<form action="" method="post" enctype="multipart/form-data">!-->
	<br>
	<input type="file" name="imgpub" value="joindre la photo">

	<!--<input type="submit"  name="photoimport" value="Enregistrer">!-->
</form>

				
</center>
		
</div>

<script>
	//let temps=20;
	var tirerr=document.getElementById('tire');
	var btreplier=document.getElementById('btrepl'); 
	var bttirer=document.getElementById('btntirer'); 

	var etiquemenuu=document.getElementById('etiquettemenu'); 
	var welcom=document.getElementById('welcom'); 


	var acc=document.getElementById('accueil');
	var command=document.getElementById('commande');
	var tableau=document.getElementById('tableau');
	var notification=document.getElementById('notification');
	var aide=document.getElementById('aide'); 
	var photacceuil=document.getElementById('photacceuil'); 
	var photcomm=document.getElementById('photcommander'); 
	var phottableaub=document.getElementById('phottableau'); 
	var photnotif=document.getElementById('photnot'); 
	var photaidee=document.getElementById('photaide'); 





	function tire(){	
	tirerr.style.width=60+"%";
	tirerr.style.height=1000+"px";
	welcom.innerText="";

	btreplier.style.width=100+"px"
	btreplier.style.height=100+"px"
	bttirer.style.width=0+"px";
	bttirer.style.height=0+"px";

	photacceuil.style.height=50+"px";
	photacceuil.style.width=60+"px";

	photcomm.style.height=50+"px";
	photcomm.style.width=60+"px";

	phottableaub.style.height=50+"px";
	phottableaub.style.width=60+"px";

	photnotif.style.height=60+"px";
	photnotif.style.width=60+"px";

	photaidee.style.height=60+"px";
	photaidee.style.width=70+"px";



	acc.value="Acceuil"
	command.value="Commande ";
	tableau.value="Tableau de Bord";
	notification.value="Notification";
	aide.value="Aide ?";
	etiquemenuu.innerText="MENU";
	}
	function replier(){	
		//style="width: 70px; height: 55px; 
	btreplier.style.width=0+"%"
	btreplier.style.height=0+"%"

	bttirer.style.width=100+"px";
	bttirer.style.height=100+"px";
	var nom='<?php echo $nom ."  ".$prenom ?>';

	welcom.innerText="Welcome Mr/Mlle "+nom ;
	acc.value="";
	command.value="";
	tableau.value="";
	notification.value="";
	aide.value="";
	etiquemenuu.innerText="";



	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";

	photacceuil.style.height=0+"px";
	photacceuil.style.width=0+"px";

	photcomm.style.height=0+"px";
	photcomm.style.width=0+"px";

	phottableaub.style.height=0+"px";
	phottableaub.style.width=0+"px";

	photnotif.style.height=0+"px";
	photnotif.style.width=0+"px";

	photaidee.style.height=0+"px";
	photaidee.style.width=0+"px";
	
	}
	function ouverture(){
	tirerr.style.width=0+"%";
	tirerr.style.height=0+"px";
	}

	
</script>
<?php 
include("footeur.php");
?>
</body>
</html>