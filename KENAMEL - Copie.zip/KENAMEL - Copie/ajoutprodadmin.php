<?php 

$idd=($_GET['ident']);
include("conn.php");

if (isset($_POST['retour'])) 
{
	header('location:commandeadmin.php?ident='.$idd.'');

}
if(isset($_POST['env']))
{
	$imgnom=$_FILES["imgpub"]["name"];
	$imgcontenu=$_FILES["imgpub"]["tmp_name"];
	$imgtaill=$_FILES["imgpub"]["size"];

	$sqllo1=mysql_query("select MAX(date_acquis) from produit");

     while ($ligne=mysql_fetch_array($sqllo1)) {
        $maxtime=$ligne[0];
	} 

	if($sqllo1)
	{
		$noo=str_replace(':', "_", $maxtime);
		$noo=$noo.".jpeg";

		if ($imgtaill<=300000)
			{
				if($imgtaill==0)
				{
					echo '<script> alert("fichier vide ou corrompu !!")</script>';

				}
				else
				{
					copy($imgcontenu,"hotimG\ProdimG\\".$noo);
					echo '<script> alert("absolu !!")</script>';
				}
				 
			}
			else
			{
				echo '<script> alert("Cet image trop!! veuillez choisir une image dont la taille est inférieure à 300ko")</script>';

			}
	}
}

if(isset($_POST['enreigistrer'])) 
{
	$nom=($_POST['nom']);
	$model=($_POST['modele']);
	$type=($_POST['typee']);
	$pu=($_POST['pu']);
	$stock=($_POST['stock']);

	$annee=($_POST['annees']);
	$moiss=($_POST['moiss']);
	$jourr=($_POST['jourr']);
	//$annee."-".$moiss."-".$jourr

	#$dat=strptime('2024-05-01', 'Y-m-d');

	if($nom=="" || $model=="" || $type=="" ||$pu=="" || $stock=="" ||$annee==""||$moiss==""||$jourr=="")
	{
		echo '<script>alert("il faut remplir tous les champs")</script>';	
		

	}
	else
	{
		$ddataujourd=date('Y-m-d');
		$dateplat='2024-10-05';

		if($ddataujourd<$dateplat)
		{
			$idp=$nom[2].$model[0].$pu[0].$stock[1].strlen($pu);

			$datee=date('Y-m-d');
			$dattime=date('Y-m-d H:m:s');

		    $reng=mysql_query("insert into produit values ('$idp','$nom','$model','$type','$pu','$stock','$stock','$dattime','$datee')");
		    if($reng)
		    {
		    	echo '<script>alert("Le produit enregistrer avec succes")</script>';

		    }
		    else
		    {
		    	echo '<script>alert(ERROR!!,veuillez reessayer plus tard ")</script>';
		    }
		}
		
	}
	


}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body><!--onload="ouverture()"--!-->

	<div style="width: 100%; height: 1700px; background-color: aliceblue">
		<center>
			<H1 style="background-color: tomato; color:white; font-size: 50px; box-shadow: 5px 13px 5px gray;" >GESTION DE PRODUITS</H1>
			<form action="" method="POST">

				<input type="submit" name="retour" value="Retour" onclick="retourconnexion()" style=" font-size: 45px; border-right: none; border-top: none; border-left:none; border-bottom: none;background-color: aliceblue; margin-left: 80%;text-shadow: black 1px 2px 1px"><br><br><br>
			</form>		

			<br><br><br><br><br>
<form action="" method="POST">

		<input type="text" id="nom" name="nom" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Nom du produit ">

			<br><br><br><br><br>
			
		<input type="text" id="modele" name="modele" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Modele(Facultatif)">

			<br><br><br><br><br>

			<table style="margin-left: 10%">
				<tr>
					<td style=" font-size: 45px;font-weight: bold;">Type</td>
					<td style="width: 100px"></td>
					<td>
						<select id="typee" name="typee" style=" font-size: 45px; width: 450px; border-color: tomato" > 
							<option></option>
							<option>Informatique</option>
							<option>Eletronique</option>
							<option>Autres</option>
							

						</select>
					</td>
				</tr>
			</table>


			<br><br><br><br><br>

		<input type="text"  id="pu" name="pu" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="PU en USD(ex: 2.12">

			<br><br><br><br><br>

		<input type="text" id="stock" name="stock" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold;" placeholder="Quantite en stock">

		<br><br><br><br><br> 

		<h3 style="background-color: gray; color:blue; text-shadow: 1px 2px 1px white;font-size: 45px">Expiration</h3>

		<b style="font-weight: bold;font-size: 25px; text-shadow: 1px 2px 1px gray">Annee</b>
		<select id="annees" name="annees" style=" font-size: 40px;font-weight: bold; width: 100px; border-color: tomato" > 
				<option> </option>
				<option>2024</option>
				<option>2025</option>
				<option>2026</option>
				<option>2027</option>
		</select>
		
		<b style="font-weight: bold;font-size: 25px; text-shadow: 1px 2px 1px gray">Mois</b>
		<select id="moiss" name="moiss" style=" font-size: 40px;font-weight: bold; width: 100px; border-color: tomato" > 
				<option> </option>
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
				<option>5</option>
				<option>6</option>
				<option>7</option>
				<option>8</option>
				<option>9</option>
				<option>10</option>
				<option>11</option>
				<option>12</option>
		</select>
		<b style="font-weight: bold;font-size: 25px; text-shadow: 1px 2px 1px gray">Jour</b>
		<select name="jourr" id="jourr" style=" font-size: 40px;font-weight: bold; width: 100px; border-color: tomato">
			<option></option>
				<option>1</option>
				<option>15</option>
				<option>30</option>
		</select>
			<br><br><br><br><br>

			

		<input type="submit" name="enreigistrer" value="Soumettez-en" style="font-size:50px; border-color: tomato; margin-left: 45%; background-color: tomato; color:white; font-weight: bold; box-shadow: 3px 8px 2px gray">	
		<br><br><br><br><br><br>	
</form>
<form action="" method="POST" enctype="multipart/form-data">

	<input type="file" id="imgpub" name="imgpub" value="Photo" style=" font-size: 45px; border-top: none; border-left: none; border-right: none; border-color: tomato; width: 80%; background-color: white; font-family: palatino; font-weight: bold">
	<br><br><br><br><br><br>
	
	<input type="submit" name="env" value="Export photo" style="font-size:50px; border-color: tomato; margin-left: 45%; background-color: tomato; color:white; font-weight: bold; box-shadow: 3px 8px 2px gray">
	
</form>
		</center>
		
	</div>

<script>	
	var iddd=document.getElementById('idd');
	var nom=document.getElementById('nom');
	var prenom=document.getElementById('prenom');
	var sexe=document.getElementById('sexe');
	var tel=document.getElementById('tel');
	var ville=document.getElementById('ville');
	var pays=document.getElementById('pays');
	var sej=document.getElementById('sejour');

	function ouverture(){
		alert("Veuillez repondre correctement aux différentes questions \n Afin de pouvoir nous permettre de décider si c'est réellement ton compte\n \n NB Veuillez vous rassurer si c'est bien répondu avant d'envisager passer à la suivante question ");
	}
	function desactive1(){
		iddd.disabled = true;
	}
	function desactive2(){
		nom.disabled = true;
	
	}
	function desactive3(){
		prenom.disabled = true;
	
	}
	function desactive4(){
		sexe.disabled = true;
	
	}
	function desactive5(){
		tel.disabled = true;
	
	}
	function desactive6(){
		ville.disabled = true;
	
	}
	function desactive7(){
		pays.disabled = true;
	
	}
	

</script>

</body>
</html>