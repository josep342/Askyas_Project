import kivy
from kivy.app import App
from kivymd.app import MDApp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.properties import NumericProperty
from kivy.metrics import dp
from kivy.uix.textinput import TextInput
from kivy.config import Config
from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.uix.relativelayout import RelativeLayout
from kivy.graphics import Color,Rectangle
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivymd.uix.datatables import MDDataTable
from kivymd.uix.floatlayout import MDFloatLayout 
from kivy.lang import Builder
from kivy.graphics.vertex_instructions import RoundedRectangle
from kivy.metrics import *
from kivy.graphics import *
from kivy.uix.image import Image
from kivy.clock import Clock

from datetime import datetime
import requests
import math
import geocoder
import folium

from kivymd.uix.textfield import MDTextField
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.boxlayout import MDBoxLayout
import random


class Pharma(MDApp):
    def build(self):


        global cadre,cadepageconnexion,cadrevente
        global tpwd,tid,bvente,bjournal,bexpert,labtitre,ic1,ic2,bsetting,tabvente1,bvente1,t1,t2,t3,t4

        cadre=Builder.load_string('''
                                                
FloatLayout:
    size_hint:1,1
    pos_hint:{'center_x':.5,'center_y':.5}
                                            
    canvas.before:
        Color:
            rgb:222/255,228/255,228/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[20,1,20,1]
            
''')
        # les boutons centrales

        bvente=Builder.load_string('''
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':.15,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]    
                                   
    on_release:app.pageVente(self)
        
    ''')
        
        bjournal=Builder.load_string('''
MDIconButton:
    icon:'view-dashboard-edit'
    pos_hint:{'center_x':.5,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]    
                                     
    on_release:app.pageJournal(self)
                                     
    ''')
        
        bexpert=Builder.load_string('''
MDIconButton:
    icon:'doctor'
    pos_hint:{'x':.75,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]   

    on_release:app.pageExpert(self) 
        
    ''')
        
        ic1=Builder.load_string('''
MDIcon:
    icon:'account-group-outline'
    pos_hint:{'center_x':.23,'y':.94}
    size_hint:.1,.1
    theme_text_color:'Custom'
    text_color:'red'

        
        ''')

        ic2=Builder.load_string('''
MDIcon:
    icon:'account-group-outline'
    pos_hint:{'center_x':.28,'y':.95}
    size_hint:.1,.1
    theme_text_color:'Custom'
    text_color:'blue'

        
        ''')


        # les outils de la page de connexion  

        
        cadepageconnexion=Builder.load_string('''
FloatLayout:
    size_hint:.9,.9
    pos_hint:{'center_x':.5,'center_y':.5}
                                              
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
        
''')
        
        progressbar=Builder.load_string('''
MDProgressBar:
    value: 0  
    max: 100  
    size_hint:1,.01
    pos_hint:{'x':0,'y':0}  
        
''')
        
        plabtit=Label(text="Connexion", font_size='25sp', pos_hint={'center_x':.5,'y':.9}, size_hint=(.7,.05), bold=True,color='black')

        imgconn=Image(source="admin.png", pos_hint={'center_x':0.5,'y':.74},size_hint=(.3,.15))
    
        tid=MDTextField(hint_text='Identifiant',line_color_normal='black',icon_right='account',font_size='15sp', pos_hint={'center_x':.5,'y':.6}, size_hint=(.8,.1), text_color_normal='black' )

        tpwd=MDTextField(hint_text='Pwd',password=True,font_size='20sp',line_color_normal='black',icon_right='account-eye', pos_hint={'center_x':.5,'y':.43}, size_hint=(.8,.1),text_color_normal='black' )
        

        pbtcon=Builder.load_string('''
Button:
    text:"Se connecter"
    pos_hint:{'x':0.4,'y':.25}
    size_hint:.5,.05
    font_size:'17sp'
    color:'white'
    background_color:[0,0,0,0]
    bold:True
                                       
    canvas.before:
                                   
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
''')
        pbtcon.bind(on_release=self.camparesecurite)

        pbpwdoublie=Builder.load_string('''
Button:
    text:"Pwd Oublié ?"
    pos_hint:{'x':.65,'y':.1}
    size_hint:.2,.1
    font_size:'13sp'
    color:'black'
    background_color:[0,0,0,0]
    bold:True
                                   
    
        
''')
        #pbpwdoublie.bind(on_release=self.openrecupeCompte)

        try:
        
            cadepageconnexion.add_widget(pbtcon)
            cadepageconnexion.add_widget(pbpwdoublie)
            cadepageconnexion.add_widget(imgconn)
            cadepageconnexion.add_widget(tid)
            cadepageconnexion.add_widget(tpwd)
            
            cadepageconnexion.add_widget(plabtit)

            cadepageconnexion.add_widget(progressbar)

        except:
            pass
        
        # les outils de la page de vente 

        labtitre=Label(text="VENTE", pos_hint={'center_x':.5,'y':.92},size_hint=(.4,.1),color='black',bold=True, font_size='17')

        cadrevente=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''')
        bsetting=Builder.load_string('''
MDIconButton:
    icon:'book-cog'
    pos_hint:{'x':.9,'y':.9}   
    size_hint:.1,.1
    

    on_release:app.pageExpert(self) 
        
    ''')
        
        trecherche=MDTextField(hint_text="Recherche",pos_hint={'center_x':.5,'center_y':.5},size_hint=(.9,.9),text_color_normal='black')

        
        cadtrech=Builder.load_string('''
FloatLayout:
    size_hint:.4,.06
    pos_hint:{'x':.15,'y':.9}
                                     
    canvas.before:
        Color:
            rgb:222/255,228/255,228/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
                                     
            radius:[5]
                                     
''')
        try:
            cadtrech.add_widget(trecherche)
        except:
            pass
        
        combaffrech=Builder.load_string('''

Button:
    text:'Choisir'
    color:'white'
    background_color:[0,0,0,0]
    background_normal:""
    pos_hint:{'x':0.58, 'y':0.9}
    markup:True
    size_hint:0.3,0.05 

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[13]      
''')
        
        t1=MDTextField(hint_text="Nom",pos_hint={'x':.025,'y':.73},size_hint=(.45,.1),icon_right='text',text_color_normal='black',line_color_normal="black")
        t2=MDTextField(hint_text="PU",pos_hint={'x':.5,'y':.73},size_hint=(.45,.1),icon_right='currency-eur',text_color_normal='black',line_color_normal="black")
        
        t3=MDTextField(hint_text="Expiration",pos_hint={'x':.025,'y':.58},size_hint=(.45,.1),icon_right='calendar-clock',text_color_normal='black',line_color_normal="black")
        t4=MDTextField(hint_text="Stock",pos_hint={'x':.5,'y':.58},size_hint=(.45,.1),icon_right='car-speed-limiter',text_color_normal='black',line_color_normal="black")

        tquantite=MDTextField(hint_text="QTE",pos_hint={'x':.5,'y':.47},size_hint=(.3,.1),icon_right='text',text_color_normal='black',line_color_normal="black")

        btproforma=Builder.load_string('''
            
MDIconButton:
    icon:'printer-eye'
    pos_hint:{'x':0.025, 'y':.49}
    size_hint:0.06,0.05

    #on_release:app.ajoutdanscoupon(self)
                                      
        ''')


        bvente1=Builder.load_string('''
            
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':0.9, 'y':0.47}
    size_hint:0.06,0.1

    #on_release:app.ajoutdanscoupon(self)
                                      
        ''')
        
        tabvente1=MDDataTable(column_data=[("N°",dp(20)),
                                           ("ID produit",dp(30)),
                                           ("Nom",dp(30)),
                                           ("P.U",dp(30)),
                                           ("Quantité",dp(30)),
                                           ("Prix total",dp(30))],
                                           rows_num=500,use_pagination=True, row_data=[],size_hint=(0.98,0.4),pos_hint={'center_x':.5,'y':0.06},check=True)
        #tabvente1.bind(on_check_press=self.retirecoupon)

        baffplus=Builder.load_string('''
            
MDIconButton:
    icon:'chevron-right-box'
    pos_hint:{'x':0.94, 'y':0}
    size_hint:0.06,0.05

    #on_release:app.ajoutdanscoupon(self)
                                      
        ''')
        

        try:
            cadrevente.add_widget(bsetting)
        except:
            pass
        
        try:
            cadrevente.add_widget(tabvente1)
        except:
            pass
        try:
            cadrevente.add_widget(bvente1)
        except:
            pass 

        try:
            cadrevente.add_widget(tquantite)
        except:
            pass 

        try:
            cadrevente.add_widget(combaffrech)
            cadrevente.add_widget(cadtrech)
        except:
            pass 
        try:
            cadrevente.add_widget(t1)
            cadrevente.add_widget(t2)
            cadrevente.add_widget(t3)
            cadrevente.add_widget(t4)
        except:
            pass
        try:
            cadrevente.add_widget(baffplus)
        except:
            pass

        try:
            cadrevente.add_widget(btproforma)
        except:
            pass


        try:
            cadre.add_widget(cadepageconnexion)
        except:
            pass 
        


        return cadre
    
    def camparesecurite(self,instance):

        try:
            cadre.remove_widget(cadepageconnexion)
        except:
            pass

        try:
            cadre.add_widget(cadrevente)
        except:
            pass

        try:
            cadre.add_widget(bvente)
        except:
            pass
        try:
            cadre.add_widget(bjournal)
        except:
            pass
        try:
            cadre.add_widget(bexpert)
        except:
            pass
        try:
            cadre.add_widget(labtitre)
        except:
            pass

        try:
            cadre.add_widget(ic1)
            cadre.add_widget(ic2)
        except:
            pass
    
    def pageVente(self,instance):  

        labtitre.text="VENTE"

    
    def pageJournal(self,instance):

        labtitre.text="JOURNAL"
    
    def pageExpert(self,instance):

        labtitre.text="MODE EXPERT"

    
Pharma().run()