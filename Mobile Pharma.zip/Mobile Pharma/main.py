import kivy
from kivy.app import App
from kivymd.app import MDApp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.properties import NumericProperty
from kivy.metrics import dp
from kivy.uix.textinput import TextInput
from kivy.config import Config
from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.uix.relativelayout import RelativeLayout
from kivy.graphics import Color,Rectangle
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivymd.uix.datatables import MDDataTable
from kivymd.uix.floatlayout import MDFloatLayout 
from kivy.lang import Builder
from kivy.graphics.vertex_instructions import RoundedRectangle
from kivy.metrics import *
from kivy.graphics import *
from kivy.uix.image import Image
from kivy.clock import Clock

from datetime import datetime
import requests
import math
import geocoder
import folium

from kivymd.uix.textfield import MDTextField
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.boxlayout import MDBoxLayout
import random

    
class Pharma(MDApp):
    def build(self):


        global cadre,cadepageconnexion,cadrevente,cadre3tbs,cadsetting,cadrejournal,cadreexpert
        global tpwd,tid,bvente,bjournal,bexpert,labtitre,ic1,ic2,bsetting,tabvente1,bvente1,t1,t2,t3,t4,btsignaler,btaide,btproformauser,btprisecharge
        global btimprimeproforma,bttaux,labtaux,cadtrech,combaffrech,tquantite
        global etaa,ettta,etatjournal
        global tabjournal,cadsuitchdate,cadsuitid,cadsuitnom,cadsuituniversel,cadsuitparticuler,trilabb,labcheckk4,labcheckk5,labdats,combnomclient,tjourclientnom,combids,tjourids,combdats,trilab,labcheck1,labcheck2,labcheck3


        ettta=0
        etatjournal=0
        etaa=0

        cadre=Builder.load_string('''
                                                
FloatLayout:
    size_hint:1,1
    pos_hint:{'center_x':.5,'center_y':.5}
                                            
    canvas.before:
        Color:
            rgb:222/255,228/255,228/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[20,1,20,1]
            
''')
        # les boutons centrales

        bvente=Builder.load_string('''
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':.15,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]    
                                   
    on_release:app.pageVente(self)
        
    ''')
        
        bjournal=Builder.load_string('''
MDIconButton:
    icon:'view-dashboard-edit'
    pos_hint:{'center_x':.5,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]    
                                     
    on_release:app.pageJournal(self)
                                     
    ''')
        
        bexpert=Builder.load_string('''
MDIconButton:
    icon:'doctor'
    pos_hint:{'x':.75,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]   

    on_release:app.pageExpert(self) 
        
    ''')
        
        ic1=Builder.load_string('''
MDIcon:
    icon:'account-group-outline'
    pos_hint:{'center_x':.23,'y':.94}
    size_hint:.1,.1
    theme_text_color:'Custom'
    text_color:'red'

        
        ''')

        ic2=Builder.load_string('''
MDIcon:
    icon:'account-group-outline'
    pos_hint:{'center_x':.28,'y':.95}
    size_hint:.1,.1
    theme_text_color:'Custom'
    text_color:'blue'

        
        ''')


        # les outils de la page de connexion  

        
        cadepageconnexion=Builder.load_string('''
FloatLayout:
    size_hint:.9,.9
    pos_hint:{'center_x':.5,'center_y':.5}
                                              
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
        
''')
        
        progressbar=Builder.load_string('''
MDProgressBar:
    value: 0  
    max: 100  
    size_hint:1,.01
    pos_hint:{'x':0,'y':0}  
        
''')
        
        plabtit=Label(text="Connexion", font_size='25sp', pos_hint={'center_x':.5,'y':.9}, size_hint=(.7,.05), bold=True,color='black')

        imgconn=Image(source="admin.png", pos_hint={'center_x':0.5,'y':.74},size_hint=(.3,.15))
    
        tid=MDTextField(hint_text='Identifiant',line_color_normal='black',icon_right='account',font_size='15sp', pos_hint={'center_x':.5,'y':.6}, size_hint=(.8,.1), text_color_normal='black' )

        tpwd=MDTextField(hint_text='Pwd',password=True,font_size='20sp',line_color_normal='black',icon_right='account-eye', pos_hint={'center_x':.5,'y':.43}, size_hint=(.8,.1),text_color_normal='black' )
        

        pbtcon=Builder.load_string('''
Button:
    text:"Se connecter"
    pos_hint:{'x':0.4,'y':.25}
    size_hint:.5,.05
    font_size:'14sp'
    color:'white'
    background_color:[0,0,0,0]
    bold:True
                                       
    canvas.before:
                                   
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
''')
        pbtcon.bind(on_release=self.camparesecurite)

        pbpwdoublie=Builder.load_string('''
Button:
    text:"Pwd Oublié ?"
    pos_hint:{'x':.65,'y':.1}
    size_hint:.2,.1
    font_size:'13sp'
    color:'black'
    background_color:[0,0,0,0]
    bold:True
                                   
    
        
''')
        #pbpwdoublie.bind(on_release=self.openrecupeCompte)

        try:
        
            cadepageconnexion.add_widget(pbtcon)
            cadepageconnexion.add_widget(pbpwdoublie)
            cadepageconnexion.add_widget(imgconn)
            cadepageconnexion.add_widget(tid)
            cadepageconnexion.add_widget(tpwd)
            
            cadepageconnexion.add_widget(plabtit)

            cadepageconnexion.add_widget(progressbar)

        except:
            pass
        
        # les outils de la page de vente 

        labtitre=Label(text="VENTE", pos_hint={'center_x':.5,'y':.92},size_hint=(.4,.1),color='black',bold=True, font_size='17')

        cadrevente=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''')
        bsetting=Builder.load_string('''
MDIconButton:
    icon:'book-cog'
    pos_hint:{'x':.9,'y':.9}   
    size_hint:.1,.1
    

    on_release:app.pagesetting(self)
        
    ''')
        
        trecherche=MDTextField(hint_text="Recherche",pos_hint={'center_x':.5,'center_y':.5},size_hint=(.9,.9),text_color_normal='black')

        
        cadtrech=Builder.load_string('''
FloatLayout:
    size_hint:.4,.06
    pos_hint:{'x':.15,'y':.9}
                                     
    canvas.before:
        Color:
            rgb:222/255,228/255,228/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
                                     
            radius:[5]
                                     
''')
        try:
            cadtrech.add_widget(trecherche)
        except:
            pass
        
        combaffrech=Builder.load_string('''

Button:
    text:'Choisir'
    color:'white'
    background_color:[0,0,0,0]
    background_normal:""
    pos_hint:{'x':0.58, 'y':0.9}
    bold:True                            
    size_hint:0.3,0.05 
    font_size:'11sp'                              

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[13]      
''')
        
        t1=MDTextField(hint_text="Nom",pos_hint={'x':.025,'y':.73},size_hint=(.45,.1),icon_right='text',text_color_normal='black',line_color_normal="black")
        t2=MDTextField(hint_text="PU",pos_hint={'x':.5,'y':.73},size_hint=(.45,.1),icon_right='currency-eur',text_color_normal='black',line_color_normal="black")
        
        t3=MDTextField(hint_text="Expiration",pos_hint={'x':.025,'y':.58},size_hint=(.45,.1),icon_right='calendar-clock',text_color_normal='black',line_color_normal="black")
        t4=MDTextField(hint_text="Stock",pos_hint={'x':.5,'y':.58},size_hint=(.45,.1),icon_right='car-speed-limiter',text_color_normal='black',line_color_normal="black")

        tquantite=MDTextField(hint_text="QTE",pos_hint={'x':.5,'y':.47},size_hint=(.3,.1),icon_right='text',text_color_normal='black',line_color_normal="black")


        labtaux=Label(text="2500",pos_hint={'x':0.19, 'y':.52},bold=True,size_hint=(.3,.1),color="black",font_size='9sp')
        bttaux=Builder.load_string('''
            
MDIconButton:
    icon:'currency-eur'
    pos_hint:{'x':0.2, 'y':.49}
    size_hint:0.1,0.12

    #on_release:app.ajoutdanscoupon(self)
                                      
        ''')

        btimprimeproforma=Builder.load_string('''
            
MDIconButton:
    icon:'printer-eye'
    pos_hint:{'x':0.025, 'y':.49}
    size_hint:0.1,0.12

    #on_release:app.ajoutdanscoupon(self)
                                      
        ''')


        bvente1=Builder.load_string('''
            
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':0.9, 'y':0.47}
    size_hint:0.1,0.12

    #on_release:app.ajoutdanscoupon(self)
                                      
        ''')
        
        tabvente1=MDDataTable(column_data=[("N°",dp(20)),
                                           ("ID produit",dp(30)),
                                           ("Nom",dp(30)),
                                           ("P.U",dp(30)),
                                           ("Quantité",dp(30)),
                                           ("Prix total",dp(30))],
                                           rows_num=500,use_pagination=True, row_data=[],size_hint=(0.98,0.4),pos_hint={'center_x':.5,'y':0.06},check=True)
        #tabvente1.bind(on_check_press=self.retirecoupon)

        baffplus=Builder.load_string('''
            
MDIconButton:
    icon:'chevron-right-box'
    pos_hint:{'x':0.94, 'y':0}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')

        btvueclaire=Builder.load_string('''
            
MDIconButton:
    icon:'eye'
    pos_hint:{'x':0.85, 'y':0}
    size_hint:0.06,0.05

    on_release:app.vueclairecoupon(self)
                                      
        ''')

        # les 3 bouttons de commande  

        bvalider=Builder.load_string('''
Button:
    text:'Valider'
    size_hint:.9,.15
    pos_hint:{'center_x':.5,'y':.7}
    background_color:[0,0,0,0]
    color:'white'
    bod:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        bsupprimer=Builder.load_string('''
Button:
    text:'Supprimer'
    size_hint:.9,.15
    pos_hint:{'center_x':.5,'center_y':.5}
    background_color:[0,0,0,0]
    color:'white'
    bod:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        bretire=Builder.load_string('''
Button:
    text:'Retire'
    size_hint:.9,.15
    pos_hint:{'center_x':.5,'y':.15}
    background_color:[0,0,0,0]
    color:'white'
    bod:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        cadre3tbs=Builder.load_string('''
FloatLayout:
    size_hint:.4,.4
    pos_hint:{'x':0.6, 'y':.06}
                                      
    canvas.before:
        Color:
            rgba:0,0,1,1
                                      #202/255,202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
''')
        

        # les outils de la page de setting

        bcommutation=Builder.load_string('''
Button:
    text:'Commutation'
    size_hint:.4,.15
    pos_hint:{'x':.05,'y':.8}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[12]
''')
        
        btcorrection=Builder.load_string('''
Button:
    text:'Correction'
    size_hint:.4,.15
    pos_hint:{'x':.55,'y':.8}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[12]
''')

        cadsetting=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0, 'y':.0}
                                      
    canvas.before:
        Color:
                                         
            rgba:202/255,202/255,202/255,202/255
                                         
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
''')
        
        btprisecharge=Builder.load_string('''
            
MDIconButton:
    icon:'walk'
    pos_hint:{'x':0.1, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')
        
        btproformauser=Builder.load_string('''
            
MDIconButton:
    icon:'notebook'
    pos_hint:{'x':0.3, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')

        btaide=Builder.load_string('''
            
MDIconButton:
    icon:'headset'
    pos_hint:{'x':0.6, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')

        btsignaler=Builder.load_string('''
            
MDIconButton:
    icon:'chat-alert'
    pos_hint:{'x':0.8, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')

        bdeconnexion=Builder.load_string('''
Button:
    text:'Deconnexion'
    size_hint:.4,.15
    pos_hint:{'x':.05,'y':.05}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        bclosesetting=Builder.load_string('''
Button:
    text:'Close'
    size_hint:.3,.15
    pos_hint:{'x':.65,'y':.05}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        bclosesetting.bind(on_release=lambda x:msggsetting.dismiss())

        try:
            cadsetting.add_widget(btcorrection)
            cadsetting.add_widget(bcommutation) 
            cadsetting.add_widget(bclosesetting)
            cadsetting.add_widget(bdeconnexion)
        except:
            pass

        try:
            cadsetting.add_widget(btsignaler)
            cadsetting.add_widget(btaide)
            cadsetting.add_widget(btproformauser)
            cadsetting.add_widget(btprisecharge)
        except:
            pass
        
        try:
            cadre3tbs.add_widget(bvalider)
            cadre3tbs.add_widget(bretire)
            cadre3tbs.add_widget(bsupprimer)
        except:
            pass
        

        try:
            cadrevente.add_widget(bsetting)
        except:
            pass
        
        try:
            cadrevente.add_widget(tabvente1)
        except:
            pass
        try:
            cadrevente.add_widget(bvente1)
        except:
            pass 

        try:
            cadrevente.add_widget(tquantite)
        except:
            pass 

        try:
            cadrevente.add_widget(combaffrech)
            cadrevente.add_widget(cadtrech)
        except:
            pass 
        try:
            cadrevente.add_widget(t1)
            cadrevente.add_widget(t2)
            cadrevente.add_widget(t3)
            cadrevente.add_widget(t4)
        except:
            pass
        try:
            cadrevente.add_widget(baffplus) 
            cadrevente.add_widget(btvueclaire) 
        except:
            pass

        try:
            cadrevente.add_widget(btimprimeproforma)
        except:
            pass
        
        try:
            cadrevente.add_widget(labtaux)
            cadrevente.add_widget(bttaux)
        except:
            pass


        cadrejournal=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''') 
        
        tabjournal=MDDataTable(column_data=[("ID PRODUIT",dp(40)),
                                            ("NOM",dp(40)),("PU",dp(20)),
                                            ("QUANTITE",dp(25)),
                                            ("PRIX TOTAL",dp(25)),
                                            ("NOM CLIENT",dp(30)),
                                            ("DATE",dp(20)),
                                            ("DATE TIME",dp(30)),
                                            ("ID TRAVAILLEUR",dp(30))],
                                            row_data=[],size_hint=(0.98,0.6),
                                            pos_hint={'center_x':0.5,'y':0.4},
                                            check=True,rows_num=2000,
                                            use_pagination=True)
        
        trilab=Label(text='[b]Trier par[/b]',font_size='12sp',color='black',pos_hint={'x':0.05,'y':0.35},size_hint=(0.082,0.05),markup=True)
        
        labcheck1=Label(text='Date',font_size='12sp',color='black',pos_hint={'x':0.09,'y':0.29},size_hint=(0.037,0.05))
        
        cadsuitchdate=Builder.load_string('''  

MDCheckbox:
    pos_hint:{'x':.3,'y':.27}
    size_hint:.1,.1
    color_active:'black'
    color_inactive:'blue'
    #on_active:app.activer(self)
        
        ''')

        suitchdate=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    #on_active:app.activer(self)
        
        ''')
       


        #CheckBox(active=True,pos_hint={'x':0.25,'y':0.35},size_hint=(0.06,0.06)) 
        #triercheck1.bind(active=self.fchecktrie1)

        labcheck2=Label(text='ID Produit',font_size='12sp',color='black',pos_hint={'x':0.08,'y':0.23},size_hint=(0.09,0.05))
        
        
        cadsuitid=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':.3,'y':.21}
    size_hint:.1,.1
    color_active:'black'
    color_inactive:'blue'
    #on_active:app.activer(self)
        
        ''')

        suitid=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    #on_active:app.activer(self)
    
        ''')
        
        #triercheck2=CheckBox(pos_hint={'x':0.25,'y':0.3},size_hint=(0.06,0.06))
        #triercheck2.bind(active=self.fchecktrie2)

        labcheck3=Label(text='Nom Client',font_size='12sp',color='black',pos_hint={'x':0.08,'y':0.17},size_hint=(0.1,0.05))
        
        #triercheck3=CheckBox(pos_hint={'x':0.25,'y':0.25},size_hint=(0.06,0.06))
        #triercheck3.bind(active=self.fchecktrie3)

        cadsuitnom=Builder.load_string('''
MDCheckbox:
    pos_hint:{'x':0.3,'y':0.15}
    size_hint:.1,.1
    color_active:'black'
    color_inactive:'blue'
    #on_active:app.activer(self)
        
        ''')

        suitnom=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    #on_active:app.activer(self)
    
        ''')

        

        trilabb=Label(text='[b]Mappage[/b]',font_size='12sp',color='black',pos_hint={'x':0.08,'y':0.12},size_hint=(0.06,0.05),markup=True)
        
        labcheckk4=Label(text='Universel',font_size='12sp',color='black',pos_hint={'x':0.08,'y':.06},size_hint=(0.09,0.05))
        
        #triercheckk4=CheckBox(pos_hint={'x':0.25,'y':0.15},size_hint=(0.06,0.06)) 
        #triercheckk4.bind(active=self.fchecktrie4)
        
        cadsuituniversel=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':.3,'y':.05}
    size_hint:.1,.05
    color_active:'black'
    color_inactive:'blue'
    #on_active:app.activer(self)
        
        ''')

        labcheckk5=Label(text='Particulier',font_size='12sp',color='black',pos_hint={'x':0.08,'y':.01},size_hint=(0.1,0.05))
        

        cadsuitparticuler=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':.3,'y':0}
    size_hint:.1,.05
    color_active:'black'
    color_inactive:'blue'
    #on_active:app.activer(self)
        
        ''')
        #triercheckk5=CheckBox(active=True,pos_hint={'x':0.25,'y':0.1},size_hint=(0.06,0.06))
        #triercheckk5.bind(active=self.fchecktrie5)

        
        labtot1=Label(text="[b]Total[/b]",color='black',pos_hint={'x':0.410, 'y':0.02},font_size='20sp',markup=True,size_hint=(0.1,0.06))
        labtot2=Label(text="[b][/b]",color='black',pos_hint={'x':0.485, 'y':0.02},font_size='20sp',markup=True,size_hint=(0.1,0.06))
        
        labdats=Label(text="Date",color='black',pos_hint={'x':0.5, 'y':0.31},font_size='13sp',size_hint=(0.05,0.06),bold=True)
        
        combdats=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.71, 'y':0.3}
    size_hint:(0.27,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        #combdats.bind(on_release=self.rechdatejournal)
        #combdats.bind(text=self.affdatejournal)  

        
        tjourids = MDTextField(hint_text="ID",line_color_normal='black', font_size='12sp', pos_hint={'x':0.48, 'y':0.19},size_hint=(0.2,0.1))
        tjourids.bind(text=self.controleurtid)
        
        combids=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.71, 'y':0.22}
    size_hint:(0.27,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')
        
        #combids.bind(on_release=self.rechidjournal)
        #combids.bind(text=self.affidprodjournal)

        tjourclientnom = MDTextField(hint_text="Client",line_color_normal='black', font_size='12sp', pos_hint={'x':0.48, 'y':0.12},size_hint=(0.2,0.1))
        tjourclientnom.bind(text=self.controleurtClient)
        combnomclient=Builder.load_string('''
Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.71, 'y':0.15}
    size_hint:(0.27,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        #combnomclient.bind(on_release=self.rechnomclientjournal) 
        #combnomclient.bind(text=self.affnomclientjournal)

        btimprjournal=Builder.load_string('''
            
MDIconButton:
    icon:'printer'
    pos_hint:{'x':0.92, 'y':0}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')

        bvecliarejournal=Builder.load_string('''
            
MDIconButton:
    icon:'eye'
    pos_hint:{'x':0.8, 'y':0}
    size_hint:0.06,0.05

    on_release:app.vueclairejournal(self)
                                      
        ''')
        
        try:
            cadrejournal.add_widget(tabjournal)
        except:
            pass

        try:
            cadrejournal.add_widget(combnomclient)
            cadrejournal.add_widget(tjourclientnom)
            cadrejournal.add_widget(combids)
            cadrejournal.add_widget(tjourids)
            cadrejournal.add_widget(combdats)

            cadrejournal.add_widget(trilab)
            cadrejournal.add_widget(labcheck1)
            cadrejournal.add_widget(labcheck2)
            cadrejournal.add_widget(labcheck3)
            cadrejournal.add_widget(trilabb)
            cadrejournal.add_widget(labcheckk4)
            cadrejournal.add_widget(labcheckk5) 
            cadrejournal.add_widget(labdats)
            
        except:
            pass
        try:
            cadrejournal.add_widget(cadsuitchdate) 
            cadrejournal.add_widget(cadsuitid)
            cadrejournal.add_widget(cadsuitnom) 
            cadrejournal.add_widget(cadsuituniversel)
            cadrejournal.add_widget(cadsuitparticuler)
        except:
            pass
    
        try:
            cadrejournal.add_widget(btimprjournal)
            cadrejournal.add_widget(bvecliarejournal)
        except:
            pass



        cadreexpert=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''') 
        
        texpert=TextInput(text="",pos_hint={'center_x': 0.5,'y': 0.6},size_hint=(.98,.35))

        btgenerer=Builder.load_string('''

Button:
    text:"Generer"
    font_size:"13sp"
    pos_hint:{'x':0.63, 'y':0.53}
    size_hint:(0.35,0.06)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')

        btactualiser=Builder.load_string('''

Button:
    text:"Actualiser"
    font_size:"13sp"
    pos_hint:{'x':0.63, 'y':0.45}
    size_hint:(0.35,0.06)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')

        cad=MDDataTable(column_data=[],row_data=[],size_hint=(0.4,0.07),
                                            pos_hint={'center_x':0.5,'center_y':0.4})
        labexp=Label(text="OpenAi",color='black',bold=True,font_size='15sp')

        try:
            cad.add_widget(labexp)
        except:
            pass
        

        try:
            cadreexpert.add_widget(texpert) 
            cadreexpert.add_widget(btgenerer)
            cadreexpert.add_widget(btactualiser)
        except:
            pass
        try:
            cadreexpert.add_widget(cad)
        except:
            pass


        try:
            cadre.add_widget(cadepageconnexion)
        except:
            pass 


        return cadre
    

    def vueclairejournal(self,instance):
        global etatjournal

        if etatjournal==0:

            tabjournal.size_hint=(0.98,0.9)
            tabjournal.pos_hint={'center_x':0.5,'y':0.1}

            try:
                cadrejournal.remove_widget(combnomclient)
                cadrejournal.remove_widget(tjourclientnom)
                cadrejournal.remove_widget(combids)
                cadrejournal.remove_widget(tjourids)
                cadrejournal.remove_widget(combdats)

                cadrejournal.remove_widget(trilab)
                cadrejournal.remove_widget(labcheck1)
                cadrejournal.remove_widget(labcheck2)
                cadrejournal.remove_widget(labcheck3)
                cadrejournal.remove_widget(trilabb)
                cadrejournal.remove_widget(labcheckk4)
                cadrejournal.remove_widget(labcheckk5) 
                cadrejournal.remove_widget(labdats)
                
            except:
                pass

        
            try:
                cadrejournal.remove_widget(cadsuitchdate) 
                cadrejournal.remove_widget(cadsuitid)
                cadrejournal.remove_widget(cadsuitnom) 
                cadrejournal.remove_widget(cadsuituniversel)
                cadrejournal.remove_widget(cadsuitparticuler)
            except:
                pass
        

            etatjournal=1
        else:

            try:
                cadrejournal.add_widget(combnomclient)
                cadrejournal.add_widget(tjourclientnom)
                cadrejournal.add_widget(combids)
                cadrejournal.add_widget(tjourids)
                cadrejournal.add_widget(combdats)

                cadrejournal.add_widget(trilab)
                cadrejournal.add_widget(labcheck1)
                cadrejournal.add_widget(labcheck2)
                cadrejournal.add_widget(labcheck3)
                cadrejournal.add_widget(trilabb)
                cadrejournal.add_widget(labcheckk4)
                cadrejournal.add_widget(labcheckk5) 
                cadrejournal.add_widget(labdats)
                
            except:
                pass
            try:
                cadrejournal.add_widget(cadsuitchdate) 
                cadrejournal.add_widget(cadsuitid)
                cadrejournal.add_widget(cadsuitnom) 
                cadrejournal.add_widget(cadsuituniversel)
                cadrejournal.add_widget(cadsuitparticuler)
            except:
                pass
        
           
            tabjournal.size_hint=(0.98,0.6)
            tabjournal.pos_hint={'center_x':0.5,'y':0.4}

            etatjournal=0

    def vueclairecoupon(self,instance):
        global ettta

        if ettta==0:
            tabvente1.size_hint=(.95,.8)

            try:
                cadrevente.remove_widget(bvente1)
            except:
                pass 

            try:
                cadrevente.remove_widget(tquantite)
            except:
                pass 

           
            try:
                cadrevente.remove_widget(t1)
                cadrevente.remove_widget(t2)
                cadrevente.remove_widget(t3)
                cadrevente.remove_widget(t4)
            except:
                pass

            try:
                cadrevente.remove_widget(btimprimeproforma)
            except:
                pass
            
            try:
                cadrevente.remove_widget(labtaux)
                cadrevente.remove_widget(bttaux)
            except:
                pass

            ettta=1
        else:
            tabvente1.size_hint=(.95,.4)

            try:
                cadrevente.add_widget(bvente1)
            except:
                pass 

            try:
                cadrevente.add_widget(tquantite)
            except:
                pass 

            
            try:
                cadrevente.add_widget(t1)
                cadrevente.add_widget(t2)
                cadrevente.add_widget(t3)
                cadrevente.add_widget(t4)
            except:
                pass

            try:
                cadrevente.add_widget(btimprimeproforma)
            except:
                pass
            
            try:
                cadrevente.add_widget(labtaux)
                cadrevente.add_widget(bttaux)
            except:
                pass

            ettta=0

    def controleurtClient(self,instance,value):
        if instance.text !="":
            instance.hint_text=""
        else:
            instance.hint_text="Client"

    def controleurtid(self,instance,value):
        if instance.text !="":
            instance.hint_text=""
        else:
            instance.hint_text="ID"


    def pagesetting(self,instance):
        global msggsetting,cadrexx

        try:
            cadrexx.remove_widget(cadsetting)
        except:
            pass


        cadrexx=FloatLayout()

        try:
            cadrexx.add_widget(cadsetting)
        except:
            pass

        

        msggsetting=Popup(title="SETTING",content=cadrexx, size_hint=(1,.5))
        msggsetting.open()
        

    def open3Buttons(self,instance):
        global etaa

        
        if etaa==0:

            try:
                cadrevente.add_widget(cadre3tbs)
            except:
                pass

            etaa=1

            instance.icon='chevron-left-box'
            
        else:
            try:
                cadrevente.remove_widget(cadre3tbs)
            except:
                pass
            
            etaa=0

            instance.icon='chevron-right-box'

    def camparesecurite(self,instance):

        try:
            cadre.remove_widget(cadepageconnexion)
        except:
            pass

        try:
            cadre.add_widget(cadrevente)
        except:
            pass

        try:
            cadre.add_widget(bvente)
        except:
            pass
        try:
            cadre.add_widget(bjournal)
        except:
            pass
        try:
            cadre.add_widget(bexpert)
        except:
            pass
        try:
            cadre.add_widget(labtitre)
        except:
            pass

        try:
            cadre.add_widget(ic1)
            cadre.add_widget(ic2)
        except:
            pass
    
    def pageVente(self,instance):  

        labtitre.text="VENTE"

        
        try:
            cadre.add_widget(cadrevente)
        except:
            pass

        try:
            cadre.remove_widget(cadrejournal)
        except:
            pass

        try:
            cadre.remove_widget(cadreexpert)
        except:
            pass

    
    def pageJournal(self,instance):

        labtitre.text="JOURNAL"

        try:
            cadre.remove_widget(cadrevente)
        except:
            pass
        try:
            cadre.add_widget(cadrejournal)
        except:
            pass

        try:
            cadre.remove_widget(cadreexpert)
        except:
            pass
    
    def pageExpert(self,instance):

        labtitre.text="MODE EXPERT"

        try:
            cadre.remove_widget(cadrevente)
        except:
            pass
        try:
            cadre.remove_widget(cadrejournal)
        except:
            pass

        try:
            cadre.add_widget(cadreexpert)
        except:
            pass
   

Pharma().run()