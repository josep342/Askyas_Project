import kivy
from kivy.app import App
from kivymd.app import MDApp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.properties import NumericProperty
from kivy.metrics import dp
from kivy.uix.textinput import TextInput
from kivy.config import Config
from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.uix.relativelayout import RelativeLayout
from kivy.graphics import Color,Rectangle
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivymd.uix.datatables import MDDataTable
from kivymd.uix.floatlayout import MDFloatLayout 
from kivy.lang import Builder
from kivy.graphics.vertex_instructions import RoundedRectangle
from kivy.metrics import *
from kivy.graphics import *
from kivy.uix.image import Image
from kivy.clock import Clock

from datetime import datetime
import requests
import math
import geocoder
import folium

from kivymd.uix.textfield import MDTextField
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.boxlayout import MDBoxLayout
import random
import mysql.connector
import pandas as pd
from reportlab.lib.pagesizes import portrait
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
import aspose.pdf as pdf

from kivy.uix.scrollview import ScrollView
from kivymd.uix.scrollview import MDScrollView

KV="""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
#:import ZBarSymbol pyzbar.pyzbar.ZBarSymbol

ZBarCam
    id:zbarcam
    pos_hint:{'center_x':0.5,'center_y':0.65}
    size_hint:.8,.35
    code_types:ZBarSymbol.QRCODE.value,ZBarSymbol.EAN13.value
    on_symbols:app.on_symbols(*args)

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,15,15]
"""

class Pharma(MDApp):
    def build(self):


        global cadre,cadepageconnexion,cadrevente,cadre3tbs,cadsetting,cadrejournal,cadreexpert
        global tpwd,tid,bvente,bjournal,bexpert,labtitre,ic1,ic2,bsetting,tabvente1,bvente1,t1,t2,t3,t4,btsignaler,btaide,btproformauser,btprisecharge
        global btimprimeproforma,bttaux,labtaux,cadtrech,combaffrech,tquantite
        global etaa,ettta,etatjournal
        global tabjournal,cadsuitchdate,cadsuitid,cadsuitnom,cadsuituniversel,cadsuitparticuler,trilabb,labcheckk4,labcheckk5,labdats,combnomclient,tjourclientnom,combids,tjourids,combdats,trilab,labcheck1,labcheck2,labcheck3

        global choixconn,tabventejournal,labtot2, btsuitegenAI,bexpert,bjournal,bvente

        global lbmsg,check1mod,check2mod,listidcommute,df
        global netpayer,msg,num,verifsel,modcommutation,labcompteur,affresultat,scrol,btsuitegenAI

        global trecherche,combaffrech,con,tquantite,t1,t2,t3,t4,labnetpayer,baffplus,retetat,texp1

        global listeqt,listcomplement,datemodel,tidconn,triercheck1,triercheck2,triercheck3,triercheckk4,triercheckk5


        global combpresc1,combpresc2,combpresc3
        global tablprise,cadresuitchmorr,labupdatpris,btsavprise,tprisee1,tprisee2,tprisee3,tprise1,tprise2,tprise3
        
        global suitmodrap,labmodrap,cadresuitcmoderap,cadprisecharge
        global tablprescription,trechpresc1,trechpresc2,trechpresc3,cadreprischarge
        global btbasss2,btbasss1

        global cadconnBd,tadr,btserver,btchangeqr,btcamera1,btcamera2,camera

        global msggsetting,etatconn

        etatconn=0

        listcomplement=[]

        listeqt=[]

        netpayer=0
        num=1
        verifsel=0
        retetat=0

        modcommutation=0

        choixconn=1

        ettta=0
        etatjournal=0
        etaa=0

        datemodel=datetime.now()

        cadre=Builder.load_string('''
                                                
FloatLayout:
    size_hint:1,1
    pos_hint:{'center_x':.5,'center_y':.5}
                                            
    canvas.before:
        Color:
            rgb:222/255,228/255,228/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[20,1,20,1]
            
''')
        # les boutons centrales

        bvente=Builder.load_string('''
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':.15,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]    
                                   
    on_release:app.pageVente(self)
        
    ''')
        
        bjournal=Builder.load_string('''
MDIconButton:
    icon:'view-dashboard-edit'
    pos_hint:{'center_x':.5,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]    
                                     
    on_release:app.pageJournal(self)
                                     
    ''')
        
        bexpert=Builder.load_string('''
MDIconButton:
    icon:'doctor'
    pos_hint:{'x':.75,'y':.0}   
    size_hint:.1,.1
    theme_text_color:'Custom' 
    text_color:[0,0,1,1]   

    on_release:app.pageExpert(self) 
        
    ''')
        
        ic1=Builder.load_string('''
MDIcon:
    icon:'account-group-outline'
    pos_hint:{'center_x':.23,'y':.94}
    size_hint:.1,.1
    theme_text_color:'Custom'
    text_color:'red'

        
        ''')

        ic2=Builder.load_string('''
MDIcon:
    icon:'account-group-outline'
    pos_hint:{'center_x':.28,'y':.95}
    size_hint:.1,.1
    theme_text_color:'Custom'
    text_color:'blue'

        
        ''')

        # les outils de la page de connexionBD

        cadconnBd=Builder.load_string('''
FloatLayout:
    size_hint:.9,.9
    pos_hint:{'center_x':.5,'center_y':.5}
                                              
    canvas.before:
        Color:
            rgb:0,0,0
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
        
''')

        camera=Builder.load_string(KV)

        btcamera1=Builder.load_string('''
Button:
    text:'Selfie'
    size_hint:.5,.05
    pos_hint:{'center_x':.3,'center_y':.37}
    color:'white'
    background_color:[0,0,0,0]
    bold:True
''')
        
        btcamera2=Builder.load_string('''
Button:
    text:'Arriere'
    size_hint:.5,.05
    pos_hint:{'center_x':.6,'center_y':.37}
    color:'white'
    background_color:[0,0,0,0]
    bold:True
''')
        
        tadr=TextInput(text="Adresse",pos_hint={'center_x':.5,'center_y':.6},size_hint=(.8,.08))
        tadr.bind(focus=self.cleatextserver)

        btserver=Builder.load_string('''
Button:
    text:'Connecter'
    size_hint:.5,.05
    pos_hint:{'center_x':.5,'center_y':.25}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
            ''')

        btserver.bind(on_release=self.testerserver)

        btchangeqr=Builder.load_string('''
Button:
    text:'Qr-Code'
    size_hint:.35,.05
    pos_hint:{'x':.55,'y':.93}
    color:'white'
    background_color:[0,0,0,0]
    bold:True


    
    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[12]
        
        ''')

        btchangeqr.bind(on_release=self.commuterqrcode)

        try:
            cadconnBd.add_widget(btchangeqr)
            cadconnBd.add_widget(btserver)
            cadconnBd.add_widget(tadr)
        except:
            pass


        # les outils de la page de connexion  

        
        cadepageconnexion=Builder.load_string('''
FloatLayout:
    size_hint:.9,.9
    pos_hint:{'center_x':.5,'center_y':.5}
                                              
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10]
        
''')
        
        progressbar=Builder.load_string('''
MDProgressBar:
    value: 0  
    max: 100  
    size_hint:1,.01
    pos_hint:{'x':0,'y':0}  
        
''')
        
        plabtit=Label(text="Connexion", font_size='25sp', pos_hint={'center_x':.5,'y':.9}, size_hint=(.7,.05), bold=True,color='black')

        imgconn=Image(source="admin.png", pos_hint={'center_x':0.5,'y':.74},size_hint=(.3,.15))
    
        tidconn=MDTextField(hint_text='Identifiant',line_color_normal='black',icon_right='account',font_size='15sp', pos_hint={'center_x':.5,'y':.6}, size_hint=(.8,.1), text_color_normal='black' )

        tpwd=MDTextField(hint_text='Pwd',password=True,font_size='20sp',line_color_normal='black',icon_right='account-eye', pos_hint={'center_x':.5,'y':.43}, size_hint=(.8,.1),text_color_normal='black' )
        

        pbtcon=Builder.load_string('''
Button:
    text:"Se connecter"
    pos_hint:{'x':0.4,'y':.25}
    size_hint:.5,.05
    font_size:'14sp'
    color:'white'
    background_color:[0,0,0,0]
    bold:True
                                       
    canvas.before:
                                   
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
''')
        pbtcon.bind(on_release=self.camparersecurite)

        pbpwdoublie=Builder.load_string('''
Button:
    text:"Pwd Oublié ?"
    pos_hint:{'x':.65,'y':.1}
    size_hint:.2,.1
    font_size:'13sp'
    color:'black'
    background_color:[0,0,0,0]
    bold:True
                                   
    
        
''')
        #pbpwdoublie.bind(on_release=self.openrecupeCompte)

        try:
        
            cadepageconnexion.add_widget(pbtcon)
            cadepageconnexion.add_widget(pbpwdoublie)
            cadepageconnexion.add_widget(imgconn)
            cadepageconnexion.add_widget(tidconn)
            cadepageconnexion.add_widget(tpwd)
            
            cadepageconnexion.add_widget(plabtit)

            cadepageconnexion.add_widget(progressbar)

        except:
            pass
        
        # les outils de la page de vente  

        labtitre=Label(text="VENTE", pos_hint={'center_x':.5,'y':.92},size_hint=(.4,.1),color='black',bold=True, font_size='17')

        cadrevente=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''')
        bsetting=Builder.load_string('''
MDIconButton:
    icon:'book-cog'
    pos_hint:{'x':.9,'y':.9}   
    size_hint:.1,.1
    

    on_release:app.pagesetting(self)
        
    ''')
        
        trecherche=MDTextField(hint_text="Recherche",pos_hint={'center_x':.5,'center_y':.5},size_hint=(.9,.9),text_color_normal='black')

        
        cadtrech=Builder.load_string('''
FloatLayout:
    size_hint:.4,.06
    pos_hint:{'x':.15,'y':.9}
                                     
    canvas.before:
        Color:
            rgb:222/255,228/255,228/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
                                     
            radius:[5]
                                     
''')
        try:
            cadtrech.add_widget(trecherche)
        except:
            pass
        
        combaffrech=Builder.load_string('''

Spinner:
    text:'Choisir'
    color:'white'
    background_color:[0,0,0,0]
    background_normal:""
    pos_hint:{'x':0.58, 'y':0.9}
    bold:True                            
    size_hint:0.3,0.05 
    font_size:'11sp'                              

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[13]      
''')
        combaffrech.bind(on_release=self.rechlikeproduit)
        combaffrech.bind(text=self.rechchargeproduit)

        t1=MDTextField(hint_text="Nom",pos_hint={'x':.025,'y':.73},size_hint=(.45,.1),icon_right='text',text_color_normal='black',line_color_normal="black")
        t2=MDTextField(hint_text="PU",pos_hint={'x':.5,'y':.73},size_hint=(.45,.1),icon_right='currency-eur',text_color_normal='black',line_color_normal="black")
        
        t3=MDTextField(hint_text="Expiration",pos_hint={'x':.025,'y':.58},size_hint=(.45,.1),icon_right='calendar-clock',text_color_normal='black',line_color_normal="black")
        t4=MDTextField(hint_text="Stock",pos_hint={'x':.5,'y':.58},size_hint=(.45,.1),icon_right='car-speed-limiter',text_color_normal='black',line_color_normal="black")

        tquantite=MDTextField(hint_text="QTE",pos_hint={'x':.5,'y':.47},size_hint=(.3,.1),icon_right='text',text_color_normal='black',line_color_normal="black")


        labtaux=Label(text="",pos_hint={'x':0.19, 'y':.52},bold=True,size_hint=(.3,.1),color="black",font_size='9sp')
        
        bttaux=Builder.load_string('''
            
MDIconButton:
    icon:'currency-eur'
    pos_hint:{'x':0.2, 'y':.49}
    size_hint:0.1,0.12

    on_release:app.actualisetauxnew(self)
                                      
        ''')

        btimprimeproforma=Builder.load_string('''
            
MDIconButton:
    icon:'printer-eye'
    pos_hint:{'x':0.025, 'y':.49}
    size_hint:0.1,0.12

    on_release:app.imprissionpreforma(self)
                                      
        ''')


        bvente1=Builder.load_string('''
            
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':0.9, 'y':0.47}
    size_hint:0.1,0.12

    on_release:app.ajoutdanscoupon(self)
                                      
        ''')
        
        tabvente1=MDDataTable(column_data=[("N°",dp(20)),
                                           ("ID produit",dp(30)),
                                           ("Nom",dp(30)),
                                           ("P.U",dp(30)),
                                           ("Quantité",dp(30)),
                                           ("Prix total",dp(30))],
                                           rows_num=500,use_pagination=True, row_data=[],size_hint=(0.98,0.4),pos_hint={'center_x':.5,'y':0.06},check=True)
        tabvente1.bind(on_check_press=self.retirecoupon)

        baffplus=Builder.load_string('''
            
MDIconButton:
    icon:'chevron-right-box'
    pos_hint:{'x':0.94, 'y':0}
    size_hint:0.06,0.05
                                     
    theme_text_color:'Custom' 

    on_release:app.open3Buttons(self)
                                      
        ''')

        btvueclaire=Builder.load_string('''
            
MDIconButton:
    icon:'eye'
    pos_hint:{'x':0.85, 'y':0}
    size_hint:0.06,0.05

    on_release:app.vueclairecoupon(self)
                                      
        ''')

        labnetpayer=Builder.load_string('''
Button:
    text:"."
    pos_hint:{'x':0.5, 'y':0}
    size_hint:.3,.05
    background_color:[0,0,0,0]
    color:'black'
    bold:True

    
        
        ''')
        labnetpayer.bind(on_release=self.verificoupon)

        # les 3 bouttons de commande  

        bvalider=Builder.load_string('''
Button:
    text:'Valider'
    size_hint:.9,.15
    pos_hint:{'center_x':.5,'y':.7}
    background_color:[0,0,0,0]
    color:'white'
    bod:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        bvalider.bind(on_release=self.validecoupon)

        bsupprimer=Builder.load_string('''
Button:
    text:'Supprimer'
    size_hint:.9,.15
    pos_hint:{'center_x':.5,'center_y':.5}
    background_color:[0,0,0,0]
    color:'white'
    bod:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')

        bsupprimer.bind(on_release=self.suprimercoupon)

        bretire=Builder.load_string('''
Button:
    text:'Retire'
    size_hint:.9,.15
    pos_hint:{'center_x':.5,'y':.15}
    background_color:[0,0,0,0]
    color:'white'
    bod:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        bretire.bind(on_release=self.retirecouponsignal)
        
        cadre3tbs=Builder.load_string('''
FloatLayout:
    size_hint:.4,.4
    pos_hint:{'x':0.6, 'y':.06}
                                      
    canvas.before:
        Color:
            rgba:0,0,1,1
                                      #202/255,202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
''')
        

        # les outils de la page de setting

        bcommutation=Builder.load_string('''
Button:
    text:'Commutation'
    size_hint:.4,.15
    pos_hint:{'x':.05,'y':.8}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[12]
''')
        
        bcommutation.bind(on_release=self.commutation)
        
        btcorrection=Builder.load_string('''
Button:
    text:'Correction'
    size_hint:.4,.15
    pos_hint:{'x':.55,'y':.8}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[12]
''')
        
        btcorrection.bind(on_release=self.corrigerreur)

        cadsetting=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0, 'y':.0}
                                      
    canvas.before:
        Color:
                                         
            rgba:202/255,202/255,202/255,202/255
                                         
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
''')
        
        btprisecharge=Builder.load_string('''
            
MDIconButton:
    icon:'walk'
    pos_hint:{'x':0.1, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.openprisecharge(self)
                                      
        ''')
        
        btproformauser=Builder.load_string('''
            
MDIconButton:
    icon:'notebook'
    pos_hint:{'x':0.3, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.proforma(self)
                                      
        ''')

        btaide=Builder.load_string('''
            
MDIconButton:
    icon:'headset'
    pos_hint:{'x':0.6, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.contactprogrammeur(self)
                                      
        ''')

        btsignaler=Builder.load_string('''
            
MDIconButton:
    icon:'chat-alert'
    pos_hint:{'x':0.8, 'center_y':.5}
    size_hint:0.06,0.05

    on_release:app.signeprobleme(self)
                                      
        ''')

        bdeconnexion=Builder.load_string('''
Button:
    text:'Deconnexion'
    size_hint:.4,.15
    pos_hint:{'x':.05,'y':.05}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        bdeconnexion.bind(on_release=self.deconnexion)
        
        bclosesetting=Builder.load_string('''
Button:
    text:'Close'
    size_hint:.3,.15
    pos_hint:{'x':.65,'y':.05}
    background_color:[0,0,0,0]
    color:'white'
    bold:True
    font_size:'12sp'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        
        bclosesetting.bind(on_release=lambda x:msggsetting.dismiss())

        try:
            cadsetting.add_widget(btcorrection)
            cadsetting.add_widget(bcommutation) 
            cadsetting.add_widget(bclosesetting)
            cadsetting.add_widget(bdeconnexion)
        except:
            pass

        try:
            cadsetting.add_widget(btsignaler)
            cadsetting.add_widget(btaide)
            cadsetting.add_widget(btproformauser)
            cadsetting.add_widget(btprisecharge)
        except:
            pass
        
        try:
            cadre3tbs.add_widget(bvalider)
            cadre3tbs.add_widget(bretire)
            cadre3tbs.add_widget(bsupprimer)
        except:
            pass
        

        try:
            cadrevente.add_widget(bsetting)
        except:
            pass
        
        try:
            cadrevente.add_widget(tabvente1)
        except:
            pass
        try:
            cadrevente.add_widget(bvente1)
        except:
            pass 

        try:
            cadrevente.add_widget(tquantite)
        except:
            pass 

        try:
            cadrevente.add_widget(combaffrech)
            cadrevente.add_widget(cadtrech)
        except:
            pass 
        try:
            cadrevente.add_widget(t1)
            cadrevente.add_widget(t2)
            cadrevente.add_widget(t3)
            cadrevente.add_widget(t4)
        except:
            pass
        try:
            cadrevente.add_widget(labnetpayer)
        except:
            pass
        try:
            cadrevente.add_widget(baffplus) 
            cadrevente.add_widget(btvueclaire) 
        except:
            pass

        try:
            cadrevente.add_widget(btimprimeproforma)
        except:
            pass
        
        try:
            cadrevente.add_widget(labtaux)
            cadrevente.add_widget(bttaux)
        except:
            pass


        cadrejournal=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''') 
        
        tabventejournal=MDDataTable(column_data=[("ID PRODUIT",dp(40)),
                                            ("NOM",dp(40)),("PU",dp(20)),
                                            ("QUANTITE",dp(25)),
                                            ("PRIX TOTAL",dp(25)),
                                            ("NOM CLIENT",dp(30)),
                                            ("DATE",dp(20)),
                                            ("DATE TIME",dp(30)),
                                            ("ID TRAVAILLEUR",dp(30))],
                                            row_data=[],size_hint=(0.98,0.6),
                                            pos_hint={'center_x':0.5,'y':0.4},
                                            check=True,rows_num=2000,
                                            use_pagination=True)
        
        trilab=Label(text='[b]Trier par[/b]',font_size='12sp',color='black',pos_hint={'x':0.05,'y':0.35},size_hint=(0.082,0.05),markup=True)
        
        labcheck1=Label(text='Date',font_size='12sp',color='black',pos_hint={'x':0.09,'y':0.29},size_hint=(0.037,0.05))
        
        triercheck1=Builder.load_string('''  

MDCheckbox:
    pos_hint:{'x':.3,'y':.27}
    size_hint:.1,.1
    color_active:'black'
    color_inactive:'blue'
    active:True
    on_active:app.controleurjour1(self)
        
        ''')

        suitchdate=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    #on_active:app.activer(self)
        
        ''')
       


        #CheckBox(active=True,pos_hint={'x':0.25,'y':0.35},size_hint=(0.06,0.06)) 
        #triercheck1.bind(active=self.fchecktrie1)

        labcheck2=Label(text='ID Produit',font_size='12sp',color='black',pos_hint={'x':0.08,'y':0.23},size_hint=(0.09,0.05))
        
        
        triercheck2=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':.3,'y':.21}
    size_hint:.1,.1
    color_active:'black'
    color_inactive:'blue'
    on_active:app.controleurjour2(self)
        
        ''')

        suitid=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    #on_active:app.activer(self)
    
        ''')

        
        
        #triercheck2=CheckBox(pos_hint={'x':0.25,'y':0.3},size_hint=(0.06,0.06))
        #triercheck2.bind(active=self.fchecktrie2)

        labcheck3=Label(text='Nom Client',font_size='12sp',color='black',pos_hint={'x':0.08,'y':0.17},size_hint=(0.1,0.05))
        
        #triercheck3=CheckBox(pos_hint={'x':0.25,'y':0.25},size_hint=(0.06,0.06))
        #triercheck3.bind(active=self.fchecktrie3)

        triercheck3=Builder.load_string('''
MDCheckbox:
    pos_hint:{'x':0.3,'y':0.15}
    size_hint:.1,.1
    color_active:'black'
    color_inactive:'blue'
    on_active:app.controleurjour3(self)
        
        ''')

        suitnom=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    #on_active:app.activer(self)
    
        ''')

        

        trilabb=Label(text='[b]Mappage[/b]',font_size='12sp',color='black',pos_hint={'x':0.08,'y':0.12},size_hint=(0.06,0.05),markup=True)
        
        labcheckk4=Label(text='Universel',font_size='12sp',color='black',pos_hint={'x':0.08,'y':.06},size_hint=(0.09,0.05))
        
        #triercheckk4=CheckBox(pos_hint={'x':0.25,'y':0.15},size_hint=(0.06,0.06)) 
        #triercheckk4.bind(active=self.fchecktrie4)
        
        triercheckk4=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':.3,'y':.05}
    size_hint:.1,.05
    color_active:'black'
    color_inactive:'blue'
    on_active:app.controleurjour4(self)
        
        ''')

        labcheckk5=Label(text='Particulier',font_size='12sp',color='black',pos_hint={'x':0.08,'y':.01},size_hint=(0.1,0.05))
        

        triercheckk5=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':.3,'y':0}
    size_hint:.1,.05
    color_active:'black'
    color_inactive:'blue'
    active:True
    on_active:app.controleurjour5(self)
        
        ''')
        #triercheckk5=CheckBox(active=True,pos_hint={'x':0.25,'y':0.1},size_hint=(0.06,0.06))
        #triercheckk5.bind(active=self.fchecktrie5)

        
        labtot1=Label(text="[b]Total[/b]",color='black',pos_hint={'x':0.410, 'y':0.02},font_size='20sp',markup=True,size_hint=(0.1,0.06))
        labtot2=Label(text="[b][/b]",color='black',pos_hint={'x':0.485, 'y':0.02},font_size='20sp',markup=True,size_hint=(0.1,0.06))
        
        labdats=Label(text="Date",color='black',pos_hint={'x':0.5, 'y':0.31},font_size='13sp',size_hint=(0.05,0.06),bold=True)
        
        combdats=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.71, 'y':0.3}
    size_hint:(0.27,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        combdats.bind(on_release=self.rechdatejournal)
        combdats.bind(text=self.affdatejournal)  

        
        tjourids = MDTextField(hint_text="ID",line_color_normal='black', font_size='12sp', pos_hint={'x':0.48, 'y':0.19},size_hint=(0.2,0.1))
        tjourids.bind(text=self.controleurtid)
        
        combids=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.71, 'y':0.22}
    size_hint:(0.27,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')
        
        combids.bind(on_release=self.rechidjournal)
        combids.bind(text=self.affidprodjournal)

        tjourclientnom = MDTextField(hint_text="Client",line_color_normal='black', font_size='12sp', pos_hint={'x':0.48, 'y':0.12},size_hint=(0.2,0.1))
        tjourclientnom.bind(text=self.controleurtClient)
        combnomclient=Builder.load_string('''
Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.71, 'y':0.15}
    size_hint:(0.27,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        combnomclient.bind(on_release=self.rechnomclientjournal) 
        combnomclient.bind(text=self.affnomclientjournal)

        labtot2=Label(text=".",pos_hint={'x':.5,'y':0},size_hint=(.3,.05),color='black',bold=True,font_size='12sp')

        btimprjournal=Builder.load_string('''
            
MDIconButton:
    icon:'printer'
    pos_hint:{'x':0.92, 'y':0}
    size_hint:0.06,0.05

    on_release:app.open3Buttons(self)
                                      
        ''')

        bvecliarejournal=Builder.load_string('''
            
MDIconButton:
    icon:'eye'
    pos_hint:{'x':0.8, 'y':0}
    size_hint:0.06,0.05

    on_release:app.vueclairejournal(self)
                                      
        ''')
        
        try:
            cadrejournal.add_widget(tabventejournal)
        except:
            pass
        try:
            cadrejournal.add_widget(labtot2)
        except:
            pass

        try:
            cadrejournal.add_widget(combnomclient)
            cadrejournal.add_widget(tjourclientnom)
            cadrejournal.add_widget(combids)
            cadrejournal.add_widget(tjourids)
            cadrejournal.add_widget(combdats)

            cadrejournal.add_widget(trilab)
            cadrejournal.add_widget(labcheck1)
            cadrejournal.add_widget(labcheck2)
            cadrejournal.add_widget(labcheck3)
            cadrejournal.add_widget(trilabb)
            cadrejournal.add_widget(labcheckk4)
            cadrejournal.add_widget(labcheckk5) 
            cadrejournal.add_widget(labdats)
            
        except:
            pass
        try:
            cadrejournal.add_widget(triercheck1) 
            cadrejournal.add_widget(triercheck2)
            cadrejournal.add_widget(triercheck3) 
            cadrejournal.add_widget(triercheckk4)
            cadrejournal.add_widget(triercheckk5)
        except:
            pass
    
        try:
            cadrejournal.add_widget(btimprjournal)
            cadrejournal.add_widget(bvecliarejournal)
        except:
            pass



        cadreexpert=Builder.load_string('''
                                                
FloatLayout:
    size_hint:.98,.85
    pos_hint:{'center_x':.5,'y':.09}
                                            
    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
''') 
        
        texp1=TextInput(text="",pos_hint={'center_x': 0.5,'y': 0.6},size_hint=(.98,.35))

        btgenerer=Builder.load_string('''

Button:
    text:"Generer"
    font_size:"13sp"
    pos_hint:{'x':0.63, 'y':0.53}
    size_hint:(0.35,0.06)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        btgenerer.bind(on_release=self.generesultat)

        bactualiser=Builder.load_string('''

Button:
    text:"Actualiser"
    font_size:"13sp"
    pos_hint:{'x':0.63, 'y':0.45}
    size_hint:(0.35,0.06)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        bactualiser.bind(on_press=self.actualisergeneration)

        cad=MDDataTable(column_data=[],row_data=[],size_hint=(0.4,0.07),
                                            pos_hint={'center_x':0.5,'center_y':0.4})
        labexp=Label(text="OpenAi",color='black',bold=True,font_size='15sp')


        labcompteur=Label(text="[b][/b]",font_size='18sp', pos_hint={'x':0.912,'y':0.715},size_hint=(0.09,0.04),color='black',markup=True)
        
        affresultat=Label(text="[b]....[/b]",text_size=(None,None),font_size='11sp', halign='left', pos_hint={'center_x':0.5,'center_y':0.5},size_hint=(0.99,0.9),color='black',markup=True)
        scrol=ScrollView(bar_color='black',bar_width=10,pos_hint={'x':.02,'y':0.05},size_hint=(0.95,0.3))


        btsuitegenAI=Builder.load_string('''
Button:
    text:"[b]Cloturer[/b]"
    font_size:'12sp'
    pos_hint:{'x':0.75,'y':.05}
    size_hint:0.2,0.04
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[7]

''')
        btsuitegenAI.bind(on_press=self.generesultatsuite)

        try:
            cadreexpert.add_widget(labcompteur)
        except:
            pass
        try:
            scrol.add_widget(affresultat)
        except:
            pass
        try:
            cadreexpert.add_widget(scrol)
        except:
            pass

        try:
            cad.add_widget(labexp)
        except:
            pass
        

        try:
            cadreexpert.add_widget(texp1) 
            cadreexpert.add_widget(btgenerer)
            cadreexpert.add_widget(bactualiser)
            #cadreexpert.add_widget(btsuitegenAI)
        except:
            pass
        try:
            cadreexpert.add_widget(cad)
        except:
            pass


        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select taux from tauxchange where num=1"
            cursor.execute(query)
            results=cursor.fetchone()
            con.close()

            if results:
                labtaux.text=str(results[0])
        except:
            pass



        
        cadreprischarge=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}
       
       ''')

        tprise1=Builder.load_string('''
MDTextField:
    
    hint_text:'E-Mail'
    pos_hint:{'x':.03,'y': .88}
    size_hint:.4,.15
    text_color:255/255,128/255,0/255
    icon_right:'gmail'
    font_size:'11sp'
    line_color_normal:'black'
    theme_color_normal:'Custom'
       
       ''')

        tprise1.bind(on_text_validate=self.deplfocusprise1)

        tprise2=Builder.load_string('''
MDTextField:
   
    hint_text:'Nom'
    pos_hint:{'x':.5,'y': .88}
    size_hint:.35,.15
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'11sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')
    
        tprise2.bind(on_text_validate=self.deplfocusprise2)

        tprise3=Builder.load_string('''
MDTextField:
    
    hint_text:'¨Prenom'
    pos_hint:{'x':.03,'y': .78}
    size_hint:.4,.15
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'11sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprise3.bind(on_text_validate=self.deplfocusprise3)

        tprisee1=Builder.load_string('''
MDTextField:
    
    hint_text:'Tel'
    pos_hint:{'x':.5,'y': .78}
    size_hint:.4,.15
    text_color:255/255,128/255,0/255
    icon_right:'phone'
    font_size:'11sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprisee1.bind(on_text_validate=self.deplfocusprise4)

        tprisee2=Builder.load_string('''
MDTextField:
    
    hint_text:'Adresse'
    pos_hint:{'x':.03,'y': .68}
    size_hint:.35,.15
    text_color:255/255,128/255,0/255
    icon_right:'home'
    font_size:'11sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprisee2.bind(on_text_validate=self.deplfocusprise5)

        tprisee3=Builder.load_string('''
MDTextField:
    
    hint_text:'Sexe'
    pos_hint:{'x':.43,'y': .68}
    size_hint:.2,.15
    text_color:255/255,128/255,0/255
    icon_right:'face-man'
    font_size:'11sp'
    line_color:'black'
    text_color_normal:'black'
       
       ''')

        btsavprise=Builder.load_string('''
Button:
    
    background_color:[0,0,0,0]
    text:"[b]Enregistrer[/b]"
    markup:True
    size_hint:(0.37,0.05)
    pos_hint:{'x':0.62,'y':0.7}
    color:"white"
    font_size:'12sp'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]   
       ''')


        btsavprise.bind(on_release=self.savepreisecharge)

        labupdatpris=Label(text="Update",pos_hint={'x':.6,'y':.62},size_hint=(.1,.05),bold=True,color="black")
            
        cadresuitchmorr=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.8,'y':.6}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitsaveprise=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.changebtnprise(self)
''')


            

        tablprise=MDDataTable(column_data=[
                ("E-mail",dp(40)),
                ("Nom",dp(40)),
                ("Prenom",dp(40)),
                ("Sexe",dp(10)),
                ("Telephone",dp(40)),
                ("Adresse ",dp(50)),
                ("Date ",dp(30)),
                ("Travailleur ",dp(30))
                ],size_hint=(0.9,0.5),pos_hint={'center_x':0.5,'y':0.1},check=True,rows_num=20,use_pagination=True)
        tablprise.bind(on_check_press=self.affinfoprise)

        cadprisebase=Builder.load_string('''
FloatLayout:
    size_hint:.98,.08
    pos_hint: {'center_x':.5,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[40,40,1,1]
                
        ''')

        # les outils de la page prescription

        labmodrap=Label(text="Mode Rapide",pos_hint={'x':.45,'y':.72},size_hint=(.1,.05),bold=True,color="black")
            
        cadresuitcmoderap=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.8,'y':.7}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitmodrap=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    #on_active:app.changebtnprise(self)
''')
        try:
            cadresuitcmoderap.add_widget(suitmodrap)
        except:
            pass

        trechpresc1=Builder.load_string('''
MDTextField:
    
    hint_text:'ID'
    pos_hint:{'x':.1,'y': .86}
    size_hint:.35,.15
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'12sp'
    line_color_normal:'black'
    theme_color_normal:'Custom'
       
       ''')
       
       

        combpresc1=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.58, 'y':0.88}
    size_hint:(0.4,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')

        combpresc1.bind(on_release=self.rechidpresc) 
        combpresc1.bind(text=self.affrecid)

        trechpresc2=Builder.load_string('''
Label:
   
    text:'Date '
    pos_hint:{'x':.03,'y': .79}
    size_hint:.1,.1
    color:'black'
    bold:True

       
''')

        combpresc2=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.15, 'y':0.82}
    size_hint:(0.3,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')

        combpresc2.bind(on_release=self.rechdatepresc)
        combpresc2.bind(text=self.affrecdate)

        trechpresc3=Builder.load_string('''
Label:
    
    text:'Fac'
    pos_hint:{'x':.45,'y': .79}
    size_hint:.1,.1
    color:'black'
    bold:True
    
       
       ''')

        combpresc3=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.58, 'y':0.81}
    size_hint:(0.4,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')

        combpresc3.bind(on_release=self.rechfacturepresc)
        combpresc3.bind(text=self.affrecfacture)

        
        tablprescription=MDDataTable(column_data=[
                ("Identifiant",dp(40)),
                ("Docteur",dp(40)),
                ("Produit",dp(30)),
                ("PU",dp(30)),
                ("PT ",dp(30)),
                ("Date_Heure ",dp(40)),
                ("Date",dp(30)),
                ("Travailleur ",dp(30))
                ],size_hint=(0.9,0.6),pos_hint={'center_x':0.5,'y':0.1},check=True,rows_num=20,use_pagination=True)
        tablprescription.bind(on_check_press=self.affinfoprise)

        btbasss1=Builder.load_string('''
Button:
    text:"Inscription"
    font_size:'15sp'
    color:'black'
    background_color:[0,0,0,0]
    size_hint:.5,.8
    pos_hint:{'x':.02,'center_y':.5}
    bold:True

''')
        btbasss1.bind(on_release=self.inscriptionPage)

        btbasss2=Builder.load_string('''
Button:
    text:"Prescription"
    font_size:'15sp'
    color:'black'
    background_color:[0,0,0,0]
    size_hint:.5,.8
    pos_hint:{'x':.52,'center_y':.5}
    bold:True
                                     
''')
        btbasss2.bind(on_release=self.PrescriptionPage)

        cadprisebase.add_widget(btbasss1)
        cadprisebase.add_widget(btbasss2)

        try:
            cadresuitchmorr.add_widget(suitsaveprise)
        except:
            pass

        try:
            cadreprischarge.add_widget(tprise3)
            cadreprischarge.add_widget(tprise2)
            cadreprischarge.add_widget(tprise1)

            cadreprischarge.add_widget(tprisee3)
            cadreprischarge.add_widget(tprisee2)
            cadreprischarge.add_widget(tprisee1)

            cadreprischarge.add_widget(btsavprise) 
            cadreprischarge.add_widget(labupdatpris)
            cadreprischarge.add_widget(cadresuitchmorr)

            cadreprischarge.add_widget(tablprise) 

        except:
            pass
        try:
            cadreprischarge.add_widget(cadprisebase)
        except:
            pass

        try:
            #cadre.add_widget(cadepageconnexion)
            cadre.add_widget(cadconnBd)
        except:
            pass 


        return cadre
    

    def actualisetauxnew(self,instance):

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select taux from tauxchange where num=1"
            cursor.execute(query)
            results=cursor.fetchone()
           
            con.close()

            if results:
                labtaux.text=str(results[0])
        except:
            pass

    def vueclairejournal(self,instance):
        global etatjournal

        if etatjournal==0:

            tabventejournal.size_hint=(0.98,0.9)
            tabventejournal.pos_hint={'center_x':0.5,'y':0.1}

            try:
                cadrejournal.remove_widget(combnomclient)
                cadrejournal.remove_widget(tjourclientnom)
                cadrejournal.remove_widget(combids)
                cadrejournal.remove_widget(tjourids)
                cadrejournal.remove_widget(combdats)

                cadrejournal.remove_widget(trilab)
                cadrejournal.remove_widget(labcheck1)
                cadrejournal.remove_widget(labcheck2)
                cadrejournal.remove_widget(labcheck3)
                cadrejournal.remove_widget(trilabb)
                cadrejournal.remove_widget(labcheckk4)
                cadrejournal.remove_widget(labcheckk5) 
                cadrejournal.remove_widget(labdats)
                
            except:
                pass

        
            try:
                cadrejournal.remove_widget(triercheck1) 
                cadrejournal.remove_widget(triercheck2)
                cadrejournal.remove_widget(triercheck3) 
                cadrejournal.remove_widget(triercheckk4)
                cadrejournal.remove_widget(triercheckk5)
            except:
                pass
        

            etatjournal=1
        else:

            try:
                cadrejournal.add_widget(combnomclient)
                cadrejournal.add_widget(tjourclientnom)
                cadrejournal.add_widget(combids)
                cadrejournal.add_widget(tjourids)
                cadrejournal.add_widget(combdats)

                cadrejournal.add_widget(trilab)
                cadrejournal.add_widget(labcheck1)
                cadrejournal.add_widget(labcheck2)
                cadrejournal.add_widget(labcheck3)
                cadrejournal.add_widget(trilabb)
                cadrejournal.add_widget(labcheckk4)
                cadrejournal.add_widget(labcheckk5) 
                cadrejournal.add_widget(labdats)
                
            except:
                pass
            try:
                cadrejournal.add_widget(triercheck1) 
                cadrejournal.add_widget(triercheck2)
                cadrejournal.add_widget(triercheck3) 
                cadrejournal.add_widget(triercheckk4)
                cadrejournal.add_widget(triercheckk5)
            except:
                pass
        
           
            tabventejournal.size_hint=(0.98,0.6)
            tabventejournal.pos_hint={'center_x':0.5,'y':0.4}

            etatjournal=0

    def vueclairecoupon(self,instance):
        global ettta

        if ettta==0:
            tabvente1.size_hint=(.95,.8)

            try:
                cadrevente.remove_widget(bvente1)
            except:
                pass 

            try:
                cadrevente.remove_widget(tquantite)
            except:
                pass 

           
            try:
                cadrevente.remove_widget(t1)
                cadrevente.remove_widget(t2)
                cadrevente.remove_widget(t3)
                cadrevente.remove_widget(t4)
            except:
                pass

            try:
                cadrevente.remove_widget(btimprimeproforma)
            except:
                pass
            
            try:
                cadrevente.remove_widget(labtaux)
                cadrevente.remove_widget(bttaux)
            except:
                pass

            ettta=1
        else:
            tabvente1.size_hint=(.95,.4)

            try:
                cadrevente.add_widget(bvente1)
            except:
                pass 

            try:
                cadrevente.add_widget(tquantite)
            except:
                pass 

            
            try:
                cadrevente.add_widget(t1)
                cadrevente.add_widget(t2)
                cadrevente.add_widget(t3)
                cadrevente.add_widget(t4)
            except:
                pass

            try:
                cadrevente.add_widget(btimprimeproforma)
            except:
                pass
            
            try:
                cadrevente.add_widget(labtaux)
                cadrevente.add_widget(bttaux)
            except:
                pass

            ettta=0

    def controleurtClient(self,instance,value):
        if instance.text !="":
            instance.hint_text=""
        else:
            instance.hint_text="Client"

    def controleurtid(self,instance,value):
        if instance.text !="":
            instance.hint_text=""
        else:
            instance.hint_text="ID"


    def pagesetting(self,instance):
        global msggsetting,cadrexx

        try:
            cadrexx.remove_widget(cadsetting)
        except:
            pass


        cadrexx=FloatLayout()

        try:
            cadrexx.add_widget(cadsetting)
        except:
            pass

        

        msggsetting=Popup(title="SETTING",content=cadrexx, size_hint=(1,.5))
        msggsetting.open()
        

    def open3Buttons(self,instance):
        global etaa

        
        if etaa==0:

            try:
                cadrevente.add_widget(cadre3tbs)
            except:
                pass

            etaa=1

            instance.icon='chevron-left-box'
            
        else:
            try:
                cadrevente.remove_widget(cadre3tbs)
            except:
                pass
            
            etaa=0

            instance.icon='chevron-right-box'
    
    
    def pageVente(self,instance):  

        labtitre.text="VENTE"
        
        try:
            cadre.add_widget(cadrevente)
        except:
            pass

        try:
            cadre.remove_widget(cadrejournal)
        except:
            pass

        try:
            cadre.remove_widget(cadreexpert)
        except:
            pass

        try:
            cadreexpert.remove_widget(btsuitegenAI)
        except:
            pass

    
    def pageJournal(self,instance):

        labtitre.text="JOURNAL"

        try:
            cadre.remove_widget(cadrevente)
        except:
            pass
        try:
            cadre.add_widget(cadrejournal)
        except:
            pass

        try:
            cadre.remove_widget(cadreexpert)
        except:
            pass

        try:
            cadreexpert.remove_widget(btsuitegenAI)
        except:
            pass
    
    def pageExpert(self,instance):

        labtitre.text="MODE EXPERT"

        try:
            cadre.remove_widget(cadrevente)
        except:
            pass
        try:
            cadre.remove_widget(cadrejournal)
        except:
            pass

        try:
            cadre.add_widget(cadreexpert)
        except:
            pass


    
    def verificoupon(self,instance):

        tabs=[]
        tot=0
        tabs=tabvente1.row_data

        for lig in tabs:
            a,b,c,d,e,f=lig

            tot+=int(f)
        
        instance.text=str(tot)
        instance.color='blue'

        bvaverif=Builder.load_string('''
Button:
    text:'Terminé'
   
    background_color:[0,0,0,0]
    color:'black'
    bod:True
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')

        msgg=Popup(title="CORRECTEUR CALCUL",content=bvaverif,size_hint=(1,.4))
        msgg.open()

    
    def retirecoupon(self,instance_table,current_row):
        global retetat,num,netpayer,listeqt,quantiterestant,listcomplement

        listeqtfaux=[]
        i=0
        k=0
        j=0

        if retetat==1:
            try:
                for i in range(len(listeqt)-1):
                    listeqtfaux.append(listeqt[i])

                listeqt=[]
                listeqt=listeqtfaux

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            datatott=tabvente1.row_data
            
            try:
                if tabvente1.row_data:
                    
                    #for indice,k in enumerate(datatott):
                    #    j=indice

                    
                
                    selll=current_row[0]
                    selll=int(selll)

                    suprelement=tabvente1.row_data.pop(selll-1)

                    suprcomplt=listcomplement.pop(selll-1)

                    retetat=0

                    baffplus.text_color='black'

                    netpayer=netpayer-float(suprelement[5])

                    labnetpayer.text=str(math.ceil(netpayer))

                    try:

                        t3.text=suprcomplt[1]
                        t4.text=suprcomplt[2]

                        t1.text=suprelement[2]
                        t2.text=suprelement[3]
                        tquantite.text=suprelement[4]
                    except:
                        pass

                   
                    couponnew=[]

                    ik=1

                    for lign in datatott:
                        if ik <= len(datatott):
                    
                            new_tuple =(ik,) + lign[1:]

                            ik+=1

                        couponnew.append(new_tuple)

                        tabvente1.row_data=[]
                        tabvente1.row_data=couponnew
                    

                    ik=1
                    listcomplementnew=[]

                    for lign in listcomplement:
                        if ik <= len(listcomplement):
                    
                            new_tuple =(ik,) + lign[1:]

                            ik+=1

                        listcomplementnew.append(new_tuple)
                  
                    listcomplement=listcomplementnew

                    print(listcomplement)
                    
                        
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
    
    def ajoutdanscoupon(self,instance):
        global num,netpayer,quantiterestant,listeqt,matprod,listcomplement
        pt=0

        try:
            if int(t4.text)>= int(tquantite.text):
                try:
                    if int(tquantite.text)<=0:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='La quantité doit etre supérieure ou egale à 1',color='white',background_color='blue'),size_hint=(None, None), size=(400,200))
                        msg.open()
                        tquantite.line_color_normal='red'
                    else:
                        num=len(tabvente1.row_data)+1

                        pt=math.ceil(float(tquantite.text)*float(t2.text))
                        datanew=(str(num),matprod,t1.text,t2.text,tquantite.text,str(pt))
                        tabvente1.row_data.append(datanew)

                        ligncomp=(str(num),t3.text,t4.text)

                        # recuperation des info complementaires

                        listcomplement.append(ligncomp)

                        netpayer=netpayer+pt

                        listeqt.append(int(t4.text))

                        btss=Builder.load_string('''          
Button:
    text:'Effectué !! '
    color:'black'
    background_color:[0,0,0,0] 

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]            
''')

                        msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(.9, .25))
                        msg.open()

                        tquantite.line_color_normal='black'
                        
                        combaffrech.text="Choisir"

                        t1.text=""
                        t2.text=""
                        t3.text=""
                        t4.text=""
                       
                        tquantite.text=""

                        totgen=0.0

                        for ligtot in tabvente1.row_data:
                            totgen+=float(ligtot[5])

                        if netpayer==totgen:
                            labnetpayer.text=str(netpayer)
                            labnetpayer.color='blue'
                        else:
                            labnetpayer.text=str(netpayer)
                            labnetpayer.color='red'
                
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Echec lors du traitement des valeurs recues'),size_hint=(None, None), size=(400,200))
                    msg.open()
                    tquantite.line_color_normal='red'
            else:

                bbvstock=Builder.load_string('''
Button:
    text:"Stock Insuffisant"
    background_color:[0,0,0,0]
    color:'black'
    canvas.before:

        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
''')

                msg=Popup(title="STATUT REQUETE",content=bbvstock,size_hint=(1,.5))
                msg.open() 
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Error'),size_hint=(None, None), size=(400,200))
            msg.open()


    def rechchargeproduit(self,instance,value):

        global matprod

        t1.text=""
        t2.text=""
        t3.text=""
        t4.text=""
        qtetot=0
        
        try:
            if int(labtaux.text)>0:
                
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="select pu,date_exp,stock_p,matricule from produit,expiration where id_exp=matricule and nom='"+instance.text+"'"
                    cursor.execute(query)
                    results=cursor.fetchone()
                    
                    con.close()

                    if results:
                        t1.text=instance.text
                        t2.text=str(results[0]*int(labtaux.text))
                        t3.text=str(results[1])
                        t4.text=str(results[2])

                        matprod=results[3]
                       
                        #qtetot=str(results[2])

                        t1.disabled=True
                        t2.disabled=True
                        t3.disabled=True
                        t4.disabled=True

                        #tquantite.hint_text="QUANTITE [< " + qtetot +" ]"

                        tquantite.focus=True

                        try:
                            nbr=float(t2.text)
                            t2.text=str(math.ceil(nbr))
                        except:
                            pass

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur, le taux de change genere le probleme'),size_hint=(None, None), size=(400,200))
                msg.open()    
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Le taux de change releve un probleme, veuillez redemarrer ou consulter le gestionnaire si le probleme persiste'),size_hint=(None, None), size=(400,200))
            msg.open()


    def rechlikeproduit(self,instance):
        global listidcommute,df,modcommutation,trecherche

        instance.text="choisir"
        
        tabcomm=[]

        try:
            if trecherche.text=="":
                pass
            
            else:

                if len(df)<1:

                    pass

                else:
                    instance.values=""
                    
                    resucom=df[df['nom'].str.contains(trecherche.text,case=False)]

                    tabcomm=resucom.values
                    
                    icom=0

                    for icom in tabcomm:
                    
                        instance.values.append(str(icom).replace("['","").replace("']",""))

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='ERROR'),size_hint=(None, None), size=(400,200))
            msg.open()

                
    def confirsuppressoff(self,instance):
        global msg
        msg.dismiss()

    def confirsuppression(self,instance):
        global netpayer,msg,bb2,listeqt
        netpayer=0

        try:

            listeqt=[]

        except:
            pass

        try:
            tabvente1.row_data=[]
            labnetpayer.text="0"
            msg.dismiss()
        except:
            pass

    def retirecouponsignal(self,instance):

        global retetat

        retetat=1
        baffplus.text_color='red'
        
    def suprimercoupon(self,instance):
        global netpayer,msg,num,verifsel

        cad=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')


        #if verifsel==0:
        if tabvente1.row_data:

            labb1=Label(text="voulez vous vraiment confirmer\ncette opération?",font_size='18sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.5,0.15))
            bb1=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.15,'center_y':0.25}
    size_hint:(0.25,0.09)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')
            
            
            bb1.bind(on_release=self.confirsuppressoff)
            
            bb2=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'center_y':0.25}
    size_hint:(0.25,0.09)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')
            
            
            bb2.bind(on_release=self.confirsuppression)

            try:
                cad.add_widget(labb1)
                cad.add_widget(bb2)
                cad.add_widget(bb1)

                
                msg=Popup(title="Confirmation",content=cad,size_hint=(.98, .5))
                msg.open()
                num=0
                

            except:
                pass
    

    def enregistrecoupon(self,instance):
        global num,netpayer,msg,txtnom,daatts,daattimes,tidconn,quantiterestant,listeqt,datemodel,imprr,labnetpayer,txtnom
        global msgfac,tabvente1

        global lbnom,trechlike,comchoix,cadd,tnomdocta,suitsavepriseuser,datemodel

        datatot=tabvente1.row_data     
        

        if suitsavepriseuser.active==True:

            try:
                msg.dismiss()
            except:
                pass

            
            if imprr.active==True:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                datatot=tabvente1.row_data
                i=0

                if datemodel<datetime.now():
                
                    datemodel=datetime.now()

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,comchoix.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                #self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                #self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                  #  self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="insert into prescription(id_prise,id_achat,docteur,datees) values(%s,%s,%s,%s)"
                                    dataa=(comchoix.text,daattimes,tnomdocta.text,daatts)
                                    cursor.execute(query,dataa)
                                    con.commit()
                                   # self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Imortalisation Impossible"),size_hint=(1,.4))
                                    msg.open()

                            
                            
                            cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                            labb1a=Label(text=" le (s) produit (s) vendu avec succces\nVoulez-vous Imprimer la Facture !",font_size='12sp',pos_hint={'center_x':0.5,'center_y':0.65},color='black',size_hint=(0.8,0.3))
                            bbb1=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'center_y':0.2}
    size_hint:0.25,0.15
    markup:True
    color:'white'  

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

                            ''')
                            
                            #bbb1.bind(on_release=self.imprimerfacture)

                            bbb2=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.15,'center_y':0.2}
    size_hint:0.25,0.15
    markup:True
    color:'white'


    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
                            #bbb2.bind(on_release=self.imprimefactureno)

                            try:
                                cad.add_widget(labb1a)
                                cad.add_widget(bbb1)
                                cad.add_widget(bbb2)
                            except:
                                pass

                            msgfac=Popup(title="STATUT REQUETE",content=cad,size_hint=(1,.4),background_color="black")
                            msgfac.open()

                            labnetpayer.text="0"
                            tabvente1.row_data=[]

                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()
            
            else:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0


                datatot=tabvente1.row_data
                i=0

                
                if datemodel<datetime.now():

                    datemodel=datetime.now()
                    

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,comchoix.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                               # self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                #self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                    #self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="insert into prescription(id_prise,id_achat,docteur,datees) values(%s,%s,%s,%s)"
                                    dataa=(comchoix.text,daattimes,tnomdocta.text,daatts)
                                    cursor.execute(query,dataa)
                                    con.commit()
                                    #self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Imortalisation Impossible"),size_hint=(1,.4))
                                    msg.open()
                            



                            btxxd=Builder.load_string('''
Button:
    text:"le (s) produit (s) vendu avec succces"
    background_color:[0,0,0,0]
    
    color:'black'


    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')

                            msg=Popup(title="STATUT REQUETE",content=btxxd,size_hint=(1,.4))
                            msg.open()

                            labnetpayer.text="0"
                            tabvente1.row_data=[]
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()

        else:

            try:
                msg.dismiss()
            except:
                pass
            

            if imprr.active==True:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                datatot=tabvente1.row_data

               
                i=0

                if datemodel<datetime.now():
                
                    datemodel=datetime.now()

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                            
                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,txtnom.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                #self.cursor.close()
                                con.close()

                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                #self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                    #self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                            
                            cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                            labb1a=Label(text=" le (s) produit (s) vendu avec succces \nVoulez-vous Imprimer la Facture !",font_size='12sp',pos_hint={'center_x':0.5,'center_y':0.65},color='black',size_hint=(0.8,0.3))
                            
                            bbb1=Builder.load_string('''

Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'center_y':0.2}
    size_hint:0.25,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]            
''')     
                            #bbb1.bind(on_release=self.imprimerfacture)

                            bbb2=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.15,'center_y':0.2}
    size_hint:0.25,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]            
''')  
                            
                            #bbb2.bind(on_release=self.imprimefactureno)

                            try:
                                cad.add_widget(labb1a)
                                cad.add_widget(bbb1)
                                cad.add_widget(bbb2)
                            except:
                                pass

                            msgfac=Popup(title="STATUT REQUETE",content=cad,size_hint=(1,.5), background_color="blue")
                            msgfac.open()

                            labnetpayer.text="0"
                            tabvente1.row_data=[]                           

                            
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="ERROR WHO"),size_hint=(1,.5))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()
            
            else:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                datatot=tabvente1.row_data
                i=0

                
                if datemodel<datetime.now():

                    datemodel=datetime.now()
                    

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,txtnom.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                #self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                #self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                   # self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                            
                            btxx=Builder.load_string('''          
Button:
    text:"le (s) produit (s) vendu avec succces"
    color:'black'
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                            msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.4))
                            msg.open()

                            labnetpayer.text="0"
                            tabvente1.row_data=[]
                            
                            
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()

    def recuperationnomclient(self,instance):
        global msg,daatts,daattimes,imprr

        global lbnom,txtnom,trechlike,comchoix,cadd,tnomdocta,suitsavepriseuser

        daatts=datetime.now().strftime('%Y-%m-%d')
        daattimes=datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        if suitsavepriseuser.active==True:

            if comchoix.text=="Choisir" or tnomdocta.text=="":

                btxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    color:'black'
    font_size:"14sp"

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                    
''')
                btxx.text="Choisissez l'adresse Gmail correctement\npuis le nom du docteur consultant !!"
                
                msg=Popup(title="ERROR",content=btxx,size_hint=(1,.4))
                msg.open()
            
            else:
                cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                labb1=Label(text="voulez vous vraiment confirmer\ncette opération?",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.5,0.15))
                bb1=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                
''')
                bb1.bind(on_release=self.confirsuppressoff)

                labimpp=Label(text="[b]Imprimer[b]",font_size='18sp',pos_hint={'x':0.6,'y':0.8},color='black',size_hint=(0.1,0.15),markup=True)
                #imprr=CheckBox(pos_hint={'x':0.8,'y':0.8},size_hint=(0.05,0.05),active=True)

                imprr=Builder.load_string('''  

MDCheckbox:
    pos_hint:{'x':0.85,'y':0.82}
    size_hint:0.1,0.05
    color_active:'black'
    color_inactive:'black'
    #on_active:app.activer(self)
        
        ''')
                
                
                bb2=Builder.load_string('''

Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.8,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
''')
                
                bb2.bind(on_release=self.enregistrecoupon)

                try:
                    cad.add_widget(labb1)
                    cad.add_widget(bb2)
                    cad.add_widget(bb1)
                    cad.add_widget(imprr)
                    cad.add_widget(labimpp)
                except:
                    pass

                msg=Popup(title="Confirmation",content=cad,size_hint=(.98, .5))
                msg.open()

                
            
        else:

            if txtnom.text !="":

                msg.dismiss()

                if txtnom.text.upper()=="GLOBAL":

                    btxx=Builder.load_string('''
Button:
    text:"MOT RESERVE !!, Veuillez changer le nom"
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                    
''')
                    msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(.98, .5))
                    msg.open()
                else:

                    cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                    labb1=Label(text="voulez vous vraiment confirmer\ncette opération??",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.5,0.15))
                    bb1=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                    
''')
                    bb1.bind(on_release=self.confirsuppressoff)

                    labimpp=Label(text="[b]Imprimer[b]",font_size='18sp',pos_hint={'x':0.6,'y':0.8},color='black',size_hint=(0.1,0.15),markup=True)
                    #imprr=CheckBox(pos_hint={'x':0.8,'y':0.8},size_hint=(0.05,0.05),active=True)

                    imprr=Builder.load_string('''  

MDCheckbox:
    pos_hint:{'x':0.8,'y':0.85}
    size_hint:0.1,0.05
    color_active:'black'
    color_inactive:'black'
    #on_active:app.activer(self)
        
        ''')
                    
                    bb2=Builder.load_string('''

Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.8,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
''')
                    
                    bb2.bind(on_release=self.enregistrecoupon)

                    try:
                        cad.add_widget(labb1)
                        cad.add_widget(bb2)
                        cad.add_widget(bb1)
                        cad.add_widget(imprr)
                        cad.add_widget(labimpp)
                    except:
                        pass

                    msg=Popup(title="Confirmation",content=cad,size_hint=(.98, .5))
                    msg.open()

                    

                    

    def chargegmailprise(self,instance):
        global trechlike

        if trechlike.text=="":
            pass
        else:
            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct gmail from prisecharge where gmail LIKE'%"+trechlike.text+"%'"
                cursor.execute(query)
                results=cursor.fetchall()
                #self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
    
    def prisechargemode(self,instance):
        global lbnom,txtnom,trechlike,comchoix,cadd,tnomdocta

        if instance.active==True:

            try:
                cadd.remove_widget(txtnom)
                cadd.remove_widget(lbnom)
                
            except:
                pass
        
            try:
                cadd.add_widget(comchoix)
                cadd.add_widget(trechlike)
                cadd.add_widget(tnomdocta)
            except:
                pass

        else:

            try:
                cadd.add_widget(txtnom)
                cadd.add_widget(lbnom)
                
            except:
                pass

            try:
                cadd.remove_widget(comchoix)
                cadd.remove_widget(trechlike)
                cadd.remove_widget(tnomdocta)
                
            except:
                pass

    def validecoupon(self,instance):
        global msg,txtnom,verifsel,lbnom,trechlike,comchoix,cadd,tnomdocta,suitsavepriseuser

        cadd=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

        if verifsel==0:

            labrienxx=Label(text="Abonné",color='black',pos_hint={'x':.55,'y':.83} ,size_hint=(.2,.1))

            cadresuitchmorruser=Builder.load_string('''
FloatLayout:
    size_hint:.2,.2
    pos_hint: {'x':.73,'y':.79}  
                                                                                                        
    canvas.before:
        Color:
            rgb:168/255,168/255,168/255 #202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')
            
            suitsavepriseuser=Builder.load_string('''  

MDCheckbox:
    pos_hint: {'x':.8,'y':.8}  
    size_hint:.1,.08
    color_active:'blue'
                                                  
    color_inactive:'blue'
    on_active:app.prisechargemode(self)
        
        ''')
             

            #suitsavepriseuser=Builder.load_string('''
#MDSwitch:
   
  #  pos_hint: {'x':.73,'y':.75}  
 #   size_hint:.2,.08
   # color_active:'blue'
  #  active:False
 #   on_active:app.prisechargemode(self)
#''')
            
            try:
                pass
                #cadresuitchmorruser.add_widget(suitsavepriseuser)
            except:
                pass

            lbnom=Label(text="[b]Client[b]",font_size='18sp',pos_hint={'x':0.1,'center_y':0.5},color='black',size_hint=(0.1,0.1),markup=True)
            #txtnom=TextInput(font_size='18sp',pos_hint={'x':0.4,'center_y':0.53},size_hint=(0.55,0.2))
            txtnom=MDTextField(hint_text="Nom",pos_hint={'x':0.4,'center_y':0.53},size_hint=(0.55,0.2), icon_right='text')
            

            trechlike=MDTextField(hint_text="Gmail",pos_hint={'x':.05,'center_y':.5},size_hint=(.4,.2), icon_right='gmail')
            tnomdocta=MDTextField(hint_text="Docteur",pos_hint={'x':.05,'center_y':.15},size_hint=(.4,.2), icon_right='text')
            
            comchoix=Builder.load_string('''
Spinner:
    text:"Choisir"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.55,'center_y':0.5}
    size_hint:(0.4,0.16)
    bold:True
    color:'white'

    canvas.before:

        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            
            size:self.size
            pos:self.pos

            radius:[15]    
''')
            comchoix.bind(on_release=self.chargegmailprise)

            bbval1=Builder.load_string('''
Button:
    text:"[b]Suivant[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'center_y':0.15}
    size_hint:(0.35,0.16)
    markup:True
    color:'white'

    canvas.before:

        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            
            size:self.size
            pos:self.pos

            radius:[15]    
''')
            
            
            bbval1.bind(on_release=self.recuperationnomclient)

            try:
                cadd.add_widget(labrienxx)
                #cadd.add_widget(cadresuitchmorruser)
                cadd.add_widget(suitsavepriseuser)
            except:
                pass

            try:
                cadd.add_widget(lbnom)
                cadd.add_widget(txtnom)
                cadd.add_widget(bbval1)
            except:
                pass

            msg=Popup(title="INFO DU CLIENT",content=cadd,size_hint=(1, .4))
            msg.open()


    def rechidproforma(self,instance):
        global trechproforma
        idprofo=[]
        instance.values=""
    
        try:

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select distinct nom_client from preforma where nom_client like'%"+trechproforma.text+"%'")
            idprofo=self.cursor.fetchall()
           # self.cursor.close()
            con.close()

            for  i in  idprofo:
                instance.values.append(str(i).replace("('","").replace("',)",""))
    
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(1,.4))
            msg.open()
    

    def affproforcoupon(self,instance,value):
        global netpayer

        idprofonew=[]

        try:

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select id_prod,nom,CEILING(pu*taux),qt,CEILING((pu*taux)*qt) from preforma,produit,tauxchange where nom_client ='"+instance.text+"' and matricule=id_prod")
            idprofo=self.cursor.fetchall()
           # self.cursor.close()
            con.close()

            numprefo=()
            coupreforma=()
            couponprefo=[]
            couponprefonew=[]

            for ik in range(len(idprofo)):
                numprefo +=(ik+1,)

            for j in range(len(idprofo)):

                coupreforma=(numprefo[j],)+(idprofo[j])

                couponprefo.append(coupreforma)

            tabvente1.row_data=couponprefo
            netpayer=0
            labnetpayer.color='black'

            for ligncup in couponprefo:
                
                netpayer+=int(ligncup[5])

            labnetpayer.text=str(netpayer)
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(1,.4))
            msg.open()
            
    
    def proforma(self,instance):

        global trechproforma,sepp,combproforma,msggsetting

        try:
            msggsetting.dismiss()
        except:
            pass  

        cadcloss=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]
            
''')
        
        btclos=Builder.load_string('''
Button:
    text:"Close"
    bold:True
    pos_hint:{'x':.7,'y':.1}
    size_hint:.25,.12
    font_size:'14sp'
    color:'white'
    background_color:[0,0,0,0]
                                   
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
            
        ''')

        btclos.bind(on_release=lambda x:msg.dismiss())

        trechproforma = MDTextField(hint_text="Client",line_color_normal='black', font_size='12sp', pos_hint={'x':0.05, 'center_y':0.5},size_hint=(0.4,0.08))
        combproforma=Builder.load_string('''
Spinner:
   
    bold:True                                      
    text:"Choisir"
    pos_hint:{'x':0.5, 'center_y':0.5}
    size_hint:0.47,0.15
   
    font_size:'14sp'
    color:'white'
    background_color:[0,0,0,0]
                                   
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        
        combproforma.bind(on_release=self.rechidproforma)
        combproforma.bind(text=self.affproforcoupon)

        try:
            cadcloss.add_widget(trechproforma)
            cadcloss.add_widget(combproforma)
            cadcloss.add_widget(btclos)
        except:
            pass

        msg=Popup(title="RECHERCHE PAR NOM",content=cadcloss,size_hint=(1,.5))
        msg.open()

    
    def impreformok(self,instance):
        global chproff,msg

        try:
            msg.dismiss()
        except:
            pass

        if chproff.active==True:

            listeprefo=[]
            listeprefonew=[]
        
            try:

                listeprefo=tabvente1.row_data

                deb_lig=0
                fin_lig=len(listeprefo)

                deb_col=0
                fin_col=5

                for i in range(deb_lig,fin_lig):
                    soustab=listeprefo[i][1],listeprefo[i][4]

                    listeprefonew.append(soustab)

                for lignpref in listeprefonew:

                    a,b=lignpref

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into preforma(id_prod,qt,nom_client,date) values(%s,%s,%s,%s)"
                    dataa=(a,b,nomcclientprefo.text,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    cursor.execute(query,dataa)
                    con.commit()
                    #self.cursor.close()
                    con.close()

                deb_pref=0
                finpref=len(listeprefo)

                listeprefok=[]

                for i in range(deb_pref,finpref):
                    ligv=listeprefo[i][2],listeprefo[i][3],listeprefo[i][4],listeprefo[i][5]

                    listeprefok.append(ligv)

                tab=listeprefok

                if len(tab)>=10:
                    largeur_px = 315
                    hauteur_px = 200+(15*len(tab))+30

                if len(tab)>1 and len(tab)<10:
                    largeur_px = 315
                    hauteur_px = 200+(15*len(tab))
                elif len(tab)==1:
                    largeur_px = 315
                    hauteur_px = 165

                largeur_pt = largeur_px * 0.75
                hauteur_pt = hauteur_px * 0.75

                c = canvas.Canvas("facture.pdf", pagesize=(largeur_pt, hauteur_pt))

                c.setFont('Helvetica',9)
                c.drawString(60,(hauteur_px-20)*0.75,'MERCIRAH PHARMA ')
                c.drawString(33,(hauteur_px-40)*0.75,'RCCM KNM /RCCM/18-A-01 319')

                c.drawString(5,(hauteur_px-60)*0.75,'N° IMPOT : A1702500M')
                c.drawString(110,(hauteur_px-60)*0.75,'ID NAT:01-G4701-N37871Z')

                c.drawString(5,(hauteur_px-80)*0.75,'ID_Trav')
                c.drawString(50,(hauteur_px-80)*0.75,tidconn.text)

                c.drawString(130,(hauteur_px-80)*0.75,'PRE-FACT N°: ')
                c.drawString(190,(hauteur_px-80)*0.75,str(random.randint(1,1500)))

                c.setFont('Helvetica',10)
                c.drawString(5,(hauteur_px-95)*0.75,'NOM')
                c.drawString(80,(hauteur_px-95)*0.75,'PU')
                c.drawString(120,(hauteur_px-95)*0.75,'QTE')
                c.drawString(160,(hauteur_px-95)*0.75,'PT')

                c.setFont('Helvetica',8)

                nom=""

                if len(nomcclientprefo.text)>10:
                    nom=nomcclientprefo.text[0:9]
                else:
                    nom=nomcclientprefo.text

                c.drawString(5,(hauteur_px-hauteur_px+15)*0.75,'Client(e)')
                c.drawString(50,(hauteur_px-hauteur_px+15)*0.75,nom)

                c.drawString(120,(hauteur_px-hauteur_px+35)*0.75,'NET')
                c.drawString(160,(hauteur_px-hauteur_px+35)*0.75,labnetpayer.text)

                c.drawString(120,(hauteur_px-hauteur_px+15)*0.75,'TVA')
                c.drawString(160,(hauteur_px-hauteur_px+15)*0.75,'0.15')

                c.line(2,(hauteur_px-84)*0.75,313,(hauteur_px-84)*0.75,)
                c.line(2,(hauteur_px-99)*0.75,313,(hauteur_px-99)*0.75,)

                haut=120

                for lig in tab:
                    x,y,t,u=lig

                    if len(x)>9:
                        xx=x[0:9]+"..."
                    else:
                        xx=x
                    
                    c.setFont('Helvetica',8)
                    c.drawString(5,(hauteur_px-haut)*0.75,xx)
                    c.drawString(80,(hauteur_px-haut)*0.75,str(y))
                    c.drawString(120,(hauteur_px-haut)*0.75,str(t))
                    c.drawString(160,(hauteur_px-haut)*0.75,str(u)) 

                    c.setFont('Helvetica',6)

                    c.drawString(5,(hauteur_px-hauteur_px+35)*0.75,'Kin, le '+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    

                    haut+=20   

                c.save()

                license = pdf.License()
                viewer = pdf.facades.PdfViewer()

                viewer.bind_pdf("facture.pdf")

                viewer.print_document()
                    
                tabvente1.row_data=[]
                labnetpayer.text=str(0)
                labnetpayer.color='black'

                btxx=Builder.load_string('''
Button:
    text:'Effectué!!'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
                
                ''')
                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.3))
                msg.open()

                labnetpayer.text="0"
                tabvente1.row_data=[]

            except:

                btxx=Builder.load_string('''
Button:
    text:'Erreur survenue'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,128/255,128/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
                
                ''')
                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.3))
                msg.open()
            
        else:

            listeprefo=[]
            listeprefonew=[]
        
            try:

                listeprefo=tabvente1.row_data

                deb_lig=0
                fin_lig=len(listeprefo)

                deb_col=0
                fin_col=5

                for i in range(deb_lig,fin_lig):
                    soustab=listeprefo[i][1],listeprefo[i][4]

                    listeprefonew.append(soustab)

                for lignpref in listeprefonew:

                    a,b=lignpref

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into preforma(id_prod,qt,nom_client,date) values(%s,%s,%s,%s)"
                    dataa=(a,b,nomcclientprefo.text,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    cursor.execute(query,dataa)
                    con.commit()
                    #self.cursor.close()
                    con.close()
                
                btxx=Builder.load_string('''
Button:
    text:'Effectué!!'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
                
                ''')
                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.3))
                msg.open()

                labnetpayer.text="0"
                tabvente1.row_data=[]

            except:

                btxx=Builder.load_string('''
Button:
    text:'ERROR !!'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,128/255,128/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
                
                ''')
                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.3))
                msg.open()

    def supptext(self,instance,value):
        
        if instance.text=="Nom":
            instance.text=""

    def imprissionpreforma(self,instance):
        global nomcclientprefo,chproff,msg

        cadcloss=Builder.load_string('''
        
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]
    ''')

        nomcclientprefo = TextInput(text="Nom", font_size='12sp', pos_hint={'center_x':0.5, 'center_y':0.65},size_hint=(0.7,0.2))
        nomcclientprefo.bind(focus=self.supptext)

        bprefo=Builder.load_string('''
Button:
    text:"[b]Valider[/b]"
    font_size:'15sp'
    pos_hint:{'x':0.55,'center_y':0.22}
    size_hint:(0.4,0.2)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')
        bprefo.bind(on_release=self.impreformok)

        labimpr=Label(text='[b]Imprimer[/b]',font_size='13sp',color='black',pos_hint={'x':0.6,'y':0.9},size_hint=(0.1,0.05),markup=True)
        
        #chproff=CheckBox(active=True,pos_hint={'x':0.95,'y':0.9},size_hint=(0.06,0.06)) 

        chproff=Builder.load_string('''  

MDCheckbox:
    pos_hint:{'x':0.8,'y':0.9}
    size_hint:0.1,0.06
    color_active:'black'
    color_inactive:'black'
    
    #on_active:app.activer(self)
        
        ''')

        try:
            cadcloss.add_widget(nomcclientprefo)
            cadcloss.add_widget(bprefo)
            cadcloss.add_widget(labimpr)
            cadcloss.add_widget(chproff)
        except:
            pass

        msg=Popup(title="NOM DU CLIENT",content=cadcloss,size_hint=(1,.5))
        msg.open()

        
    def misajour(self,instance):
        global lbmsg,check1mod,check2mod,listidcommute,df

        if check2mod.active==True:

            lbmsg.text="Chargement encours..."

            try:
                self.cconnexion()
                query="select nom from produit"
                df=pd.read_sql(query,con)
                con.close()
                lbmsg.text="Chargement reussi : "+str(len(df))

            except:

                msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de chargement '),size_hint=(1,.4))
                msg.open()
                lbmsg.text="Error"


    def commutation(self,instance):

        global lbmsg,msggsetting,check2mod,listidcommute,df

        cadclos=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')
            
        lbm=Label(text="Cette fonctionnalité 'Deconnecté'\nfavorise l optimisation de la machine",font_size='14sp',pos_hint={'center_x':0.5,'center_y':0.7},color='black',size_hint=(0.5,0.15))
        bb1m=Builder.load_string('''   
Button:
    text:"[b]Mise à jour[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.73,'y':0.2}
    size_hint:(0.25,0.12)
    markup:True
    font_size:'15sp'
    color:'white' 

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]            

''')      
            
        bb1m.bind(on_release=self.misajour)

        moddecon=Label(text="[b]Mode deconnecté[/b]",markup=True,color='black',pos_hint={'x':0.4, 'y':0.4},font_size='15sp',size_hint=(0.25,0.07))
        

        check2mod=Builder.load_string('''
                                      
MDCheckbox:
    pos_hint:{'x':0.87,'y':0.4}
    size_hint:(0.1,0.05)
    active:True
                                      
    color_active:'black'
    color_inactive:'black'
    #on_active:app.activer(self)
        
        ''')

        #check2mod.bind(active=self.modcheck2)

        lbmsg=Label(text="",color='blue',pos_hint={'center_x':0.5, 'y':0.1},font_size='10sp',size_hint=(0.25,0.07))

        try:
            cadclos.add_widget(lbmsg)
            cadclos.add_widget(check2mod)
           
            cadclos.add_widget(lbm)
            cadclos.add_widget(bb1m)
            
            cadclos.add_widget(moddecon)
        except:
            pass


        msggsetting.dismiss()

        msg=Popup(title="MODE DE COMMUTATION",content=cadclos, size_hint=(1,.5))
        msg.open()
        

    def affnomclientjournal(self,instance,value):

        global selimprime

        tabventejournal.row_data=[]
        labtot2.text=""
        selimprime=1
        
        if instance.text=="Tous":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                #self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                #self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
     
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and Nom_client='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                #self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where  Nom_client='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                #self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
    

    def affidprodjournal(self,instance,value):
        tabventejournal.row_data=[]
        labtot2.text=""
        
        if instance.text=="Tous":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                #self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                #self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
     
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and ID_Produit='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                #self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and ID_Produit='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                #self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def affdatejournal(self,instance,value):
        tabventejournal.row_data=[]
        labtot2.text=""
        #datform=datetime.strftime(instance.text,'%Y-%m-%d')
        
        if instance.text=="Aujourd hui":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                #self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                #self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0]) 
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,historique.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from historique,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and Dates='"+instance.text+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                #self.cursor.close()
                con.close()
                
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from historique where id_travailleur='"+tidconn.text+"' and Dates='"+instance.text+"'")
                results=self.cursor.fetchone()
                #self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()


    def rechnomclientjournal(self,instance):

        instance.text="choisir"

        if triercheckk4.active==True:
        
            if triercheck3.active==True:
                instance.values=("")
                j="Tous"
                instance.values.append(j)
                self.cconnexion()
                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Nom_client from achat where Nom_client LIKE'%"+tjourclientnom.text+"%' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                    results=self.cursor.fetchall()
                    #datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                    #self.cursor.close()
                    con.close()
                    for  i in  results:
                        instance.values.append(str(i).replace("('","").replace("',)",""))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                    msg.open()
            else:
                instance.values=("")

                btxx=Builder.load_string('''
Button:
    text:"Triage non autorisé"
    color:'black'
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
                
                ''')
                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.4))
                msg.open()

        elif triercheckk5.active==True:

            if triercheck3.active==True:
                instance.values=("")
                j="Tous"
                instance.values.append(j)
                self.cconnexion()
                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Nom_client from achat where Nom_client LIKE'%"+tjourclientnom.text+"%' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"' and id_travailleur='"+tidconn.text+"'")
                    results=self.cursor.fetchall()
                   # self.cursor.close()
                    con.close()
                    for  i in  results:
                        instance.values.append(str(i).replace("('","").replace("',)",""))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                    msg.open()
            else:
                instance.values=("")
                btxx=Builder.load_string('''
Button:
    text:"Triage non autorisé"
    color:'black'
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
                
                ''')
                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.4))
                msg.open()

    def rechidjournal(self,instance):

        instance.text="choisir"

        if triercheck2.active==True:
            instance.values=("")
            j="Tous"
            instance.values.append(j)
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct ID_Produit from achat where ID_Produit LIKE'%"+tjourids.text+"%' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                #datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                #self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()
        else:
            instance.values=("")
            btxx=Builder.load_string('''
Button:
    text:"Triage non autorisé"
    color:'black'
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
                
                ''')
            msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.4))
            msg.open()

    def rechdatejournal(self,instance):

        instance.text="choisir"

        if triercheck1.active==True:
            instance.values=("")
            j="Aujourd hui"
            
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct Dates from historique where id_travailleur='"+tidconn.text+"' order by Dates ASC")
                results=self.cursor.fetchall()
                datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                #self.cursor.close()
                con.close()
                for  i in  datat:
                    instance.values.append(str(i))
                
                instance.values.append(j)
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()
        else:
            instance.values=("")
            btxx=Builder.load_string('''
Button:
    text:"Triage non autorisé"
    color:'black'
    background_color:[0,0,0,0]
                                         
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
                
                ''')
            msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.4))
            msg.open()
    
    def controleurtdeb(self,instance):

        if triercheck1.active==True:

            triercheck2.active=False
            triercheck3.active=False

        elif triercheck2.active==True:

            triercheck1.active=False
            triercheck3.active=False

        elif triercheck3.active==True:

            triercheck2.active=False
            triercheck1.active=False
    
    def controleurjour1(self,instance):

        if instance.active==True:
            triercheck3.active=False
            triercheck2.active=False

    def controleurjour2(self,instance):

        if instance.active==True:
            triercheck1.active=False
            triercheck3.active=False

    def controleurjour3(self,instance):

        if instance.active==True:
            
            triercheck1.active=False
            triercheck2.active=False


    def controleurjour4(self,instance):

        if instance.active==True:
            triercheckk5.active=False

    def controleurjour5(self,instance):

        if instance.active==True:
            triercheckk4.active=False
    

    def affpas_a_pas(self,dt):
        global l,lcont,resuplainte,indiceaff,listplainte,repsuite,unitul,listedebut,listecharniere,listnom,listcategorie,listtraite,listanti,listposlogoie,listeage,listepuu
        global nomaff,categorieaff,taitaff,antaff,posologaff,agaff,paff,mot,listfin

        unitul=" je suis sur que c est toi qui m as fait ca  neamoins il faut comprendre que la vie evolue de la sorte das le cas que l amsi dis de n pas avoie une dent cotre toit mais tu le bois en te supectant dans les faaaires courangtes et dans les betises dans le domaine simple pure et esctat je suis sur uqe c est oit qui m as fait ca  mneamoins il faut comprendre que la vie evolue de la sorte das le cas que l amsi dis de n pas avoie une dent cotre toit mais tu le bois en te supectant dans les faaaires courangtes et dans les betises dans le domaine simple pure et esctat"
        

        if len(mot)<=1000:
            
            affresultat.text=affresultat.text[0:len(affresultat.text)-1]

            try:
                cadre.remove_widget(btsuitegenAI)
            except:
                pass
            
            if l < len(mot):
                if lcont==130:
                    affresultat.text+="\n"
                    lcont=0

                affresultat.text += mot[l]+"|"
                l += 1
                lcont+=1
            else:
                #bgenererresulat.background_color="seagreen"
                return False  
        else:
            
            if repsuite==0:

                if l <= 1000:

                    affresultat.text=affresultat.text[0:len(affresultat.text)-1]

                    if lcont==130:
                        affresultat.text+="\n"
                        lcont=0

                    affresultat.text += mot[l]+"|"
                    l += 1
                    lcont+=1

                    #labelement.text=str(l)
                else:
                    try:
                        cadre.add_widget(btsuitegenAI)
                    except:
                        pass

                    return False
    
            elif repsuite==1:
                        
                if l > 1000 and l < len(mot):
                    affresultat.text=affresultat.text[0:len(affresultat.text)-1]

                    if lcont==130:
                        affresultat.text+="\n"
                        lcont=0

                    affresultat.text += mot[l]+"|"
                    l += 1
                    lcont+=1
                else:
                    #bgenererresulat.background_color="seagreen"
                    return False

    def affpas_a_pasfin(self,dt):                            
                                        
        global l,lcont,motrappfin

        if len(motrappfin)<=1500:
            
            affresultat.text=affresultat.text[0:len(affresultat.text)-1]

            try:
                cadre.remove_widget(btsuitegenAI)
            except:
                pass
            
            if l < len(motrappfin):
                if lcont==130:
                    affresultat.text+="\n"
                    lcont=0

                affresultat.text += motrappfin[l]+"|"
                l += 1
                lcont+=1
            else:
                #bgenererresulat.background_color="seagreen"

                try:
                    cadreexpert.add_widget(btsuitegenAI)
                    btsuitegenAI.text='[b]Oui[/b]'
                    
                except:
                    pass
                
                return False
            
    def generesultat(self,instance):
        global listeplainte,ki,l,lcont,listplainte,kj,resuplainte,indiceaff,unitul,listedebut,listecharniere,listnom,listcategorie,listtraite,listanti,listposlogoie,listeage,listepuu
        global nomaff,categorieaff,taitaff,antaff,posologaff,agaff,paff,mot,listfin, compfois,motrappfin,debsessionheure,listdeburap

        plainterecu=""
        motrappfin=""
        debsessionheure=""

        mot="Erreur a été générée, veuillez redemarrer le systeme "
        cherapp=0

        indicerapp=0
        
        try:
           
            plainterecu=texp1.text
            plainterecu=plainterecu.split()

            salutation=plainterecu[0].lower()
            genre=plainterecu[1].lower()
            nomopenai=plainterecu[2].lower()

            heurenow=datetime.now().strftime("%H:%M:%S")

            if salutation=="bonjour" or salutation=="bjr" or salutation=="bonsoir" or salutation=="bsr" or salutation=="bon_apres_midi":
            
                if genre=='monsieur' or genre=='mr' or genre=='madame':

                    if nomopenai=="askyas":

                        if heurenow < "12:00:00":
                            if salutation=="bonjour" or salutation=="bjr":

                                deccoup=texp1.text.split()
                                di=0
                                for di in range(len(deccoup)):
                                    if deccoup[di].lower()=="rapport-du-jour":
                                        cherapp=1
                                        break

                                if cherapp==1:

                                    indicerapp=random.randint(0,4)

                                    listdeburap=['Recupération des données du ','Extration des données du ','Structuration des données du ','Filtration des données du ','Lecture des données du ']
                                    listnomrap=[' Travailleur ',' Bosseur ',' Pharmacien(Travailleur) ',' Bookinneur ',' Coéquipier ']
                                    listfinrapp=[' tu es sur (e) de pouvoir mettre ce rapport au propre ? (repondez par : oui ou non)NB: oui, c-a-d on transmet sur le serveur et ta journée est cloturée',' es-tu pret (e) de que ce rapport soit transmis au serveur(Oui/Non)?? oui , c-a-d on transmet au gestionnaire et le processus est clos aujourdui',' je parie que  tu es pret (e) d envoyer ce rapport à l interface admin ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)',' je m imagine que  tu es sensible d envoyer ce dit rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, veut dire on transfert sur le serveur et ta journée est limité par ci)',' je me fait l ide du genre tu es deja pret (e) d envoyer ce rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)']
                                    
                                    listmotif=[' alors suite à la gestion, on a  sorti le montant  ','  dependament à la gestion, on a  sorti une somme  ','  sous-pretexte du motif que demande la gestion demande, on a  depensé  ','  voyant les situations que la gestion, on a  sorti le montant  ','  sachant que la gestion oblige les OUTPUT,on a depensé  ']
                                    
                                    listfinrappo=['; Merci et n hésitez pas de me consulter encore si nécessaire.','; Humblement reconnaissant et je vous espère me consulter encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.','. Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.','. Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                    try:
                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select nom,prenom,sexe from compte where id='"+tidconn.text+"'")
                                        identitetrav=self.cursor.fetchone()
                                        #self.cursor.close()
                                        con.close()

                                        if identitetrav:
                                            nomrap=identitetrav[0]
                                            prenomrap=identitetrav[1]
                                            sexerap=identitetrav[2]

                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                        debsession=self.cursor.fetchone()
                                        #self.cursor.close()
                                        con.close()

                                        if debsession:
                                            debsessionheure=debsession[0]

                                        
                                        valmotif=0
                                        totrestant=0

                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select SUM(montant) from motif_signaler,commande where id_trav='"+tidconn.text+"' and date_motif=borne")
                                        montamotif=self.cursor.fetchone()
                                        #self.cursor.close()
                                        con.close()

                                        if montamotif:
                                            valmotif=montamotif[0]


                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select SUM(PT) from achat,commande where id_travailleur='"+tidconn.text+"' and Dates=borne")
                                        totrapp=self.cursor.fetchone()
                                        #self.cursor.close()
                                        con.close()

                                        if totrapp:

                                            totalrapp=totrapp[0]

                                            try:
                                                totrestant=int(totalrapp)-valmotif
                                            except:
                                                totrestant=totalrapp
                                        else:
                                            valmotif=0
                                            totrestant=0

                                        motrappfin=listdeburap[indicerapp]+listnomrap[indicerapp]+ " Nom : "+nomrap + " Prenom : "+prenomrap+ " Sexe : "+sexerap + " ta connexion ou bien session a été ouverte depuis :  "+str(debsessionheure) + " . Il sied de montrer que selon mes analyses et calculs, tu as vendu aujourdhui :" + str(totalrapp) +"  chargement encours.... "+ listmotif[indicerapp]+"[ "+ str(valmotif) +" ]  apres toutes les soustrations de charges officielles connues on realise t avoir en main : "+str(totrestant)+listfinrappo[indicerapp]+ listfinrapp[indicerapp]
                                    
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pasfin, 0.1)  
                                        

                                    except:
                                        msg=Popup(title="STATUT REQUETE",content=Button(text=' Le generateur du rapport a echoué, veuillez ressayer plus tard '),size_hint=(1,.4))
                                        msg.open()

                                else:

                                    if genre=='monsieur' or genre=='mr':


                                        compfois=0

                                        indiceaff=random.randint(0,4)

                                        #instance.background_color="red"

                                        plaintes=[]
                                        plaintes=listplainte

                                        if kj<=len(plaintes)-1:
                                            elementvalue=plaintes[kj]
                                            elementvalue=elementvalue[0:len(elementvalue)-1]

                                            labcompteur.text="[b]"+ str(kj+1) + "/"+ str(len(plaintes))+"[/b]"

                                            try:
                                                self.cconnexion()
                                                self.cursor=con.cursor()
                                                self.cursor.execute("select nom,categorie,anti,traite,posologie,age_utilisation,pu from produit where traite='"+ elementvalue +"'")
                                                resuplainte=self.cursor.fetchone()
                                               # self.cursor.close()
                                                con.close()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                    
                                            if resuplainte:
                                                nomaff=resuplainte[0]
                                                categorieaff=resuplainte[1]
                                                taitaff=resuplainte[2]
                                                antaff=resuplainte[3]
                                                posologaff=resuplainte[4]
                                                agaff=resuplainte[5]
                                                paff=str(resuplainte[6])


                                                listedebut=[' Effectivement monsieur/madame, ',' Exactement monsieur/madame, ',' Franchement monsieur/madame, ',' Cela etant vrai monsieur/madame, ',' Extrêmement bien dit monsieur/madame , ']
                                                listecharniere=['. En effet, ','. En outre, ','. En réalité, ','. En connaissance de cause, ','. Selon ce dit ci-haut, ']
                                                
                                                listnom=[' tu es prié de prendre : ','  tu es conseillé d acheter : ','  tu es sous proprosition du produit tel que : ','  nous te suggerons le medicament : ',' Veuillez acheter le produit : ']
                                                listcategorie=[' ce dernier faisant de partie de ',' catégorié dans ',' classifié parmi ',' connu parmi ',' retrouvé dans la fammile de ']
                                                listtraite=[' ce produit traite ',' il est capable de traiter ',' il est reconnu pour la guerison de  ',' il va guerir', ' utiliser pour sa supere puissance de guerir']
                                                listanti=[' mais attention de ce produit !! car ne supporte pas  ',' néamoins attention de consommer ce produit si tu as ',' sois informé de ce produit que ca ne supporte pas ',' éveilles-toi, ce produit ne co-habite pas avec ',' franchement ce dernier ne supporte pas ']
                                                listposlogoie=[' voila comment ca s utilise ', ' regardes comment ca se prend ',' tu sais comment est son usage...? ',' ca s employe de la manière ', ' sa posologie normale montre ce qui suit ']
                                                listeage=[' tout en dependant avec cette repartition d âge ',' cadran avec ce decallage d âge ', ' en rapport de cet âge ', ' comme on le prevoit par âge', ' en tenant coompte de la fréquence d âge ']
                                                listepuu=['. Keba !!! tout depend de ta poche, voila le prix que revient ce produit ', '. Keba !!! c est la contrainte budgétaire qui conclut, voila tel est son prix ','. Keba !!! l unique et seule dernière decision c est ton budget, voila son prix ', '. Keba !!! tout se conclut avec ce prix ', '. Keba !!! tu nous sera le bienvenue que si tu disposes pour ce produit ' ]            

                                                listfin=[' Merci et n hésitez pas de consulter encore si nécessaire.   ',' Merci et j espère que vous me consultiez encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.  ',' . Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.  ',' . Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                                try:
                                                    mot="Recupération des plaintes ... "+str(plaintes) +"  decomposition encours... ressemblage... Generation OpenAI demarre! ."+ listedebut[indiceaff] + listnom[indiceaff]+nomaff + ","+ listcategorie[indiceaff]+ categorieaff+listtraite[indiceaff]+taitaff+ ", " + listanti[indiceaff]+antaff + ", "+ listposlogoie[indiceaff]+ ", "+ posologaff+listeage[indiceaff]+agaff+listepuu[indiceaff]+paff+ listfin[indiceaff]
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Génération/Ressamblage a échoué, veuillez recommancer '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                        
                                                try:
                                                    pass
                                                    #discourantt=os.path.dirname(__file__)
                                                    #disprodd=os.path.join(discourantt,"ftx",nomaff)
                                                    #imgexpert.background_normal= disprodd + ".jpg"

                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors du chargement de la photo'),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            
                                            kj+=1
                                        else:
                                            kj=0
                                        
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)


                                    elif genre=='madame':

                                        compfois +=1
                                        indicdmad= random.randint(0,3)
                                        listefemme=['Desolé Monsieur/Madame, je suis très inquiet de m avoir confondu  à une femme car une femme ne peut pas raisonner comme moi, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Wouaw !!! Monsieur/Madame, sur quel plan tu peux m accorder cette humilliation, je suis inconsolable de m avoir egalisé à une femme car une femme est une être reputée en incomprehension et impossible d imaginer meme me comparer avec elle, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Incroyable Monsieur/Madame, je ne suis pas d hummeur de m avoir confondu  à une femme car si j etais une femme, je ne pouvais pas meme te repondre à ce temps, de grace, je souhaite une considération de ta part, cela pourra me motiver et me donner la conviction de vous repondre favorablement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Merde !! Monsieur/Madame par quelle concentement tu peux me manquer ainsi ??, je suis très inquiet de m avoir rapproché  à une femme car une femme ne peut pas prendre en charge tous ce que je fais, de grace, j aime une considération de ta part, cela pourra me pousser et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ']
                                        mot=listefemme[indicdmad]

                                        #print(compfois)

                                        if compfois==4:
                                            pass  # arreter la machine ici

                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)

                            else:
                                indicdmad= random.randint(0,3)
                                listefemme=['Wouw!!! Desolé Madame/Monsieur, en rigueur de la politesse à cette heure, il est imperatif de se dire "Bonjour" avant d aborder n importe quel probleme','Wouff !! Vraiment Madame/Monsieur, tu es si realiste de me donner une salutation à cette heure si c n est "Bonjour" en terme de la politesse ?? ','Inconcevable mais vrai!!!  Madame/Monsieur, comment tu veux supposer me consulter avec une salutation à cette heure si ce n est pas  "Bonjour"','Ahh !! non pardon cher (e) Monsieur/Madame !! j ai droit à etre salué avant de tenir n importe quel discussion à ma personnalité, NB: à cette heure j attend rien d autre que  "Bonjour']
                                mot=listefemme[indicdmad]

                                affresultat.text = ""
                                l = 0
                                lcont=0

                                Clock.schedule_interval(self.affpas_a_pas, 0.1)                            

                        elif heurenow < "15:00:00":
                            if salutation=="bon_apres_midi":
                                if genre=='monsieur' or genre=='mr':

                                    deccoup=texp1.text.split()
                                    di=0
                                    for di in range(len(deccoup)):
                                        if deccoup[di].lower()=="rapport-du-jour":
                                            cherapp=1
                                            break

                                    if cherapp==1:
                                        
                                        indicerapp=random.randint(0,4)

                                        listdeburap=['Recupération des données du ','Extration des données du ','Structuration des données du ','Filtration des données du ','Lecture des données du ']
                                        listnomrap=[' Travailleur ',' Bosseur ',' Pharmacien(Travailleur) ',' Bookinneur ',' Coéquipier ']
                                        listfinrapp=[' tu es sur (e) de pouvoir mettre ce rapport au propre ? (repondez par : oui ou non)NB: oui, c-a-d on transmet sur le serveur et ta journée est cloturée',' es-tu pret (e) de que ce rapport soit transmis au serveur(Oui/Non)?? oui , c-a-d on transmet au gestionnaire et le processus est clos aujourdui',' je parie que  tu es pret (e) d envoyer ce rapport à l interface admin ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)',' je m imagine que  tu es sensible d envoyer ce dit rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, veut dire on transfert sur le serveur et ta journée est limité par ci)',' je me fait l ide du genre tu es deja pret (e) d envoyer ce rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)']
                                        
                                        listmotif=[' alors suite aux problemes que confronte la gestion, on a  sorti le montant  ',' aussi suite aux depenses liées à la gestion, on a  sorti une somme  ','  sous-pretexte du motif que demande la gestion demande, on a  depensé  ','  voyant les situations que soubit la gestion , on a  sorti le montant  ','  sachant que la gestion oblige les imprevus voila une somme qui a été confrontée à la gestion  ']
                                        listfinrappo=['. Merci et n hésitez pas de me consulter encore si nécessaire.','. Humblement reconnaissant et je vous espère me consulter encore à la prochaine.  ','. Je te remercie de m avoir consulté et je te serai toujours disponible.','. Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.','. Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                        
                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select nom,prenom,sexe from compte where id='"+tidconn.text+"'")
                                            identitetrav=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if identitetrav:
                                                nomrap=identitetrav[0]
                                                prenomrap=identitetrav[1]
                                                sexerap=identitetrav[2]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                            debsession=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if debsession:
                                                debsessionheure=debsession[0]

                                            valmotif=0
                                            totrestant=0

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(montant) from motif_signaler,commande where id_trav='"+tidconn.text+"' and date_motif=borne")
                                            montamotif=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if montamotif:

                                                valmotif=montamotif[0]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(PT) from achat,commande where id_travailleur='"+tidconn.text+"' and Dates=borne")
                                            totrapp=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if totrapp:
                                                totalrapp=totrapp[0]

                                                try:
                                                    totrestant=int(totalrapp)-valmotif
                                                except:
                                                    totrestant=totalrapp
                                            else:
                                                valmotif=0
                                                totrestant=0

                                            motrappfin=listdeburap[indicerapp]+listnomrap[indicerapp]+ " Nom : "+nomrap + " Prenom : "+prenomrap+ " Sexe : "+sexerap + " ta connexion ou bien session a été ouverte depuis :  "+str(debsessionheure) + " . Il sied de montrer que selon mes analyses et calculs, tu as vendu aujourdhui :" + str(totalrapp) +"  chargement encours.... "+ listmotif[indicerapp]+"[ "+ str(valmotif) +" ]  apres toutes les soustrations de charges officielles connues on realise t avoir en main : "+str(totrestant)+listfinrappo[indicerapp]+ listfinrapp[indicerapp]
                                    
                                            affresultat.text = ""
                                            l = 0
                                            lcont=0

                                            Clock.schedule_interval(self.affpas_a_pasfin, 0.1)  
                                            

                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text=' Le generateur du rapport a echoué, veuillez ressayer plus tard '),size_hint=(1,.5))
                                            msg.open()

                                    else:

                                        compfois=0

                                      
                                        
                                        indiceaff=random.randint(0,4)

                                        #instance.background_color="red"

                                        plaintes=[]
                                        plaintes=listplainte

                                        if kj<=len(plaintes)-1:
                                            elementvalue=plaintes[kj]
                                            elementvalue=elementvalue[0:len(elementvalue)-1]

                                            labcompteur.text="[b]"+ str(kj+1) + "/"+ str(len(plaintes))+"[/b]"

                                            try:
                                                self.cconnexion()
                                                self.cursor=con.cursor()
                                                self.cursor.execute("select nom,categorie,anti,traite,posologie,age_utilisation,pu from produit where traite='"+ elementvalue +"'")
                                                resuplainte=self.cursor.fetchone()
                                             #   self.cursor.close()
                                                con.close()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                    
                                            if resuplainte:
                                                nomaff=resuplainte[0]
                                                categorieaff=resuplainte[1]
                                                taitaff=resuplainte[2]
                                                antaff=resuplainte[3]
                                                posologaff=resuplainte[4]
                                                agaff=resuplainte[5]
                                                paff=str(resuplainte[6])


                                                listedebut=[' Effectivement monsieur/madame, ',' Exactement monsieur/madame, ',' Franchement monsieur/madame, ',' Cela etant vrai monsieur/madame, ',' Extrêmement bien dit monsieur/madame , ']
                                                listecharniere=['. En effet, ','. En outre, ','. En réalité, ','. En connaissance de cause, ','. Selon ce dit ci-haut, ']
                                                
                                                listnom=[' tu es prié de prendre : ','  tu es conseillé d acheter : ','  tu es sous proprosition du produit tel que : ','  nous te suggerons le medicament : ',' Veuillez acheter le produit : ']
                                                listcategorie=[' ce dernier faisant de partie de ',' catégorié dans ',' classifié parmi ',' connu parmi ',' retrouvé dans la fammile de ']
                                                listtraite=[' ce produit traite ',' il est capable de traiter ',' il est reconnu pour la guerison de  ',' il va guerir', ' utiliser pour sa supere puissance de guerir']
                                                listanti=[' mais attention de ce produit !! car ne supporte pas  ',' néamoins attention de consommer ce produit si tu as ',' sois informé de ce produit que ca ne supporte pas ',' éveilles-toi, ce produit ne co-habite pas avec ',' franchement ce dernier ne supporte pas ']
                                                listposlogoie=[' voila comment ca s utilise ', ' regardes comment ca se prend ',' tu sais comment est son usage...? ',' ca s employe de la manière ', ' sa posologie normale montre ce qui suit ']
                                                listeage=[' tout en dependant avec cette repartition d âge ',' cadran avec ce decallage d âge ', ' en rapport de cet âge ', ' comme on le prevoit par âge', ' en tenant coompte de la fréquence d âge ']
                                                listepuu=['. Keba !!! tout depend de ta poche, voila le prix que revient ce produit ', '. Keba !!! c est la contrainte budgétaire qui conclut, voila tel est son prix ','. Keba !!! l unique et seule dernière decision c est ton budget, voila son prix ', '. Keba !!! tout se conclut avec ce prix ', '. Keba !!! tu nous sera le bienvenue que si tu disposes pour ce produit ' ]            

                                                listfin=[' Merci et n hésitez pas de consulter encore si nécessaire.   ',' Merci et j espère que vous me consultiez encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.  ',' . Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.  ',' . Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                                try:
                                                    mot="Recupération des plaintes ... "+str(plaintes) +"  decomposition encours... ressemblage... Generation OpenAI demarre! ."+ listedebut[indiceaff] + listnom[indiceaff]+nomaff + ","+ listcategorie[indiceaff]+ categorieaff+listtraite[indiceaff]+taitaff+ ", " + listanti[indiceaff]+antaff + ", "+ listposlogoie[indiceaff]+ ", "+ posologaff+listeage[indiceaff]+agaff+listepuu[indiceaff]+paff+ listfin[indiceaff]
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Génération/Ressamblage a échoué, veuillez recommancer '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                        
                                                try:
                                                    pass

                                                    #discourantt=os.path.dirname(__file__)
                                                    #disprodd=os.path.join(discourantt,"ftx",nomaff)
                                                    #imgexpert.background_normal= disprodd + ".jpg"

                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors du chargement de la photo'),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            
                                            kj+=1
                                        else:
                                            kj=0
                                        
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)  

                                elif genre=='madame':
                                    compfois +=1
                                    indicdmad= random.randint(0,3)
                                    listefemme=['Desolé Monsieur/Madame, je suis très inquiet de m avoir confondu  à une femme car une femme ne peut pas raisonner comme moi, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Wouaw !!! Monsieur/Madame, sur quel plan tu peux m accorder cette humilliation, je suis inconsolable de m avoir egalisé à une femme car une femme est une être reputée en incomprehension et impossible d imaginer meme me comparer avec elle, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Incroyable Monsieur/Madame, je ne suis pas d hummeur de m avoir confondu  à une femme car si j etais une femme, je ne pouvais pas meme te repondre à ce temps, de grace, je souhaite une considération de ta part, cela pourra me motiver et me donner la conviction de vous repondre favorablement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Merde !! Monsieur/Madame par quelle concentement tu peux me manquer ainsi ??, je suis très inquiet de m avoir rapproché  à une femme car une femme ne peut pas prendre en charge tous ce que je fais, de grace, j aime une considération de ta part, cela pourra me pousser et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ']
                                    mot=listefemme[indicdmad]

                                    if compfois==4:
                                        pass  # arreter la machine ici

                                    affresultat.text = ""
                                    l = 0
                                    lcont=0

                                    Clock.schedule_interval(self.affpas_a_pas, 0.1)

                            else:

                                indicdmad= random.randint(0,3)
                                listefemme=['Wouw!!! Desolé Madame/Monsieur, sans mancher le mot à cette heure, il sied de se dire "Bon_apres_midi" avant d aborder n importe quel probleme','Wouff !! Vraiment Madame/Monsieur, tu es determiné de me donner une salutation à cette heure si c n est "Bon_apres_midi" en terme de la politesse ?? ','incroyable mais vrai!!!  Madame/Monsieur, comment tu veux supposer me consulter avec une salutation à cette heure si ce n est pas  "Bon_apres_midi"','Ahh !! non pardon cher (e) Monsieur/Madame !! j ai droit à etre salué avant de tenir n importe quel discussion à ma personnalité, NB: à cette heure j attend rien d autre que  "Bon_apres_midi']
                                mot=listefemme[indicdmad]

                                affresultat.text = ""
                                l = 0
                                lcont=0

                                Clock.schedule_interval(self.affpas_a_pas, 0.1)
                                

                        elif heurenow >= "15:00:00":
                            if salutation=="bonsoir" or salutation=="bsr":
                                if genre=='monsieur' or genre=='mr':
                                    
                                    deccoup=texp1.text.split()
                                    di=0
                                    for di in range(len(deccoup)):
                                        if deccoup[di].lower()=="rapport-du-jour":
                                            cherapp=1
                                            break

                                    if cherapp==1:

                                        indicerapp=random.randint(0,4)

                                        listdeburap=['Recupération des données du ','Extration des données du ','Structuration des données du ','Filtration des données du ','Lecture des données du ']
                                        listnomrap=[' Travailleur ',' Bosseur ',' Pharmacien(Travailleur) ',' Bookinneur ',' Coéquipier ']
                                        listfinrapp=[' tu es sur (e) de pouvoir mettre ce rapport au propre ? (repondez par : oui ou non)NB: oui, c-a-d on transmet sur le serveur et ta journée est cloturée',' es-tu pret (e) de que ce rapport soit transmis au serveur(Oui/Non)?? oui , c-a-d on transmet au gestionnaire et le processus est clos aujourdui',' je parie que  tu es pret (e) d envoyer ce rapport à l interface admin ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)',' je m imagine que  tu es sensible d envoyer ce dit rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, veut dire on transfert sur le serveur et ta journée est limité par ci)',' je me fait l ide du genre tu es deja pret (e) d envoyer ce rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)']
                                        listmotif=[' alors suite aux problemes que confronte la gestion, on a  sorti le montant  ',' aussi vus depenses liées à la gestion, on a  sorti une somme  ','  sous-pretexte du motif que demande la gestion demande, on a  depensé  ','  voyant les situations que presente gestion, on a  sorti le montant  ','  sachant que la gestion oblige les imprevus voila une somme qui a été confrontée à la gestion  ']
                                        listfinrappo=['; Merci et n hésitez pas de me consulter encore si nécessaire.','; Humblement reconnaissant et je vous espère me consulter encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.','. Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.','. Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']                                        

                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select nom,prenom,sexe from compte where id='"+tidconn.text+"'")
                                            identitetrav=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if identitetrav:
                                                nomrap=identitetrav[0]
                                                prenomrap=identitetrav[1]
                                                sexerap=identitetrav[2]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                            debsession=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if debsession:
                                                debsessionheure=debsession[0]
                                            

                                            valmotif=0
                                            totrestant=0

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(montant) from motif_signaler,commande where id_trav='"+tidconn.text+"' and date_motif=borne")
                                            montamotif=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if montamotif:
                                                valmotif=montamotif[0]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(PT) from achat,commande where id_travailleur='"+tidconn.text+"' and Dates=borne")
                                            totrapp=self.cursor.fetchone()
                                            #self.cursor.close()
                                            con.close()

                                            if totrapp:
                                                totalrapp=totrapp[0]

                                                try:
                                                    totrestant=int(totalrapp)-valmotif
                                                except:
                                                    totrestant=totalrapp
                                            else:
                                                valmotif=0
                                                totrestant=0

                                            motrappfin=listdeburap[indicerapp]+listnomrap[indicerapp]+ " Nom : "+nomrap + " Prenom : "+prenomrap+ " Sexe : "+sexerap + " ta connexion ou bien session a été ouverte depuis :  "+str(debsessionheure) + " . Il sied de montrer que selon mes analyses et calculs, tu as vendu aujourdhui :" + str(totalrapp) +"  chargament encours.... "+listmotif[indicerapp]+ " [ "+str(valmotif)+" ] apres toutes les soustrations de charges officielles connues on realise t avoir en main : "+str(totrestant)+listfinrappo[indicerapp]+ listfinrapp[indicerapp]
                                    
                                            affresultat.text = ""
                                            l = 0
                                            lcont=0

                                            Clock.schedule_interval(self.affpas_a_pasfin, 0.1)  
                                            

                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text=' Le generateur du rapport a echoué, veuillez ressayer plus tard '),size_hint=(1,.5))
                                            msg.open()

                                    else:
                                    
                                      

                                        compfois=0
                                        
                                        indiceaff=random.randint(0,4)

                                        #instance.background_color="red"

                                        plaintes=[]
                                        plaintes=listplainte

                                        if kj<=len(plaintes)-1:
                                            elementvalue=plaintes[kj]
                                            elementvalue=elementvalue[0:len(elementvalue)-1]

                                            labcompteur.text="[b]"+ str(kj+1) + "/"+ str(len(plaintes))+"[/b]"

                                            try:
                                                self.cconnexion()
                                                self.cursor=con.cursor()
                                                self.cursor.execute("select nom,categorie,anti,traite,posologie,age_utilisation,pu from produit where traite='"+ elementvalue +"'")
                                                resuplainte=self.cursor.fetchone()
                                               # self.cursor.close()
                                                con.close()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                    
                                            if resuplainte:
                                                nomaff=resuplainte[0]
                                                categorieaff=resuplainte[1]
                                                taitaff=resuplainte[2]
                                                antaff=resuplainte[3]
                                                posologaff=resuplainte[4]
                                                agaff=resuplainte[5]
                                                paff=str(resuplainte[6])


                                                listedebut=[' Effectivement monsieur/madame, ',' Exactement monsieur/madame, ',' Franchement monsieur/madame, ',' Cela etant vrai monsieur/madame, ',' Extrêmement bien dit monsieur/madame , ']
                                                listecharniere=['. En effet, ','. En outre, ','. En réalité, ','. En connaissance de cause, ','. Selon ce dit ci-haut, ']
                                                
                                                listnom=[' tu es prié de prendre : ','  tu es conseillé d acheter : ','  tu es sous proprosition du produit tel que : ','  nous te suggerons le medicament : ',' Veuillez acheter le produit : ']
                                                listcategorie=[' ce dernier faisant de partie de ',' catégorié dans ',' classifié parmi ',' connu parmi ',' retrouvé dans la fammile de ']
                                                listtraite=[' ce produit traite ',' il est capable de traiter ',' il est reconnu pour la guerison de  ',' il va guerir', ' utiliser pour sa supere puissance de guerir']
                                                listanti=[' mais attention de ce produit !! car ne supporte pas  ',' néamoins attention de consommer ce produit si tu as ',' sois informé de ce produit que ca ne supporte pas ',' éveilles-toi, ce produit ne co-habite pas avec ',' franchement ce dernier ne supporte pas ']
                                                listposlogoie=[' voila comment ca s utilise ', ' regardes comment ca se prend ',' tu sais comment est son usage...? ',' ca s employe de la manière ', ' sa posologie normale montre ce qui suit ']
                                                listeage=[' tout en dependant avec cette repartition d âge ',' cadran avec ce decallage d âge ', ' en rapport de cet âge ', ' comme on le prevoit par âge', ' en tenant coompte de la fréquence d âge ']
                                                listepuu=['. Keba !!! tout depend de ta poche, voila le prix que revient ce produit ', '. Keba !!! c est la contrainte budgétaire qui conclut, voila tel est son prix ','. Keba !!! l unique et seule dernière decision c est ton budget, voila son prix ', '. Keba !!! tout se conclut avec ce prix ', '. Keba !!! tu nous sera le bienvenue que si tu disposes pour ce produit ' ]            

                                                listfin=[' Merci et n hésitez pas de consulter encore si nécessaire.   ',' Merci et j espère que vous me consultiez encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.  ',' . Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.  ',' . Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                                try:
                                                    mot="Recupération des plaintes ... "+str(plaintes) +"  decomposition encours... ressemblage... Generation OpenAI demarre! ."+ listedebut[indiceaff] + listnom[indiceaff]+nomaff + ","+ listcategorie[indiceaff]+ categorieaff+listtraite[indiceaff]+taitaff+ ", " + listanti[indiceaff]+antaff + ", "+ listposlogoie[indiceaff]+ ", "+ posologaff+listeage[indiceaff]+agaff+listepuu[indiceaff]+paff+ listfin[indiceaff]
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Génération/Ressamblage a échoué, veuillez recommancer '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                        
                                                try:
                                                    pass

                                                    #discourantt=os.path.dirname(__file__)
                                                    #disprodd=os.path.join(discourantt,"ftx",nomaff)
                                                    #imgexpert.background_normal= disprodd + ".jpg"

                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors du chargement de la photo'),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            
                                            kj+=1
                                        else:
                                            kj=0
                                        
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)  

                                elif genre=='madame':
                                    
                                    compfois +=1
                                    indicdmad= random.randint(0,3)
                                    listefemme=['Desolé Monsieur/Madame, je suis très inquiet de m avoir confondu  à une femme car une femme ne peut pas raisonner comme moi, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Wouaw !!! Monsieur/Madame, sur quel plan tu peux m accorder cette humilliation, je suis inconsolable de m avoir egalisé à une femme car une femme est une être reputée en incomprehension et impossible d imaginer meme me comparer avec elle, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Incroyable Monsieur/Madame, je ne suis pas d hummeur de m avoir confondu  à une femme car si j etais une femme, je ne pouvais pas meme te repondre à ce temps, de grace, je souhaite une considération de ta part, cela pourra me motiver et me donner la conviction de vous repondre favorablement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Merde !! Monsieur/Madame par quelle concentement tu peux me manquer ainsi ??, je suis très inquiet de m avoir rapproché  à une femme car une femme ne peut pas prendre en charge tous ce que je fais, de grace, j aime une considération de ta part, cela pourra me pousser et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ']
                                    mot=listefemme[indicdmad]

                                    #print(compfois)

                                    if compfois==4:
                                        pass  # arreter la machine ici

                                    affresultat.text = ""
                                    l = 0
                                    lcont=0

                                    Clock.schedule_interval(self.affpas_a_pas, 0.1) 
                            else:
                                indicdmad= random.randint(0,3)
                                listefemme=['Wouw!!! Desolé Madame/Monsieur, au nom de la politesse à cette heure, il sied de se dire "Bonsoir" avant d aborder n importe quel probleme','Wouff !! Vraiment Madame/Monsieur, tu es serieux(se) de me donner une salutation à cette heure si c n est "Bonsoir" en terme de la politesse ?? ','Inconcevable Madame/Monsieur, comment tu veux supposer m aborder avec une salutation à cette heure si ce n est pas  "Bonsoir"','Ahh !! non pardon cher (e) Monsieur/Madame !! j ai droit à etre salué avant de tenir n importe quel discussion à ma personnalité, NB: à cette heure j attend rien d autre que  "Bonsoir']
                                mot=listefemme[indicdmad]

                                affresultat.text = ""
                                l = 0
                                lcont=0

                                Clock.schedule_interval(self.affpas_a_pas, 0.1)
                                
                        else:
                            pass
                    else:

                        btss=Builder.load_string('''
Button:
    text:'Simulateur Introuvable!!'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]                        
                        ''')
                        msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(1,.5))
                        msg.open()

                else:

                    btss=Builder.load_string('''
Button:
    text:'Genre Introuvable!!'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]                        
                        ''')
                    msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(1,.5))
                    msg.open()
                    

            else:
                btss=Builder.load_string('''
Button:
    text:'Salutation Introuvable!!'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]                        
                        ''')
                msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(1,.5))
                msg.open()
        except:
            btss=Builder.load_string('''
Button:
    text:'Error inattendue !'
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]                        
                        ''')
            msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(1,.5))
            msg.open()
    

    
    def actualisergeneration(self,instance):
        global listplainte,kj

        listplainte=[]
        kj=0

        affresultat.text=""
        texp1.text=""

        #bgenererresulat.background_color="seagreen"
        labcompteur.text=""


        try:
            cadreexpert.remove_widget(btsuitegenAI)
        except:
            pass
    
    def generesultatsuite(self,instance):
        global repsuite,debsessionheure

        listventeindividual=[]

        if instance.text=='[b]Oui[/b]':

            try:
                self.cconnexion()
                cursor=con.cursor()
                query="insert into controleur(id,datess,debut,finn) values(%s,%s,%s,%s)"
                dataa=(tidconn.text,datetime.now().strftime('%Y-%m-%d'),debsessionheure,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                cursor.execute(query,dataa)
                con.commit()
                #self.cursor.close()
                con.close()

                l1=1

            except:

                l1=0
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees au controleur systeme'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                cursor=con.cursor()
                cursor.execute("delete from session where ids='"+tidconn.text+"'")
                con.commit()
                #self.cursor.close()
                con.close()

                l2=1
            except:

                l2=0
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue car la session n a été supprimée comme prevue'),size_hint=(None, None), size=(400,200))
                msg.open()
            
            instance.text=='[b]Suite[/b]'

            try:
                cadre.remove_widget(instance)
            except:
                pass

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from achat where id_travailleur='"+ tidconn.text +"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                listventeindividual=self.cursor.fetchall()
                #self.cursor.close()
                con.close()

                self.exportateurvente("VENTE INDIVIDUELLE DES PRODUITS ",listventeindividual)

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                msg.open()


            if l1==1 and l2==1:
                self.stop()
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text=' Erreur a été captée, c est une erreur qui cadre avec la fermeture de la session '),size_hint=(None, None), size=(400,200))
                msg.open()
 
        else:

            repsuite=1
            affresultat.text=''

            try:
                cadre.remove_widget(instance)
            except:
                pass

            Clock.schedule_interval(self.affpas_a_pas, 0.1)



    def deconnverfie(self,instance):
        global sepp,msgdec


        try:
            msgdec.dismiss()
        except:
            pass

        
        v2=0

        if tabvente1.row_data:
            v2=1

            lbnomdec=Label(text="[b]Impossible de deconnecter car \nle coupon dispose les données\n non sauvegardées  [b]",font_size='13sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.98,0.6),markup=True)
        
        if v2==1:
            cadd=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

            bbval1dec=Builder.load_string('''
Button:
    text:"[b]Close[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.07}
    size_hint:0.25,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
            ''')

            bbval1dec.bind(on_release=lambda x: msggb.dismiss())

            try:
                cadd.add_widget(bbval1dec)
                cadd.add_widget(lbnomdec)

                msggb=Popup(title="CONTROLEUR SYSTEME",content=cadd,size_hint=(1,.5))
                msggb.open()

            except:
                pass
        else:

            try:
        
                self.cconnexion()
                cursor=con.cursor()
                cursor.execute("delete from session where ids='"+tidconn.text+"'")
                con.commit()
                #self.cursor.close()
                con.close()


                tpwd.text=""
               
                try:
                    cadre.add_widget(cadepageconnexion)
                except:
                    pass

                try:
                    cadre.remove_widget(cadrevente)
                except:
                    pass

                try:
                    cadre.remove_widget(bvente)
                except:
                    pass
                try:
                    cadre.remove_widget(bjournal)
                except:
                    pass
                try:
                    cadre.remove_widget(bexpert)
                except:
                    pass
                try:
                    cadre.remove_widget(labtitre)
                except:
                    pass

                try:
                    cadre.remove_widget(ic1)
                    cadre.remove_widget(ic2)
                except:
                    pass
            

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(1,.4))
                msg.open()



    def deconnexion(self,instance):

        global msgdec,msggsetting

        try:
            msggsetting.dismiss()
        except:
            pass

        cadddec=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

        lbnomdec=Label(text="[b]Voulez-vous vraiment \nvous deconnecter?[b]",font_size='14sp',pos_hint={'center_x':0.5,'center_y':0.5},color='black',markup=True,size_hint=(1,.4))
        
        bbval1dec=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'center_y':0.1}
    size_hint:0.25,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')
        
        bbval1dec.bind(on_release=self.deconnverfie)#deconnok)

        bbval2dec=Builder.load_string('''

Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.05,'center_y':0.1}
    size_hint:0.25,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        
        ''')
        
        bbval2dec.bind(on_release=lambda x:msgdec.dismiss())

        cadddec.add_widget(lbnomdec)
        cadddec.add_widget(bbval1dec)
        cadddec.add_widget(bbval2dec)

        msgdec=Popup(title="NOTIFICATION",content=cadddec,size_hint=(1,.5))
        msgdec.open()


    def pagevente(self):

        try:
            cadre.remove_widget(cadepageconnexion)
        except:
            pass

        try:
            cadre.add_widget(cadrevente)
        except:
            pass

        try:
            cadre.add_widget(bvente)
        except:
            pass
        try:
            cadre.add_widget(bjournal)
        except:
            pass
        try:
            cadre.add_widget(bexpert)
        except:
            pass
        try:
            cadre.add_widget(labtitre)
        except:
            pass

        try:
            cadre.add_widget(ic1)
            cadre.add_widget(ic2)
        except:
            pass



    def camparersecurite(self,instance):
        #datancienne='0000-00-00 00:00:00'
        
        global pwdvrai,idmach,tlicence

        datecontrol='0000-00-00'
     
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select datess from controleur where id='"+ tidconn.text +"'")
            contro=self.cursor.fetchone()
           # self.cursor.close()
            con.close()
            

            if contro:
                datecontrol=str(contro[0])

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la verification via le controleur\n Vuillez redemarrer le systeme pour corriger les erreurs'),size_hint=(None, None), size=(400,200))
            msg.open()

        
        try:

            if datecontrol == '0000-00-00' or datecontrol < datetime.now().strftime('%Y-%m-%d'):

                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("delete from controleur where id='"+ tidconn.text +"'")
                    con.commit()
                  #  self.cursor.close()
                    con.close()
                    

                except:
                    pass
                
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select ddats from commande where etat='1'")
                    resuu=self.cursor.fetchone()
                   # self.cursor.close()
                    con.close()
                    if resuu:
                        datancienne=str(resuu[0])

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                    msg.open()
                    
                try:

                    if datancienne < datetime.now().strftime('%Y-%m-%d %H:%M:%S'):
                        
                        
                        try:
                            self.cconnexion()
                            cursor=con.cursor()
                            query="update commande set ddats=%s,borne=%s where etat=%s"
                            cursor.execute(query,(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d'),'1'))
                            con.commit()
                            #self.cursor.close()
                            con.close()

                            if tidconn.text=="" or tpwd.text=="":

                                btxx=Builder.load_string('''
                                
Button:
    background_color:[0,0,0,0]
    color:'black'
    font_size:'12sp'
                                                         
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
   ''')
                                btxx.text="Saisie erronnée "

                                msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(1,.4))
                                msg.open()

                            else:
                                pwdvrai=""
                                idmach=""
                                content=""

                                
                                try:
                                    self.cconnexion()
                                    self.cursor=con.cursor()
                                    self.cursor.execute("select pwd from compte where id='"+tidconn.text+"'and type='user'")
                                    results=self.cursor.fetchone()
                                    #self.cursor.close()
                                    con.close()
                                    if results:
                                        pwdvrai=str(results[0])
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                    msg.open()

                                try:
                                    self.cconnexion()
                                    self.cursor=con.cursor()
                                    self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                    ress=self.cursor.fetchone()
                                   # self.cursor.close()
                                    con.close()
                                    if ress:
                                        idmachine=str(ress[0])
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                    msg.open()
                                
                                try:
                                    idmach=str(idmachine)
                                except:
                                    pass

                                datnow=datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                                if idmach=="":
                                    try:
                                    
                                        try:
                                            if pwdvrai==tpwd.text:

                                                with open('xy.txt','w') as file:
                                                    file.write(str(datnow))

                                                try:
                                                    self.cconnexion()
                                                    cursor=con.cursor()
                                                    query="insert into session(ids,date_tim) values(%s,%s)"
                                                    cursor.execute(query,(tidconn.text,datnow))
                                                    con.commit()
                                                 #   self.cursor.close()
                                                    con.close()
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                               
                                                self.pagevente()

                                                
                                            else:

                                                btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                                                btdxx.text='Mot de passe incorrect '

                                                msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                                                msg.open()

                                                
                                                tpwd.text=""
                                                tidconn.text=""

                                        except:

                                            btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                                            btdxx.text='Erreur survenue '

                                            msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                                            msg.open()
                                           
                                    except:

                                        btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                                        btdxx.text='Erreur survenue '

                                        msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                                        msg.open()
                                        
                                else:
                                    try:
                                        with open('xy.txt','r') as fil:
                                            content=fil.read()
                                    except:
                                        pass
                                        
                                    if content==idmach:
                                        
                                        self.pagevente()
                                    else:
                                        
                                        btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                                        btdxx.text='Desolé car cet ID a deja sa session ouverte '

                                        msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                                        msg.open()
                        except:
                            
                            btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                            btdxx.text='ERROR '

                            msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                            msg.open()
                            
                    else: 

                        btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                        btdxx.text='L horloge  n est pas à jour\nveuillez bien regler la date et l heure\npuis ressayer plus tard '

                        msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                        msg.open()
                       
                except:

                    btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
                                              
    font_size:'12sp'
                                              
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                    btdxx.text='Erreur survenue, veuillez ressayer plus tard'

                    msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                    msg.open()
         
            else:

                btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
    font_size:'12sp'
                                          
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

                btdxx.text='Ce travailleur a été supposé cloturé\nses activités du jour Veuillez venir\ndemain Stp !!'

                msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
                msg.open()
                

        except:

            btdxx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    bold:True
    color:'black'
    font_size:'12sp'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]    
            
            ''')

            btdxx.text='La comparaison de données a echoué !!\nVeuillez redemarrer si ca persite !'

            msg=Popup(title="STATUT REQUETE",content=btdxx,size_hint=(1,.5))
            msg.open()
    

    def corrigerreur(self,instance):
    
        global msggsetting

        try:
            msggsetting.dismiss()
        except:
            pass
        
        i=0

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select matricule from produit,achat where matricule=ID_Produit and id_travailleur='"+tidconn.text+"'")
            listmatriculeprod=self.cursor.fetchall()
            self.cursor.close()
            con.close()

            for i in range(len(listmatriculeprod)):
                qtproduit=None
                differencee=None

                idprod=str(listmatriculeprod[i]).replace("('","").replace("',)","")

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(Qte),stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                resultats=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if resultats:
                    qtproduit=resultats[0]
                    differencee=resultats[1]

                    self.cconnexion()
                    cursor=con.cursor()
                    query="update produit set stock_p=%s where matricule=%s"
                    cursor.execute(query,(differencee,idprod))
                    con.commit()
                    self.cursor.close()
                    con.close()

            
            btx=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    color:'black'
    bold:True
    text:'Correction realisée avec succes'

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
            
            ''')

            msg=Popup(title="STATUT REQUETE",content=btx,size_hint=(1,.5))
            msg.open()
            
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue'),size_hint=(1,.4))
            msg.open()


    def televersersignal(self,instance,value):
        global idprodmotif
        
        idprodmotif.text=instance.text
    
    def rechsignalproblem(self,instance):
        global idprodmotif

        if idprodmotif.text=="":
            pass
        else:
            instance.values=""
            
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select nom from produit where nom LIKE'%"+idprodmotif.text+"%'")
                results=self.cursor.fetchall()
                #self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()

    def soumettre(self,instance):
        global combmotif,msgmotif,idprodmotif,ptmotif

        detailfin=""

        if instance.text=="[b]Terminez[/b]":
            msgmotif.dismiss()
        else:
            if textdetailmotif.text=="Le detail du motif stp !!" or textdetailmotif.text=="":
                pass
            else:

                detailfin= textdetailmotif.text +" Réf_Produit: "+idprodmotif.text

                if combmotif.text =="Autres":
                    try:

                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                        cursor.execute(query,(combmotif.text,textdetailmotif.text,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),0))
                        con.commit()
                       # self.cursor.close()
                        con.close()

                        if query:

                            instance.text="[b]Terminez[/b]"

                            idprodmotif.text=""
                            ptmotif.text=""
                            textdetailmotif.text=""

                    except:
                        instance.text="[b]Error[/b]"

                elif combmotif.text=="Sortie argent":

                    try:
                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                        cursor.execute(query,(combmotif.text,textdetailmotif.text,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),int(ptmotif.text)))
                        con.commit()
                        #self.cursor.close()
                        con.close()

                        if query:

                            instance.text="[b]Terminez[/b]"
                            idprodmotif.text=""
                            ptmotif.text=""
                            textdetailmotif.text=""

                    except:
                        instance.text="[b]Error[/b]"

                else:

                    idmotifin=None

                    self.cconnexion()
                    cursor=con.cursor()
                    query="select nom from produit where nom='"+idprodmotif.text+"'"
                    cursor.execute(query)
                    resultsmotif=cursor.fetchone()
                    #self.cursor.close()
                    con.close()
                    if resultsmotif:
                        idmotifin=resultsmotif[0]

                        if combmotif.text=="Retournement":

                            try:
                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                                cursor.execute(query,(combmotif.text,detailfin,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),int(ptmotif.text)))
                                con.commit()
                               # self.cursor.close()
                                con.close()

                                if query:

                                    instance.text="[b]Terminez[/b]"
                                    idprodmotif.text=""
                                    ptmotif.text=""
                                    textdetailmotif.text=""

                            except:
                                instance.text="[b]Error[/b]"

                        elif combmotif.text=="Rupture":
                            try:
                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                                cursor.execute(query,(combmotif.text,detailfin,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),(0)))
                                con.commit()
                                #self.cursor.close()
                                con.close()

                                if query:

                                    instance.text="[b]Terminez[/b]"
                                    idprodmotif.text=""
                                    ptmotif.text=""
                                    textdetailmotif.text=""

                            except:
                                instance.text="[b]Error[/b]"

                    else:
                        idprodmotif.line_color_normal='red'
                        idprodmotif.focus=True

    def checkmotif(self,instance,value):
        global combsigale

        if instance.text =="Autres":
            try:
                cadclos.remove_widget(combsigale)
            except:
                pass

            try:
                cadclos.add_widget(textdetailmotif)
            except:
                pass

            try:
                cadclos.remove_widget(ptmotif)
            except:
                pass

            try:
                cadclos.remove_widget(idprodmotif)
            except:
                pass
 
        elif instance.text=="Retournement":
            try:
                cadclos.add_widget(combsigale)
            except:
                pass

            try:
                cadclos.add_widget(ptmotif)
            except:
                pass

            try:
                cadclos.add_widget(idprodmotif)
            except:
                pass
        
        elif instance.text=="Sortie argent":
            try:
                cadclos.remove_widget(combsigale)
            except:
                pass

            try:
                cadclos.add_widget(ptmotif)
            except:
                pass

            try:
                cadclos.remove_widget(idprodmotif)
            except:
                pass
        elif instance.text=="Rupture":
            try:
                cadclos.add_widget(combsigale)
            except:
                pass

            try:
                cadclos.remove_widget(ptmotif)
            except:
                pass

            try:
                cadclos.add_widget(idprodmotif)
            except:
                pass
    

    def rechmotif(self,instance):
        global combmotif

        combmotif.values=''

        combmotif.values.append("Rupture")
        combmotif.values.append("Retournement")
        combmotif.values.append("Sortie argent")
        combmotif.values.append("Autres")


    def resetdetail(self,instance,value):

        if instance.text=="Le detail du motif stp !!":
            instance.text=""
    
    def clearprod(self,instance,value):
        if instance.text !="":
            instance.hint_text=""
    
    def clearmontant(self,instance,value):

        if instance.text !="":
            instance.hint_text=""

    def signeprobleme(self,instance):
        global cadclos,textdetailmotif,idprodmotif,ptmotif,bnmotifs,combmotif,msgmotif, combsigale

        global msggsetting

        try:
            msggsetting.dismiss()
        except:
            pass


        cadclos=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10,10,1,1]
                                    
        ''')
        tabclos=MDDataTable(column_data=[], row_data=[],size_hint=(0.6,0.1),pos_hint={'x':0.2,'y':0.85})

        labchek=Label(text="[b]SIGNAL PROBLEME[/b]",markup=True,color='red',pos_hint={'center_x':0.5, 'y':0.9},font_size='15sp',size_hint=(0.15,0.1))                  

        lb=Label(text="[b]Motif[/b]",markup=True,font_size='13sp',pos_hint={'x':0.2,'y':0.72},color='black',size_hint=(0.1,0.08))
        
        combmotif=Builder.load_string('''
Spinner:
    text:"[b]Choisir[/b]"
    markup:True
    pos_hint:{'x':0.4, 'y':0.72}
    size_hint:0.55,0.12
    background_color:[0,0,0,0]
    color:"white"
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')
        
        combmotif.bind(on_release=self.rechmotif)
        combmotif.bind(text=self.checkmotif)

        textdetailmotif=TextInput(text="Le detail du motif stp !!",size_hint=(0.9,0.3),pos_hint={'center_x':0.5, 'y':0.35},font_size='15sp')
        textdetailmotif.bind(focus=self.resetdetail)

        idprodmotif=MDTextField(hint_text="PRODUIT",icon_right='text',line_color_normal='black', font_size='11sp', size_hint=(0.4,0.1),pos_hint={'x':0.05,'y':0.1})
        idprodmotif.bind(focus=self.clearprod)

        ptmotif=MDTextField(hint_text="MONTANT",icon_right='spider',line_color_normal='black', font_size='11sp', size_hint=(0.4,0.1),pos_hint={'x':0.55,'y':0.1})
        ptmotif.bind(focus=self.clearmontant)
        bnmotifs=Builder.load_string('''
Button:
    text:"[b]Soumettre[/b]"
    markup:True
    font_size:'13sp'
    size_hint:0.35,0.11
    pos_hint:{'x':0.6,'y':.03}
    background_color:[0,0,0,0]
    color:"white"
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')
        
        bnmotifs.bind(on_release=self.soumettre)

        combsigale=Builder.load_string('''
Spinner:
    text:"Choisir"
    font_size:'11sp'
    pos_hint:{'x':0.05, 'y':.03}
    size_hint:0.4,0.11
        
    background_color:[0,0,0,0]
    color:"white"
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')
        
        combsigale.bind(on_release=self.rechsignalproblem)
        combsigale.bind(text=self.televersersignal)
    
        try:
            cadclos.add_widget(labchek)
            #cadclos.add_widget(tabclos)
            cadclos.add_widget(lb)

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,20))
            msg.open()
        
        try:
            cadclos.add_widget(bnmotifs)
        except:
            pass

        try:
            cadclos.add_widget(combmotif)
        except:
            pass
        try:
            cadclos.add_widget(textdetailmotif)
        except:
            pass

        msgmotif=Popup(title="CAHIER D'INFORMATION",content=cadclos,size_hint=(1,.6))
        msgmotif.open()

    def contactprogrammeur(self,instance):
        
        global msggsetting

        try:
            msggsetting.dismiss()
        except:
            pass


        cadclos=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10,10,1,1]
        
        
        ''')
        lb=Label(text="[b]Contact rapide du programmeur : \nWatsapp:0970494397\nTel:0823382732\nGmail:askyas17@gmail.com[/b]",markup=True,font_size='11sp',pos_hint={'center_x':0.5,'center_y':0.5},color='black',size_hint=(0.98,0.3))
        
        tabclos=MDDataTable(column_data=[], row_data=[],size_hint=(0.6,0.1),pos_hint={'x':0.2,'y':0.8})

        labchek=Label(text="[b]CONTACT DU PROGRAMMEUR[/b]",markup=True,color='red',pos_hint={'center_x':0.5, 'y':0.8},font_size='12sp',size_hint=(0.8,0.1))                  
        
       

        try:
            cadclos.add_widget(labchek)
           
            cadclos.add_widget(lb)
        
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text=' Error '),size_hint=(1,.5))
            msg.open()

        msg=Popup(title="INFO FOR ENGINNER PROGRAMMING",content=cadclos,size_hint=(1,.5))
        msg.open()


    def openprisecharge(self,instance):
        global cadprisecharge
        global msggsetting

        try:
            msggsetting.dismiss()
        except:
            pass

        try:
            cadprisecharge.remove_widget(cadreprischarge)
        except:
            pass

        cadprisecharge=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')
        #btest.bind(on_release=self.deconnexion) 

        btclosprisecharge=Builder.load_string('''
MDIconButton:
    icon:'close-circle'
    text_color:'red'
    theme_text_color:'Custom'
    size_hint:.1,.05
    pos_hint:{'x':0.85, 'y':0.95}
                                        
''')
        btclosprisecharge.bind(on_release=lambda x:msssopen.dismiss())       

        try:
            cadprisecharge.add_widget(btclosprisecharge)
        except:
            pass
    
        cadreprischarge.size_hint=(1,1)

        

        try:
            cadprisecharge.add_widget(cadreprischarge)
        except:
            pass


        msssopen=Popup(title="PRISE EN CHARGE",content=cadprisecharge,size_hint=(1,1))
        msssopen.open()

    def affichpriseudirecte(self,instance,value):

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select * from prisecharge where gmail='"+instance.text+"' order by dates DESC"
            cursor.execute(query)
            results=cursor.fetchall()
            #self.cursor.close()
            con.close()

            tablprise.row_data=results
        except:
            pass



    def chargegmailprise(self,instance):
        global trechlike

        if trechlike.text=="":
            pass
        else:
            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct gmail from prisecharge where gmail LIKE'%"+trechlike.text+"%'"
                cursor.execute(query)
                results=cursor.fetchall()
             #   self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()


    def recherchepriseudirecte(self,instance):
        global trecherup

        try:

            instance.values=""

            self.cconnexion()
            cursor=con.cursor()
            query="select distinct gmail from prisecharge where gmail LIKE'%"+trecherup.text+"%'"
            cursor.execute(query)
            results=cursor.fetchall()
            #self.cursor.close()
            con.close()

            for el in results:
                instance.values.append(str(el).replace("('","").replace("',)",""))
        except:
            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
            msg.open()

    
    def deplfocusprise1(self,instance):

        tprise2.focus=True

    def deplfocusprise2(self,instance):

        tprise3.focus=True
    
    def deplfocusprise3(self,instance):

        tprisee1.focus=True
    
    def deplfocusprise4(self,instance):

        tprisee2.focus=True

    def deplfocusprise5(self,instance):

        tprisee3.focus=True


    def affichprise(self):
        tablprise.row_data=[]

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select * from prisecharge order by dates DESC limit 10"
            cursor.execute(query)
            results=cursor.fetchall()
            #self.cursor.close()
            con.close()

            tablprise.row_data=results
        except:
            pass

    def affinfoprise(self,instance_table,current_row):
        identid=""
        try:
            identid=str(current_row[0])
            self.cconnexion()
            cursor=con.cursor()
            query="select gmail,nom,prenom,sexe,tel,adresse,dates from prisecharge where gmail='"+identid+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            #self.cursor.close()
            con.close()
            if results:
                
                tprise1.text=str(results[0])
                tprise2.text=str(results[1])
                tprise3.text=str(results[2])
                tprisee3.text=str(results[3])
                tprisee1.text=str(results[4])
                tprisee2.text=str(results[5])

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        btsavprise.text="[b]Modifier[/b]"

    def savepreisecharge(self,instance):

        if tprise1.text=="" or tprise2.text=="" or tprise3.text=="" or tprisee3.text=="" or tprisee1.text=="" or tprisee2.text=="":

            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Aucun champ ne doit etre vide !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
            msg.open() 
        
        else:

            if btsavprise.text=="[b]Enregistrer[/b]":

                try:

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into prisecharge(gmail,nom,prenom,sexe,tel,adresse,dates,trav) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                    cursor.execute(query,(tprise1.text,tprise2.text,tprise3.text,tprisee3.text,tprisee1.text,tprisee2.text,datetime.now().strftime('%Y-%m-%d'),tidconn.text))
                    con.commit()
                  #  self.cursor.close()
                    con.close()

                    tprise1.text=""
                    tprise2.text=""
                    tprise3.text=""
                    tprisee3.text=""
                    tprisee1.text=""
                    tprisee2.text=""

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Save Succeful !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()


                except:

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()

            elif btsavprise.text=="[b]Modifier[/b]":
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update prisecharge set nom=%s,prenom=%s,sexe=%s,tel=%s,adresse=%s,dates=%s,trav=%s where gmail=%s"
                    cursor.execute(query,(tprise2.text,tprise3.text,tprisee3.text,tprisee1.text,tprisee2.text,datetime.now().strftime('%Y-%m-%d'),tidconn.text,tprise1.text))
                    con.commit()
                 #   self.cursor.close()
                    con.close()

                    tprise1.text=""
                    tprise2.text=""
                    tprise3.text=""
                    tprisee3.text=""
                    tprisee1.text=""
                    tprisee2.text=""

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Save Succeful !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()

                except:

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()   

            self.affichprise() 
    
    def rechidpresc(self,instance):

        instance.text="Chosir"

        if trechpresc1.text=="":
            pass
        else:
            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct id_prise from prescription where id_prise LIKE'%"+trechpresc1.text+"%'"
                cursor.execute(query)
                results=cursor.fetchall()
                #self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()

    def affrecid(self,instance,value):

        tablprescription.row_data=[]

        if suitmodrap.active==True:
            pass
        else:
            
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat and id_prise='"+instance.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
               # self.cursor.close()
                con.close()

                tablprescription.row_data=results
                
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()

    def rechdatepresc(self,instance):

        instance.text="Chosir"

        if combpresc1.text=="":
            pass
        else:

            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct datees from prescription where id_prise ='"+combpresc1.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
                datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
               # self.cursor.close()
                con.close()

                for el in datat:
                    instance.values.append(str(el))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
    
    def affrecdate(self,instance,value): 

        tablprescription.row_data=[]

        if suitmodrap.active==True:
            pass
        else:
            
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat and id_prise='"+combpresc1.text+"' and datees='"+instance.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
              #  self.cursor.close()
                con.close()

                tablprescription.row_data=results
                
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
        
    def rechfacturepresc(self,instance):

        instance.text="Chosir"

        if combpresc2.text=="":
            pass
        else:

            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct id_achat from prescription where datees ='"+combpresc2.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
             #   self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
    
    def affrecfacture(self,instance,value):

        tablprescription.row_data=[]
            
        try:
            self.cconnexion()
            cursor=con.cursor()
            query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat and id_prise='"+combpresc1.text+"' and datees='"+combpresc2.text+"' and id_achat='"+instance.text+"'"
            cursor.execute(query)
            results=cursor.fetchall()
            #self.cursor.close()
            con.close()

            tablprescription.row_data=results
            
        except:
            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
            msg.open()

    def PrescriptionPage(self,instance):

        if tablprescription.row_data==[]:

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat order by datees DESC limit 10"
                cursor.execute(query)
                results=cursor.fetchall()
               # self.cursor.close()
                con.close()

                tablprescription.row_data=results
            except:
                pass   

        try:
            cadreprischarge.add_widget(cadresuitcmoderap)
            cadreprischarge.add_widget(labmodrap)
        except:
            pass

        try:
            cadreprischarge.add_widget(trechpresc1)
            cadreprischarge.add_widget(trechpresc2)
            cadreprischarge.add_widget(trechpresc3)

            cadreprischarge.add_widget(combpresc1)
            cadreprischarge.add_widget(combpresc2)
            cadreprischarge.add_widget(combpresc3)

            cadreprischarge.add_widget(tablprescription)
            
        except:
            pass

        try:
            cadreprischarge.remove_widget(tprise3)
            cadreprischarge.remove_widget(tprise2)
            cadreprischarge.remove_widget(tprise1)

            cadreprischarge.remove_widget(tprisee3)
            cadreprischarge.remove_widget(tprisee2)
            cadreprischarge.remove_widget(tprisee1)

            cadreprischarge.remove_widget(btsavprise) 
            cadreprischarge.remove_widget(labupdatpris)
            cadreprischarge.remove_widget(cadresuitchmorr)

            cadreprischarge.remove_widget(tablprise) 

        except:
            pass

        btbasss1.color='black'
        instance.color='blue'

    def inscriptionPage(self,instance):

        try:
            cadreprischarge.add_widget(tprise3)
            cadreprischarge.add_widget(tprise2)
            cadreprischarge.add_widget(tprise1)

            cadreprischarge.add_widget(tprisee3)
            cadreprischarge.add_widget(tprisee2)
            cadreprischarge.add_widget(tprisee1)

            cadreprischarge.add_widget(btsavprise) 
            cadreprischarge.add_widget(labupdatpris)
            cadreprischarge.add_widget(cadresuitchmorr)

            cadreprischarge.add_widget(tablprise) 

        except:
            pass

        
        try:
            cadreprischarge.remove_widget(cadresuitcmoderap)
            cadreprischarge.remove_widget(labmodrap)
        except:
            pass
        

        try:
            cadreprischarge.remove_widget(trechpresc1)
            cadreprischarge.remove_widget(trechpresc2)
            cadreprischarge.remove_widget(trechpresc3)

            cadreprischarge.remove_widget(combpresc1)
            cadreprischarge.remove_widget(combpresc2)
            cadreprischarge.remove_widget(combpresc3)

            cadreprischarge.remove_widget(tablprescription)
        except:
            pass

        btbasss2.color='black'
        instance.color='blue'

    def changebtnprise(self,instance):

        global trecherup

        if instance.active==True:

            btsavprise.text="[b]Modifier[/b]"

            cad=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')

            trecherup=MDTextField(hint_text='Recherche',pos_hint={'x':.05,'center_y':.5},size_hint=(.4,.2))

            comb=Builder.load_string('''
Spinner:
    text:"[b]Choisir[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.55,'center_y':0.5}
    size_hint:(0.4,0.15)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
''')
            comb.bind(on_release=self.recherchepriseudirecte)
            comb.bind(text=self.affichpriseudirecte)

            bb1=Builder.load_string('''
Spinner:
    text:"[b]Close[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.1}
    size_hint:(0.25,0.15)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
''')        
            bb1.bind(on_release=lambda x:msg.dismiss())
            
            try:
                cad.add_widget(comb)
                cad.add_widget(bb1) 
                cad.add_widget(trecherup)
                
                msg=Popup(title="Recherche",content=cad,size_hint=(1, .5))
                msg.open()

            except:
                pass


        else:
            btsavprise.text="[b]Enregistrer[/b]"
    

    def cleatextserver(self,instance,value):

        if instance.text=="Adresse":

            instance.text=""

    def commuterqrcode(self,instance):

        if instance.text=="Qr-Code":
            
            try:
                cadconnBd.add_widget(btcamera1)
                cadconnBd.add_widget(btcamera2)
                cadconnBd.add_widget(camera)
            except:
                pass
            
            try:
                cadconnBd.remove_widget(tadr)
                cadconnBd.remove_widget(btserver)
            except:
                pass

            instance.text="Adresse"

        elif instance.text=="Adresse":

            try:
                cadconnBd.add_widget(tadr)
                cadconnBd.add_widget(btserver)
            except:
                pass
            
            try:
                cadconnBd.remove_widget(btcamera1)
                cadconnBd.remove_widget(btcamera2)
                cadconnBd.remove_widget(camera)
            except:
                pass
            
                
            instance.text="Qr-Code"


    def on_symbols(self,instance,symbols):
        global adrip,etatconn
        global datat,newpho,imgproduit
            
        if not symbols=="":
            
            for symbol in symbols:
                datat=str(symbol.data.decode())
                if datat=="":
                    
                    pass

                else:
                    adrip=datat

                    self.cconnexion()

                    if etatconn==1:
                        
                        try:
                            cadre.add_widget(cadepageconnexion)
                            cadre.remove_widget(cadconnBd)
                        except:
                            pass
                    

    def testerserver(self,instance):
        global adrip, con,etatconn

        adrip=tadr.text

        
        self.cconnexion()

        bb1=Builder.load_string('''
Spinner:
    text:"[b]Succeful Server!![/b]"
    background_color:[0,0,0,0]
    markup:True
    color:'black'
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')
        

        if etatconn==1:

            try:
                cadre.add_widget(cadepageconnexion)
                cadre.remove_widget(cadconnBd)
            except:
                pass 

        else:
            bb1.text='[b]Serveur Injoignable ![/b]'

            msgb=Popup(title="Connexion",content=bb1,size_hint=(1,.5))
            msgb.open()

    def cconnexion(self):
        global con,choixconn,adrip,etatconn

        adrip=adrip.replace("@",".").replace("w","1")

        try:
            con=mysql.connector.connect(
            host=adrip,
            #"localhost",
            user="askyas",
            password="askyas",
            database="pharma"
            )

            etatconn=1

            return con

        except:

            bterr=Builder.load_string('''
Button:
    text:'Serveur Injoignable'
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color: 
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
            
''')
            msg=Popup(title="STATUT CONNEXION",content=bterr,size_hint=(1,.4))
            msg.open()


Pharma().run()