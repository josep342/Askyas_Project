-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mer 27 Novembre 2024 à 05:29
-- Version du serveur: 5.6.12-log
-- Version de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `pharma`
--
CREATE DATABASE IF NOT EXISTS `pharma` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pharma`;

-- --------------------------------------------------------

--
-- Structure de la table `achat`
--

CREATE TABLE IF NOT EXISTS `achat` (
  `ID_Produit` varchar(31) NOT NULL,
  `PU` double(15,0) NOT NULL,
  `Qte` int(11) NOT NULL,
  `PT` double(15,0) NOT NULL,
  `Nom_client` varchar(20) NOT NULL,
  `Dates` date NOT NULL,
  `Dats_id` datetime NOT NULL,
  `id_travailleur` varchar(11) NOT NULL,
  PRIMARY KEY (`ID_Produit`,`PU`,`Qte`,`PT`,`Nom_client`,`Dats_id`,`id_travailleur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `achat`
--

INSERT INTO `achat` (`ID_Produit`, `PU`, `Qte`, `PT`, `Nom_client`, `Dates`, `Dats_id`, `id_travailleur`) VALUES
('10', 12500, 2, 25000, 'junior', '2024-10-23', '2024-10-23 16:21:32', '00033'),
('10', 12500, 3, 37500, 'junior', '2024-10-23', '2024-10-23 16:21:32', '00033'),
('10', 14000, 1, 14000, 'junio', '2024-11-16', '2024-11-16 13:07:46', '00033'),
('10', 14000, 2, 28000, 'askyasdev@gmail.com', '2024-11-16', '2024-11-16 07:42:46', '00033'),
('10', 14000, 7, 98000, 'askyas2001@gmai', '2024-10-29', '2024-10-29 13:11:01', '00033'),
('10', 14250, 1, 14250, 'junior', '2024-10-20', '2024-10-20 08:27:36', '00033'),
('10', 14250, 1, 14250, 'kkk', '2024-10-21', '2024-10-21 17:34:44', '00033'),
('10', 14250, 2, 28500, 'askyas2001@gmai', '2024-10-21', '2024-10-21 18:14:21', '00033'),
('10', 14250, 2, 28500, 'junior', '2024-10-21', '2024-10-21 14:47:57', '00033'),
('10', 14250, 2, 28500, 'junior', '2024-10-21', '2024-10-21 18:01:18', '00033'),
('10', 14250, 2, 28500, 'junior', '2024-10-21', '2024-10-21 18:12:05', '00033'),
('10', 14250, 2, 28500, 'kkk', '2024-10-21', '2024-10-21 14:48:52', '00033'),
('10', 14250, 3, 42750, 'askyas', '2024-10-20', '2024-10-20 08:30:26', '00033'),
('10', 14250, 3, 42750, 'askyas2001@gmai', '2024-10-21', '2024-10-21 18:23:10', '00033'),
('10', 14250, 3, 42750, 'askyasdev@gmail', '2024-10-21', '2024-10-21 18:17:36', '00033'),
('10', 14250, 3, 42750, 'junior', '2024-10-20', '2024-10-20 08:27:36', '00033'),
('10', 14250, 4, 57000, 'askyas', '2024-10-20', '2024-10-20 08:30:26', '00033'),
('10', 14250, 5, 71250, 'ddd', '2024-10-21', '2024-10-21 17:58:53', '00033'),
('10', 14250, 6, 85500, 'askyas2001@gmai', '2024-10-21', '2024-10-21 17:30:50', '00033'),
('100', 18760, 1, 18760, 'askyas201@gmail.com', '2024-11-14', '2024-11-14 16:54:42', '00033'),
('100', 18760, 1, 18760, 'higulo', '2024-11-14', '2024-11-14 16:32:46', '00033'),
('100', 18760, 1, 18760, 'julio', '2024-11-14', '2024-11-14 16:48:18', '00033'),
('100', 18760, 1, 18760, 'junlo', '2024-11-14', '2024-11-14 16:36:19', '00033'),
('100', 18760, 2, 37520, 'asky tina', '2024-11-14', '2024-11-14 16:22:57', '00033'),
('100', 18760, 2, 37520, 'gggg', '2024-11-14', '2024-11-14 15:19:27', '00033'),
('100', 18760, 2, 37520, 'julmioe bernado', '2024-11-14', '2024-11-14 15:55:42', '00033'),
('100', 18760, 2, 37520, 'junior @gmail.com', '2024-11-14', '2024-11-14 16:52:20', '00033'),
('100', 18760, 3, 56280, 'askyas2001@gmai', '2024-10-29', '2024-10-29 13:11:01', '00033'),
('100', 22400, 1, 22400, 'junio', '2024-11-16', '2024-11-16 13:07:46', '00033'),
('100', 22400, 2, 44800, 'bernardo', '2024-11-16', '2024-11-16 13:56:10', '00033'),
('100', 22400, 2, 44800, 'j16text', '2024-11-16', '2024-11-16 07:36:24', '00033'),
('100', 22400, 2, 44800, 'junio', '2024-11-16', '2024-11-16 11:09:12', '00033'),
('100', 22400, 2, 44800, 'junior ksb', '2024-11-17', '2024-11-17 22:27:57', '00033'),
('100', 22400, 4, 89600, 'jules xx', '2024-11-17', '2024-11-17 22:31:13', '00033'),
('1277', 25200, 1, 25200, 'askyas2001@gmail', '2024-11-16', '2024-11-16 13:58:19', '00033'),
('1277', 25200, 1, 25200, 'jules xx', '2024-11-17', '2024-11-17 22:31:13', '00033'),
('1277', 25200, 2, 50400, 'junio', '2024-11-16', '2024-11-16 13:07:46', '00033'),
('1277', 25200, 2, 50400, 'junior ksb', '2024-11-17', '2024-11-17 22:27:57', '00033'),
('1277', 25200, 3, 75600, 'junio', '2024-11-16', '2024-11-16 11:09:12', '00033'),
('5', 2240, 2, 4480, 'junior ksb', '2024-11-17', '2024-11-17 22:27:57', '00033');

-- --------------------------------------------------------

--
-- Structure de la table `autorisation`
--

CREATE TABLE IF NOT EXISTS `autorisation` (
  `etat` int(2) NOT NULL,
  `id` varchar(10) NOT NULL,
  `etat_ravitaillement` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `autorisation`
--

INSERT INTO `autorisation` (`etat`, `id`, `etat_ravitaillement`) VALUES
(0, 'selecteur', 1);

-- --------------------------------------------------------

--
-- Structure de la table `autorisationchangeprix`
--

CREATE TABLE IF NOT EXISTS `autorisationchangeprix` (
  `id` varchar(2) NOT NULL,
  `etat` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE IF NOT EXISTS `commande` (
  `etat` varchar(2) NOT NULL,
  `ddats` datetime NOT NULL,
  `borne` date NOT NULL,
  PRIMARY KEY (`ddats`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `commande`
--

INSERT INTO `commande` (`etat`, `ddats`, `borne`) VALUES
('1', '2024-11-27 06:25:16', '2024-11-27');

-- --------------------------------------------------------

--
-- Structure de la table `commandefacture`
--

CREATE TABLE IF NOT EXISTS `commandefacture` (
  `id_commande` varchar(15) NOT NULL,
  `id_prod` varchar(31) NOT NULL,
  `ajout` int(11) NOT NULL,
  `pucdf` int(11) NOT NULL,
  `IdTrav` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `date_heure` datetime NOT NULL,
  `impactprix` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_commande`,`id_prod`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `commandefacture`
--

INSERT INTO `commandefacture` (`id_commande`, `id_prod`, `ajout`, `pucdf`, `IdTrav`, `date`, `date_heure`, `impactprix`) VALUES
('20241028123924', '100', 2, 18750, '0055', '2024-10-28', '2024-10-28 12:39:24', 0),
('20241028123924', '1277', 6, 25000, '0055', '2024-10-28', '2024-10-28 12:39:24', 0),
('20241028124009', '100', 3, 18750, '0055', '2024-10-28', '2024-10-28 12:40:09', 0),
('20241028124009', '1277', 3, 25000, '0055', '2024-10-28', '2024-10-28 12:40:09', 0),
('20241028133444', '100', 2, 18750, '0055', '2024-10-28', '2024-10-28 13:34:44', 0),
('20241028133444', '1277', 3, 25000, '0055', '2024-10-28', '2024-10-28 13:34:44', 0),
('20241028133444', '5', 5, 1750, '0055', '2024-10-28', '2024-10-28 13:34:44', 0),
('20241028135313', '100', 2, 18750, '0055', '2024-10-28', '2024-10-28 13:53:13', 1),
('20241028135313', '1277', 6, 25000, '0055', '2024-10-28', '2024-10-28 13:53:13', 1),
('20241028135616', '100', 5, 18750, '0055', '2024-10-28', '2024-10-28 13:56:16', 0),
('20241028140256', '100', 3, 18750, '0055', '2024-10-28', '2024-10-28 14:02:56', 1),
('20241028140256', '1277', 3, 25000, '0055', '2024-10-28', '2024-10-28 14:02:56', 1),
('20241029130234', '100', 3, 18750, '0055', '2024-10-29', '2024-10-29 13:02:34', 1),
('20241029130234', '1277', 3, 25000, '0055', '2024-10-29', '2024-10-29 13:02:34', 1),
('20241029130234', '5', 4, 2240, '0055', '2024-10-29', '2024-10-29 13:02:34', 1),
('20241029134157', '100', 3, 18750, '00033', '2024-10-29', '2024-10-29 13:41:57', 0),
('20241029134157', '1277', 3, 25000, '00033', '2024-10-29', '2024-10-29 13:41:57', 0),
('20241029134157', '5', 4, 2240, '00033', '2024-10-29', '2024-10-29 13:41:57', 0),
('20241116071853', '100', 2, 18760, '0055', '2024-11-16', '2024-11-16 07:18:53', 0),
('20241116072639', '100', 1, 22400, '0055', '2024-11-16', '2024-11-16 07:26:39', 1),
('20241116072639', '1277', 4, 25200, '0055', '2024-11-16', '2024-11-16 07:26:39', 1),
('20241117222615', '100', 200, 22400, '00033', '2024-11-17', '2024-11-17 22:26:15', 0),
('20241117222615', '1277', 200, 25200, '00033', '2024-11-17', '2024-11-17 22:26:15', 0),
('20241117222615', '5', 200, 2240, '00033', '2024-11-17', '2024-11-17 22:26:15', 0);

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE IF NOT EXISTS `compte` (
  `nom` varchar(10) NOT NULL,
  `postnom` varchar(10) NOT NULL,
  `prenom` varchar(10) NOT NULL,
  `sexe` varchar(2) NOT NULL,
  `id` varchar(10) NOT NULL,
  `pwd` int(5) NOT NULL,
  `type` varchar(5) NOT NULL,
  `dates` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `compte`
--

INSERT INTO `compte` (`nom`, `postnom`, `prenom`, `sexe`, `id`, `pwd`, `type`, `dates`) VALUES
('bengaaa', 'kalanga', 'joseph', 'm', '00033', 1234, 'user', '2024-04-30'),
('askyas', 'tumba', 'junior', 'm', '0010', 2222, 'user', '2024-06-11'),
('kemba', 'julio', 'fred', 'm', '00100', 123456, 'user', '2024-05-28'),
('fdr new', 'dd', 'ddd jj', 'dd', '00125', 2525, 'user', '2024-10-16'),
('kalangaaaa', 'pogo', 'joseph', 'm', '0050', 12345, 'user', '2024-05-24'),
('gala', 'dongo', 'juinior', 'm', '0055', 0, 'admin', '2024-04-08'),
('kllk', 'k,kl', 'kl,lk', 'm', '006', 2020, 'user', '2024-10-12');

-- --------------------------------------------------------

--
-- Structure de la table `controleur`
--

CREATE TABLE IF NOT EXISTS `controleur` (
  `id` varchar(11) NOT NULL,
  `datess` date NOT NULL,
  `debut` datetime NOT NULL,
  `finn` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `controleur`
--

INSERT INTO `controleur` (`id`, `datess`, `debut`, `finn`) VALUES
('00/11', '2024-05-18', '2024-05-17 08:44:52', '2024-05-18 10:08:21'),
('00545', '2024-05-16', '2024-05-16 19:47:29', '2024-05-16 21:10:52');

-- --------------------------------------------------------

--
-- Structure de la table `expiration`
--

CREATE TABLE IF NOT EXISTS `expiration` (
  `id_exp` varchar(31) NOT NULL,
  `date_exp` date NOT NULL,
  PRIMARY KEY (`id_exp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `expiration`
--

INSERT INTO `expiration` (`id_exp`, `date_exp`) VALUES
('1277', '2025-04-30'),
('190621', '2026-04-30'),
('190733', '2026-04-30'),
('191619', '2026-05-30'),
('191716', '2026-01-30'),
('20241119184503', '2026-04-30'),
('20241119184646', '2026-05-30'),
('20241119184758', '2026-05-30'),
('20241119184949', '2026-04-30'),
('20241119185142', '2026-06-30'),
('5', '2025-05-15');

-- --------------------------------------------------------

--
-- Structure de la table `gestionerreurvente`
--

CREATE TABLE IF NOT EXISTS `gestionerreurvente` (
  `id_p` text NOT NULL,
  `qt` int(10) NOT NULL,
  `date_t` datetime NOT NULL,
  `date` date NOT NULL,
  `etats` varchar(2) NOT NULL,
  PRIMARY KEY (`date_t`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `historique`
--

CREATE TABLE IF NOT EXISTS `historique` (
  `ID_Produit` varchar(31) NOT NULL,
  `PU` double(15,0) NOT NULL,
  `Qte` int(11) NOT NULL,
  `PT` double(15,0) NOT NULL,
  `Nom_client` varchar(15) NOT NULL,
  `Dates` date NOT NULL,
  `Dats_id` datetime NOT NULL,
  `id_travailleur` varchar(11) NOT NULL,
  PRIMARY KEY (`ID_Produit`,`PU`,`Qte`,`PT`,`Nom_client`,`Dats_id`,`id_travailleur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `historique`
--

INSERT INTO `historique` (`ID_Produit`, `PU`, `Qte`, `PT`, `Nom_client`, `Dates`, `Dats_id`, `id_travailleur`) VALUES
('10', 7470, 3, 22411, 'cli neee', '2024-06-18', '2024-06-18 11:28:45', '00033'),
('10', 7471, 4, 29884, 'cli neee', '2024-06-18', '2024-06-18 11:28:45', '00033'),
('10', 7604, 3, 22811, 'junio 02', '2024-06-16', '2024-06-16 14:34:53', '00033'),
('10', 7604, 3, 22811, 'junior auj', '2024-06-16', '2024-06-16 14:30:42', '00033'),
('10', 8004, 3, 24012, 'cisco packer', '2024-06-20', '2024-06-20 22:44:35', '00033'),
('10', 8004, 3, 24012, 'client pro', '2024-06-20', '2024-06-20 22:41:42', '00033'),
('10', 8004, 7, 56028, 'bidoli', '2024-06-20', '2024-06-20 19:39:04', '00033'),
('10', 9334, 4, 37338, 'new client', '2024-05-30', '2024-05-30 18:06:03', '00033'),
('10', 9335, 1, 9335, 'onee', '2024-06-03', '2024-06-03 00:15:58', '00033'),
('10', 9335, 2, 18670, 'juior', '2024-06-03', '2024-06-03 22:00:51', '00033'),
('10', 9335, 3, 28005, 'junior', '2024-05-30', '2024-05-30 17:55:34', '00033'),
('10', 9335, 6, 56010, 'josuate', '2024-05-31', '2024-05-31 18:23:07', '00033'),
('10', 9335, 7, 65345, 'soso', '2024-05-27', '2024-05-30 17:57:20', '000333'),
('10', 9338, 5, 46690, 'bernard', '2024-06-11', '2024-06-11 10:16:46', '00033'),
('10', 9338, 5, 46690, 'josue ', '2024-06-10', '2024-06-10 22:33:07', '00033'),
('10', 9468, 2, 18936, 'beyando', '2024-06-02', '2024-06-02 16:12:44', '00033'),
('100', 13743, 2, 27485, 'junio 02', '2024-06-16', '2024-06-16 14:34:53', '00033'),
('100', 13743, 2, 27485, 'junior auj', '2024-06-16', '2024-06-16 14:30:42', '00033'),
('100', 15000, 2, 30000, 'joel', '2024-06-20', '2024-06-20 19:37:09', '0050'),
('100', 15000, 2, 30000, 'neww', '2024-06-20', '2024-06-20 19:35:04', '0050'),
('100', 15000, 5, 75000, 'cisco packer', '2024-06-20', '2024-06-20 22:44:35', '00033'),
('100', 15000, 5, 75000, 'client pro', '2024-06-20', '2024-06-20 22:41:42', '00033'),
('100', 16877, 2, 33754, 'bernard', '2024-06-11', '2024-06-11 10:16:46', '00033'),
('100', 16877, 2, 33754, 'junior', '2024-05-30', '2024-05-30 17:55:34', '00033'),
('100', 16877, 2, 33754, 'new client', '2024-05-28', '2024-05-30 18:06:03', '00033'),
('100', 16877, 3, 50631, 'josuate', '2024-05-31', '2024-05-31 18:23:07', '00033'),
('100', 16877, 5, 84385, 'new client', '2024-05-28', '2024-05-30 18:06:03', '00033'),
('100', 16877, 8, 135016, 'soso', '2024-05-30', '2024-05-30 17:57:20', '00033'),
('100', 16877, 10, 168770, 'josue ', '2024-06-10', '2024-06-10 22:33:07', '00033'),
('100', 17118, 3, 51354, 'beyando', '2024-06-02', '2024-06-02 16:12:44', '00033');

-- --------------------------------------------------------

--
-- Structure de la table `indice`
--

CREATE TABLE IF NOT EXISTS `indice` (
  `id_ind` varchar(11) NOT NULL,
  `valeur` float NOT NULL,
  PRIMARY KEY (`id_ind`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `indice`
--

INSERT INTO `indice` (`id_ind`, `valeur`) VALUES
('indice', 1.3);

-- --------------------------------------------------------

--
-- Structure de la table `infoimpression`
--

CREATE TABLE IF NOT EXISTS `infoimpression` (
  `id` varchar(1) NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `infoimpression`
--

INSERT INTO `infoimpression` (`id`, `info`) VALUES
('1', 'ASKYAS_PHARMA NOUVELLE,RCC%MMMMMMMM,IMPOTTTTT,TVA 0056556');

-- --------------------------------------------------------

--
-- Structure de la table `motif_signaler`
--

CREATE TABLE IF NOT EXISTS `motif_signaler` (
  `nom_motif` text NOT NULL,
  `detail_motif` text NOT NULL,
  `id_trav` varchar(31) NOT NULL,
  `date_motif` date NOT NULL,
  `date_timemotif` datetime NOT NULL,
  `montant` int(15) NOT NULL,
  PRIMARY KEY (`date_timemotif`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `motif_signaler`
--

INSERT INTO `motif_signaler` (`nom_motif`, `detail_motif`, `id_trav`, `date_motif`, `date_timemotif`, `montant`) VALUES
('Retournement produit', 'Le produit dont le reference revient Réf_Produit: A-DEM SAVON 75 GM', '00033', '2024-05-28', '2024-05-28 13:59:42', 50000),
('Retournement produit', 'sortie Réf_Produit: A-DEM SAVON 75 GM                 ', '00033', '2024-05-31', '2024-05-31 19:05:44', 10),
('Rupture de stock', 'voila le produit qui n pas actif Réf_Produit: A-DEM SAVON 75 GM                       ', '00033', '2024-05-31', '2024-05-31 20:07:44', 0),
('Retournement produit', 'retounement bizarre de cd produit Réf_Produit: PARA-C CES PLQ/4                        ', '00033', '2024-05-31', '2024-05-31 20:09:59', 12500),
('Rupture de stock', 'rien Réf_Produit: A-DEM SAVON 75 GM                       ', '00033', '2024-06-02', '2024-06-02 16:10:53', 0),
('Rupture de stock', 'monsieur ce produit n''est plus Réf_Produit: ANGINOVAG SPRAY                         ', '00033', '2024-06-11', '2024-06-11 09:59:48', 0),
('Retournement produit', 'le client tel a retourne l produit Réf_Produit: ARTEFORT 180MG INJ                      ', '00033', '2024-06-11', '2024-06-11 10:03:52', 4000),
('Sortie d argent', 'paiement SNEL', '00033', '2024-06-11', '2024-06-11 10:04:19', 40000),
('Retournement produit', 'le retournement produit dont le nom revient en marge Réf_Produit: roe', '00033', '2024-06-20', '2024-06-20 22:52:41', 25000),
('Sortie d argent', 'paiement snel', '00033', '2024-06-19', '2024-06-20 22:54:43', 15000),
('Rupture de stock', 'le produit w=x esili Réf_Produit: ANGINOVAG SPRAY                         ', '00033', '2024-08-09', '2024-08-09 16:25:41', 0),
('Retournement produit', 'le client lldmf Réf_Produit: ANGINOVAG SPRAY                         ', '00033', '2024-09-03', '2024-09-03 12:13:37', 2000),
('Rupture de stock', 'ce pjihuigyug Réf_Produit: PARACE 1                                ', '006', '2024-10-12', '2024-10-12 18:28:55', 0),
('Sortie d argent', 'paiement SNEL', '006', '2024-10-12', '2024-10-12 18:30:14', 25000),
('Retournement produit', 'KKKK Réf_Produit: ANGINOVAG SPRAY                         ', '006', '2024-10-12', '2024-10-12 18:32:00', 30000);

-- --------------------------------------------------------

--
-- Structure de la table `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `idd` varchar(10) NOT NULL,
  `datee` datetime NOT NULL,
  `respondable` text NOT NULL,
  `adresse` text NOT NULL,
  `gps` text NOT NULL,
  `tel` text NOT NULL,
  PRIMARY KEY (`idd`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `online`
--

INSERT INTO `online` (`idd`, `datee`, `respondable`, `adresse`, `gps`, `tel`) VALUES
('202020', '2024-11-11 00:00:00', 'joel', 'kga', '-2.026665,356656', '0970494397');

-- --------------------------------------------------------

--
-- Structure de la table `preforma`
--

CREATE TABLE IF NOT EXISTS `preforma` (
  `id_prod` varchar(31) NOT NULL,
  `qt` int(11) NOT NULL,
  `nom_client` varchar(15) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id_prod`,`qt`,`nom_client`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `preforma`
--

INSERT INTO `preforma` (`id_prod`, `qt`, `nom_client`, `date`) VALUES
('10', 2, 'cclient 1', '2024-07-06 15:10:56'),
('10', 2, 'cclient 2', '2024-07-06 15:09:33'),
('10', 2, 'cclientt 3', '2024-07-06 15:36:06'),
('10', 2, 'jjjjj', '2024-07-02 18:30:06'),
('10', 2, 'joseph aujour', '2024-09-03 12:03:17'),
('10', 2, 'josueee', '2024-07-04 08:15:23'),
('10', 2, 'junior', '2024-07-21 16:50:42'),
('10', 2, 'jup 2', '2024-07-02 17:10:36'),
('10', 2, 'kkkkklelo', '2024-07-06 12:52:04'),
('10', 2, 'taill 2 new', '2024-07-02 22:52:22'),
('10', 2, 'wwwwwhh', '2024-07-06 12:40:52'),
('10', 2, 'xxx cli 1', '2024-07-06 15:37:00'),
('10', 3, 'apouch 15', '2024-07-06 15:46:22'),
('10', 3, 'cclient 7', '2024-07-06 15:07:47'),
('10', 3, 'client 11', '2024-07-06 14:13:57'),
('10', 3, 'client 15', '2024-07-06 14:16:27'),
('10', 3, 'client 15 n', '2024-07-06 14:18:05'),
('10', 3, 'client 7', '2024-07-06 14:10:56'),
('10', 3, 'cllient 15l', '2024-07-06 15:38:25'),
('10', 3, 'hhhhhhh', '2024-07-03 09:10:39'),
('10', 3, 'jean new 04', '2024-07-03 08:32:02'),
('10', 3, 'jjjpopl', '2024-07-06 12:59:02'),
('10', 3, 'JOELLE LELO', '2024-07-06 12:29:10'),
('10', 3, 'joseph aujour', '2024-09-03 12:03:17'),
('10', 3, 'jule bils', '2024-10-14 19:02:49'),
('10', 3, 'junior 3', '2024-07-02 17:13:47'),
('10', 3, 'newww', '2024-07-02 23:59:27'),
('10', 3, 'postolo', '2024-07-03 01:23:43'),
('10', 3, 'segion poid2', '2024-07-03 10:08:51'),
('10', 3, 'SISIRO BEYA', '2024-07-06 12:17:57'),
('10', 3, 'taill 16', '2024-07-06 14:55:00'),
('10', 3, 'xxxxxxxx new', '2024-07-03 00:37:36'),
('10', 4, 'jean3', '2024-07-02 17:02:55'),
('10', 4, 'josuable', '2024-07-03 08:11:34'),
('10', 4, 'rrdddddd', '2024-07-03 00:21:56'),
('10', 4, 'wwwwwwwww', '2024-07-03 00:19:04'),
('10', 4, 'xxxxxx', '2024-07-02 17:12:44'),
('10', 5, 'apouch 15', '2024-07-06 15:46:22'),
('10', 5, 'cclient 7', '2024-07-06 15:07:47'),
('10', 5, 'client 11', '2024-07-06 14:13:57'),
('10', 5, 'client 15', '2024-07-06 14:16:27'),
('10', 5, 'client 15 n', '2024-07-06 14:18:05'),
('10', 5, 'client 7', '2024-07-06 14:10:56'),
('10', 5, 'cllient 15l', '2024-07-06 15:38:25'),
('10', 5, 'filo', '2024-07-03 20:15:11'),
('10', 5, 'filo new', '2024-07-03 20:16:25'),
('10', 5, 'fin 1', '2024-07-06 15:45:25'),
('10', 5, 'hhhhhhh', '2024-07-03 09:10:39'),
('10', 5, 'jean new 04', '2024-07-03 08:32:02'),
('10', 5, 'jean3', '2024-07-02 17:02:54'),
('10', 5, 'jjjpopl', '2024-07-06 12:59:02'),
('10', 5, 'JOELLE LELO', '2024-07-06 12:29:10'),
('10', 5, 'josuable', '2024-07-03 08:11:35'),
('10', 5, 'junior 3', '2024-07-02 17:13:47'),
('10', 5, 'newww', '2024-07-02 23:59:28'),
('10', 5, 'postolo', '2024-07-03 01:23:43'),
('10', 5, 'robert', '2024-08-09 16:27:04'),
('10', 5, 'rrdddddd', '2024-07-03 00:21:56'),
('10', 5, 'SISIRO BEYA', '2024-07-06 12:17:57'),
('10', 5, 'soso poid2', '2024-07-03 10:11:18'),
('10', 5, 'taill 1', '2024-07-06 14:56:46'),
('10', 5, 'taill 16', '2024-07-06 14:55:00'),
('10', 5, 'wwwwwwwww', '2024-07-03 00:19:04'),
('10', 5, 'xxxxxx', '2024-07-02 17:12:45'),
('10', 5, 'xxxxxxxx new', '2024-07-03 00:37:36'),
('10', 6, 'josuable', '2024-07-03 08:11:35'),
('10', 7, 'josuable', '2024-07-03 08:11:35'),
('10', 10, 'apouch 15', '2024-07-06 15:46:22'),
('10', 10, 'cclient 7', '2024-07-06 15:07:47'),
('10', 10, 'client 11', '2024-07-06 14:13:57'),
('10', 10, 'client 15', '2024-07-06 14:16:27'),
('10', 10, 'client 15 n', '2024-07-06 14:18:05'),
('10', 10, 'client 7', '2024-07-06 14:10:56'),
('10', 10, 'cllient 15l', '2024-07-06 15:38:25'),
('10', 10, 'jean new 04', '2024-07-03 08:32:02'),
('10', 10, 'JOELLE LELO', '2024-07-06 12:29:11'),
('10', 10, 'SISIRO BEYA', '2024-07-06 12:17:57'),
('10', 10, 'taill 16', '2024-07-06 14:55:00'),
('10', 14, 'apouch 15', '2024-07-06 15:46:22'),
('10', 14, 'client 11', '2024-07-06 14:13:58'),
('10', 14, 'client 15', '2024-07-06 14:16:27'),
('10', 14, 'client 15 n', '2024-07-06 14:18:05'),
('10', 14, 'cllient 15l', '2024-07-06 15:38:25'),
('10', 14, 'taill 16', '2024-07-06 14:55:00'),
('10', 15, 'apouch 15', '2024-07-06 15:46:22'),
('10', 15, 'client 11', '2024-07-06 14:13:58'),
('10', 15, 'client 15', '2024-07-06 14:16:27'),
('10', 15, 'client 15 n', '2024-07-06 14:18:05'),
('10', 15, 'cllient 15l', '2024-07-06 15:38:25'),
('10', 15, 'taill 16', '2024-07-06 14:55:00'),
('10', 30, 'taill 16', '2024-07-06 14:55:00'),
('100', 1, 'j16prefo', '2024-11-16 07:38:40'),
('100', 2, 'beatricce', '2024-11-14 16:50:07'),
('100', 2, 'filo', '2024-07-03 20:15:12'),
('100', 2, 'filo new', '2024-07-03 20:16:25'),
('100', 2, 'julioeben', '2024-11-14 15:25:23'),
('100', 2, 'junio ff', '2024-11-17 22:31:59'),
('100', 2, 'junlio', '2024-11-16 13:55:27'),
('100', 3, 'kkkkkk', '2024-10-12 18:39:19'),
('100', 3, 'xxxxxxxxxxx new', '2024-07-03 09:16:01'),
('100', 4, 'segion poid2', '2024-07-03 10:08:50'),
('100', 5, 'cclient 2', '2024-07-06 15:09:33'),
('100', 5, 'cclientt 3', '2024-07-06 15:36:06'),
('100', 5, 'jjjjj', '2024-07-02 18:30:05'),
('100', 5, 'JOELLE LELO', '2024-07-06 12:29:11'),
('100', 5, 'josueee', '2024-07-04 08:15:24'),
('100', 5, 'jup 2', '2024-07-02 17:10:36'),
('100', 5, 'kkkkklelo', '2024-07-06 12:52:04'),
('100', 5, 'pius biblio', '2024-10-14 13:55:07'),
('100', 5, 'taill 2 new', '2024-07-02 22:52:22'),
('100', 5, 'wwwwwhh', '2024-07-06 12:40:52'),
('100', 6, 'apouch 15', '2024-07-06 15:46:22'),
('100', 6, 'cclientt 3', '2024-07-06 15:36:06'),
('100', 6, 'client 11', '2024-07-06 14:13:58'),
('100', 6, 'client 15', '2024-07-06 14:16:27'),
('100', 6, 'client 15 n', '2024-07-06 14:18:05'),
('100', 6, 'cllient 15l', '2024-07-06 15:38:25'),
('100', 6, 'josueee', '2024-07-04 08:15:24'),
('100', 6, 'kkkkklelo', '2024-07-06 12:52:04'),
('100', 6, 'soso poid2', '2024-07-03 10:11:18'),
('100', 6, 'taill 16', '2024-07-06 14:55:00'),
('100', 6, 'wwwwwhh', '2024-07-06 12:40:52'),
('100', 7, 'apouch 15', '2024-07-06 15:46:22'),
('100', 7, 'cclient 7', '2024-07-06 15:07:47'),
('100', 7, 'client 11', '2024-07-06 14:13:57'),
('100', 7, 'client 11', '2024-07-06 14:13:58'),
('100', 7, 'client 15', '2024-07-06 14:16:27'),
('100', 7, 'client 15 n', '2024-07-06 14:18:05'),
('100', 7, 'client 7', '2024-07-06 14:10:56'),
('100', 7, 'cllient 15l', '2024-07-06 15:38:25'),
('100', 7, 'hhhhhhh', '2024-07-03 09:10:39'),
('100', 7, 'jean new 04', '2024-07-03 08:32:02'),
('100', 7, 'jjjpopl', '2024-07-06 12:59:02'),
('100', 7, 'JOELLE LELO', '2024-07-06 12:29:11'),
('100', 7, 'junior 3', '2024-07-02 17:13:47'),
('100', 7, 'newww', '2024-07-02 23:59:28'),
('100', 7, 'postolo', '2024-07-03 01:23:43'),
('100', 7, 'SISIRO BEYA', '2024-07-06 12:17:57'),
('100', 7, 'taill 16', '2024-07-06 14:55:00'),
('100', 7, 'xxxxxx', '2024-07-02 17:12:45'),
('100', 7, 'xxxxxxxx new', '2024-07-03 00:37:36'),
('100', 8, 'apouch 15', '2024-07-06 15:46:22'),
('100', 8, 'cclient 7', '2024-07-06 15:07:47'),
('100', 8, 'client 11', '2024-07-06 14:13:57'),
('100', 8, 'client 15 n', '2024-07-06 14:18:05'),
('100', 8, 'client 7', '2024-07-06 14:10:56'),
('100', 8, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 8, 'jean3', '2024-07-02 17:02:55'),
('100', 8, 'josuable', '2024-07-03 08:11:35'),
('100', 8, 'rrdddddd', '2024-07-03 00:21:56'),
('100', 8, 'taill 16', '2024-07-06 14:55:00'),
('100', 8, 'wwwwwwwww', '2024-07-03 00:19:04'),
('100', 8, 'xxxxxx', '2024-07-02 17:12:45'),
('100', 10, 'apouch 15', '2024-07-06 15:46:22'),
('100', 10, 'cclient 7', '2024-07-06 15:07:47'),
('100', 10, 'client 11', '2024-07-06 14:13:57'),
('100', 10, 'client 15 n', '2024-07-06 14:18:05'),
('100', 10, 'client 7', '2024-07-06 14:10:56'),
('100', 10, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 10, 'filo new', '2024-07-03 20:16:25'),
('100', 10, 'taill 16', '2024-07-06 14:55:00'),
('100', 11, 'apouch 15', '2024-07-06 15:46:23'),
('100', 11, 'cclient 7', '2024-07-06 15:07:48'),
('100', 11, 'client 11', '2024-07-06 14:13:57'),
('100', 11, 'client 15 n', '2024-07-06 14:18:05'),
('100', 11, 'client 7', '2024-07-06 14:10:57'),
('100', 11, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 11, 'taill 16', '2024-07-06 14:55:00'),
('100', 13, 'apouch 15', '2024-07-06 15:46:23'),
('100', 13, 'client 15 n', '2024-07-06 14:18:05'),
('100', 13, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 13, 'taill 16', '2024-07-06 14:55:00'),
('100', 21, 'apouch 15', '2024-07-06 15:46:23'),
('100', 21, 'client 15 n', '2024-07-06 14:18:05'),
('100', 21, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 21, 'taill 16', '2024-07-06 14:55:00'),
('100', 22, 'apouch 15', '2024-07-06 15:46:23'),
('100', 22, 'client 15 n', '2024-07-06 14:18:05'),
('100', 22, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 22, 'taill 16', '2024-07-06 14:55:00'),
('100', 25, 'apouch 15', '2024-07-06 15:46:23'),
('100', 25, 'client 15 n', '2024-07-06 14:18:05'),
('100', 25, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 25, 'taill 16', '2024-07-06 14:55:00'),
('100', 26, 'apouch 15', '2024-07-06 15:46:23'),
('100', 26, 'client 15 n', '2024-07-06 14:18:05'),
('100', 26, 'cllient 15l', '2024-07-06 15:38:26'),
('100', 26, 'taill 16', '2024-07-06 14:55:00'),
('1000', 5, 'xxxxxxxxxxx new', '2024-07-03 09:16:01'),
('20241012174009', 3, 'kkkkkk', '2024-10-12 18:39:19');

-- --------------------------------------------------------

--
-- Structure de la table `prescription`
--

CREATE TABLE IF NOT EXISTS `prescription` (
  `id_prise` varchar(30) NOT NULL,
  `id_achat` varchar(30) NOT NULL,
  `docteur` text NOT NULL,
  `datees` date NOT NULL,
  PRIMARY KEY (`id_prise`,`id_achat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prescription`
--

INSERT INTO `prescription` (`id_prise`, `id_achat`, `docteur`, `datees`) VALUES
('askyas2001@gmail', '2024-10-21 17:30:50', 'djodjo', '2024-10-21'),
('askyas2001@gmail', '2024-10-21 18:14:21', 'nick', '2024-10-21'),
('askyas2001@gmail', '2024-10-21 18:23:10', 'ddd', '2024-10-21'),
('askyas2001@gmail', '2024-10-29 13:11:01', 'bernard', '2024-10-29'),
('askyas2001@gmail', '2024-11-16 13:58:19', '54444', '2024-11-16'),
('askyas201@gmail.com', '2024-11-14 16:54:42', 'jjj', '2024-11-14'),
('askyasdev@gmail.com', '2024-10-21 18:17:36', 'jojo', '2024-10-21'),
('askyasdev@gmail.com', '2024-11-16 07:42:46', 'bodo', '2024-11-16'),
('junior @gmail.com', '2024-11-14 16:52:20', 'boto', '2024-11-14');

-- --------------------------------------------------------

--
-- Structure de la table `prisecharge`
--

CREATE TABLE IF NOT EXISTS `prisecharge` (
  `gmail` varchar(30) NOT NULL,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `sexe` text NOT NULL,
  `tel` text NOT NULL,
  `adresse` text NOT NULL,
  `dates` date NOT NULL,
  `trav` varchar(30) NOT NULL,
  PRIMARY KEY (`gmail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `prisecharge`
--

INSERT INTO `prisecharge` (`gmail`, `nom`, `prenom`, `sexe`, `tel`, `adresse`, `dates`, `trav`) VALUES
('askyas2001@gmail', 'ntumba', 'josephhh', 'm', 'kindele', 'm', '2024-10-21', '00033'),
('askyas201@gmail.com', 'ntumba new', 'joseph', 'm', '0970494397', 'kananga', '2024-10-23', '0055'),
('askyasdev@gmail.com', 'ntumba', 'joseph', 'm', '0970494397', 'kananga', '2024-10-20', ''),
('junior @gmail.com', 'ntumba new', 'joseph new', 'm', '0970494397 new', 'kananga new', '2024-10-20', '0055'),
('m:m', 'juhh', 'k,k', 'm', 'okoko', 'kga', '2024-10-21', '00033'),
('ntumba', 'ntumba new ok', 'joseph new ok', 'm', '0970494397 new ok', 'kananga new ok', '2024-10-20', '0055');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE IF NOT EXISTS `produit` (
  `matricule` varchar(31) NOT NULL,
  `nom` text NOT NULL,
  `categorie` varchar(10) NOT NULL,
  `anti` text NOT NULL,
  `traite` text NOT NULL,
  `posologie` text NOT NULL,
  `age_utilisation` text NOT NULL,
  `pu` float NOT NULL,
  `stock` int(7) NOT NULL,
  `dats` date NOT NULL,
  `stock_p` int(7) NOT NULL,
  PRIMARY KEY (`matricule`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `produit`
--

INSERT INTO `produit` (`matricule`, `nom`, `categorie`, `anti`, `traite`, `posologie`, `age_utilisation`, `pu`, `stock`, `dats`, `stock_p`) VALUES
('100', 'ANGINOVAG SPRAY                         ', '-', '-', '-', '-', '-ss', 10, 777, '2024-11-18', 777),
('1277', 'ORANGINE SP FL/100 ML                   ', '-', '-', '-', '-', '-', 8.96552, 444, '2024-11-18', 444),
('190621', 'ddd', '', '', '', '', '', 5, 0, '2024-11-19', 0),
('190733', 'kfff', '', '', '', '', '', 8, 0, '2024-11-19', 0),
('191619', 'ppp', '', '', '', '', '', 4, 0, '2024-11-19', 0),
('191716', 'kkkkkk fin', '', '', '', '', '', 6, 0, '2024-11-19', 0),
('20241101112254', 'jjj', '-', '-', '-', '-', '-', 1.786, 1500, '2024-11-18', 0),
('20241119184503', 'kkl,kl,', '', '', '', '', '', 5, 0, '2024-11-19', 0),
('20241119184646', 'hhhhhhhhhh', '', '', '', '', '', 2, 0, '2024-11-19', 0),
('20241119184758', 'kkkkkkkkkkkbien', '-', '-', '-', '-', '-', 5, 20, '2024-11-19', 20),
('20241119184949', 'pppppp', '', '', '', '', '', 6, 0, '2024-11-19', 0),
('20241119185142', 'llllll', '', '', '', '', '', 3, 50, '2024-11-19', 50),
('5', 'A-DEM CREME 15G                         ', '-', '-', '-', '-', '-', 0.8, 111, '2024-11-18', 111);

-- --------------------------------------------------------

--
-- Structure de la table `registrefluxonline`
--

CREATE TABLE IF NOT EXISTS `registrefluxonline` (
  `dateheure` datetime NOT NULL,
  `datee` date NOT NULL,
  `idtrav` varchar(10) NOT NULL,
  `operation` text NOT NULL,
  PRIMARY KEY (`dateheure`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `registrefluxonline`
--

INSERT INTO `registrefluxonline` (`dateheure`, `datee`, `idtrav`, `operation`) VALUES
('2024-11-18 11:25:32', '2024-11-18', '00033', 'Telechargement CLOUD'),
('2024-11-18 11:41:16', '2024-11-18', '00033', 'Envois CLOUD'),
('2024-11-18 11:44:26', '2024-11-18', '00033', 'Telechargement CLOUD'),
('2024-11-18 12:58:53', '2024-11-18', '00033', 'Telechargement CLOUD Produit'),
('2024-11-18 13:01:10', '2024-11-18', '00033', 'Telechargement CLOUD Produit'),
('2024-11-20 17:42:35', '2024-11-20', '00033', 'Envois CLOUD');

-- --------------------------------------------------------

--
-- Structure de la table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `ids` varchar(10) NOT NULL,
  `date_tim` datetime NOT NULL,
  PRIMARY KEY (`date_tim`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tauxchange`
--

CREATE TABLE IF NOT EXISTS `tauxchange` (
  `num` int(11) NOT NULL,
  `taux` int(11) NOT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tauxchange`
--

INSERT INTO `tauxchange` (`num`, `taux`) VALUES
(1, 2900);

-- --------------------------------------------------------

--
-- Structure de la table `verificateur_stock`
--

CREATE TABLE IF NOT EXISTS `verificateur_stock` (
  `nom_p` varchar(31) NOT NULL,
  `datess` datetime NOT NULL,
  PRIMARY KEY (`nom_p`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `verificateur_stock`
--

INSERT INTO `verificateur_stock` (`nom_p`, `datess`) VALUES
('A-DEM CREME 15G', '2024-11-19 07:11:51'),
('ORANGINE SP FL/100 ML', '2024-11-19 07:11:15');

-- --------------------------------------------------------

--
-- Structure de la table `version_essaie`
--

CREATE TABLE IF NOT EXISTS `version_essaie` (
  `id_comp` varchar(4) NOT NULL,
  `datenow` date NOT NULL,
  `compteur` int(4) NOT NULL,
  PRIMARY KEY (`id_comp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `version_essaie`
--

INSERT INTO `version_essaie` (`id_comp`, `datenow`, `compteur`) VALUES
('asky', '2024-09-05', 22);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
