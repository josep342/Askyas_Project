from kivymd.app import MDApp
from kivy.lang import Builder
from pyzbar.pyzbar import ZBarSymbol
from kivymd.uix.snackbar import snackbar
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.floatlayout import MDFloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.uix.popup import Popup
from kivymd.uix.textfield import MDTextField
from kivymd.uix.datatables import MDDataTable
from kivy.uix.image import Image
import socket
from kivy.uix.camera import Camera

global host,port,sock

KV="""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
#:import ZBarSymbol pyzbar.pyzbar.ZBarSymbol
MDBoxLayout:
    size_hint:None,None
    size:300,240
    pos_hint:{'center_x':0.5,'center_y':0.62}
    orientation:'vertical'
    ZBarCam
        id:zbarcam
        code_types:ZBarSymbol.QRCODE.value,ZBarSymbol.EAN13.value
        on_symbols:app.on_symbols(*args)
"""

Window.size=(300,500)
class Myapp(MDApp):
    def build(self):
        global camera,etat,lab,datat,t1,labb,labtitre,imglogo,labidentifiant
        
        global btcamera,cameraphot,btqr,cadre,lab,labb,t1,camera
        
        cadre=MDFloatLayout(md_bg_color='white')

        datat=""
        etat="0"
        camera=Builder.load_string(KV)
        
        bt=Button(text="[b]Tester la connexion[/b]",pos_hint={'x':0.6,'y':0.3},size_hint=(0.2,0.08),markup=True)
        cadtitre=MDDataTable(pos_hint={'center_x':0.5,'y':0.88},size_hint=(0.8,0.1))
        labtitre=Label(text="[b]SCANNEUR PHARMA[/b]",markup=True,pos_hint={'center_x':0.5,'y':0.9},font_size="20sp",size_hint=(0.5,0.1),color='blue')
        imglogo=Image(source="mon logoo.jpg", size_hint=(0.2,0.2), pos_hint={'center_x':0.9,'y':0})

        
        lab=Label(text="[b]Etat[/b]",markup=True,pos_hint={'x':0.5,'y':0.3},size_hint=(0.1,0.1),color='black')
        labb=Label(text="[b].[/b]",markup=True,pos_hint={'x':0.7,'y':0.3},size_hint=(0.1,0.1),color='black')
        t1=MDTextField(hint_text="Coding",pos_hint={'center_x':0.5,'y':0.22},size_hint=(0.9,0.1),font_size="15sp",password=True)
        
        bt.bind(on_release=self.op)

        btqr=Button(text="[b]Basculer Code QR[/b]", pos_hint={'x':0.05,'y':0.17},size_hint=(0.5,0.05),font_size='15sp',color='white',background_color='blue', markup=True)
        btqr.bind(on_press=self.codeqr)

        try:
            cadre.add_widget(lab)
            
            cadre.add_widget(labb)
       
            cadre.add_widget(t1)

            cadre.add_widget(imglogo)

            cadtitre.add_widget(labtitre)
            cadre.add_widget(cadtitre)

            cadre.add_widget(camera)

            cadre.add_widget(btqr)
        
        except:
            pass


        return cadre
    
    def codeqr(self,instance):

        camera=Builder.load_string(KV)

        try:
            cadre.add_widget(camera)
        except:
            pass

    def op(self,instance):
        global sock
        testeur=""
        try:
            sock.connect((host,port))
            msg=Popup(title="COMMUTATION",content=Button(text="Communication favorable au serveur"),size_hint=(None, None), size=(300,200))
            msg.open()
            
        except:
            msg=Popup(title="COMMUTATION",content=Button(text="Communication echouée"),size_hint=(None, None), size=(300,200))
            msg.open()

    def on_symbols(self,instance,symbols):
        global datat
            
        if not symbols=="":
            for symbol in symbols:
                datat=str(symbol.data.decode())
                if datat=="":
                    pass
                else:
                    #print("deja ton code est : ",datat)
                    t1.text=datat

                    host,port=('localhost',5566)
                    sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                    try:
                        sock.connect((host,port))
                
                        data=datat
                        data=data.encode("utf8")
                        sock.sendall(data)
                        
                        msg=Popup(title="STATUT",content=Button(text='Commutation\nréussie!!!'),size_hint=(None, None), size=(250,200))
                        msg.open()
                        labb.text="Reussi"
                    except:
                        labb.text="Echec"
                        msg=Popup(title="ERROR",content=Button(text='Commutation\nechouée'),size_hint=(None, None), size=(250,200))
                        msg.open()
                
                    finally:
                        sock.close()
Myapp().run()