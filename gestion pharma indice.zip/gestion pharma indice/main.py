#from kivy import Config
#Config.set('graphics', 'multisamples', '0')  # Désactiver l'anti-aliasing pour OpenGL
#Config.set('graphics', 'gles', '0')  # Désactiver l'utilisation de GLES

import kivy
from kivymd.app import MDApp
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.properties import NumericProperty
from kivy.metrics import dp
from kivy.uix.textinput import TextInput
from kivy.config import Config
from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.uix.relativelayout import RelativeLayout
from kivy.graphics import Color,Rectangle
from kivymd.uix.screen import Screen
from kivymd.uix.textfield import MDTextField
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.label import MDLabel
from kivymd.uix.floatlayout import MDFloatLayout
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.utils import get_color_from_hex
from kivy.uix.camera import Camera
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager,Screen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.datatables import MDDataTable
from datetime import datetime
from kivy.uix.spinner import Spinner
from kivy.lang import Builder
from kivy.uix.checkbox import CheckBox
from kivy.uix.modalview import ModalView
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.clock import Clock
from kivy.lang import Builder

#from pyzbar.pyzbar import ZBarSymbol
#from kivymd.uix.snackbar import snackbar
import mysql.connector
import socket
import threading
import os
import shutil
import random
import math
import subprocess
import pandas as pd
from openpyxl import Workbook
#from fpdf import FPDF
import time
import openpyxl

from openpyxl import load_workbook
from PIL import ImageDraw, ImageFont

import win32print

from reportlab.lib.pagesizes import portrait
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
import aspose.pdf as pdf
import webbrowser
import qrcode
from qrcode.constants import ERROR_CORRECT_L
qr=qrcode.QRCode(
    version=3,
    error_correction=ERROR_CORRECT_L,
    box_size=3,
    border=5
)

import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import db
from datetime import datetime

chem=''

#KV="""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
#:import ZBarSymbol pyzbar.pyzbar.ZBarSymbol
#MDBoxLayout:
#    size_hint:None,None
#    size:300,300
#    pos_hint:{'x':0.7,'y':0}
#    orientation:'vertical'
#    ZBarCam
#        id:zbarcam
#        code_types:ZBarSymbol.QRCODE.value,ZBarSymbol.EAN13.value
#        on_symbols:app.on_symbols(*args)
#"""
#KVV="""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
#:import ZBarSymbol pyzbar.pyzbar.ZBarSymbol
#MDBoxLayout:
#    size_hint:None,None
#    size:1,1
#    pos_hint:{'x':0,'y':0}
#    orientation:'vertical'

#    ZBarCam
#        id:zbarcam
#        code_types:ZBarSymbol.QRCODE.value,ZBarSymbol.EAN13.value
#        on_symbols:app.on_symbol(*args)
#"""

class Pharma(MDApp):   
    def build(self):
        global host,port,sock
        global b1,b2,b3,b4,b5,trech,cadre,btnrechimg,btnrechimgdirrect,btaction,btenregistrer,labremarque,labremarque0,tablegestionvente,hautlab1,btncamera
        global etat,combo1,combo2,tunitil,labqt,labtot,qt,tot,hautlab1,tabstock1,tabstock2,labstock1,labstock2
        global tb1,tb2,tb3,tb4,tb5,tb6,tb7,tb8,btnstock2,ldetail,btnstock1,tablstock,sepp,tabmod,labmod,btnravitail
        global btnmodqt,taccueil,laccueil,imgaccuel,accueilcad1,accueilcad2,accueilcad3
        global lacc3,lacc2,lacc1,luser,ladmin,imglogo,imgacc1,imgacc2,imgacc3,btnconn,tidconn,tpwdconn,imggconn,labconn
        global cadregauche,labpwwd,typee,ptitre,plabadmin,plabuser,badmin,typee,buser,bretour,bdeconn,bgestionuser
        global tabl,bgestionuserchanger,labvente,bsystem,bjournal,bcoupcendr,lbv,tabv,tabvente1,bvente1,tquantite
        global cadrehaut,btirehaut,labhaut1,labhaut2,labhaut3,combohaut1,combohaut2,combohaut3
        global labhaut1b,labhaut2b,labhaut3b,check1,check2,labcheck,btest,barret,bdemm
        global check,bcad1,bcad2,bcad3,bscanneur,trechvente,trechventlike,bcharger,num
        global idcam,camera,idt,conentrant,bcharg,treceve,bretireelementcoupon,bsuprimercoupon,bvalidercoupon,retetat
        global netpayer,labnet,labnetpayer,bvueclaire,tabventejournal,verifsel,triercheck3,triercheck2,triercheck1,trilab,labcheck1,labcheck2,labcheck3
        global triercheckk2,labcheckk2,triercheckk1,labcheckk1,trilabb,triercheckk4,triercheckk5
        global labcheckk4,labcheckk5,labtyp,labtyp1,labtyp2,labtypp,labtypp1,labtypp2,labtot1,labtot2,combnomclient,tjourclientnom,combids,tjourids,combdats,labdats
        global labexp2,texp1,labexp1,expcheck2,expcheck1,labcheckexp2,labcheckexp1,bexpert1,bexpert2,bexpert3
        global listeplainte,quantiterestant,listeqt,bvueclaireadmin,listplainte,bgenererresulat
        global ki,labelement,photoproduit,bscanneurannuler,bdemserveur,affresultat,l,scrol,kj,indiceaff,imgexpert,btsuitegenAI
        global repsuite,labcompteur,bactualiser,bcorrection,compfois,labstockfini,tablstockfini,tablstocktotal
        global bflechhaut,bflechbas,bflech0,selid,btridtrav,hlab3,combotrav
        global scroll1,modcommutation,listidcommute,df,trechlikemodif,combravitail,trecravitail
        global labcombine,checkcombine,btrechcombine,datemodel,checkcodelocal,labcodelocal,idlocal,imgtaux,taux,bclose
        global msgexp,btaide,btsignale,combmotif,textdetailmotif,bnmotifs,idprodmotif,ptmotif,tablmotiftravil,gesttrav,gestmotif
        global labdatmotif,combdatmotif,labidmotif,combidmotif,tabtotmotif,labtotmotif,labcombinmotif,checkmotif,tauxjour
        global bperemption,tablstockperime,idprodrav,bcommutadmin,modcommutationadmin,dfadmin,proepuisedirrect,dfv
        global typeexport,bexport,separstock,resultsperime,listprofini,listenormale,listecritique,listfini,listventecombine
        global tlicence,bquiter,bimpression,listproravitail,selimprime,bimpressionpreforma,bpreforma,trechproforma,combproforma

        global nomcclientprefo,combjourintervalvente,combmoisintervalveny,combanneintervalvente,interval,bcalcbenefice
        global combsigale,checkgobal,labglobal,etattabbord,btautorisermodtp,cheautoriclient,chexportdirrect,rechlikepromodqt
        global tmodqt,qtmodauto,btmodstockauto,configserveur,indicateurindice,labindice,indicevaleur,choixconn
        global bcanetterelage,jourcannette,moiscanette,annecanette,labcombinmotif,pasconnette,cadcanette,textregaleidpro
        global datdeb,datefin,checkchangecdf,labchange,btfond,fondpagevente,fondacceuil
        global iccon2,iccon1,cadrehautnew,bautomodiftravprod,cadxxsetting,bgestionusernew,btusernew
        global labxx,cadresuitchmode,cadrebtfleche,cadbttablbord,cadbttablbordhaut,cadbtsave,btnchangeCdfUsd,tauxchangenew
        global barrmenu,cadregauche,cadremenue,cadremenueIcon,cadreprischarge,btsavprise
        global btbasss1,btbasss2
        global tprise1,tprise2,tprise3,tprisee1,tprisee2,tprisee3,tablprise,trechpresc1,trechpresc2,trechpresc3,tablprescription
        global combpresc1,combpresc2,combpresc3
        global tablprise,cadresuitchmorr,labupdatpris,btsavprise,tprisee1,tprisee2,tprisee3,tprise1,tprise2,tprise3
        global suitmodrap,labmodrap,cadresuitcmoderap,cadprisecharge,btntauxadmin,cadreravitaimultiple,tablravmultiple,btclosrav,btopenravmult
        global msgopentrav,checkmodecloaud
        global suitravvprix,suitravv,tprixrechrav,tqterechrav,tidrechrav,tstockcourant,combaffravv

        global btetatretir,totqtbrouil,totusdbrouil,totcdfbrouil,progressbarr,etetatretirer
        global anneexpmult,moisexpmult,jrsexpmult,combrechhisto,trechhisto,openerror,btopenerrror,listerror
        global openinfo,btopeninfo,retaccueil,openuser,btopenravclient,n1,n2,n3,n4
        global idonline,dateonline,cadbtnonligne,btcompte,bchangeprix,btcommiterav,nb,kcompt
        global btsaveI,tStockIinitial,tPrixUnitaire,tnomProx,cadresuitcravv,labravv,tablravAjout,cadreravitaiAjout
        global suitravvAjout,cadexpiration,labbt,btajouterav,btretirerav,btchecking,labravvprix,cadresuitrapprix,typecloud

        typecloud=0
        idonline=None
        dateonline=None
        nb=1
        n1=""
        n2=""
        n3=""
        n4=""
        kcompt=0

        datdeb='0000-00-00'
        datefin='0000-00-00'
        
        listerror=[]

        openuser=0

        choixconn=1
        tauxchangenew=0
        etetatretirer=0

        listprofini=[]
        listenormale=[]
        listecritique=[]
        listfini=[]
        listventecombine=[]
        listproravitail=[]
        etattabbord=0
        interval=0
        separstock=0
        selimprime=0
        typeexport=""
        idprodrav=""
        resultsperime=[]
        proepuisedirrect=[]
        df=[]
        dfv=[]
        dfadmin=[]
        datemodel='0000-00-00 00:00:00'
        selid="b"
        compfois=0
        idlocal=1
        repsuite=0
        indiceaff=0
        modcommutation=0
        modcommutationadmin=0
        kj=0
        l=0
        ki=-1
        listplainte=[]
        listeqt=[]
        listidcommute=[]
        listeplainte=""
        quantiterestant=0
        verifsel=0
        netpayer=0
        num=0
        retetat=0
        conentrant=0
        idcam=0
        idt=0
        etat = 0
        sepp=0
        typee=""
        wid=50
        heigh=70
        indicevaleur=0

        screenwidth, screenheight=Window.size
        new_width=int(screenwidth*(wid/100))
        new_height=int(screenheight*(heigh/100))
        
        Window.size=(500,400)
        
        #webcam=Camera(play=True)
        #webcam.resolution=(640,480)
        #tete=Rectangle(pos=(100,100),size=(200,100))

        global img1, img2,img3, img4, t1,t3,t5,t7,t2,t4,t6,t8,t10,t9,table,tabunitiltete,tabunitilbas,hlab1,hlab2,btrid,btrierdate
       

       # les outils de la page prise en charge

        Window.bind(on_request_close=self.deconnexionforcer)
        
        
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select idd,datee from online")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                idonline=results[0]
                dateonline=results[1]

        except:
            pass
        
        cadreprischarge=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}
       
       ''')

        tprise1=Builder.load_string('''
MDTextField:
    
    hint_text:'E-Mail'
    pos_hint:{'x':.05,'y': .8}
    size_hint:.24,.1
    text_color:255/255,128/255,0/255
    icon_right:'gmail'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprise1.bind(on_text_validate=self.deplfocusprise1)

        tprise2=Builder.load_string('''
MDTextField:
   
    hint_text:'Nom'
    pos_hint:{'x':.39,'y': .8}
    size_hint:.23,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')
    
        tprise2.bind(on_text_validate=self.deplfocusprise2)

        tprise3=Builder.load_string('''
MDTextField:
    
    hint_text:'¨Prenom'
    pos_hint:{'x':.68,'y': .8}
    size_hint:.23,.1
    text_color:255/255,128/255,0/255
    icon_right:'eye'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprise3.bind(on_text_validate=self.deplfocusprise3)

        tprisee1=Builder.load_string('''
MDTextField:
    
    hint_text:'Tel'
    pos_hint:{'x':.05,'y': .7}
    size_hint:.24,.1
    text_color:255/255,128/255,0/255
    icon_right:'phone'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprisee1.bind(on_text_validate=self.deplfocusprise4)

        tprisee2=Builder.load_string('''
MDTextField:
    
    hint_text:'Adresse'
    pos_hint:{'x':.39,'y': .7}
    size_hint:.23,.1
    text_color:255/255,128/255,0/255
    icon_right:'home'
    font_size:'20sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprisee2.bind(on_text_validate=self.deplfocusprise5)

        tprisee3=Builder.load_string('''
MDTextField:
    
    hint_text:'Sexe'
    pos_hint:{'x':.68,'y': .7}
    size_hint:.06,.1
    text_color:255/255,128/255,0/255
    icon_right:'face-man'
    font_size:'13sp'
    line_color:'black'
    text_color_normal:'black'
       
       ''')

        btsavprise=Builder.load_string('''
MDChip:
    
    background_color:[0,0,0,0]
    text:"[b]Enregistrer[/b]"
    markup:True
    size_hint:(0.12,0.05)
    pos_hint:{'x':0.75,'y':0.715}
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
       
       ''')


        btsavprise.bind(on_release=self.savepreisecharge)

        labupdatpris=Label(text="Update",pos_hint={'x':.88,'y':.715},size_hint=(.05,.05),bold=True,color="black")
            
        cadresuitchmorr=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.93,'y':.72}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitsaveprise=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.changebtnprise(self)
''')


            

        tablprise=MDDataTable(column_data=[
                ("E-mail",dp(40)),
                ("Nom",dp(40)),
                ("Prenom",dp(40)),
                ("Sexe",dp(10)),
                ("Telephone",dp(40)),
                ("Adresse ",dp(50)),
                ("Date ",dp(30)),
                ("Travailleur ",dp(30))
                ],size_hint=(0.9,0.57),pos_hint={'center_x':0.5,'y':0.1},check=True,rows_num=20,use_pagination=True)
        tablprise.bind(on_check_press=self.affinfoprise)

        cadprisebase=Builder.load_string('''
FloatLayout:
    size_hint:.98,.08
    pos_hint: {'center_x':.5,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[40,40,1,1]
                
        ''')

        # les outils de la page prescription

        labmodrap=Label(text="Mode Rapide",pos_hint={'x':.8,'y':.86},size_hint=(.1,.05),bold=True,color="black")
            
        cadresuitcmoderap=Builder.load_string('''
FloatLayout:
    size_hint:.05,.04
    pos_hint: {'x':.9,'y':.87}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitmodrap=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.changebtnprise(self)
''')
        try:
            cadresuitcmoderap.add_widget(suitmodrap)
        except:
            pass

        trechpresc1=Builder.load_string('''
MDTextField:
    
    hint_text:'Recherche ID'
    pos_hint:{'x':.05,'y': .8}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')
       
       

        combpresc1=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.2, 'y':0.82}
    size_hint:(0.13,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
    
        
        ''')

        combpresc1.bind(on_release=self.rechidpresc) 
        combpresc1.bind(text=self.affrecid)

        trechpresc2=Builder.load_string('''
Label:
   
    text:'Date '
    pos_hint:{'x':.39,'y': .79}
    size_hint:.1,.1
    color:'black'
    bold:True

       
''')

        combpresc2=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.55, 'y':0.82}
    size_hint:(0.13,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
    
        
        ''')

        combpresc2.bind(on_release=self.rechdatepresc)
        combpresc2.bind(text=self.affrecdate)

        trechpresc3=Builder.load_string('''
Label:
    
    text:'Facture'
    pos_hint:{'x':.7,'y': .79}
    size_hint:.1,.1
    color:'black'
    bold:True
    
       
       ''')

        combpresc3=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.8, 'y':0.81}
    size_hint:(0.15,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')

        combpresc3.bind(on_release=self.rechfacturepresc)
        combpresc3.bind(text=self.affrecfacture)

        
        tablprescription=MDDataTable(column_data=[
                ("Identifiant",dp(40)),
                ("Docteur",dp(40)),
                ("Produit",dp(30)),
                ("PU",dp(30)),
                ("PT ",dp(30)),
                ("Date_Heure ",dp(40)),
                ("Date",dp(30)),
                ("Travailleur ",dp(30))
                ],size_hint=(0.9,0.65),pos_hint={'center_x':0.5,'y':0.1},check=True,rows_num=20,use_pagination=True)
        tablprescription.bind(on_check_press=self.affinfoprise)

        btbasss1=Builder.load_string('''
Button:
    text:"Inscription"
    font_size:'20sp'
    color:'black'
    background_color:[0,0,0,0]
    size_hint:.5,.8
    pos_hint:{'x':.02,'center_y':.5}
    bold:True

''')
        btbasss1.bind(on_release=self.inscriptionPage)

        btbasss2=Builder.load_string('''
Button:
    text:"Prescription"
    font_size:'20sp'
    color:'black'
    background_color:[0,0,0,0]
    size_hint:.5,.8
    pos_hint:{'x':.52,'center_y':.5}
    bold:True
                                     
''')
        btbasss2.bind(on_release=self.PrescriptionPage)

        cadprisebase.add_widget(btbasss1)
        cadprisebase.add_widget(btbasss2)

        try:
            cadresuitchmorr.add_widget(suitsaveprise)
        except:
            pass

        try:
            cadreprischarge.add_widget(tprise3)
            cadreprischarge.add_widget(tprise2)
            cadreprischarge.add_widget(tprise1)

            cadreprischarge.add_widget(tprisee3)
            cadreprischarge.add_widget(tprisee2)
            cadreprischarge.add_widget(tprisee1)

            cadreprischarge.add_widget(btsavprise) 
            cadreprischarge.add_widget(labupdatpris)
            cadreprischarge.add_widget(cadresuitchmorr)

            cadreprischarge.add_widget(tablprise) 

        except:
            pass
        try:
            cadreprischarge.add_widget(cadprisebase)
        except:
            pass
        

        cadre=Builder.load_string('''
                                  
FloatLayout:
    size_hint:.98,.98
    pos_hint:{'center_x':.5,'center_y':.5}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]

        ''')
        
        cadregauche=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        Rectangle:
            size:self.size
            pos:self.pos

        ''')

        barrmenu=Builder.load_string(
'''
FloatLayout:

    size_hint: 1, .07
    pos_hint: {'x': 0,'y': 0.93}

    canvas.before:
        Color:
            rgba:0,0,1,1
        Rectangle:
            size:self.size
            pos:self.pos
            
    MDTopAppBar:
        title: "MENU"
        pos_hint: {'x': 0,'y': 0}
        size_hint:1,1
        md_bg_color: [0,0,1,1]
        elevation:4
        left_action_items: [["menu", lambda x: app.sepliernew(self)]]
        right_action_items: [["dots-vertical", lambda x: app.sepliernew(self)]]

''')
        
        cadscroll=ScrollView()
        #cadregauche=FloatLayout()
    

        b1=Builder.load_string('''
Button:
    size_hint:0.37,0.1
    text:"Accueil"
    color:'black'
    background_color:[0,0,0,0]
    font_size:"22"
    bold:True

        
        ''')
        b1.bind(on_release=self.pageaccueil)

        b2=Builder.load_string('''
Button:
    size_hint:0.68,0.1
    text:"Ajout Produit"
    color:'black'
    background_color:[0,0,0,0]
    font_size:"22"
    bold:True
        
        ''')
        b2.bind(on_release=self.pageinsert)

        b3=Builder.load_string('''
Button:
    size_hint:0.59,0.1
    text:"Mise à jour"
    color:'black'
    background_color:[0,0,0,0]
    font_size:"22"
    bold:True
        
        ''')
        b3.bind(on_release=self.pagemodif)

        b4=Builder.load_string('''
Button:
    size_hint:0.75,0.1
    text:"Gestion Ventes"
    color:'black'
    background_color:[0,0,0,0]
    font_size:"22"
    bold:True
        
        ''')
        b4.bind(on_release=self.gestionventes)

        b5=Builder.load_string('''
Button:
    size_hint:0.7,0.1
    text:"Gestion Stock"
    color:'black'
    background_color:[0,0,0,0]
    border:0,0,0,0
    font_size:"22"
    bold:True
        
        ''')
        b5.bind(on_release=self.gestionstock)

        b6=Builder.load_string('''
Button:
    size_hint:0.8,0.1
    text:"Prise en charge"
    color:'black'
    background_color:[0,0,0,0]
    font_size:"22"
    bold:True
        
        ''')
        b6.bind(on_release=self.pageprisecharge)
        
        btaction=Button(size_hint=(0,0),pos_hint={'x':0,'top':0.86})#(size_hint=(0.05,0.1),pos_hint={'x':0,'top':0.86})
        #btaction.background_normal='c1.PNG'
        #btaction.bind(on_press=self.seplier)

        cadremenue=Builder.load_string('''
BoxLayout:
    orientation:'vertical'
    spacing:10
    padding:10

    size_hint:.2,.7
    pos_hint:{'x':.04,'y':.23}

    canvas.before:
        Color:
            rgba:216/255,216/255,216/255,216/255
                                       
        RoundedRectangle:

            size:self.size
            pos:self.pos

            radius:[2]
        
        ''')

        try:
            cadremenue.add_widget(b1)
            cadremenue.add_widget(b2)
            cadremenue.add_widget(b3)
            cadremenue.add_widget(b4)
            cadremenue.add_widget(b5)
            cadremenue.add_widget(b6)
        except:
            pass

        btic1=Builder.load_string('''
MDIconButton:
    icon:'home'
    size_hint:.95,.1
    theme_text_color:'Custom'
    text_color:[0,0,1,1]
                                      
        ''')

        btic2=Builder.load_string('''
MDIconButton:
    icon:'basket-plus'
    size_hint:.95,.1
    theme_text_color:'Custom'
    text_color:[0,0,1,1]
                                      
        ''')

        btic3=Builder.load_string('''
MDIconButton:
    icon:'book-edit'
    size_hint:.95,.1
    theme_text_color:'Custom'
    text_color:[0,0,1,1]
                                      
        ''')

        btic4=Builder.load_string('''
MDIconButton:
    icon:'cart-plus'
    size_hint:.95,.1
    theme_text_color:'Custom'
    text_color:[0,0,1,1]
                                      
        ''')

        btic5=Builder.load_string('''
MDIconButton:
    icon:'database'
    size_hint:.95,.1
    theme_text_color:'Custom'
    text_color:[0,0,1,1]
                                      
        ''')

        btic6=Builder.load_string('''
MDIconButton:
    icon:'family-tree'
    size_hint:.95,.1
    theme_text_color:'Custom'
    text_color:[0,0,1,1]
                                      
        ''')

        cadremenueIcon=Builder.load_string('''
BoxLayout:
    orientation:'vertical'
    spacing:10
    padding:10

    size_hint:.04,.7
    pos_hint:{'x':0,'y':.23}

    canvas.before:
        Color:
            rgba:216/255,216/255,216/255,216/255
                                       
        RoundedRectangle:

            size:self.size
            pos:self.pos

            radius:[2]
        
        ''')

        try:
            cadremenueIcon.add_widget(btic1)
        except:
            pass

        try:
            cadremenueIcon.add_widget(btic2)
        except:
            pass

        try:
            cadremenueIcon.add_widget(btic3)
        except:
            pass

        try:
            cadremenueIcon.add_widget(btic4)
        except:
            pass

        try:
            cadremenueIcon.add_widget(btic5)
        except:
            pass
    
        try:
            cadremenueIcon.add_widget(btic6)
        except:
            pass

        
        #imgtete=Image(source="photot.jpg", size_hint=(0.99,0.25), pos_hint={'x':0,'top':1})
        imgg=Image(source="storage.ico", size_hint=(0.2,0.2), pos_hint={'center_x':0.1,'center_y':0.9})

        imgexpert=Button(pos_hint={'x':0.001,'y':0.12},size_hint=(0.07,0.2),background_normal='')

        # les font d page 

        btfond=Button(pos_hint={'x':0,'y':0},size_hint=(0.98,0.98),background_normal='page_connexion.png')
        fondpagevente=Button(pos_hint={'center_x':0.5,'center_y':0.5},size_hint=(0.99,0.99),background_normal='pagevente.jpg')
        fondacceuil=Button(background_normal="page_accueil.jpg", size_hint=(0.99,0.99), pos_hint={'center_x':0.5,'center_y':0.5})
        
        #  fondacceuil.background_normal='page_insert.jpg'

        imgtaux=Button(background_normal='USD-CDF-sep.png',pos_hint={'x':0.002,'y':0.5},size_hint=(0.1,0.14))
        imgtaux.bind(on_release=self.chargetaux)

        taux=Label(text="[b]0[/b]",color='black',pos_hint={'x':0.0,'y':0.45},size_hint=(0.15,0.06),font_size='20sp',markup=True)
        

        trech = TextInput(text="Rechercher", font_size='20sp',
            pos_hint={'x':0.75, 'y':0.94},size_hint=(0.15,0.05))
        trech.bind(focus=self.eff)
        btnrechimgdirrect=Button(pos_hint={'x':0.68, 'y':0.92},size_hint=(0.07,0.1))
        btnrechimgdirrect.background_normal='numeriseur.ico'
        btnrechimgdirrect.bind(on_release=self.chargeinfo)

        btnrechimg=Button(pos_hint={'x':0, 'y':0},size_hint=(0,0))#{'x':0.9, 'y':0.92},size_hint=(0.09,0.1))
        btnrechimg.background_normal='rech.png'
        btnrechimg.bind(on_press=self.rechinfo)

        tabmod=MDDataTable(column_data=[], 
                                row_data=[],
                                size_hint=(0.4,0.05),
                                pos_hint={'x':0.25,'y':0.95},rows_num=1500,pagination_menu_pos='auto')
        
        # auxiliaire 
        tabmod.size_hint=(0.4,0.05)
        tabmod.pos_hint={'x':0.25,'y':0.95}

        photoproduit=Button(pos_hint={'x':0.2,'y':0.33},size_hint=(0.0,0.0),background_normal='')
                            
        labmod=Label(text="[b]INSERTION DE DONNEES[/b]",markup=True,color="black",font_size="27sp",pos_hint={'x':0.5,'y':0.5},size_hint=(0.3,0.07))
    
        bautomodiftravprod=Builder.load_string('''
MDIconButton:
    icon:'qrcode'
    pos_hint:{'x':0.13, 'y':0.88}
    size_hint:0.06,0.09

    on_release:app.chargeinfo(self)
''')
        #bautomodiftravprod.background_normal="numeriseur.ico"
        #bautomodiftravprod.bind(on_release=self.chargeinfo)
        
        
        bscanneur=Button(pos_hint={'x':0.11, 'y':0.87},size_hint=(0,0))#0.06,0.09
        bscanneur.background_normal="numeriseur.icoo"
        bscanneur.bind(on_release=self.chargeinfo)

        checkcodelocal=Builder.load_string('''
CheckBox:
    active:True
    pos_hint:{'x':0.1,'y':0.94}
    size_hint:0.02,0.025

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[2]

''')
        checkcodelocal.bind(active=self.idlocall)
        labcodelocal=Label(text='[b]Local QR[/b]',markup=True,color='black',pos_hint={'x':0.01,'y':0.93},size_hint=(0.065,0.05))
        
        indicateurindice=Builder.load_string('''

CheckBox:
    #active:True
    pos_hint:{'x':0.1,'y':0.91}
    size_hint:0.02,0.025

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[2]

''')
        indicateurindice.bind(active=self.idlocall)
        labindice=Label(text='[b]Indice #[/b]',markup=True,color='black',pos_hint={'x':0.01,'y':0.9},size_hint=(0.065,0.05))



        t1 = MDTextField(hint_text="ID ", icon_right='spider', helper_text="ID Medicament",font_size='20sp',line_color_focus="red",
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.14, 'y':0.86},size_hint=(0.25,0.1))
        
        t2 = MDTextField(hint_text="Nom",icon_right='text', helper_text="Nom Medicament",font_size='20sp',
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.5, 'y':0.86},size_hint=(0.4,0.1))
        t2.bind(on_text_validate=self.depl1)

        t3 = MDTextField(hint_text="Catégorie",icon_right='alert', helper_text="Catégorie médicament",font_size='20sp',
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.14, 'y':0.78},size_hint=(0.25,0.1))
        t3.bind(on_text_validate=self.depl1)
        
        t4 = MDTextField(hint_text="Anti",icon_right='apache-kafka', helper_text="Maladie qu'il ne supporte",font_size='20sp',
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.5, 'y':0.78},size_hint=(0.4,0.1))
        t4.bind(on_text_validate=self.depl1)

        t5 = MDTextField(hint_text="Ca traite",icon_right='apache-kafka',line_color_normal='black', helper_text="Maladie à guerir",font_size='20sp',
            helper_text_mode="on_focus", pos_hint={'x':0.14, 'y':0.68},size_hint=(0.25,0.1))
        t5.bind(on_text_validate=self.depl1)

        t6 = MDTextField(hint_text="Posologie",icon_right='chess-pawn', helper_text="Mode d'utilisation",font_size='20sp',
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.5, 'y':0.68},size_hint=(0.4,0.1))
        t6.bind(on_text_validate=self.depl1)

        t7 = MDTextField(hint_text="Echeance d'age", icon_right='chess-queen', helper_text="Decalage d'age",font_size='20sp',
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.14, 'y':0.58},size_hint=(0.25,0.1))
        t7.bind(on_text_validate=self.depl1)

        t8 = MDTextField(hint_text="Prix unitaire USD", icon_right='currency-eur', helper_text="Prix unitaire",font_size='20sp',
            helper_text_mode="on_focus",line_color_normal='black', pos_hint={'x':0.5, 'y':0.58},size_hint=(0.4,0.1))
        t8.bind(on_text_validate=self.depl1)
        #t8.bind(text=self.arrondir)
        

        t9 = MDTextField(hint_text="Stock Unitial",icon_right='archive-market', helper_text="Nombre d'echantillon que compte le produit",font_size='20sp',
            helper_text_mode="on_focus", line_color_normal='black',pos_hint={'x':0.14, 'y':0.48},size_hint=(0.25,0.1))
        t9.bind(on_text_validate=self.depl1)

        t10 = MDTextField(hint_text="Date",icon_right='calandar',line_color_normal='black', helper_text="Date d'acquisition",
            helper_text_mode="on_focus", pos_hint={'x':0.5, 'y':0.48},size_hint=(0.4,0.1))
        t10.bind(on_text_validate=self.depl1)
        
        tunitil=MDTextField(text="..",pos_hint={'x':0, 'y':0},size_hint=(0.2,0.1))
        #l1 = MDLabel(text="Ajouter la photo", pos_hint={'x':0.5, 'y':0.38},size_hint=(0.4,0.1))
        btncamera=Button(size_hint=(0.07,0.1),pos_hint={'x':0.5, 'y':0.38})
        btncamera.background_normal='2956596.png'
        btncamera.bind(on_release=self.capturerproduit)
        
        #opendialog=MDDialog(title='Select categorie',type='confirmatio,',items=[CategoryPopup(text="M"),CategoryPopup(text="F")])
        labremarque=MDLabel(text="[b]Remarque[/b]",font_size='3sp',theme_text_color="Custom",text_color='tomato',pos_hint={'x':0.01, 'y':0.40},size_hint=(0.25,0.2),markup=True)
        labremarque0=MDLabel(font_size='2sp',text="1. ID non modificable\n2. Stock non modificable\n3. Date non modificable",theme_text_color="Custom",text_color='black',pos_hint={'x':0.01, 'y':0.30},size_hint=(0.3,0.25),markup=True)

        btenregistrer=Builder.load_string('''
Button:
    text:'[b]Enregistrer[/b]'
    size_hint:0.25,0.4
    color:'white'
    pos_hint:{'x':0.7, 'y':0.38}
    background_color:[0,0,0,0]
    font_size:'16sp'
    markup:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        
        
        btenregistrer.bind(on_press=self.operation)

        btrefresh=Builder.load_string('''
MDIconButton:
    icon:'eye-refresh'
    pos_hint:{'x':.3,'center_y':.5}
    size_hint:.02,.5

    theme_text_color:'Custom'
    text_color:[1,0,0,1]

    on_release:app.refreshProduit(self)   
        
        ''')
        cadbtnUsdCdfchange=Builder.load_string('''
FloatLayout:
    size_hint:.04,.32
    pos_hint:{'x':0.6,'y':0.4}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:

            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        checkchangecdf=Builder.load_string('''
MDSwitch:
    pos_hint:{'center_x':0.5,'center_y':0.5}
    color_active:'red'
    active:True
    #icon_inactive:'close'
    #icon_inactive_color: "grey"
    on_active:app.changecdf(self)     
        
        ''')

        try:
            cadbtnUsdCdfchange.add_widget(checkchangecdf)
        except:
            pass

        labchangex=Label(text="[b]Change CDF[/b]",font_size='15sp',markup=True,pos_hint={'x':0.5,'center_y':0.5},size_hint=(0.06,0.1),color='black')

        labinput=Label(text="[b]Input USD[/b]",font_size='15sp',markup=True,pos_hint={'x':0.35,'center_y':0.5},size_hint=(0.06,0.1),color='black')
        
        cadbtnUsdCdf=Builder.load_string('''
FloatLayout:
    size_hint:.04,.32
    pos_hint:{'x':.42,'center_y':.5}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:

            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        btnchangeCdfUsd=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    active:True
    #icon_inactive:'close'
    #icon_inactive_color: "grey"
    on_active:app.changeinput(self)    
        
        ''')

        try:
            cadbtnUsdCdf.add_widget(btnchangeCdfUsd)
        except:
            pass


        cadbtsave=Builder.load_string('''
FloatLayout:
    size_hint:1,.11
    pos_hint:{'x':0,'y':.35}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
        
        ''') 

        try:
            cadbtsave.add_widget(btrefresh)
        except:
            pass   

        try:
            cadbtsave.add_widget(cadbtnUsdCdf)
            cadbtsave.add_widget(labinput)
        except:
            pass

        try:
            cadbtsave.add_widget(btenregistrer)
        
        except:
            pass
        try:
            cadbtsave.add_widget(labchangex)
        except:
            pass

        try:
            cadbtsave.add_widget(cadbtnUsdCdfchange)
        except:
            pass

        tabl=MDDataTable(column_data=[
                ("Nom",dp(30)),
                (("Postnom",dp(30))),
                (("Prenom",dp(30))),
                (("Sexe",dp(10))),
                (("ID travailleur",dp(30))),
                (("Pwd",dp(25))),
                (("Type ",dp(25))),
                (("Date",dp(30))) 
                ],size_hint=(0.9,0.4),pos_hint={'x':0.05,'y':0.05},check=True,rows_num=20,use_pagination=True)
        tabl.bind(on_check_press=self.affitravail)

        tablmotiftravil=MDDataTable(column_data=[
                ("MOTIF",dp(60)),
                (("DETAIL",dp(70))),
                (("ID TRAVAILLEUR",dp(30))),
                (("DATE",dp(30))),
                (("DATE ET HEURE",dp(30))),
                (("MONTANT",dp(30))) 
                ],size_hint=(0.9,0.4),pos_hint={'x':0.05,'y':0.05},check=True,rows_num=20,use_pagination=True)
        tablmotiftravil.bind(on_check_press=self.affmotif)

        table=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("Nom",dp(35))),
            (("Catégorie",dp(35))),
            (("Anti..",dp(40))),
            (("Maladie Traitée",dp(40))),
            (("Posologie",dp(25))),
            (("Age ",dp(25))),
            (("Prix unitaire",dp(25))),
            (("Stock Initial",dp(25))),
            (("Date",dp(25))),
            (("Stock Courant",dp(25)))   
            ], row_data=[],
            size_hint=(0.9,0.3),
            pos_hint={'x':0.036,'y':0.01},check=True,rows_num=2000,use_pagination=True)
        table.bind(on_check_press=self.afficheviaclic) 
   
        # les outils de table de la page tableau de bord

        tabunitiltete=MDDataTable(column_data=[], 
                                row_data=[],
                                size_hint=(0.4,0.05),
                                pos_hint={'x':0.25,'y':0.95},rows_num=1500,pagination_menu_pos='auto')

        tablegestionvente=MDDataTable(column_data=[("ID_Produit",dp(50)),("PU",dp(30)),("Qte",dp(30)),("PT",dp(30)),("Nom_client",dp(30)),("Date",dp(30)),("Date_Time",dp(30)),("ID_Travailleur",dp(30))], row_data=[],size_hint=(0.9,0.605),pos_hint={'x':0.05,'y':0.2},check=True,rows_num=2000,use_pagination=True)
        tablegestionvente.bind(on_check_press=self.affnomprodv)

        labqt=Label(text="Quantité Vendue",color="black",font_size="20sp",pos_hint={'x':0.5,'y':0.1},size_hint=(0.25,0.1))
        labtot=Label(text="Prix Total",color="black",font_size="20sp",pos_hint={'x':0.7,'y':0.1},size_hint=(0.25,0.1))
        qt=Label(text=".",color="blue",font_size="20sp",pos_hint={'x':0.515,'y':0.04},size_hint=(0.25,0.1))
        tot=Label(text=".",color="blue",font_size="20sp",pos_hint={'x':0.715,'y':0.04},size_hint=(0.25,0.1))
        
        hautlab1=Label(text="[b]TABLEAU DE BORD[/b]",markup=True,color="black",font_size="23sp",pos_hint={'x':0.2,'y':0.75},size_hint=(0.3,0.1))
        
        hlab2=Label(text="Trier par Date",color="black",font_size="16sp",pos_hint={'x':0.4,'center_y':0.5},size_hint=(0.2,0.1))
        hlab1=Label(text="Trier par ID",color="black",font_size="16sp",pos_hint={'x':0.65,'center_y':0.5},size_hint=(0.2,0.1))
        hlab3=Label(text="Trier par ID Travailleur",color="black",font_size="16sp",pos_hint={'x':0.1,'center_y':0.5},size_hint=(0.2,0.1))

        #btrierdate=Button(pos_hint={'x':0.64, 'center_y':0.5},size_hint=(0.05,0.8))
        #btrierdate.background_normal='rech.png'
        #btrierdate.bind(on_release=self.affichdate)

        btrierdate=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    pos_hint:{'x':0.64, 'center_y':0.5}
    size_hint:0.08,0.8

    on_release:app.affichdate(self)
        
        
        ''')
        
        #btrid=Button(pos_hint={'x':0.89, 'center_y':0.5},size_hint=(0.5,0.8))
        #btrid.background_normal='rech.png'
        #btrid.bind(on_release=self.affichId)

        btrid=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    pos_hint:{'x':0.89, 'center_y':0.5}
    size_hint:0.08,0.8

    on_release:app.affichId(self)
        
        ''')
        
        #btridtrav=Button(pos_hint={'x':0.38, 'center_y':0.5},size_hint=(0.5,0.8))
        #btridtrav.background_normal='rech.png'
        #btridtrav.bind(on_release=self.rechidtrav)
        
        btridtrav=Builder.load_string('''
MDIconButton:
    icon:'card-search'
    pos_hint:{'x':0.38, 'center_y':0.5}
    size_hint:0.08,0.8

    on_release:app.rechidtrav(self)
        
        ''')

        combo1=Builder.load_string('''
Spinner:
    text:"Toutes"
    pos_hint:{'x':0.56, 'center_y':0.5}
    size_hint:0.15,0.5
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        
        ''')
        
        combo1.bind(text=self.traiterdater)
        combo1.bind(on_release=self.rechdate)

        combo2=Builder.load_string('''
Spinner:
    text:"Tous"
    pos_hint:{'x':0.80, 'center_y':0.5}
    size_hint:0.15,0.5
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        
        ''')
        
        combo2.bind(text=self.traiterId)
        combo2.bind(on_release=self.rechId)

        combotrav=Builder.load_string('''
Spinner:
    text:"Tous"
    pos_hint:{'x':0.29, 'center_y':0.5}
    size_hint:0.15,0.5
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        
        ''')
        
        combotrav.bind(on_release=self.affidtravailleur)
        combotrav.bind(text=self.traiteridtrav)
    
        cadbttablbordhaut=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'

    size_hint:1,.08
    pos_hint:{'x':0,'y':.812}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

        try:
            cadbttablbordhaut.add_widget(hlab3)
            cadbttablbordhaut.add_widget(combotrav)
            cadbttablbordhaut.add_widget(btridtrav)
            cadbttablbordhaut.add_widget(hlab2)
            cadbttablbordhaut.add_widget(combo1)
            cadbttablbordhaut.add_widget(btrierdate)

            cadbttablbordhaut.add_widget(hlab1)
            cadbttablbordhaut.add_widget(combo2)
            cadbttablbordhaut.add_widget(btrid)

        except:
            pass




        btrechcombine=Builder.load_string('''
MDIconButton:
    icon:'table-filter'
    pos_hint:{'x':0.83, 'center_y':0.5}
    size_hint:0.06,0.5

    on_release:app.rechcombine(self)
        
''')

        checkcombine=Builder.load_string('''

MDCheckbox:
        pos_hint:{'x':0.4,'center_y':0.5}
        size_hint:.05,.5
        color_active:'blue'
        color_inactive:'red'
        #on_active:app.fchecktrie1(self)
                                                 
''')
        
        
        #checkcombine.bind(active=self.fchecktrie1)
        labcombine=Label(text="[b]Combiné[/b]",color="black",markup=True,font_size="15sp",pos_hint={'x':0.27,'center_y':0.5},size_hint=(0.1,0.05))

        checkgobal=Builder.load_string('''

MDCheckbox:
        pos_hint:{'x':0.67,'center_y':0.5}
        size_hint:.05,.5
        color_active:'blue'
        color_inactive:'red'
       
''')
        
        labglobal=Label(text="[b]Global[/b]",color="black",markup=True,font_size="15sp",pos_hint={'x':0.52,'center_y':0.5},size_hint=(0.1,0.05))
        
        bcalcbenefice=Builder.load_string('''
MDIconButton:
    icon:'scale-balance'  
    pos_hint:{'x':0.1,'center_y':0.5}
    size_hint:0.05,0.5

    on_release:app.configbenefice(self)

''')

        cadbttablbord=Builder.load_string('''
FloatLayout:
    size_hint:.4,.1
    pos_hint:{'x':.05,'y':.05}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')

        try:
            cadbttablbord.add_widget(btrechcombine)
            cadbttablbord.add_widget(checkcombine)
            cadbttablbord.add_widget(labcombine)
            cadbttablbord.add_widget(checkgobal)
            cadbttablbord.add_widget(bcalcbenefice)
            cadbttablbord.add_widget(labglobal)

        except:
            pass


        #btrechcombine=Button(pos_hint={'x':0.3, 'y':0.04},size_hint=(0.06,0.1))
        #btrechcombine.background_normal='oks.jpg'
        #btrechcombine.bind(on_release=self.rechcombine)
        
        #les outils de la page de connexion checkgobal.active=True

        btnconn=Button(text="[b]Connexion[/b]",markup=True,color='white',background_color="blue",font_size='30sp',pos_hint={'x':0.5, 'y':0.3},size_hint=(0.3,0.08))
        btnconn.bind(on_release=self.camparersecurite)
        
        tidconn = MDTextField(hint_text="Identifiant",icon_right='account-circle',font_size="22sp",line_color_normal='black',pos_hint={'x':0.2, 'y':0.62},size_hint=(0.6,0.1))
        
        tpwdconn = MDTextField(hint_text="Votre Password",icon_right='eye',password=True,font_size='22sp',line_color_normal='black',pos_hint={'x':0.2, 'y':0.45},size_hint=(0.6,0.1))
        
        imggconn=Image(source="fast.jpg", size_hint=(0.0,0.0), pos_hint={'x':0.4,'y':0})
        labconn=Label(text="[b]Connectez-vous[/b]",color="black",markup=True,font_size="26sp",pos_hint={'x':0.3,'y':0.8},size_hint=(0.4,0.1))
        
        bretour=Button(pos_hint={'x':0, 'y':0.85},size_hint=(0.13,0.16))
        bretour.background_normal="back.jpg"
        bretour.bind(on_release=self.retour)

        # les outils de lapage d'accueil
            #les hauts outils
        taccueil=MDDataTable(column_data=[], 
                                row_data=[],
                                size_hint=(0.4,0.05),
                                pos_hint={'x':0.25,'y':0.95},rows_num=1500,pagination_menu_pos='auto')
        laccueil=Label(text="[b]BIENVENU AU SUPER PHARMA[/b]",color="black",markup=True,font_size="23sp",pos_hint={'x':0.65,'y':0.78},size_hint=(0.2,0.1))
        imgaccuel=Image(source="pharma.png", size_hint=(0,0), pos_hint={'x':0,'y':0}) #size_hint=(0.1,0.15), pos_hint={'x':0.88,'y':0.85}

        imglogo=Image(source="mon logoo.jpg", size_hint=(0,0), pos_hint={'x':0,'y':0})#source="mon logoo.jpg", size_hint=(0.0,0.0), pos_hint={'x':-0.02,'y':0}
        
        imgacc1=Image(source="IMG-20220211-WA0023.jpg", size_hint=(0,0), pos_hint={'x':0,'y':0})
        imgacc2=Image(source="MAQUETTE SUPER PHARMA 2.jpg", size_hint=(0,0), pos_hint={'x':0,'y':0})
        imgacc3=Image(source="maquette_accuel.jpg", size_hint=(0,0), pos_hint={'x':0,'y':0})
        # page_accueil.jpg"

        imgacc3=Label(text="[b]NOTA : Ce produit est concu\nsur les règles et  principes\ncongolais  en collaboration\navec les pharmaciens compétents[/b]",color="black",markup=True,font_size="20sp",pos_hint={'center_x':0.5,'center_y':0.4},size_hint=(0.5,0.5))

        #Cher  Gestionnaire,  c'est une  chance d'avoir\ncet outil pour la gestion de votre organisation,\nil sied  de  vous assurer  que ce dernier vous\nassistera  :  d'évaluer  avec   exactitude  les\nopérations journalières, hebdomadaires,mensuelles\net annuelles et aussi cet outil peut vous assiter\ndans la prise de décision : voir  les  produits\nrentables et  produits  non  rentables au cours\nd'une période\nCe logiciel Expert permet le control des ventes,\nravitaillements de produits pharmaceutiques \nde pret ou à distance afin de pouvoir bien prendre\nla décision et laisses moi vous garentir \nqu'aucune perte ne sera à votre porté si ce \nn'est pas ta faute de manipulation 
        
        ladmin=Label(text="[b]Gestionnaire[/b]",color="black",markup=True,font_size="26sp",pos_hint={'x':0.1,'y':0.78},size_hint=(0.2,0.1))
        luser=Label(text="[b]Travailleur[/b]",color="black",markup=True,font_size="26sp",pos_hint={'x':0.6,'y':0.78},size_hint=(0.2,0.1))
        lacc2=Label(text="[b]Vs[/b]",color="black",markup=True,font_size="28sp",pos_hint={'x':0.5,'y':0.5},size_hint=(0.2,0.1))

        lacc1=Label(text="L'espace décisionnel, stratégique\npermettant de fixer les objectifs et\ncritères afin d'améliorer la production de \nl'entreprise ",color="blue",markup=True,font_size="17sp",pos_hint={'x':0.02,'y':0.3},size_hint=(0.98,0.98))
        lacc3=Label(text="L'espace Travailleur, opératoire \npermettant d'accomplir les objectifs \nfixés par le comité directeur",color="blue",markup=True,font_size="17sp",pos_hint={'x':0.02,'y':0.3},size_hint=(0.98,0.98))
        
        accueilcad1=MDDataTable(column_data=[], row_data=[],size_hint=(0.3,0.2),pos_hint={'x':0.07,'y':0.6})
        accueilcad2=MDDataTable(column_data=[], row_data=[],size_hint=(0.17,0.2),pos_hint={'x':0.38,'y':0.6})
        accueilcad3=MDDataTable(column_data=[], row_data=[],size_hint=(0.3,0.2),pos_hint={'x':0.57,'y':0.6})

        #bgestionuserchanger=Button(pos_hint={'x':0.9,'y':0.6},font_size='20sp',size_hint=(0.04,0.07))
        #bgestionuserchanger.background_normal="undoarrow_undo_1534.ico"
        #bgestionuserchanger.bind(on_release=self.changergestuser) 
         
        labxx=Label(text="Update",bold=True,color='black',pos_hint={'x':.8,'y':.6},size_hint=(.1,.07),font_size='12sp')
        
        cadresuitchmode=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.9,'y':.6}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitchmode=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.changergestuser(self)
''')
         

        try:
            cadresuitchmode.add_widget(suitchmode)
        except:
            pass
       
        # les outils de la page de première  ,background_normal='',background_down='' 
        ptitre=Button(text="[b]Type de connexion[/b]",markup=True,color="black",font_size="25sp",pos_hint={'x':0.4,'y':0.8},size_hint=(0.2,0.05),background_normal='',background_down='')
        ptitre.bind(on_release=self.supsession)

        plabadmin=Label(text="[b]Gestionnaire[/b]",markup=True,color="black",font_size="20sp",pos_hint={'x':0.22,'y':0.55},size_hint=(0.2,0.05))
        plabuser=Label(text="[b]Travailleur[/b]",markup=True,color="black",font_size="20sp",pos_hint={'x':0.62,'y':0.55},size_hint=(0.2,0.05))
        
        badmin=Button(pos_hint={'x':0.2, 'y':0.3},size_hint=(0.2,0.2))
        badmin.background_normal='admin.png'
        badmin.bind(on_release=self.adminpage)

        buser=Button(pos_hint={'x':0.6, 'y':0.3},size_hint=(0.2,0.2))
        buser.background_normal="commander-1466555-1242334.png"
        buser.bind(on_release=self.userpage)

        configserveur=Button(pos_hint={'x':0.01,'y':0.8},size_hint=(0.15,0.18))
        configserveur.background_normal="storage.jpg"
        configserveur.bind(on_release=self.partageserveur)


        
        # outils de la page gestion de stock
        tablstockperime=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("Nom",dp(35))),
            (("Catégorie",dp(35))),
            (("Anti..",dp(40))),
            (("Maladie Traitée",dp(40))),
            (("Posologie",dp(25))),
            (("Age ",dp(25))),
            (("Prix unitaire",dp(25))),
            (("Stock Initial",dp(25))),
            (("Date",dp(25))),
            (("Stock Courant",dp(25)))
            ], row_data=[],size_hint=(0.9,0.7),pos_hint={'x':0.05,'y':0.15},check=True,rows_num=2000,use_pagination=True)


        tablstocktotal=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("Nom",dp(35))),
            (("Catégorie",dp(35))),
            (("Anti..",dp(40))),
            (("Maladie Traitée",dp(40))),
            (("Posologie",dp(25))),
            (("Age ",dp(25))),
            (("Prix unitaire",dp(25))),
            (("Stock Initial",dp(25))),
            (("Date",dp(25))),
            (("Stock Courant",dp(25)))
            ], row_data=[],size_hint=(0.9,0.38),pos_hint={'x':0.05,'y':0.45},check=True,rows_num=2000,use_pagination=True)

        labstockfini=Label(text="[b]STOCK EPUISE[/b]",color="black",font_size="20sp",pos_hint={'center_x':0.5,'y':0.37},size_hint=(0.2,0.1),markup=True)
        
        bflechhaut=Builder.load_string('''
MDIconButton:
    icon:'arrow-up-bold-circle'
    size_hint:0.6,0.2
    pos_hint:{'center_x':0.5,'y':0.7}

    on_release:app.haut(self)

        ''')

        #bflechhaut=Button(size_hint=(0.06,0.1),pos_hint={'x':0.935,'y':0.7})
        #bflechhaut.background_normal="fleche haute.jpg"
        #bflechhaut.bind(on_press=self.haut)
        

        #bflechbas=Button(size_hint=(0.06,0.1),pos_hint={'x':0.935,'y':0.5})
        #bflechbas.background_normal="fleche basse.jpg"
        #bflechbas.bind(on_press=self.bas)

        bflechbas=Builder.load_string('''
MDIconButton:
    icon:'arrow-down-bold-circle'
    size_hint:0.6,0.2
    pos_hint:{'center_x':0.5,'y':0.1}

    on_release:app.bas(self)

        ''')

        bflech0=Builder.load_string('''
MDIconButton:
    icon:'swap-vertical-circle'
    size_hint:0.6,0.2
    pos_hint:{'center_x':0.5,'y':0.4}

    on_release:app.centre(self)

        ''')

        #bflech0=Button(size_hint=(0.06,0.1),pos_hint={'x':0.935,'y':0.6})
        #bflech0.background_normal="fleche centre.jpg"
        #bflech0.bind(on_press=self.centre)

        cadrebtfleche=Builder.load_string('''
FloatLayout:
    size_hint:0.04,0.3
    pos_hint:{'x':.955,'y':.52}
    
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')

        try:
            cadrebtfleche.add_widget(bflechhaut)
            cadrebtfleche.add_widget(bflechbas)
            cadrebtfleche.add_widget(bflech0)
        except:
            pass 
    
        tablstockfini=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("Nom",dp(35))),
            (("Catégorie",dp(35))),
            (("Anti..",dp(40))),
            (("Maladie Traitée",dp(40))),
            (("Posologie",dp(25))),
            (("Age ",dp(25))),
            (("Prix unitaire",dp(25))),
            (("Stock Initial",dp(25))),
            (("Date",dp(25))),
            (("Stock Courant",dp(25)))
            ], row_data=[],size_hint=(0.9,0.25),pos_hint={'x':0.05,'y':0.13},check=True,rows_num=2000,use_pagination=True)
        
        

        # les outils de la page de ravitaillement Ajout


        cadreravitaiAjout=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:1,1,1 #202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        tablravAjout=MDDataTable(column_data=[  
            ("ID",dp(50)),
            ("Nom",dp(35)),
            ("Prix",dp(35)),
            ("Stock",dp(35)),
            ("Date Expiration",dp(40)),
            ("Créer",dp(40))

            ], row_data=[],size_hint=(0.6,0.73),pos_hint={'x':0.35,'y':0.13},check=True,rows_num=2000,use_pagination=True)

        tablravAjout.bind(on_check_press=self.retireelementBrouillon)

        labravv=Label(text="Change Input",size_hint=(.1,.08),pos_hint= {'x':.35,'y':.89},color='black')

        cadresuitcravv=Builder.load_string('''
FloatLayout:
    size_hint:.05,.04
    pos_hint: {'x':.45,'y':.9}  
                                                                                                        
    canvas.before:
        Color:
            rgb:111/255,94/255,103/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitravvAjout=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False

    on_active:app.changeinputAjout(self)
    
''')
        #suitravvAjout.bind(on_release=self.changeinputAjout)

        try:
            cadresuitcravv.add_widget(suitravvAjout)
        except:
            pass


        tnomProx=Builder.load_string('''
MDTextField:
    
    hint_text:'Nom Produit'
    pos_hint:{'x':.02,'y': .89}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'card-search'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tPrixUnitaire=Builder.load_string('''
MDTextField:
    
    hint_text:'Prix USD'
    pos_hint:{'x':.02,'y': .79}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tStockIinitial=Builder.load_string('''
MDTextField:
    
    hint_text:'Stock'
    pos_hint:{'x':.17,'y': .79}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        btsaveI=Builder.load_string('''
Button:
    text:"Enregistrer"
    size_hint:.15,.05
    pos_hint:{'x':.17,'y':.65}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        ''')

        btsaveI.bind(on_release=self.saveProduitDirect)

        try:
            cadreravitaiAjout.add_widget(btsaveI)
            cadreravitaiAjout.add_widget(tStockIinitial)
            cadreravitaiAjout.add_widget(tPrixUnitaire)
            cadreravitaiAjout.add_widget(tnomProx)
            cadreravitaiAjout.add_widget(cadresuitcravv)
            cadreravitaiAjout.add_widget(labravv)
            cadreravitaiAjout.add_widget(tablravAjout)
        except:
            pass


        # c"est ca le ravitaillement 


        cadreravitaimultiple=Builder.load_string('''
FloatLayout:
    size_hint:1,.92
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:1,1,1 #202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        
        tablravmultiple=MDDataTable(column_data=[
            ("N°",dp(25)),
            ("ID",dp(50)),
            ("Nom",dp(35)),
            ("Ajout",dp(35)),
            ("Date Expiration",dp(40)),
            ("USD",dp(35)),
            ("CDF",dp(40)),
            ("TravID",dp(40)) 

            ], row_data=[],size_hint=(0.6,0.73),pos_hint={'x':0.35,'y':0.13},check=True,rows_num=2000,use_pagination=True)

        tablravmultiple.bind(on_check_press=self.retireelementBrouillon)

        labravv=Label(text="Change Input",size_hint=(.1,.08),pos_hint= {'x':.35,'y':.89},color='black')

        cadresuitcravv=Builder.load_string('''
FloatLayout:
    size_hint:.05,.04
    pos_hint: {'x':.45,'y':.9}  
                                                                                                        
    canvas.before:
        Color:
            rgb:111/255,94/255,103/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitravv=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.changemodeinput(self)
''')
        try:
            cadresuitcravv.add_widget(suitravv)
        except:
            pass


        labravvprix=Label(text="Impact Prix",size_hint=(.1,.08),pos_hint= {'x':.6,'y':.89},color='black')
        
        cadresuitrapprix=Builder.load_string('''
FloatLayout:
    size_hint:.05,.04
    pos_hint: {'x':.7,'y':.9}  
                                                                                                        
    canvas.before:
        Color:
            rgb:111/255,94/255,103/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suitravvprix=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    #on_active:app.changebtnprise(self)
''')
        try:
            cadresuitrapprix.add_widget(suitravvprix)
        except:
            pass



        tidrechrav=Builder.load_string('''
MDTextField:
    
    hint_text:'Nom Produit'
    pos_hint:{'x':.02,'y': .89}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'card-search'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tprixrechrav=Builder.load_string('''
MDTextField:
    
    hint_text:'Prix USD'
    pos_hint:{'x':.02,'y': .79}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tqterechrav=Builder.load_string('''
MDTextField:
    
    hint_text:'Ajout'
    pos_hint:{'x':.17,'y': .79}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        tstockcourant=Builder.load_string('''
MDTextField:
    
    hint_text:'QTE Restant'
    pos_hint:{'x':.02,'y': .65}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'

    disabled:True
       
       ''') 
        
        combaffravv=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.17, 'y':0.91}
    size_hint:(0.15,0.04)
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
    
        
        ''')

        combaffravv.bind(on_release=self.rechprodds) 
        combaffravv.bind(text=self.affdetail)


        btajouterav=Builder.load_string('''
Button:
    text:"Ajouter"
    size_hint:.15,.05
    pos_hint:{'x':.17,'y':.65}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

            

        ''')

        btajouterav.bind(on_release=self.ajouterbrouillon)

        btretirerav=Builder.load_string('''
Button:
    text:"Retirer"
    size_hint:.15,.05
    pos_hint:{'x':.17,'y':.5}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''') 

        btretirerav.bind(on_release=self.retraitelement)

        btopenerrror=Builder.load_string('''
Button:
    text:"OpenError"
    size_hint:.1,.05
    pos_hint:{'x':.2,'y':.26}
    color:'black'
    background_color:[0,0,0,0]
    bold:True

        ''')
        btopenerrror.bind(on_release=self.openerrorbrouill)

        openerror=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    pos_hint:{'x':.27,'y':.26}
    size_hint:.05,.05
    theme_text_color:"Custom"
    text_color:'red'

    on_release:app.openerrorbrouill(self)
        
        ''')

        btcommiterav=Builder.load_string('''
Button:
    text:"Commuter"
    size_hint:.15,.05
    
    pos_hint:{'x':.17,'y':.2}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        ''')

        btcommiterav.bind(on_release=self.commuterbruillon)

        btchecking=Builder.load_string('''
Button:
    text:"Checking"
    size_hint:.15,.05
    pos_hint:{'x':.17,'y':.35}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

            

        ''') 

        btchecking.bind(on_release=self.checkingbrouillon)

        totqtbrouil=Builder.load_string('''
MDTextField:
    
    hint_text:'QUANTITE'
    pos_hint:{'x':.35,'y': .02}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
    disabled:True
       
       ''')

        totusdbrouil=Builder.load_string('''
MDTextField:
    
    hint_text:'NET USD'
    pos_hint:{'x':.62,'y': .02}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
    disabled:True
       
       ''')

        totcdfbrouil=Builder.load_string('''
MDTextField:
    
    hint_text:'NET CDF'
    pos_hint:{'x':.82,'y': .02}
    size_hint:.13,.1
    text_color:255/255,128/255,0/255
    icon_right:'text'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
    disabled:True
       
       ''')

        progressbarr=Builder.load_string('''
MDProgressBar:
    pos_hint:{'x':0,'y':0}
    value: 0  # Valeur initiale de la barre de progression
    max: 100  
        
        ''')

        cadexpiration=Builder.load_string('''
BoxLayout:
    orientation:'vertical'
    padding:10
    spaccing:10
    elevation:10

    size_hint:.08,.45
    pos_hint:{'x':.04,'y':.2}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')
        
        labbt=Label(text="Expiration",size_hint=(.9,.1),color="black",bold=True)

        labbtrr1=Label(text="",size_hint=(.9,.05),color="black",bold=True)
        labbtrr2=Label(text="",size_hint=(.9,.05),color="black",bold=True)

        btup1=Builder.load_string('''
MDIconButton:
    icon:'chevron-up-box-outline'
    size_hint:1,.05

    on_release:app.jrsplus(self)

        
        ''')

        

        anneexpmult=Builder.load_string('''

Spinner:
    text:"2026"
    font_size:"12sp"
    size_hint:.96,.15
    background_color:[0,0,0,0]
    color:"black"
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')

        anneexpmult.bind(on_release=self.chargerannee)


        btdown1=Builder.load_string('''
MDIconButton:
    icon:'chevron-down-box-outline'
    size_hint:1,.05

    on_release:app.jrsmoins(self) 

        
        ''')

        btup2=Builder.load_string('''
MDIconButton:
    icon:'chevron-up-box-outline'
    size_hint:1,.05

    on_release:app.plusmois(self)

        
        ''')

        moisexpmult=Builder.load_string('''

Spinner:
    text:"12"
    font_size:"12sp"
    background_color:[0,0,0,0]
    color:"black"
    bold:True
    size_hint:.96,.15

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')

        moisexpmult.bind(on_release=self.chargemois)

        btdown2=Builder.load_string('''
MDIconButton:
    icon:'chevron-down-box-outline'
    size_hint:1,.05

    on_release:app.moismoins(self)

        
        ''')

        
        btup3=Builder.load_string('''
MDIconButton:
    icon:'chevron-up-box-outline'
    size_hint:1,.05

    on_release:app.plusannee(self)  

        
        ''')

        jrsexpmult=Builder.load_string('''

Spinner:
    text:"30"
    font_size:"12sp"
    background_color:[0,0,0,0]
    color:"black"
    bold:True
    size_hint:.96,.15

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
    
        
        ''')

        jrsexpmult.bind(on_release=self.chargejour)

        btdown3=Builder.load_string('''
MDIconButton:
    icon:'chevron-down-box-outline'
    size_hint:1,.05

    on_release:app.moisannee(self)

        
        ''')

        btetatretir=Button(text="",size_hint=(.02,.45),pos_hint={'x':0,'y':.2},color='white',background_color=[202/255,202/255,202/255],background_normal="",bold=True)

        try:
            cadexpiration.add_widget(labbt)

            cadexpiration.add_widget(btup1)

            cadexpiration.add_widget(jrsexpmult)

            
            cadexpiration.add_widget(btdown1) 
            cadexpiration.add_widget(labbtrr1)
            cadexpiration.add_widget(btup2)

            cadexpiration.add_widget(moisexpmult)

            cadexpiration.add_widget(btdown2)
            cadexpiration.add_widget(labbtrr2)
            cadexpiration.add_widget(btup3)

            cadexpiration.add_widget(anneexpmult)

            cadexpiration.add_widget(btdown3)

            #cadexpiration.add_widget()
            #cadexpiration.add_widget()
        except:
            pass

        labbt=Label(text="Historique",size_hint=(.3,.1),color="black",bold=True,pos_hint={'x':.03,'y':.12})

        trechhisto=Builder.load_string('''
MDTextField:
    
    hint_text:'Recherche Histo'
    pos_hint:{'x':.02,'y':.03}
    size_hint:.15,.1
    text_color:255/255,128/255,0/255
    icon_right:'card-search'
    font_size:'14sp'
    line_color_normal:'black'
    text_color_normal:'black'
       
       ''')

        combrechhisto=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    size_hint:.15,.05
    pos_hint:{'x':.17,'y':.05}
    background_color:[0,0,0,0]
    color:"white"
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        ''') 

        combrechhisto.bind(on_release=self.rechdistincidfaccommande) 
        combrechhisto.bind(text=self.affidfaccommande)

        btopeninfo=Builder.load_string('''
Button:
    text:"OpenInfo"
    size_hint:.1,.05
    pos_hint:{'x':.2,'y':.0}
    color:'black'
    background_color:[0,0,0,0]
    bold:True

        ''')
        btopeninfo.bind(on_release=self.lireinfo)

        openinfo=Builder.load_string('''
MDIconButton:
    icon:'open-in-new'
    pos_hint:{'x':.27,'y':.0}
    size_hint:.05,.05
    theme_text_color:"Custom"
    text_color:'red'

    on_release:app.lireinfo(self)
        
        ''')


        try:
            #cadreravitaimultiple.add_widget(btclosravnew)
            cadreravitaimultiple.add_widget(tablravmultiple)
            cadreravitaimultiple.add_widget(tidrechrav)
            
            cadreravitaimultiple.add_widget(cadresuitcravv) 
            cadreravitaimultiple.add_widget(combaffravv)  
            cadreravitaimultiple.add_widget(labravv)

            cadreravitaimultiple.add_widget(cadresuitrapprix)
            cadreravitaimultiple.add_widget(labravvprix) 

            cadreravitaimultiple.add_widget(tprixrechrav)
            cadreravitaimultiple.add_widget(tqterechrav)
            cadreravitaimultiple.add_widget(tstockcourant)

            cadreravitaimultiple.add_widget(btchecking)
            cadreravitaimultiple.add_widget(btretirerav) 
            cadreravitaimultiple.add_widget(btcommiterav)

            cadreravitaimultiple.add_widget(btajouterav)

            cadreravitaimultiple.add_widget(btetatretir)

            cadreravitaimultiple.add_widget(totusdbrouil)
            cadreravitaimultiple.add_widget(totcdfbrouil)
            cadreravitaimultiple.add_widget(totqtbrouil) 
            
            cadreravitaimultiple.add_widget(cadexpiration) 

            cadreravitaimultiple.add_widget(combrechhisto)
            cadreravitaimultiple.add_widget(trechhisto)
            cadreravitaimultiple.add_widget(labbt)

            cadreravitaimultiple.add_widget(openinfo)
            cadreravitaimultiple.add_widget(btopeninfo)

        except:
            pass

        btopenravmult=Builder.load_string('''
MDIconButton:
    icon:'flask-empty-plus'
    pos_hint:{'x':.9,'y':.94}
    size_hint:.05,.05

    on_release:app.openravitamultp(self)
        
        ''')

        tablstock=MDDataTable(column_data=[
            ("ID",dp(50)),
            (("Nom",dp(35))),
            (("Catégorie",dp(35))),
            (("Anti..",dp(40))),
            (("Maladie Traitée",dp(40))),
            (("Posologie",dp(25))),
            (("Age ",dp(25))),
            (("Prix unitaire",dp(25))),
            (("Stock Initial",dp(25))),
            (("Date",dp(25))),
            (("Stock Courant",dp(25)))
            ], row_data=[],size_hint=(0.9,0.73),pos_hint={'x':0.05,'y':0.13},check=True,rows_num=2000,use_pagination=True)
        tablstock.bind(on_check_press=self.affravatail)

        tabstock1=MDDataTable(column_data=[("ID",dp(50)),("Nom",dp(30)),("Catégorie",dp(20)),("P.U",dp(20)),("Date",dp(20)),("S. Initial",dp(20)),("S. Courant",dp(20))], row_data=[],size_hint=(0.42,0.5),pos_hint={'x':0.05,'y':0.3},check=True,rows_num=2000,use_pagination=True)
        tabstock1.bind(on_check_press=self.afficheviaclicpagestock)
        
        tabstock2=MDDataTable(column_data=[("ID",dp(50)),("Nom",dp(30)),("Catégorie",dp(20)),("P.U",dp(20)),("Date",dp(20)),("S. Initial",dp(20)),("S. Courant",dp(20))], row_data=[],size_hint=(0.422,0.5),pos_hint={'x':0.52,'y':0.3},check=True,rows_num=2000,use_pagination=True)
        tabstock2.bind(on_check_press=self.afficheviaclicpagestock)

        labstock1=Label(text="[b]SITUATION NORMALE[/b]",markup=True,color="black",font_size="20sp",pos_hint={'x':0.12,'y':0.8},size_hint=(0.2,0.1))
        labstock2=Label(text="[b]SITUATION CRITIQUE[/b]",markup=True,color="black",font_size="20sp",pos_hint={'x':0.62,'y':0.8},size_hint=(0.2,0.1))
        #  partie basse de detail 
        
        tb1 = MDTextField(hint_text="ID",icon_right='spider',line_color_normal='black', disabled=True,font_size='22sp', pos_hint={'x':0.05, 'y':0.13},size_hint=(0.13,0.1))
        tb2 = MDTextField(hint_text="Nom",icon_right='text',line_color_normal='black',disabled=True,font_size='22sp', pos_hint={'x':0.21, 'y':0.13},size_hint=(0.2,0.1))
        tb3 = MDTextField(hint_text="Categorie",icon_right='alert',line_color_normal='black',disabled=True,font_size='22sp', pos_hint={'x':0.44, 'y':0.13},size_hint=(0.2,0.1))
        tb4 = MDTextField(hint_text="Prix Unitaire",icon_right='currency-eur',line_color_normal='black',disabled=True,font_size='22sp', pos_hint={'x':0.67, 'y':0.13},size_hint=(0.2,0.1))
        tb5 = MDTextField(hint_text="Stock courant",icon_right='archive-minus',line_color_normal='black',disabled=True,font_size='22sp', pos_hint={'x':0.21, 'y':0.05},size_hint=(0.2,0.1))
        tb6 = MDTextField(hint_text="Stock Initial",icon_right='archive-market',line_color_normal='black',disabled=True,font_size='22sp', pos_hint={'x':0.44, 'y':0.05},size_hint=(0.2,0.1))
        tb7 = MDTextField(hint_text="Date",icon_right='calandar',line_color_normal='black',font_size='22sp',disabled=True, pos_hint={'x':0.67, 'y':0.05},size_hint=(0.2,0.1))
        tb8 = MDTextField(hint_text="Quantité Vendue",icon_right='foot-takeout-box',line_color_normal='black',font_size='25sp',disabled=True, pos_hint={'x':0.05, 'y':0.05},size_hint=(0.13,0.1))
        ldetail=Label(text="[b]Détail[/b]",markup=True,color="black",font_size="20sp",pos_hint={'x':0.025,'y':0.25},size_hint=(0.1,0.05))

        bperemption=Builder.load_string("""
Button:
    text:"[b]Péremption Produit[/b]"
    markup:True
    elevation:4
    background_color:[0,0,0,0]
    color:'white'
    font_size:"18sp"
    pos_hint:{'x':0.07, 'y':0.05}
    size_hint:0.2,0.05

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        """)
        
        bperemption.bind(on_release=self.peremption)
        
        btnravitail=Builder.load_string('''
Button:
    text:"[b]Ravitaillement Produit[/b]"
    markup:True
    background_color:[0,0,0,0]
    color:'white'
    font_size:"18sp"
    pos_hint:{'x':0.3, 'y':0.05}
    size_hint:0.2,0.05

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')
        
        btnravitail.bind(on_release=self.ravitaillement)
        
        btnstock1=Builder.load_string('''
Button:
    text:"[b]Analyseur Performance[/b]"
    markup:True
    background_color:[0,0,0,0]
    color:'white'
    font_size:"18sp"
    pos_hint:{'x':0.52, 'y':0.05}
    size_hint:0.23,0.05

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]


''')
        
        btnstock1.bind(on_release=self.analyseurstock)

        btnstock2=Builder.load_string('''
Button:
    text:"[b]Stock Produit[/b]"
    markup:True
    background_color:[0,0,0,0]
    color:'white'
    font_size:"18sp"
    pos_hint:{'x':0.77, 'y':0.05}
    size_hint:0.17,0.05

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        
        btnstock2.bind(on_release=self.stock)

        btnmodqt=Builder.load_string('''
MDIconButton:
    icon:'content-save-edit'
    pos_hint:{'x':0.19, 'y':0.055}
    size_hint:0.05,0.08

    on_release:app.modquantproduit(self)

''')
        #btnmodqt.background_normal="image_downloader_1647277128354.png"
        #btnmodqt.bind(on_press=self.modquantproduit)
    
        img1=Image(source="house-icon_34406.png", size_hint=(0.12,0.14), pos_hint={'x':0.02,'y':0.86})
        img2=Image(source="wifi_wireless_internet_location_pointer_icon_124599.ico", size_hint=(0.12,0.14), pos_hint={'x':0.02,'y':0.76})
        img3=Image(source="calendar-5983133_960_720.png", size_hint=(0.12,0.14), pos_hint={'x':0.02,'y':0.66})
        img4=Image(source="adminn.png", size_hint=(0.12,0.14), pos_hint={'x':0.02,'y':0.56})


            
        


        #les outils de la page de vente
        labvente=Label(text="[b]SUPER PHARMA[/b]",color="black",markup=True,font_size="25sp",pos_hint={'x':0.4,'y':0.93},size_hint=(0.2,0.1))
        
        iccon1=Builder.load_string('''
MDIcon:
    icon:'account-group'
    pos_hint:{'x':0.38,'y':0.97}
    size_hint:.1,.1
    text_color:[0,0,1,1]
    theme_text_color:'Custom'
   
        
        ''')
        iccon2=Builder.load_string('''
MDIcon:
    icon:'account-group'
    pos_hint:{'x':0.37,'y':0.95}
    size_hint:.1,.1
    text_color:[1,0,0,1]
    theme_text_color:'Custom'

        ''')


        bcoupcendr=Builder.load_string('''

Button:
    text:'[b]Vendre[/b]'
    color:'white'
    background_color:[0,0,0,0]
    background_normal:""
    pos_hint:{'x':0.14, 'y':0.47}
    font_size:'20sp'
    markup:True
    size_hint:0.2,0.04  

    canvas.before:
        Color:
            rgb:255/255,7/255,1/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]      
''')

        bcoupcendr.bind(on_release=self.vendre)

        bjournal=Builder.load_string('''
Button:
    text:'[b]Journal[/b]'
    color:'white'
    background_color:[0,0,0,0]
    background_normal:''
    pos_hint:{'x':0.405, 'y':0.47}
    font_size:'20sp'
    markup:True
    size_hint:0.2,0.04

    canvas.before:
        Color:
            rgb:255/255,7/255,1/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        ''')

        bjournal.bind(on_release=self.journal)

        bsystem=Builder.load_string('''
Button:
    text:'[b]Mode Expert[/b]'
    color:'white'
    background_color:[0,0,0,0]
    background_normal:''
    pos_hint:{'x':0.65, 'y':0.47}
    font_size:'20sp'
    markup:True
    size_hint:0.25,0.04

    canvas.before:
        Color:
            rgb:255/255,7/255,1/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]     
        
        ''')
        
        bsystem.bind(on_release=self.modexpert)

        scroll1=ScrollView()

        tabv=MDDataTable(column_data=[], row_data=[],size_hint=(0.25,0.05),pos_hint={'x':0.375,'y':0.38},check=True)
        lbv=Label(text="[b]NOUVEAU COUPON[/b]",color="black",markup=True,font_size="20sp",pos_hint={'x':0.5,'y':0.5},size_hint=(0.2,0.05))
        
        tabvente1=MDDataTable(column_data=[("N°",dp(20)),("ID produit",dp(50)),("Nom",dp(35)),("P.U",dp(30)),("Quantité",dp(32)),("Prix total",dp(40))],rows_num=500,use_pagination=True, row_data=[],size_hint=(0.8,0.25),pos_hint={'x':0.1,'y':0.1},check=True)
        tabvente1.bind(on_check_press=self.retirecoupon)

        tabventejournal=MDDataTable(column_data=[("ID PRODUIT",dp(40)),("NOM",dp(40)),("PU",dp(20)),("QUANTITE",dp(25)),("PRIX TOTAL",dp(25)),("NOM CLIENT",dp(30)),("DATE",dp(20)),("DATE TIME",dp(30)),("ID TRAVAILLEUR",dp(30))], row_data=[],size_hint=(0.8,0.32),pos_hint={'x':0.1,'y':0.58},check=True,rows_num=2000,use_pagination=True)
        

        bvente1=Builder.load_string('''
            
MDIconButton:
    icon:'cart-plus'
    pos_hint:{'x':0.78, 'y':0.36}
    size_hint:0.06,0.1

    on_release:app.ajoutdanscoupon(self)
                                      
        ''')

        #bvente1=Button(pos_hint={'x':0.83, 'y':0.36},size_hint=(0.06,0.1))
        #bvente1.background_normal="add_new_user_16686.ico"
        #bvente1.bind(on_press=self.ajoutdanscoupon)

        bretireelementcoupon=Builder.load_string('''
Button:

    text:'[b]Retirer[/b]'
    color:'white'
    background_color:'blue'#[0,0,1,1]
    background_normal:''
    pos_hint:{'x':0.905, 'y':0.285}
    font_size:'15sp'
    markup:True
    size_hint:0.08,0.05
    
        ''')

        bretireelementcoupon.bind(on_release=self.retirecoup)

        bsuprimercoupon=Builder.load_string('''

Button:
    text:'[b]Suprimer[/b]'
    color:'white'
    background_color:'blue'
    background_normal:''
    pos_hint:{'x':0.905, 'y':0.205}
    font_size:'15sp'
    markup:True
    size_hint:0.08,0.05

    

    
''')
        
        bsuprimercoupon.bind(on_release=self.suprimercoupon)

        bvalidercoupon=Builder.load_string('''      
Button:
    text:'[b]Valider[/b]'
    color:'white'
    background_color:'blue'
    background_normal:''
    pos_hint:{'x':0.905, 'y':0.125}
    font_size:'15sp'
    markup:True
    size_hint:0.08,0.05
        
''')        
        
        bvalidercoupon.bind(on_release=self.validecoupon)

        bvueclaire=Button(pos_hint={'x':0.915, 'y':0.045},size_hint=(0.07,0.09))
        bvueclaire.background_normal="vue claire.jpg"
        bvueclaire.bind(on_release=self.affichevueclaire)

        bvueclaireadmin=Button(pos_hint={'x':0.923, 'y':0.045},size_hint=(0.07,0.09))
        bvueclaireadmin.background_normal="vue claire.jpg"
        bvueclaireadmin.bind(on_release=self.affdonneesclaire)

        bdemserveur=Button(pos_hint={'x':0, 'y':0},size_hint=(0,0)) # {'x':0.92, 'y':0.7},size_hint=(0.06,0.09)
        bdemserveur.background_normal="refresh_106672.png"
        bdemserveur.bind(on_release=self.demarreserveur)
        
        tquantite = MDTextField(hint_text="QUANTITE",icon_right='text',line_color_normal='black',font_size='22sp', pos_hint={'x':0.65, 'y':0.36},size_hint=(0.1,0.08), helper_text="Quantite voulue")
        
        labnet=Button(text='[b]NET A PAYER[/b]',background_normal='',background_down='',color='black',font_size='17sp',markup=True,pos_hint={'x':0.6,'y':0.015},size_hint=(0.1,0.08))
        labnet.bind(on_release=self.ajusterpt)

        #labnet=Label(text="[b]NET A PAYER[/b]",font_size='17sp',markup=True,pos_hint={'x':0.6,'y':0.015},size_hint=(0.1,0.08),color='black')
        labnetpayer=Label(text="[b].[/b]",font_size='17sp',markup=True,pos_hint={'x':0.7,'y':0.015},size_hint=(0.1,0.08),color='black')

        btirehaut=Builder.load_string('''
            
MDIconButton:
    icon:'book-cog'
    pos_hint:{'x':0.92,'y':0.92}
    size_hint:(0.06,0.085)
    text_color:255/255,128/255,0/255
    theme_text_color:'Custom'
    text_color:'black'

    on_release:app.opensetting(self)
                                      
        ''')
        
        
        #Button(pos_hint={'x':0.92,'y':0.92},size_hint=(0.06,0.085))
        #btirehaut.background_normal="configuration.ico"
        #btirehaut.bind(on_release=self.tirehaut)==0pensetting

        # les outils de la barre haute ==0pensetting


        cadrehautnew=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}
    
    canvas.before:
        Color:
            rgb:171/255,176/255,157/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
        
        ''')

        labhaut1=Label(text='[b]Type de camera[/b]',color='black',pos_hint={'x':0.05,'y':0.9},font_size='16sp',size_hint=(0.15,0.05),markup=True)
        labhaut2=Label(text='[b]Communication[/b]',color='black',pos_hint={'x':0.05,'y':0.8},font_size='16sp',size_hint=(0.15,0.05),markup=True)
        labhaut3=Label(text='[b]Type Affichage[/b]',color='black',pos_hint={'x':0.05,'y':0.7},font_size='16sp',size_hint=(0.15,0.05),markup=True)

        combohaut1=Spinner(text="Caméra normale",background_normal='',values=('Caméra normale','Caméra Externe'),pos_hint={'x':0.25, 'y':0.9},size_hint=(0.2,0.03),background_color="red", color="white")
        combohaut1.bind(text=self.selcam)
        combohaut2=Spinner(text="Synchrone",background_normal='',values=('Synchrone','Asynchrone'),pos_hint={'x':0.25, 'y':0.8},size_hint=(0.2,0.03),background_color="red", color="white")
        combohaut3=Spinner(text="Graphique",background_normal='',values=('Graphique','Libre Export'),pos_hint={'x':0.25, 'y':0.7},size_hint=(0.2,0.03),background_color="red", color="white")

        labhaut1b=Label(text='[b]Autoriser la connexion Entrante[/b]',font_size='16', color='black',pos_hint={'x':0.55,'y':0.9},size_hint=(0.3,0.05),markup=True)
        labhaut2b=Label(text='[b]Brouiller la connexion Entrante[/b]',font_size='16',color='black',pos_hint={'x':0.55,'y':0.8},size_hint=(0.3,0.05),markup=True)
        labhaut3b=Label(text='[b]Etat de la connexion standard[/b]',font_size='16',color='black',pos_hint={'x':0.55,'y':0.7},size_hint=(0.3,0.05),markup=True)

        check1=CheckBox(pos_hint={'x':0.9,'y':0.9},size_hint=(0.05,0.05))
        check1.bind(active=self.fcheck1)
        check2=CheckBox(active=True,pos_hint={'x':0.9,'y':0.8},size_hint=(0.05,0.05))
        check2.bind(active=self.fcheck2)
        labcheck=Label(text='...',color='black',font_size='16',pos_hint={'x':0.9,'y':0.7},size_hint=(0.05,0.05))

        bdemm=Builder.load_string('''

Button:
    text:'[b]Demarrer le serveur ?[/b]'
    background_color:[0,0,0,0]
    color:'white'
    pos_hint:{'x':0.05, 'y':0.55}
    font_size:'15sp'
    markup:True
    size_hint:0.4,0.06

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]

''')
        bdemm.bind(on_release=self.demarreserveur)
        
        barret=Builder.load_string('''

Button:
    text:'[b]Arreter le serveur ?[/b]'
    background_color:[0,0,0,0]
    color:'white'
    pos_hint:{'x':0.55, 'y':0.55}
    font_size:'16sp'
    markup:True
    size_hint:0.4,0.06

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
''')
        barret.bind(on_release=self.arretserveur)

        btest=Builder.load_string('''
MDIconButton:
    icon:'web-check'
    pos_hint:{'x':0.35, 'y':0.39}
    size_hint:0.07,0.1

''')

        bprisencharge=Builder.load_string('''
MDIconButton:
    icon:'walk'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.1

    on_release:app.openprisecharge(self)

''')  
        iconmode=Builder.load_string('''
MDIcon:
    icon:'elevator-up'
    pos_hint:{'x':0.25,'y':0.318}
    size_hint:.1,.1
    text_color:'red'
    theme_text_color:'Custom'    
        
        ''')
        checkmodecloaud=Builder.load_string('''
MDCheckbox:
    pos_hint:{'x':0.22,'y':0.31}
    size_hint:.03,.05
    color_active:'blue'
    color_inactive:'black'
    on_active:app.backUpProduitsimple(self)
        
        ''')    

        labtitre=Label(text="Service en Ligne", color='black',bold=True,font_size='15sp',pos_hint={'center_x':.5,'y':.3},size_hint=(.6,.1))


        cadbtnonligne=Builder.load_string('''
BoxLayout:
    orientation:'horizontal'
    spaccing:10
    padding:10
    elevation:10

    pos_hint:{'center_x':0.5,'y':.15}
    size_hint:.9,.15

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos  

            radius:[10]     
        
        ''')

        btenvonline=Builder.load_string('''
MDIconButton:
    icon:'cloud-upload'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''') 
        btenvonline.bind(on_release=self.transfertOnline)

        btdownaldupdateonligne=Builder.load_string('''
MDIconButton:
    icon:'cloud-sync'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''')
        btdownaldupdateonligne.bind(on_release=self.lectureonlignProduit)

        btelechargercmd=Builder.load_string('''
MDIconButton:
    icon:'cloud-download'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''')    
        
        btelechargercmd.bind(on_release=self.lectureonlign)

        btAnulerTelechargercloud=Builder.load_string('''
MDIconButton:
    icon:'clipboard-remove'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''')
        btAnulerTelechargercloud.bind(on_release=self.annuleroperationcloud)
        
        bthistocmdonline=Builder.load_string('''
MDIconButton:
    icon:'cloud-print-outline'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''')
        bthistocmdonline.bind(on_release=self.openhistoriqueCloud)

        btnotificationoneline=Builder.load_string('''
MDIconButton:
    icon:'email-newsletter'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''') 
        btnotificationoneline.bind(on_release=self.reabonnementCloud)

        btabonnonlinenew=Builder.load_string('''
MDIconButton:
    icon:'cast-connected'
    pos_hint:{'x':0.4, 'y':0.39}
    size_hint:0.07,0.6

''')
        btabonnonlinenew.bind(on_release=self.demarrerserviceonline)

        bchangeprix=Builder.load_string('''
MDIconButton:
    icon:'currency-eur'  
    pos_hint:{'center_x':0.35, 'y':0.05}
    size_hint:0.07,0.1

    on_release:app.openchangeprix(self)

''')

        settingbtaide=Builder.load_string('''
MDIconButton:
    icon:'headset'
    pos_hint:{'center_x':0.45,'y':0.051}
    size_hint:(0.05,0.08)
    text_color:'red'
        
    on_release:app.contactprogrammeur(self)
''')
        
        settingbtsignale=Builder.load_string('''
MDIconButton:
    icon:'chat-alert'
    pos_hint:{'center_x':0.55,'y':0.05}
    size_hint:(0.05,0.1)
    text_color:'red'
        
    on_release:app.signeprobleme(self)
        
''') 
        btopenravclient=Builder.load_string('''
MDIconButton:
    icon:'flask-empty-plus'
    pos_hint:{'center_x':0.65, 'y':0.05}
    size_hint:0.07,0.1

    on_release:app.openravitamultp(self)

''')
        btcompte=Builder.load_string('''
Button:
    size_hint:.1,.07
    text:".."
    pos_hint:{'center_x':.5,'y':0}
    background_color:[0,0,0,0]
    color:'red'
    bold:True
        
        ''')

        btcompte.bind(on_release=self.demarrer)
        
        try:
            cadrehautnew.add_widget(checkmodecloaud)
        except:
            pass
        try:
            cadrehautnew.add_widget(iconmode)
        except:
            pass


        try:
            cadbtnonligne.add_widget(btenvonline)
        except:
            pass
        try:
            cadbtnonligne.add_widget(btdownaldupdateonligne)
        except:
            pass
        try:
            cadbtnonligne.add_widget(btelechargercmd)
        except:
            pass
        
        try:
            cadbtnonligne.add_widget(btAnulerTelechargercloud)
        except:
            pass

        try:
            cadbtnonligne.add_widget(bthistocmdonline)
        except:
            pass
        try:
            cadbtnonligne.add_widget(btnotificationoneline)
        except:
            pass
        
        try:
            cadbtnonligne.add_widget(btabonnonlinenew)
        except:
            pass

        bcorrection=Builder.load_string('''
Button:
    text:'[b]Correction d erreur ?[/b]'
    background_color:[0,0,0,0]
    color:'white'
    pos_hint:{'x':0.55, 'y':0.4}
    font_size:'16sp'
    markup:True
    size_hint:0.3,0.06

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
                                        
''')
        bcorrection.bind(on_release=self.corrigerreur)
    
        bdeconn=Builder.load_string('''
Button:
    text:'[b]Deconnexion[/b]'
    background_color:[0,0,0,0]
    color:'white'
    pos_hint:{'x':0.05, 'y':0.05}
    markup:True
    size_hint:0.2,0.06
            
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]    
''')
        
        bdeconn.bind(on_release=self.deconnexion)

        bclose=Builder.load_string('''

Button:
    text:'[b]Closing day ?[/b]'
    background_color:[0,0,0,0]
    color:'white'
    pos_hint:{'x':0.55, 'y':0.25} 
    font_size:'15sp'
    markup:True
    size_hint:0.3,0.06

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
''')
        
        bclose.bind(on_release=self.cloturejourne)


        bcharg=Button(text='[b][¤][/b]',color='black',font_size="20sp",markup=True,background_color='seagreen',pos_hint={'x':0.91, 'y':0.8},size_hint=(0.07,0.1))
        #bcharg.bind(on_release=self.chargerdonneeqr) 

        try:
            cadrehautnew.add_widget(settingbtaide)
        except:
            pass

        try:
            cadrehautnew.add_widget(settingbtsignale)
        except:
            pass

        try:
            cadrehautnew.add_widget(cadbtnonligne)
        except:
            pass
        try:
            cadrehautnew.add_widget(bprisencharge)
        except:
            pass
        try:
            cadrehautnew.add_widget(labtitre)
        except:
            pass
        
        try:
            cadrehautnew.add_widget(bpreforma)
        except:
            pass

        try:
            cadrehautnew.add_widget(bclose)
        except:
            pass
        bclose.text="[b]Mode Commutation[/b]"
        
        try:
            cadrehautnew.add_widget(bcorrection)
        except:
            pass

        

        
        try:
            #cadrehautnew.add_widget(bcad1)
            #cadrehautnew.add_widget(bcad2)
            #cadrehautnew.add_widget(bcad3)
            pass
        except:
            pass

        try:
            cadrehautnew.add_widget(labhaut1b)
            cadrehautnew.add_widget(labhaut2b)
            cadrehautnew.add_widget(labhaut3b)
            cadrehautnew.add_widget(check1)
            cadrehautnew.add_widget(check2)
            cadrehautnew.add_widget(labcheck)

            cadrehautnew.add_widget(btest)
            cadrehautnew.add_widget(barret)
            cadrehautnew.add_widget(bdemm)
            
            cadrehautnew.add_widget(labhaut1)
            cadrehautnew.add_widget(labhaut2)
            cadrehautnew.add_widget(labhaut3)
            cadrehautnew.add_widget(combohaut1)
            cadrehautnew.add_widget(combohaut2)
            cadrehautnew.add_widget(combohaut3)
        except:
            pass
        try:
            cadrehautnew.add_widget(bdeconn)
        except:
            pass 

        try:
            cadrehautnew.add_widget(btcompte)
        except:
            pass
        
        
        bscanneurannuler=Button(pos_hint={'x':0, 'y':0},size_hint=(0,0)) #(pos_hint={'x':0.92, 'y':0.8},size_hint=(0.06,0.09)
        bscanneurannuler.background_normal="reset.png"
        bscanneurannuler.bind(on_release=self.liberinstance)

        bcharger=Button(pos_hint={'x':0.835,'y':0.915},size_hint=(0,0))#(0.08,0.1)
        bcharger.background_normal="rechoo.png"
        bcharger.bind(on_release=self.recherchventeproduit)
        
        trechvente = TextInput(text="Rechercher", font_size='15sp',pos_hint={'x':0.63, 'y':0.94},size_hint=(0.1,0.04))
        trechvente.bind(focus=self.eff2)
        
        trechventlike=Builder.load_string('''
Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.742, 'y':0.94}
    size_hint:(0.11,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

        ''')
        
        trechventlike.bind(on_press=self.rechlikeproduit)
        trechventlike.bind(text=self.recherchventeproduitspinneur)

        trechlikemodif=Builder.load_string('''

Spinner:
    text:"Choisir"
    pos_hint:{'x':0.8, 'y':0.87}
    font_size:"12sp"
    size_hint:(0.1,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
''')
        
        trechlikemodif.bind(on_press=self.rechlikeproduimodif)
        trechlikemodif.bind(text=self.chargeinfomod)

        # les outils du cadran
        bcad1=Button(size_hint=(1,0.03),pos_hint={'x':0, 'y':0.82},background_color='seagreen')
        bcad2=Button(size_hint=(0.01,0.2),pos_hint={'x':0.36, 'y':0.845},background_color='seagreen')
        bcad3=Button(size_hint=(0.01,0.2),pos_hint={'x':0.66, 'y':0.845},background_color='seagreen')

        treceve = Label(text="..",font_size='15sp',color='black', pos_hint={'x':0, 'y':0},size_hint=(0.1,0.1))

        trilab=Label(text='[b]Trier par[/b]',font_size='18sp',color='black',pos_hint={'x':0.12,'y':0.4},size_hint=(0.15,0.05),markup=True)
        
        labcheck1=Label(text='[b]Date[/b]',font_size='13sp',color='black',pos_hint={'x':0.15,'y':0.35},size_hint=(0.07,0.05),markup=True)
        
        triercheck1=CheckBox(active=True,pos_hint={'x':0.25,'y':0.35},size_hint=(0.06,0.06)) 
        triercheck1.bind(active=self.fchecktrie1)

        labcheck2=Label(text='[b]ID Produit[/b]',font_size='13sp',color='black',pos_hint={'x':0.149,'y':0.3},size_hint=(0.1,0.05),markup=True)
        
        triercheck2=CheckBox(pos_hint={'x':0.25,'y':0.3},size_hint=(0.06,0.06))
        triercheck2.bind(active=self.fchecktrie2)

        labcheck3=Label(text='[b]Nom Client[/b]',font_size='13sp',color='black',pos_hint={'x':0.15,'y':0.25},size_hint=(0.1,0.05),markup=True)
        
        triercheck3=CheckBox(pos_hint={'x':0.25,'y':0.25},size_hint=(0.06,0.06))
        triercheck3.bind(active=self.fchecktrie3)

        trilabb=Label(text='[b]Mappage Type[/b]',font_size='18sp',color='black',pos_hint={'x':0.13,'y':0.2},size_hint=(0.15,0.05),markup=True)
        
        labcheckk4=Label(text='[b]Universel[/b]',font_size='13sp',color='black',pos_hint={'x':0.15,'y':0.15},size_hint=(0.1,0.05),markup=True)
        
        triercheckk4=CheckBox(pos_hint={'x':0.25,'y':0.15},size_hint=(0.06,0.06)) 
        triercheckk4.bind(active=self.fchecktrie4)

        labcheckk5=Label(text='[b]Particulier[/b]',font_size='13sp',color='black',pos_hint={'x':0.15,'y':0.1},size_hint=(0.1,0.05),markup=True)
        
        triercheckk5=CheckBox(active=True,pos_hint={'x':0.25,'y':0.1},size_hint=(0.06,0.06))
        triercheckk5.bind(active=self.fchecktrie5)

        labtyp=Label(text='[b]Critère de selection[/b]',font_size='18sp',color='black',pos_hint={'x':0.7,'y':0.4},size_hint=(0.15,0.05),markup=True)
        labtyp1=Label(text='[b]Aucun[/b]',font_size='13sp',color='black',pos_hint={'x':0.71,'y':0.35},size_hint=(0.1,0.05),markup=True)
        labtyp2=Label(text='[b]Aucun[/b]',font_size='13sp',color='black',pos_hint={'x':0.71,'y':0.3},size_hint=(0.1,0.05),markup=True)
        
        labtypp=Label(text='[b]Selecteur Universel[/b]',font_size='18sp',color='black',pos_hint={'x':0.7,'y':0.25},size_hint=(0.15,0.05),markup=True)
        labtypp1=Label(text='[b]Aucun[/b]',font_size='13sp',color='black',pos_hint={'x':0.71,'y':0.2},size_hint=(0.1,0.05),markup=True)
        labtypp2=Label(text='[b]Aucun[/b]',font_size='13sp',color='black',pos_hint={'x':0.71,'y':0.15},size_hint=(0.1,0.05),markup=True)
        
        labtot1=Label(text="[b]Total[/b]",color='black',pos_hint={'x':0.410, 'y':0.02},font_size='22sp',markup=True,size_hint=(0.1,0.06))
        labtot2=Label(text="[b][/b]",color='black',pos_hint={'x':0.485, 'y':0.02},font_size='20sp',markup=True,size_hint=(0.1,0.06))
        
        labdats=Label(text="La date",color='black',pos_hint={'x':0.375, 'y':0.3},font_size='17sp',size_hint=(0.1,0.06))
        combdats=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.51, 'y':0.3}
    size_hint:(0.09,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgb:22/255,7/255,158/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        combdats.bind(on_release=self.rechdatejournal)
        combdats.bind(text=self.affdatejournal)  

        
        tjourids = MDTextField(hint_text="ID Produit",line_color_normal='black', font_size='20sp', pos_hint={'x':0.4, 'y':0.21},size_hint=(0.09,0.1))
        combids=Builder.load_string('''

Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.51, 'y':0.23}
    size_hint:(0.09,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgb:22/255,7/255,158/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
    
        
        ''')
        
        combids.bind(on_release=self.rechidjournal)
        combids.bind(text=self.affidprodjournal)

        tjourclientnom = MDTextField(hint_text="Nom Client",line_color_normal='black', font_size='20sp', pos_hint={'x':0.4, 'y':0.14},size_hint=(0.09,0.1))
        
        combnomclient=Builder.load_string('''
Spinner:
    text:"Choisir"
    font_size:"12sp"
    pos_hint:{'x':0.51, 'y':0.16}
    size_hint:(0.09,0.04)
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgb:22/255,7/255,158/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        combnomclient.bind(on_release=self.rechnomclientjournal) 
        combnomclient.bind(text=self.affnomclientjournal)   

# les outils de la page mode expert   
        labexp1=Label(text="[b]Plaintes du malade[/b]",pos_hint={'x':0.11,'y':0.9},size_hint=(0.1,0.08),font_size='20sp', markup=True,color='black')
        texp1=TextInput(pos_hint={'x':0.1,'y':0.7},size_hint=(0.8,0.2), multiline=True,font_size='17sp')
        texp1.bind(text=self.separateurtexte)

        bgenererresulat=Builder.load_string('''

Button:
    text:"[b]Generer[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.905,'y':0.852}
    size_hint:(0.09,0.04)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:22/255,7/255,158/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        
        bgenererresulat.bind(on_press=self.generesultat)

        bactualiser=Builder.load_string('''

Button:
    text:"[b]Actualiser[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.905,'y':0.785}
    size_hint:(0.09,0.04)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:22/255,7/255,158/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
        ''')
        
        bactualiser.bind(on_press=self.actualisergeneration)

        labcompteur=Label(text="[b][/b]",font_size='18sp', pos_hint={'x':0.912,'y':0.715},size_hint=(0.09,0.04),color='black',markup=True)
        
        affresultat=Label(text="[b][/b]",text_size=(None,None),font_size='20sp', halign='left', pos_hint={'x':0.01,'y':0.01},size_hint=(0.99,0.9),color='black',markup=True)
        scrol=ScrollView(bar_color='blue',bar_width=10,pos_hint={'x':0.05,'y':0.08},size_hint=(0.95,0.3))

        labexp2=Builder.load_string('''

Button:
    text:"[b]Correcteur Automatique[/b]"
    font_size:'20sp'
    pos_hint:{'x':0,'y':0.64}
    size_hint:1,0.03
    color:'blue'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        Rectangle:
            size:self.size
            pos:self.pos
''')

        labcheckexp1=Label(text="[b]Activer[/b]",font_size='15sp', pos_hint={'x':0.79,'y':0.6},size_hint=(0.1,0.04),color='black',markup=True)
        labcheckexp2=Label(text="[b]Desactiver[/b]",font_size='15sp', pos_hint={'x':0.8,'y':0.57},size_hint=(0.1,0.04),color='black',markup=True)

        expcheck1=Builder.load_string('''
CheckBox:
    pos_hint:{'x':0.92,'y':0.61}
    size_hint:0.02,0.025

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
        ''')
        
        expcheck1.bind(active=self.expch1)
        expcheck2=Builder.load_string('''
CheckBox:
    active:True
    pos_hint:{'x':0.92,'y':0.58}
    size_hint:0.02,0.025

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]

''')
        expcheck2.bind(active=self.expch2)        
        
        bexpert1=Button(text='.',font_size='13sp', pos_hint={'x':0.01,'y':0.59},size_hint=(0.1,0.04),background_color='white',color='blue',markup=True,background_normal='',background_down='',border=(0,0,0,0))
        bexpert1.bind(on_release=self.correcteur1)
        
        bexpert2=Button(text='.',font_size='13sp', pos_hint={'x':0.15,'y':0.59},size_hint=(0.1,0.04),background_color='white',color='blue',markup=True,background_normal='',background_down='',border=(0,0,0,0))
        bexpert2.bind(on_release=self.correcteur2)
        
        bexpert3=Button(text='.',font_size='13sp', pos_hint={'x':0.30,'y':0.59},size_hint=(0.1,0.04),background_color='white',color='blue',markup=True,background_normal='',background_down='',border=(0,0,0,0))
        bexpert3.bind(on_release=self.correcteur3)

        labelement=Label(text="......",font_size='15sp', pos_hint={'x':0,'y':0},size_hint=(0.1,0.04),color='black')
        
        btsuitegenAI=Builder.load_string('''
Button:
    text:"[b]Suite[/b]"
    font_size:'15sp'
    pos_hint:{'x':0.95,'y':0.01}
    size_hint:0.045,0.04
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[7]

''')
        btsuitegenAI.bind(on_press=self.generesultatsuite) 

        trecravitail = MDTextField(hint_text="Recheche",line_color_normal='black', font_size='15sp', pos_hint={'x':0.7, 'y':0.2},size_hint=(0.1,0.08))
        combravitail=Spinner(text="Choisir",pos_hint={'x':0.85, 'y':0.21},size_hint=(0.1,0.04),background_color="blue", color="white")
        combravitail.bind(on_release=self.rechidproravitail)
        combravitail.bind(text=self.affdonnravitail)

        #cadrehautnew

        btaide=Builder.load_string('''
MDIconButton:
    icon:'headset'
    pos_hint:{'x':0.02,'y':0.15}
    size_hint:(0.05,0.08)
    text_color:'red'
        
    on_release:app.contactprogrammeur(self)
        ''')
        
        
        #Button(background_normal='aide.ico',pos_hint={'x':0.001,'y':0.15},size_hint=(0.05,0.08))
        #btaide.bind(on_release=self.contactprogrammeur)

        btsignale=Builder.load_string('''

MDIconButton:
    icon:'chat-alert'
    pos_hint:{'x':0.02,'y':0.25}
    size_hint:(0.05,0.1)
    text_color:'red'
        
    on_release:app.signeprobleme(self)
        
        ''')
        
        #Button(background_normal='Signalez.jpg',pos_hint={'x':0.001,'y':0.25},size_hint=(0.05,0.1))
        #btsignale.bind(on_release=self.signeprobleme)

        btusernew=Builder.load_string('''
MDChip:
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.5}
    size_hint:(0.2,0.04)
    markup:True
    text:"[b]Enregistrer[/b]"
    line_color: "black"
    text_color:"black"
    no_ripple_effect: True    

    on_release:app.gestionuserInsertUpdate(self)

    MDIcon:
        icon:"content-save-cog"
        pos_hint:{'x':.5,'center_y':0.5}
        theme_text_color:'Custom'
        text_color:'black'
            
''') 

        gestmotif=Builder.load_string('''

Button:
    text:"[b]Gestion des motifs[/b]"
    markup:True
    color:'white'
    font_size:"15sp"
    pos_hint:{'x':0.68, 'y':0.95}
    size_hint:0.15,0.04

    background_color:[0,0,0,0]
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
''')
        
        gestmotif.bind(on_release=self.gestionmotif)

        gesttrav=Builder.load_string('''
Button:
    text:"[b]Gestion des travailleurs[/b]"
    markup:True
    color:'white'
    font_size:"15sp"
    pos_hint:{'x':0.85, 'y':0.95}
    size_hint:0.15,0.04

    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]

''')
        
        gesttrav.bind(on_release=self.gestionuserrs)

        labdatmotif=Label(text="Date",color='black',pos_hint={'x':0.1, 'y':0.6},font_size='17sp',size_hint=(0.1,0.06))
        combdatmotif=Builder.load_string('''

Spinner:
    text:"[b]Choisir[/b]"
    pos_hint:{'x':0.25, 'y':0.6}
    font_size:'17sp'
    size_hint:0.2,0.05
    markup:True
    color:"white"

    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')
        
        combdatmotif.bind(on_release=self.rechdatemotif)
        combdatmotif.bind(text=self.affmotifdate)

        labidmotif=Label(text="ID Travailleur",color='black',pos_hint={'x':0.5, 'y':0.6},font_size='17sp',size_hint=(0.15,0.06))
        
        combidmotif=Builder.load_string('''
Spinner:
    text:"[b]Choisir[/b]"
    pos_hint:{'x':0.7, 'y':0.6}
    font_size:'17sp'
    size_hint:0.2,0.05
    background_color:[0,0,0,0]
    markup:True
    color:"white"

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')
        combidmotif.bind(on_release=self.rechidmotif)
        combidmotif.bind(text=self.affmotifidtrav)

        tabtotmotif=MDDataTable(column_data=[], row_data=[],size_hint=(0.25,0.05),pos_hint={'x':0.7,'y':0.5},check=True)
        labtotmotif=Label(text="[b]TOTAL : [/b]",color="black",markup=True,font_size="20sp",pos_hint={'center_x':0.5,'center_y':0.5},size_hint=(0.2,0.05))
        
        labcombinmotif=Label(text="[b]Combiné[/b]",color="black",markup=True,font_size="10sp",pos_hint={'x':0.84,'y':0.45},size_hint=(0.1,0.05))
        checkmotif=Builder.load_string('''

CheckBox:
    active:True
    pos_hint:{'x':0.9,'y':0.46}
    size_hint:0.02,0.025

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[2]
''')

        checkmotif.bind(active=self.combinemotif)

        bgestionusernew=Builder.load_string('''
            
MDIconButton:
    icon:'account-key'
    pos_hint:{'center_x':0.5, 'y':0.7}
    size_hint:0.8,0.15

    on_release:app.chargPageUnsermananger(self)
                                      
        ''') 

        retaccueil=Builder.load_string('''
            
MDIconButton:
    icon:'arrow-left-bold-circle'
    pos_hint:{'x':0.02, 'y':0.9}
    size_hint:0.05,0.05

    on_release:app.retouracceuil(self)
                                      
        ''')

        global msgauto1,msgopen
        
        #bgestionusernew=Button(text='[b]Gestion des travailleurs[/b]',background_color='blue',color='white',pos_hint={'x':0.25, 'y':0.02},font_size='20sp',markup=True,size_hint=(0.2,0.05))
        #bgestionusernew.bind(on_release=self.gestionuser) 

        bcommutadmin=Builder.load_string('''
MDIconButton:
    icon:'archive-arrow-down'
    pos_hint:{'center_x':.5,'y':0.4}
    size_hint:0.8,0.15
        
    on_release:app.commutationadmin(self)
                                         
''')
                                    
        #bcommutadmin=Button(pos_hint={'x':0.82,'y':0.92},size_hint=(0.05,0.09))
        #bcommutadmin.background_normal="load.jpg"
        #bcommutadmin.bind(on_release=self.commutationadmin)

        btautorisermodtp=Builder.load_string('''
MDIconButton:
    icon:'basket-fill'
    pos_hint:{'center_x':.5,'y':0.1}
    size_hint:0.8,0.15
        
    on_release:app.openautorisation(self)
                                         
''')
        #btautorisermodtp=Button(background_normal='server_protected_icon_191510.png',pos_hint={'x':0.75,'y':0.91},size_hint=(0.05,0.09))
        #btautorisermodtp.bind(on_release=self.openautorisation)
    
        cadxxsetting=Builder.load_string('''
FloatLayout:
    size_hint:.08,.4
    pos_hint: {'center_x':.5,'y':.55}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        
        ''')

        
        
        bexport=Button(pos_hint={'x':0.94,'y':0.025},size_hint=(0.06,0.1))
        bexport.background_normal="excel3.png"
        bexport.bind(on_release=self.tester)

        bquiter=Button(pos_hint={'x':0.87, 'y':0.01},size_hint=(0.12,0.12))
        bquiter.background_normal='down.ico'
        bquiter.bind(on_release=self.quiteprogramme)

        bimpression=Button(pos_hint={'x':0.915, 'y':0.19},size_hint=(0.07,0.12))
        bimpression.background_normal='impr.png'
        bimpression.bind(on_release=self.imprissionfact)

        bimpressionpreforma=Builder.load_string('''
MDIconButton:
    icon:'printer-eye'
    pos_hint:{'x':0.915, 'y':0.35}
    size_hint:0.07,0.12

    on_release:app.imprissionpreforma(self)
    
''') 
        #bimpressionpreforma=Button(pos_hint={'x':0.915, 'y':0.35},size_hint=(0.07,0.12))
        #bimpressionpreforma.background_normal='3208671.png'
        #bimpressionpreforma.bind(on_release=self.imprissionpreforma)

        btntauxadmin=Builder.load_string('''
MDIconButton:
    icon:'currency-eur'
    pos_hint:{'center_x':0.5,'y':0.38}
    size_hint:0.045,0.11

    on_release:app.chargetauxadmin(self)
''')

        btmodstockauto=Builder.load_string('''
MDIconButton:
    icon:'database-edit'
    pos_hint:{'x':0.88,'y':0.38}
    size_hint:0.045,0.11

    on_release:app.modopentrav(self)
''')
        #btmodstockauto.background_normal="motif.jpg"
        #btmodstockauto.bind(on_release=self.modopentrav)
        
        bpreforma=Builder.load_string('''
MDIconButton:
    icon:'notebook'  
    pos_hint:{'x':0.92, 'y':0.38}
    size_hint:(0.045,0.11)

    on_release:app.proforma(self)

''')

        #bpreforma.background_normal='400010756.jpg'
        #bpreforma.bind(on_release=self.proforma)

        infofac=""
        
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select info from infoimpression where id='1'")
            res=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if res:
                infofac=str(res[0])
            

            tabinfo=infofac.split(',')

            if tabinfo:
                n1=tabinfo[0]
                n2=tabinfo[1]
                n3=tabinfo[2]
                n4=tabinfo[3]
            else:
                n1=""
                n2=""
                n3=""
                n4=""

        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select taux from tauxchange where num=1")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                taux.text=str(results[0])
                tauxchangenew=results[0]
                
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de l importateur de change, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
                
        combanneintervalvente=Builder.load_string('''

Spinner:
    text:"[b]AAAA[/b]"
    markup:True
    pos_hint:{'x':0.95, 'y':0.4}
    size_hint:0.05,0.04
    background_color:[0,0,0,0]
    color:"white"
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        
        combanneintervalvente.bind(on_release=self.chargerannee)

        combmoisintervalveny=Builder.load_string('''
Spinner:
    text:"[b]MM[/b]"
    markup:True
    pos_hint:{'x':0.95, 'y':0.5}
    size_hint:0.05,0.04
    background_color:[0,0,0,0]
    color:"white"

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        
        combmoisintervalveny.bind(on_release=self.chargemois)

        combjourintervalvente=Builder.load_string('''

Spinner:
    text:"[b]JJ[/b]"
    markup:True
    pos_hint:{'x':0.95, 'y':0.6}
    size_hint:0.05,0.04
    background_color:[0,0,0,0]
    color:"white"
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        
        ''')
        
        combjourintervalvente.bind(on_release=self.chargejour)

                

        #bcalcbenefice=Button(pos_hint={'x':0.1,'y':0.025},size_hint=(0.06,0.1))
        #bcalcbenefice.background_normal="benefice.jpg"
        #bcalcbenefice.bind(on_release=self.configbenefice)
       
        

        #background_normal='',background_down='',border=(0,0,0,0)

        #combohaut1=Spinner(text="Caméra normale",values=('Caméra normale','Caméra Externe'),pos_hint={'x':0.18, 'y':0.95},size_hint=(0.13,0.03),background_color="seagreen", color="white")
        #ajout des outils accueil
        #taccueil.add_widget(laccueil)
        #cadre.add_widget(taccueil)
        #cadre.add_widget(imgaccuel)

        #cadre.add_widget(imgacc1)
        #cadre.add_widget(imgacc2)
        #cadre.add_widget(imgacc3)

        #accueilcad2.add_widget(lacc2)
        #accueilcad1.add_widget(lacc1)
        #accueilcad3.add_widget(lacc3)

        #cadre.add_widget(accueilcad1)
        #cadre.add_widget(accueilcad2)
        #cadre.add_widget(accueilcad3)

        #cadre.add_widget(ladmin)
        #cadre.add_widget(luser)

        # ajout des outils de la page de connnexion

        #cadre.add_widget(btnconn)
        #cadre.add_widget(tidconn)
        #cadre.add_widget(tpwdconn)
        #cadre.add_widget(imggconn)
        #cadre.add_widget(labconn)

        #ajout des outils de la premiere page
        # les outils de regalage

        

        bcanetterelage=Builder.load_string('''
MDIconButton:
    icon:'filter-cog'
    pos_hint:{'x':0.88,'y':0.025}
    size_hint:0.06,0.1
        
    on_release:app.cannettereglage(self)
                                         
''')

        #bcanetterelage=Button(pos_hint={'x':0.88,'y':0.025},size_hint=(0.06,0.1))
        #bcanetterelage.background_normal="barre-reglages.png"
        #bcanetterelage.bind(on_release=self.cannettereglage)


        cadcanette=Builder.load_string('''

FloatLayout:
    pos_hint:{'x':0.55,'y':0.0}
    size_hint:0.35,0.17

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
        
        ''')

        reglsystem=Label(text="[b]Reglage systeme[/b]",color="black",markup=True,font_size="15sp",pos_hint={'center_x':0.5,'y':0.9},size_hint=(0.1,0.1))

        labcombinmotif=Label(text="[b]Borne[/b]",color="black",markup=True,font_size="10sp",pos_hint={'x':0.1,'y':0.6},size_hint=(0.1,0.1))

        annecanette=Builder.load_string('''
Spinner:
    text:"[b]AAAA[/b]"
    markup:True
    font_size:"10sp"
    pos_hint:{'x':0.2, 'y':0.6}
    size_hint:(0.15,0.15)
    background_color:[0,0,0,0]
    color:"white"
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
        ''')
            
        annecanette.bind(on_release=self.chargerannee)

        moiscanette=Builder.load_string('''
Spinner:
    text:"[b]MM[/b]"
    markup:True
    font_size:"10sp"
    pos_hint:{'x':0.4, 'y':0.6}
    size_hint:(0.15,0.15)
    background_color:[0,0,0,0]
    color:"white"
           
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
        
        ''')
        
        
        moiscanette.bind(on_release=self.chargemois)

        jourcannette=Builder.load_string('''

Spinner:
    text:"[b]JJ[/b]"
    markup:True
    font_size:"10sp"
    pos_hint:{'x':0.6, 'y':0.6}
    size_hint:0.15,0.15
    background_color:[0,0,0,0]
    color:"white"
        
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
        ''')
        
        jourcannette.bind(on_release=self.chargejour)

        pasconnette=Builder.load_string('''

Spinner:
    text:"Pas"
    markup:True
    font_size:"10sp"
    pos_hint:{'x':0.8, 'y':0.6}
    size_hint:0.15,0.15
    background_color:[0,0,0,0]
    color:"white"
        
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[5]
        
        
        ''')
        
        pasconnette.bind(on_release=self.chargepas)

        regl=Label(text="[b]Prefixe ID[/b]",color="black",markup=True,font_size="10sp",pos_hint={'x':0.1,'y':0.2},size_hint=(0.1,0.1))

        textregaleidpro=TextInput(text="", font_size='10sp',pos_hint={'x':0.22, 'y':0.185},size_hint=(0.25,0.25))

        bsavecanette=Builder.load_string('''
Button:
    pos_hint:{'x':0.8,'y':0.1}
    color:"white"
    background_color:[0,0,0,0]
    font_size:'10sp'
    size_hint:(0.15,0.2)
    text:"[b]Save[/b]"
    markup:True
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[10]
        
        ''')
        
        bsavecanette.bind(on_release=self.savecanette)

        try:
            cadcanette.add_widget(labcombinmotif)
            cadcanette.add_widget(annecanette)
            cadcanette.add_widget(moiscanette)
            cadcanette.add_widget(jourcannette)
            cadcanette.add_widget(pasconnette)
            cadcanette.add_widget(regl)
            cadcanette.add_widget(textregaleidpro)
            cadcanette.add_widget(reglsystem)
            cadcanette.add_widget(bsavecanette)
        except:
            pass
        
        try:
            
            cadre.add_widget(btfond)
            cadre.add_widget(imglogo)
            cadre.add_widget(ptitre)
            cadre.add_widget(plabadmin)
            cadre.add_widget(plabuser)
            cadre.add_widget(badmin)
            cadre.add_widget(buser)
            cadre.add_widget(treceve)

            cadre.add_widget(bquiter)
            cadre.add_widget(configserveur)

            cadregauche.add_widget(cadre)
        
            return cadregauche
        
        except:
            pass
    
    def jrsplus(self,instance):

        if int(jrsexpmult.text)<31:

            jrsexpmult.text=str(int(jrsexpmult.text)+1)
    
    def jrsmoins(self,instance):

        if int(jrsexpmult.text)>1:

            jrsexpmult.text=str(int(jrsexpmult.text)-1)

    def moismoins(self,instance): 

        if int(moisexpmult.text)>1:

            moisexpmult.text=str(int(moisexpmult.text)-1)
    
    def plusmois(self,instance):

        if int(moisexpmult.text)<12:

            moisexpmult.text=str(int(moisexpmult.text)+1)


    def plusannee(self,instance):

        if int(anneexpmult.text)<2030:

            anneexpmult.text=str(int(anneexpmult.text)+1)
    
    def moisannee(self,instance):

        if int(anneexpmult.text)>2024:

            anneexpmult.text=str(int(anneexpmult.text)-1)

    def start_progress(self):
        global temppp
        temppp=1
        
        Clock.schedule_interval(self.update_progress, 0.1)

    def update_progress(self, dt):
        global temppp

        if temppp < 65:
            temppp+=1
            progressbarr.value =temppp
        else:
            pass
    
    def lireinfo(self,instance):

        if combrechhisto.text=="" or combrechhisto.text=="Choisir":
            pass
        else:

            e=""

            try:
                self.cconnexion()
                cursor=con.cursor()
                query="select count(id_commande),IdTrav,date,date_heure,impactprix from commandefacture where id_commande='"+combrechhisto.text+"'"
                cursor.execute(query)
                results=cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    a=str(results[0])
                    b=str(results[1])
                    c=str(results[2])
                    d=str(results[3])
                    e=str(results[4])

            except:
                pass

            if e=="0":
                repp="Non"
            else:
                repp="Oui"
            
            cadprisravvnew=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
                
                ''')

            labb=Label(text="INFO SUR LA COMMANDE : [ "+ combrechhisto.text+" ]" ,bold=True,size_hint=(.5,.05),pos_hint={'center_x':.5,'y':.9},color="black")

            n1=Label(text="Total Ravitaillé ",size_hint=(.2,.05),pos_hint={'x':.1,'y':.8},color="black")
            n2=Label(text="Travailleur",size_hint=(.13,.05),pos_hint={'x':.1,'y':.7},color="black")
            n3=Label(text="Date ",size_hint=(.05,.05),pos_hint={'x':.1,'y':.6},color="black")
            n4=Label(text="Date Heure ",size_hint=(.13,.05),pos_hint={'x':.1,'y':.5},color="black")
            n5=Label(text="Prix impacté ",size_hint=(.15,.05),pos_hint={'x':.1,'y':.4},color="black")

            nn1=Label(text=":  "+ a,size_hint=(.05,.05),pos_hint={'x':.4,'y':.8},color="blue")
            nn2=Label(text=":  "+ b,size_hint=(.2,.05),pos_hint={'x':.4,'y':.7},color="blue")
            nn3=Label(text=":  "+ c,size_hint=(.15,.05),pos_hint={'x':.4,'y':.6},color="blue")
            nn4=Label(text=":  "+ d,size_hint=(.24,.05),pos_hint={'x':.4,'y':.5},color="blue")
            nn5=Label(text=":  "+ repp,size_hint=(.05,.05),pos_hint={'x':.4,'y':.4},color="blue")


            bt1v=Builder.load_string('''

Button:
    text:'Close'
    color:'white'

    background_color:[0,0,0,0]
    bold:True
    size_hint:.3,.05
    pos_hint:{'x':.65,'y':.1}

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                
        ''')
            bt1v.bind(on_release=lambda x:msggd.dismiss())


            
            try:
                

                cadprisravvnew.add_widget(n1) 
                cadprisravvnew.add_widget(n2)
                cadprisravvnew.add_widget(n3) 
                cadprisravvnew.add_widget(n4)
                cadprisravvnew.add_widget(n5)

                cadprisravvnew.add_widget(nn1) 
                cadprisravvnew.add_widget(nn2)
                cadprisravvnew.add_widget(nn3) 
                cadprisravvnew.add_widget(nn4)
                cadprisravvnew.add_widget(nn5) 

                cadprisravvnew.add_widget(bt1v) 
                cadprisravvnew.add_widget(labb)

                msggd=Popup(title="CONTROL",content=cadprisravvnew,size_hint=(.5,.9))
                msggd.open()

            except:
                pass


    def openerrorbrouill(self,instance):
        global listerror

        tablravmultiple.row_data=listerror
    
    def affidfaccommande(self,instance,value):

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select id_prod,produit.nom,ajout,date_exp,ROUND(pucdf/taux,2),pucdf,IdTrav from commandefacture,tauxchange,expiration,produit where tauxchange.num=1 and id_exp=id_prod and id_prod=matricule and id_commande='"+instance.text+"' order by produit.nom ASC"
            cursor.execute(query)
            results=cursor.fetchall()
            self.cursor.close()
            con.close()

            ii=0

            tablneww=[]

            for ligg in results:
                a,b,c,d,e,f,g=ligg

                if ii<len(results):

                    ii+=1

                    lignew=(ii,a,b,c,d,e,f,g)

                    tablneww.append(lignew)    

            tablravmultiple.row_data=tablneww

        except:
            pass


    def rechdistincidfaccommande(self,instance):

        instance.text="Choisir"

        instance.values=""

        tablravmultiple.row_data=[]

        try:
    
            self.cconnexion()
            cursor=con.cursor()
            query="select distinct id_commande from commandefacture where id_commande LIKE'%"+trechhisto.text+"%' order by date_heure DESC"
            cursor.execute(query)
            results=cursor.fetchall()
            self.cursor.close()
            con.close()

            for lig in results:
                instance.values.append(str(lig).replace("('","").replace("',)",""))
        except:
            pass

    def commuterbruillon(self,instance):

        global msggd,labb,nb,bt2v,bt1v,cadprisravvnewconfirmer

        nb=1

        cadprisravvnewconfirmer=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')

        labb=Label(text="Voulez-vous vraiment valider cette operation ?\nNB:l'appuie sur Valider apporte la modification aux données\n NOTA: Veuillez redemarrer le Programme apres avoir Valider",size_hint=(1,.5),pos_hint={'center_x':.5,'center_y':.6},color="black")

        bt1v=Builder.load_string('''

Button:
    text:'Annuler'
    color:'white'

    background_color:[0,0,0,0]
    bold:True
    size_hint:.3,.13
    pos_hint:{'x':.05,'y':.2}

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
    ''')
        bt1v.bind(on_release=lambda x:msggd.dismiss())

        bt2v=Builder.load_string('''

Button:
    text:'Valider'
    color:'white'
    size_hint:.3,.13
    pos_hint:{'x':.65,'y':.2}

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
    ''')

        bt2v.bind(on_release=self.commuterbruillonfin)

        try:
            cadprisravvnewconfirmer.add_widget(bt2v)
            cadprisravvnewconfirmer.add_widget(bt1v) 
            cadprisravvnewconfirmer.add_widget(labb) 
        except:
            pass

        if tablravmultiple.row_data:
            msggd=Popup(title="ENQUETE",content=cadprisravvnewconfirmer,size_hint=(.5,.3))
            msggd.open()


    def commuterbruillonfin(self,instance):
        global nb,minuteur,cadreravitaimultiple,msgopentrav,cadprisravvnew


        minuteur=Clock.schedule_interval(lambda dt: self.update_progressProgres(nb), 0.1) 
    
    
    def update_progressProgres(self,progress_bar):

        global labb,nb,minuteur,bt2v,bt1v,cadprisravvnewconfirmer

        try:
            cadprisravvnewconfirmer.remove_widget(bt2v)
            cadprisravvnewconfirmer.remove_widget(bt1v)
        except:
            pass

        try:

            if progress_bar < 20:
                progress_bar += 2

                nb=progress_bar

                labb.text="Traitement encours ..."

            else:
                
                self.commuterbrouillonfinthread()

                Clock.unschedule(minuteur)

        except:
            pass    
        

    def commuterbrouillonfinthread(self):  
        global msggd,listerror  

        try:
            pass
            #cadreravitaimultiple.add_widget(progressbarr)
        except:
            pass

        try:
            cadreravitaimultiple.remove_widget(btopenerrror)
            cadreravitaimultiple.remove_widget(openerror)
           
        except:
            pass


        datte=datetime.now().strftime('%Y-%m-%d')
        
        dateheuree=datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        idcomm=dateheuree.replace("-","").replace(":","").replace(" ","")

        if suitravvprix.active==True:

            tabbrouill=[]
            listerror=[]
            erroo=False

            tabbrouill=tablravmultiple.row_data

            for lign in tabbrouill:
                a,id,b,ajout,dateex,pu,c,hh=lign

                ajoutv=int(ajout)
                puv=float(pu)

                dateexp=dateex
                #datetime.strptime(dateex,"%Y-%m-%d")

                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update expiration set date_exp=%s where id_exp=%s"
                    cursor.execute(query,(dateexp,id))
                    con.commit()
                    self.cursor.close()
                    con.close()
                

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into commandefacture(id_commande,id_prod,ajout,pucdf,IdTrav,date,date_heure,impactprix) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                    cursor.execute(query,(idcomm,id,ajout,c,tidconn.text,datte,dateheuree,1))
                    con.commit()
                    self.cursor.close()
                    con.close()


                    self.cconnexion()
                    cursor=con.cursor()
                    query="update produit set pu=%s,stock=stock+%s,stock_p=stock_p+%s where matricule=%s"
                    cursor.execute(query,(puv,ajoutv,ajoutv,id))
                    con.commit()
                    self.cursor.close()
                    con.close()

                except:
                
                    erroo=True

                    listerror.append(lign)
            
            if erroo==False:
                btnval=Builder.load_string('''

Button:
    text:'Operation terminé avec succes  !!'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
    ''')    

                msg=Popup(title="STATUT REQUETE",content=btnval,size_hint=(.4, .2))
                msg.open()

                tablravmultiple.row_data=[]

                msggd.dismiss()

            else:

                try:
                    cadreravitaimultiple.add_widget(btopenerrror)
                    cadreravitaimultiple.add_widget(openerror)
                except:
                    pass
                
                btnval=Builder.load_string('''

Button:
    text:'Operation terminée avec quelques erreurs !!'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')    

                msg=Popup(title="STATUT REQUETE",content=btnval,size_hint=(.4, .2))
                msg.open()  

                msggd.dismiss() 

                tablravmultiple.row_data=[]

        
        else:
            tabbrouill=[]
            listerror=[]
            erroo=False

            tabbrouill=tablravmultiple.row_data

            for lign in tabbrouill:
                a,id,b,ajout,dateex,pu,c,hh=lign

                ajoutv=int(ajout)
                puv=float(pu)

                dateexp=dateex
                #datetime.strptime(dateex,"%Y-%m-%d")

                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update expiration set date_exp=%s where id_exp=%s"
                    cursor.execute(query,(dateexp,id))
                    con.commit()
                    self.cursor.close()
                    con.close()

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into commandefacture(id_commande,id_prod,ajout,pucdf,IdTrav,date,date_heure,impactprix) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                    cursor.execute(query,(idcomm,id,ajout,c,tidconn.text,datte,dateheuree,0))
                    con.commit()
                    self.cursor.close()
                    con.close()

                
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update produit set stock=stock+%s,stock_p=stock_p+%s where matricule=%s"
                    cursor.execute(query,(ajoutv,ajoutv,id))
                    con.commit()
                    self.cursor.close()
                    con.close()

                except:
                
                    erroo=True

                    listerror.append(lign)
            
            if erroo==False:
                btnval=Builder.load_string('''

Button:
    text:'Operation terminé avec succes  !!'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
    ''')    

                msg=Popup(title="STATUT REQUETE",content=btnval,size_hint=(.4, .2))
                msg.open()

                tablravmultiple.row_data=[]

                msggd.dismiss()

            else:

                try:
                    cadreravitaimultiple.add_widget(btopenerrror)
                    cadreravitaimultiple.add_widget(openerror)
                except:
                    pass

                btnval=Builder.load_string('''

Button:
    text:'Operation terminée avec quelques erreurs !!'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')    

                msg=Popup(title="STATUT REQUETE",content=btnval,size_hint=(.4, .2))
                msg.open() 

                msggd.dismiss()

                tablravmultiple.row_data=[]
    
    def checkingbrouillon(self,instance):
        global temppp

        try:
            cadreravitaimultiple.add_widget(progressbarr)

        except:
            pass
    
        self.start_progress()

        listbrouill=[]
        totqt=0
        totcdf=0
        

        listbrouill=tablravmultiple.row_data
        
        try:
            for lignn in listbrouill:
                a,b,c,d,e,f,g,hh=lignn 

                soustotcdf=float(d)*float(g)

                totqt+=int(d)
                totcdf+=float(soustotcdf)

            totqtbrouil.text=str(totqt)
            totcdfbrouil.text=str(math.ceil(totcdf))

            totusdbrouil.text=str(round(totcdf/float(tauxchangenew),2))

            temppp=65

            progressbarr.value=0

        except:
            pass

    def retireelementBrouillon(self,instance_table,current_row):
        global etetatretirer,num,netpayer,listeqt


        totqtbrouil.text=""
        totcdfbrouil.text=""
        totusdbrouil.text=""

        listeqtfaux=[]
        i=0
        k=0
        j=0



        if etetatretirer==1:
            
            try:
                if tablravmultiple.row_data:
                
                    selll=current_row[0]
                    selll=int(selll)

                    suprelement=tablravmultiple.row_data.pop(selll-1)

                    if suitravv.active==True:

                        matriculeprods=suprelement[1]
                        combaffravv.text=str(suprelement[2])
                        tqterechrav.text=str(suprelement[3])
                        tprixrechrav.text=str(suprelement[6])
                        
                    else:

                        matriculeprods=suprelement[1]
                        combaffravv.text=str(suprelement[2])
                        tqterechrav.text=str(suprelement[3])
                        tprixrechrav.text=str(suprelement[5])

                    etetatretirer=0
                    btetatretir.background_color=[216/255,216/255,216/255]

                    tabnewbrouill=[]

                    datatottnew=tablravmultiple.row_data

                    ikk=1

                    for lign in datatottnew:
                        if ikk <= len(datatottnew):
                    
                            new_tuple =(ikk,) + lign[1:]

                            ikk+=1

                        tabnewbrouill.append(new_tuple)

                        tablravmultiple.row_data=[]
                        tablravmultiple.row_data=tabnewbrouill

                
                btnval=Builder.load_string('''

Button:
    text:'Effectué !!'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')    

                msg=Popup(title="STATUT REQUETE",content=btnval,size_hint=(.4, .2))
                msg.open()    
                        
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def retraitelement(self,instance):
        global etetatretirer

        etetatretirer=1
        
        btetatretir.background_color=(1,0,0,1)

    def ajouterbrouillon(self,instance):
        global matriculeprods

        totqtbrouil.text=""
        totcdfbrouil.text=""
        totusdbrouil.text=""

        try:
            int(tqterechrav.text)

            if suitravv.active==True:

                usdd=round(float(tprixrechrav.text)/float(tauxchangenew),2)
                cdff=tprixrechrav.text

            else:

                cdff=math.ceil(float(tprixrechrav.text)*float(tauxchangenew))
                usdd =tprixrechrav.text
            
            datatott=tablravmultiple.row_data

            nbr=len(datatott)

            nbr+=1

            dattss=anneexpmult.text+"-"+moisexpmult.text+"-"+jrsexpmult.text
            
            ligne=(nbr,str(matriculeprods),combaffravv.text,tqterechrav.text,dattss,str(usdd),str(cdff),tidconn.text)

            tablravmultiple.add_row(ligne)

            btnval=Builder.load_string('''

Button:
    text:'Effectué !!'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')    

            msg=Popup(title="STATUT REQUETE",content=btnval,size_hint=(.4, .2))
            msg.open()

            combaffravv.text="Chosir"
            tqterechrav.text=""
            tprixrechrav.text=""
            tstockcourant.text=""

        except:
            msggb=Popup(title="MESSAGE SYSTEME",content=Button(text="Erreur",color='white',background_color="blue"),size_hint=(.4,.25))
            msggb.open()

    def affdetail(self,instance,value):

        global matriculeprods

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select matricule,nom,pu,stock_p from produit where nom ='"+instance.text+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:

                matriculeprods=results[0]
                #tidrechrav.text=str(results[1])
                tprixrechrav.text=str(results[2])
                tstockcourant.text=str(results[3])


                tqterechrav.focus=True
               
        except:
            pass


    def rechprodds(self,instance):

        instance.text="Chosir"

        instance.values=""

        if tidrechrav.text=="":
            
            pass

        else:

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="select nom from produit where nom LIKE'%"+tidrechrav.text+"%' order by nom ASC"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                for lig in results:
                    instance.values.append(str(lig).replace("('","").replace("',)",""))
            except:
                pass

    
    def changemodeinput(self,instance):
        if instance.active==True:

            tprixrechrav.hint_text='Prix CDF'
            
        else:
            tprixrechrav.hint_text='Prix USD'

    
    def closeRavitail(self,instance):
        global msgopentrav,cadprisravvnew,cadreravitaimultiple

        try:
            cadprisravvnew.remove_widget(cadreravitaimultiple)
        except:
            pass

        msgopentrav.dismiss()

    def openajoutFenClient(self,instance):
        global  cadprisravvnew

        try:
            cadreravitaimultiple.remove_widget(cadexpiration)
        except:
            pass

        try:
            cadreravitaiAjout.add_widget(cadexpiration)
        except:
            pass

        try:
            cadprisravvnew.remove_widget(cadreravitaimultiple)
            cadprisravvnew.add_widget(cadreravitaiAjout)
        except:
            pass

    def openravitaillementfin(self,instance):
        global  cadprisravvnew,cadexpiration

        try:
            cadreravitaiAjout.remove_widget(cadexpiration)
        except:
            pass
        
        try:
            cadreravitaimultiple.add_widget(cadexpiration)
        except:
            pass

        try:
            cadprisravvnew.add_widget(cadreravitaimultiple)
            cadprisravvnew.remove_widget(cadreravitaiAjout)
        except:
            pass
    
    def changeinputAjout(self,instance):
        # tStockIinitial,tPrixUnitaire,tnomProx,tablravAjout

        if instance.active==True:

            tPrixUnitaire.hint_text="PU CDF"

        else:

            tPrixUnitaire.hint_text="PU USD"

    def saveProduitDirect(self,instance):
        global tauxchangenew

        tabajour=[]
        puInput=None
        matr=random.randint(0,40000)

        dattss=anneexpmult.text+"-"+moisexpmult.text+"-"+jrsexpmult.text

        try:

            btx1msg=Builder.load_string('''
Button:
    background_color:[0,0,0,0]
    size_hint:.5,.5
    pos_hint:{'center_x':.5,'center_y':.5}
    color:'black'
    bold:True

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
        
''')
            btx1msg.bind(on_release=lambda x:msg.dismiss())

            if suitravvAjout.active==True:

                puInput=round(float(tPrixUnitaire.text)/float(tauxchangenew),2)

            else:

                puInput=float(tPrixUnitaire.text)
            
            self.cconnexion()
            cursor=con.cursor()
            query="insert into produit(matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,dats,stock_p) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(query,(matr,tnomProx.text,"-","-","-","-","-",puInput,int(tStockIinitial.text),datetime.now().strftime('%Y-%m-%d'),int(tStockIinitial.text)))
            con.commit()
            self.cursor.close()
            con.close()

            self.cconnexion()
            cursor=con.cursor()
            queryy="insert into expiration(id_exp,date_exp) values(%s,%s)"
            cursor.execute(queryy,(matr,dattss))
            con.commit()
            self.cursor.close()
            con.close()

            #tStockIinitial,tPrixUnitaire,tnomProx,tablravAjout

            lign=(str(matr),tnomProx.text,str(puInput),tStockIinitial.text,dattss,datetime.now().strftime('%Y-%m-%d'))

            tabajour.append(lign)

            tablravAjout.row_data=tabajour

            tnomProx.text=""
            tStockIinitial.text=""
            tPrixUnitaire.text=""

            btx1msg.text="Effectué"

            try:
                msg=Popup(title="RAVITAILLEMENT MULTIPLE",content=btx1msg,size_hint=(1,1))
            except:
                pass

            msg.open()

        except Exception as e:
            
            btx1msg.text="ERROR"

            try:
                msg=Popup(title="RAVITAILLEMENT MULTIPLE",content=btx1msg,size_hint=(1,1))
            except:
                pass

            msg.open()

    def openravitamultp(self,instance):
        global msgopentrav,cadprisravvnew,cadreravitaimultiple,kcompt,tauxchangenew,cadreravitaiAjout

        try:
            cadprisravvnew.remove_widget(cadreravitaiAjout)
        except:
            pass

        try:
            cadprisravvnew.remove_widget(cadreravitaimultiple)
        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select taux from tauxchange where num=1")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                
                tauxchangenew=results[0]
                
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de l importateur de change, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        btclose=Builder.load_string('''
MDIconButton:
    icon:'close-octagon'
    pos_hint:{'x':.95,'y':.95} 
    size_hint:.05,.05   
        
        ''')
        btclose.bind(on_release=lambda x:msgopentrav.dismiss())

        
        
        cadprisravvnew=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')

        
        #btsaveI,tStockIinitial,tPrixUnitaire,tnomProx,cadresuitcravv,labravv,tablravAjout,cadreravitaiAjout

        btx1=Builder.load_string('''
Button:
    text:"Ajout"
    background_color:[0,0,0,0]
    pos_hint:{'x':.6,'y':.95}
    size_hint:.15,.04
    color:'white'
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
''')
        btx1.bind(on_release=self.openajoutFenClient)
        
        btx2=Builder.load_string('''
Button:
    text:"Ravitaillement"
    background_color:[0,0,0,0]
    pos_hint:{'x':.8,'y':.95}
    size_hint:.15,.04
    color:'white'
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
        btx2.bind(on_release=self.openravitaillementfin)

        try:
            cadprisravvnew.add_widget(btclose)
            cadprisravvnew.add_widget(btx2)
            cadprisravvnew.add_widget(btx1)
        except:
            pass

        try:
            cadprisravvnew.add_widget(cadreravitaimultiple)
        except:
            pass
        
        try:
            msgopentrav=Popup(title="RAVITAILLEMENT MULTIPLE",content=cadprisravvnew,size_hint=(1,1))
        except:
            pass

        msgopentrav.open()

    def openprisecharge(self,instance):
        global cadprisecharge

        if sepp==8:

            try:
                cadprisecharge.remove_widget(cadreprischarge)
            except:
                pass

            cadprisecharge=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')
        #btest.bind(on_release=self.deconnexion) 

            btclosprisecharge=Builder.load_string('''
Button:
    text:'Close'
    background_color:[0,0,0,0]
    color:'white'
    pos_hint:{'x':0.8, 'y':0.93}
    font_size:'16sp'
    bold:True
    size_hint:0.15,0.04

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
                                        
''')
            btclosprisecharge.bind(on_release=lambda x:msssopen.dismiss())       

            try:
                cadprisecharge.add_widget(btclosprisecharge)
            except:
                pass
        
            cadreprischarge.size_hint=(1,.98)

            

            try:
                cadprisecharge.add_widget(cadreprischarge)
            except:
                pass


            msssopen=Popup(title="PRISE EN CHARGE",content=cadprisecharge,size_hint=(1,1))
            msssopen.open()

        else:

            btnval=Builder.load_string('''

Button:
    text:'Veuillez cliquer sur MENU, puis Prise en charge'
    color:'white'

    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')    

            msg=Popup(title="PROCEDURE ADMIN",content=btnval,size_hint=(.6, .2))
            msg.open()


    def affichpriseudirecte(self,instance,value):

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select * from prisecharge where gmail='"+instance.text+"' order by dates DESC"
            cursor.execute(query)
            results=cursor.fetchall()
            self.cursor.close()
            con.close()

            tablprise.row_data=results
        except:
            pass



    def chargegmailprise(self,instance):
        global trechlike

        if trechlike.text=="":
            pass
        else:
            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct gmail from prisecharge where gmail LIKE'%"+trechlike.text+"%'"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()


    def recherchepriseudirecte(self,instance):
        global trecherup

        try:

            instance.values=""

            self.cconnexion()
            cursor=con.cursor()
            query="select distinct gmail from prisecharge where gmail LIKE'%"+trecherup.text+"%'"
            cursor.execute(query)
            results=cursor.fetchall()
            self.cursor.close()
            con.close()

            for el in results:
                instance.values.append(str(el).replace("('","").replace("',)",""))
        except:
            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
            msg.open()

    
    def deplfocusprise1(self,instance):

        tprise2.focus=True

    def deplfocusprise2(self,instance):

        tprise3.focus=True
    
    def deplfocusprise3(self,instance):

        tprisee1.focus=True
    
    def deplfocusprise4(self,instance):

        tprisee2.focus=True

    def deplfocusprise5(self,instance):

        tprisee3.focus=True


    def affichprise(self):
        tablprise.row_data=[]

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select * from prisecharge order by dates DESC limit 10"
            cursor.execute(query)
            results=cursor.fetchall()
            self.cursor.close()
            con.close()

            tablprise.row_data=results
        except:
            pass

    def affinfoprise(self,instance_table,current_row):
        identid=""
        try:
            identid=str(current_row[0])
            self.cconnexion()
            cursor=con.cursor()
            query="select gmail,nom,prenom,sexe,tel,adresse,dates from prisecharge where gmail='"+identid+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()
            if results:
                
                tprise1.text=str(results[0])
                tprise2.text=str(results[1])
                tprise3.text=str(results[2])
                tprisee3.text=str(results[3])
                tprisee1.text=str(results[4])
                tprisee2.text=str(results[5])

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        btsavprise.text="[b]Modifier[/b]"

    def savepreisecharge(self,instance):

        if tprise1.text=="" or tprise2.text=="" or tprise3.text=="" or tprisee3.text=="" or tprisee1.text=="" or tprisee2.text=="":

            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Aucun champ ne doit etre vide !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
            msg.open() 
        
        else:

            if btsavprise.text=="[b]Enregistrer[/b]":

                try:

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into prisecharge(gmail,nom,prenom,sexe,tel,adresse,dates,trav) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                    cursor.execute(query,(tprise1.text,tprise2.text,tprise3.text,tprisee3.text,tprisee1.text,tprisee2.text,datetime.now().strftime('%Y-%m-%d'),tidconn.text))
                    con.commit()
                    self.cursor.close()
                    con.close()

                    tprise1.text=""
                    tprise2.text=""
                    tprise3.text=""
                    tprisee3.text=""
                    tprisee1.text=""
                    tprisee2.text=""

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Save Succeful !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()


                except:

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()

            elif btsavprise.text=="[b]Modifier[/b]":
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update prisecharge set nom=%s,prenom=%s,sexe=%s,tel=%s,adresse=%s,dates=%s,trav=%s where gmail=%s"
                    cursor.execute(query,(tprise2.text,tprise3.text,tprisee3.text,tprisee1.text,tprisee2.text,datetime.now().strftime('%Y-%m-%d'),tidconn.text,tprise1.text))
                    con.commit()
                    self.cursor.close()
                    con.close()

                    tprise1.text=""
                    tprise2.text=""
                    tprise3.text=""
                    tprisee3.text=""
                    tprisee1.text=""
                    tprisee2.text=""

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Save Succeful !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()

                except:

                    msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                    msg.open()   

            self.affichprise() 
    
    def rechidpresc(self,instance):

        instance.text="Chosir"

        if trechpresc1.text=="":
            pass
        else:
            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct id_prise from prescription where id_prise LIKE'%"+trechpresc1.text+"%'"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()

    def affrecid(self,instance,value):

        tablprescription.row_data=[]

        if suitmodrap.active==True:
            pass
        else:
            
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat and id_prise='"+instance.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                tablprescription.row_data=results
                
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()

    def rechdatepresc(self,instance):

        instance.text="Chosir"

        if combpresc1.text=="":
            pass
        else:

            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct datees from prescription where id_prise ='"+combpresc1.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
                datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                self.cursor.close()
                con.close()

                for el in datat:
                    instance.values.append(str(el))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
    
    def affrecdate(self,instance,value): 

        tablprescription.row_data=[]

        if suitmodrap.active==True:
            pass
        else:
            
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat and id_prise='"+combpresc1.text+"' and datees='"+instance.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                tablprescription.row_data=results
                
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
        
    def rechfacturepresc(self,instance):

        instance.text="Chosir"

        if combpresc2.text=="":
            pass
        else:

            try:

                instance.values=""

                self.cconnexion()
                cursor=con.cursor()
                query="select distinct id_achat from prescription where datees ='"+combpresc2.text+"'"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                for el in results:
                    instance.values.append(str(el).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
                msg.open()
    
    def affrecfacture(self,instance,value):

        tablprescription.row_data=[]
            
        try:
            self.cconnexion()
            cursor=con.cursor()
            query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat and id_prise='"+combpresc1.text+"' and datees='"+combpresc2.text+"' and id_achat='"+instance.text+"'"
            cursor.execute(query)
            results=cursor.fetchall()
            self.cursor.close()
            con.close()

            tablprescription.row_data=results
            
        except:
            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !',color='white',background_color='blue'),size_hint=(None, None), size=(400,150))
            msg.open()

    def PrescriptionPage(self,instance):

        if tablprescription.row_data==[]:

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="select id_prise,docteur,ID_Produit,PU,PT,Dats_id,datees,id_travailleur from prescription,achat where Dats_id=id_achat order by datees DESC limit 10"
                cursor.execute(query)
                results=cursor.fetchall()
                self.cursor.close()
                con.close()

                tablprescription.row_data=results
            except:
                pass   

        try:
            cadreprischarge.add_widget(cadresuitcmoderap)
            cadreprischarge.add_widget(labmodrap)
        except:
            pass

        try:
            cadreprischarge.add_widget(trechpresc1)
            cadreprischarge.add_widget(trechpresc2)
            cadreprischarge.add_widget(trechpresc3)

            cadreprischarge.add_widget(combpresc1)
            cadreprischarge.add_widget(combpresc2)
            cadreprischarge.add_widget(combpresc3)

            cadreprischarge.add_widget(tablprescription)
            
        except:
            pass

        try:
            cadreprischarge.remove_widget(tprise3)
            cadreprischarge.remove_widget(tprise2)
            cadreprischarge.remove_widget(tprise1)

            cadreprischarge.remove_widget(tprisee3)
            cadreprischarge.remove_widget(tprisee2)
            cadreprischarge.remove_widget(tprisee1)

            cadreprischarge.remove_widget(btsavprise) 
            cadreprischarge.remove_widget(labupdatpris)
            cadreprischarge.remove_widget(cadresuitchmorr)

            cadreprischarge.remove_widget(tablprise) 

        except:
            pass

        btbasss1.color='black'
        instance.color='blue'

    def inscriptionPage(self,instance):

        try:
            cadreprischarge.add_widget(tprise3)
            cadreprischarge.add_widget(tprise2)
            cadreprischarge.add_widget(tprise1)

            cadreprischarge.add_widget(tprisee3)
            cadreprischarge.add_widget(tprisee2)
            cadreprischarge.add_widget(tprisee1)

            cadreprischarge.add_widget(btsavprise) 
            cadreprischarge.add_widget(labupdatpris)
            cadreprischarge.add_widget(cadresuitchmorr)

            cadreprischarge.add_widget(tablprise) 

        except:
            pass

        
        try:
            cadreprischarge.remove_widget(cadresuitcmoderap)
            cadreprischarge.remove_widget(labmodrap)
        except:
            pass
        

        try:
            cadreprischarge.remove_widget(trechpresc1)
            cadreprischarge.remove_widget(trechpresc2)
            cadreprischarge.remove_widget(trechpresc3)

            cadreprischarge.remove_widget(combpresc1)
            cadreprischarge.remove_widget(combpresc2)
            cadreprischarge.remove_widget(combpresc3)

            cadreprischarge.remove_widget(tablprescription)
        except:
            pass

        btbasss2.color='black'
        instance.color='blue'

    def changebtnprise(self,instance):

        global trecherup

        if instance.active==True:

            btsavprise.text="[b]Modifier[/b]"

            cad=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:216/255,216/255,216/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
            
            ''')

            trecherup=MDTextField(hint_text='Recherche',pos_hint={'x':.05,'center_y':.5},size_hint=(.4,.2))

            comb=Builder.load_string('''
Spinner:
    text:"[b]Choisir[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.55,'center_y':0.5}
    size_hint:(0.4,0.15)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
''')
            comb.bind(on_release=self.recherchepriseudirecte)
            comb.bind(text=self.affichpriseudirecte)

            bb1=Builder.load_string('''
Spinner:
    text:"[b]Close[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.7,'y':0.1}
    size_hint:(0.25,0.15)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
''')        
            bb1.bind(on_release=lambda x:msg.dismiss())
            
            try:
                cad.add_widget(comb)
                cad.add_widget(bb1) 
                cad.add_widget(trecherup)
                
                msg=Popup(title="Recherche",content=cad,size_hint=(.5, .4))
                msg.open()

            except:
                pass


        else:
            btsavprise.text="[b]Enregistrer[/b]"


    def deplnew(self,instance):

        t9.focus

    def changeinput(self,instance):

        if instance.active==True:
            t8.hint_text='P.U en USD'

        
        else:
            t8.hint_text='P.U en CDF'
    
    def changedevise(self,instance):

        global combdev,newprixdev,trechdev

        if instance.active==True:

            newprixdev.hint_text='PU en USD'

        else:
            newprixdev.hint_text='PU en CDF'

    def rechprodd(self,instance):
        global trechdev

        if trechdev.text=="":
            pass
        else:
        
            instance.values=""

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select nom from produit where nom like'%"+trechdev.text+"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                for li in results:

                    instance.values.append(str(li).replace("('","").replace("',)",""))

            except:
                pass
    
    def rechupdate(self,instance):
        global combdev,newprixdev,suitchdevise

        btcl=Builder.load_string('''
Button:
    color:'white'
    pos_hint:{'x':.05,'y':.05}
    size_hint:1,1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
''')
        btcl.bind(on_release=lambda x:mg.dismiss())

        
        try:

            if suitchdevise.active==True:

                ppu=float(newprixdev.text)

            else:
                ppu=float(newprixdev.text)/tauxchangenew

                
            self.cconnexion()
            self.cursor=con.cursor()
            query="update produit set pu=%s where nom=%s"
            self.cursor.execute(query,(ppu,combdev.text))
            con.commit()
            con.close()

            btcl.text="Effectué !!"
            mg=Popup(title="STATUT",content=btcl,size_hint=(.4,.2))
            mg.open()

            newprixdev.text=""
            combdev.text="Choisir"
            trechdev.text=""

        except:
            
            btcl.text="Erreur survenue !!"
            mg=Popup(title="STATUT",content=btcl,size_hint=(.4,.2))
            mg.open()

    def openchangeprix(self,instance):
        global combdev,newprixdev,trechdev,suitchdevise

        global msgg

        try:
            cadrehautnewvieux.remove_widget(cadrehautnew)
        except:
            pass

        msgg.dismiss()

        cadrchangeprix=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}
    
    canvas.before:
        Color:
            rgb:171/255,176/255,157/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

        btcl=Builder.load_string('''
Button:
    text:"Close"
    color:'white'
    pos_hint:{'x':.05,'y':.05}
    size_hint:.25,.1
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,0,0
        RoundedRectangle:
            size:self.size
            pos:self.pos
''')
        labdev=Label(text="DEVISE",color='black',size_hint=(.1,.1),pos_hint={'x': .75, 'center_y': .9},font_size='12sp')

        btcl.bind(on_release=lambda x:msg.dismiss())

        suitchdevise=Builder.load_string('''
MDSwitch:
    pos_hint: {'x': .88, 'center_y': .9}
    color_active:'red'
    active:True
    on_active:app.changedevise(self)
    
        ''')

        trechdev=MDTextField(hint_text='Recherche',pos_hint={'x':.05,'center_y':.6},size_hint=(.4,.25),icon_right='text')

        newprixdev=MDTextField(hint_text='PU en USD',pos_hint={'x':.6,'center_y':.35},size_hint=(.3,.25),icon_right='text')

        combdev=Builder.load_string('''
Spinner:
    text:"[b]Chosir[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.7,'center_y':0.6}
    size_hint:(0.4,0.12)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
''')
        combdev.bind(on_release=self.rechprodd)

        btsavdev=Builder.load_string('''
Spinner:
    text:"[b]Save[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'y':0.05}
    size_hint:(0.3,0.1)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
''')
        btsavdev.bind(on_release=self.rechupdate)

        try:
            cadrchangeprix.add_widget(btcl)
        except:
            pass
        
        try:
            cadrchangeprix.add_widget(suitchdevise)
        except:
            pass
        try:
            cadrchangeprix.add_widget(labdev)
        except:
            pass
        
        try:
            cadrchangeprix.add_widget(trechdev)
        except:
            pass
    
        try:
            cadrchangeprix.add_widget(combdev)
        except:
            pass
        try:
            cadrchangeprix.add_widget(newprixdev)
        except:
            pass
        
        try:
            cadrchangeprix.add_widget(btsavdev)
        except:
            pass

        msg=Popup(title="MISE A JOUR",content=cadrchangeprix,size_hint=(.5,.5))
        msg.open()

    def closesettingferm(self,instance):
        global msgg

        try:
            cadrehautnewvieux.remove_widget(cadrehautnew)
        except:
            pass

        msgg.dismiss()

    def opensetting(self,instance):
        global msgg,cadrehautnewvieux,verifsel

        try:
            cadrehautnewvieux.remove_widget(cadrehautnew)
        except:
            pass
        

        cadrehautnewvieux=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}
    
    canvas.before:
        Color:
            rgb:171/255,176/255,157/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[5]
        
        ''')

        btcl=Builder.load_string('''
Button:
    text:"Close"
    color:'white'
    pos_hint:{'x':.7,'y':.05}
    size_hint:.25,.06
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:1,0,0
        RoundedRectangle:
            size:self.size
            pos:self.pos
''')

        btcl.bind(on_release=self.closesettingferm)

        
        try:
            cadrehautnew.add_widget(btcl)
        except:
            pass
        
        try:
            cadrehautnew.add_widget(bpreforma)
        except:
            pass

        bclose.pos_hint={'x':0.05, 'y':0.4} 
        bdeconn.pos_hint={'x':0.05, 'y':0.05}
    
        if sepp==1:

            verifsel=1

            imgtaux.pos_hint={'center_x':.5,'y':0.9}
            imgtaux.size_hint=(0.1,0.1)    

            bclose.text='[b]Closing day ?[/b]'
            #bclose.pos_hint={'x':0.9, 'y':0.85}

            #bdeconn.pos_hint={'x':0.88, 'y':0.95} 

            

            try:
                cadrehautnew.add_widget(btntauxadmin)
            except:
                pass

            try:
                cadxxsetting.add_widget(btautorisermodtp)
                cadxxsetting.add_widget(bcommutadmin)
                cadxxsetting.add_widget(bgestionusernew)
                cadxxsetting.add_widget(bautomodiftravprod)
            except:
                pass
        
            try:
                cadrehautnew.add_widget(bcorrection)
            except:
                pass
        
            
            

            try:
                cadrehautnew.add_widget(cadxxsetting)
                #cadrehautnew.add_widget(cadxxsetting)

                #bautomodiftravprod.pos_hint={'x':0, 'y':0}
                #cadre.add_widget(bautomodiftravprod)
            except:
                pass
        
        if labvente.text=="[b]SUPER PHARMA[/b]" and sepp==8:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select etat,etat_ravitaillement from autorisation where id='selecteur'")
                resultetatautorisa=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                etat=0
                etatravitail=0

                if resultetatautorisa:
                    etat=resultetatautorisa[0]
                    etatravitail=resultetatautorisa[1]
                
                if etat==1:

                    try:
                        cadrehautnew.add_widget(btmodstockauto)
                    except:
                        pass

                if etatravitail==1:

                    try:
                        cadrehautnew.add_widget(btopenravclient)
                    except:
                        pass
                    
                    try:
                        cadrehautnew.add_widget(bchangeprix)
                    except:
                        pass


                else:

                    try:
                        cadrehautnew.remove_widget(btopenravclient)
                    except:
                        pass
                    
                    try:
                        cadrehautnew.remove_widget(bchangeprix)
                    except:
                        pass

                    try:
                        cadrehautnew.remove_widget(btmodstockauto)
                    except:
                        pass
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Errorr!!'),size_hint=(None, None), size=(400,200))
                msg.open()

                
        try:  
            cadrehautnewvieux.add_widget(cadrehautnew)
        except:
            pass
        
        msgg=Popup(title="PARAMETRES",content=cadrehautnewvieux,size_hint=(.7,.7),background_color='black')
        msgg.open()

        
    def changecdf(self,instance):

        net=0

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select taux from tauxchange where num=1")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                net=results[0]

            net=math.ceil(net*float(t8.text))

            cadcloss=MDFloatLayout()
            lablink1= Label(text=str(net)+" CDF",font_size='15sp',color='white', pos_hint={'center_x':0.5, 'center_y':0.5},size_hint=(0.9,0.08))

            try:
                cadcloss.add_widget(lablink1)

                msg=Popup(title="MESSAGE SYSTEME",content=cadcloss,size_hint=(None, None), size=(400,200),background_color='blue')
                msg.open()

            except:
                pass

        except:
            msg=Popup(title="MESSAGE SYSTEME",content=Button(text='ERROR !'),size_hint=(None, None), size=(400,150))
            msg.open()

    def savecanette(self,instance):
        global datdeb,datefin

        vall=0  

        try:      

            if pasconnette.text=="1":
                vall=5
            elif pasconnette.text=="2":
                vall=10
            elif pasconnette.text=="3":
                vall=15

            if (int(jourcannette.text)+vall)>31:

                msg=Popup(title="MESSAGE SYSTEME",content=Button(text='Depassement du Pas !!, veuillez bien ajuster !'),size_hint=(None, None), size=(400,200))
                msg.open()

            else:
                if len(moiscanette.text)==1:
                    moiscanette.text="0"+moiscanette.text
                
                if len(jourcannette.text)==1:
                    jourcannette.text="0"+jourcannette.text

                try:

                    datdeb=annecanette.text +"-"+ moiscanette.text +"-"+ jourcannette.text
                    
                    datefin=annecanette.text +"-"+ moiscanette.text +"-"+ str(int(jourcannette.text)+vall)

                    datdeb=datetime.strptime(datdeb,'%Y-%m-%d')
                    datefin=datetime.strptime(datefin,'%Y-%m-%d')
                    
                except:

                    pamsg=Popup(title="Msg ERROR",content=Button(text='Date invalide !'),size_hint=(None, None), size=(400,200))
                    msg.open()

                msg=Popup(title="CONTROLEUR SYSTEME!!",content=Button(text='Effectué !'),size_hint=(None, None), size=(400,200))
                msg.open()
        except:
            msg=Popup(title="CONTROLEUR SYSTEME!!",content=Button(text='ERROR !'),size_hint=(None, None), size=(400,200))
            msg.open()
      

    def chargepas(self,instance):
        lis=["1","2","3","Pas"]

        instance.values=""

        for i in lis:
            instance.values.append(i)

    def cannettereglage(self,instance):

        combo2.text="choisir"

        #background_normal=="barre-reglages.png":
        
        if instance.icon=='filter-cog':

            try:
                cadre.add_widget(cadcanette)
            except:
                pass

            #instance.background_normal="back.jpg"

            instance.icon='exit-to-app'

        else:

            try:
                cadre.remove_widget(cadcanette)
            except:
                pass

            instance.icon='filter-cog'

            #instance.background_normal="barre-reglages.png"


    def connectetoserver(self,instance):
        global choixconn,tlink,adrip,msgconnect

        adrip=tlink.text
        choixconn=0
        adrip=adrip.replace("@",".").replace("w","1")

        try:
            con=mysql.connector.connect(
            host=adrip,
            #"localhost",
            user="askyas",
            password="askyas",
            database="pharma"
            )

            msg=Popup(title="CONTROLEUR SYSTEME!!",content=Button(text='Connexion au serveur reussie !!'),size_hint=(None, None), size=(400,200))
            msg.open()

            msgconnect.dismiss()

        except:
            msg=Popup(title="FATAL ERROR!!",content=Button(text='Impossible car le Serveur est injoignable'),size_hint=(None, None), size=(400,200))
            msg.open()

    def generatorlink(self,instance):
        global lablink1,lablink2,choixconn, tlink,cadcloss

        choixconn=1

        ip_address=""

        mach=socket.gethostname()
        ips=socket.gethostbyname(mach)

        try:
            cadcloss.remove_widget(tlink)
        except:
            pass

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))  # Connecter à un serveur quelconque
                ip_address = s.getsockname()[0]

        except:
            pass
        try:
        
            ips=ips.replace(".","@").replace("1","w")
            
            ip_address=ip_address.replace(".","@").replace("1","w")

            lablink1.text="LAN : "+ips
            
            lablink2.text="WLAN : "+ip_address    
        except:
            msg=Popup(title="FATAL ERROR!!",content=Button(text='Cette machine n est pas connectée à une Ressource reseau\Veuillez d abord vous connecter à un reseau puis ressayer'),size_hint=(None, None), size=(400,200))
            msg.open()        

    def effacetextserveur(self,instance,value):

        if instance.text=="L'adresse du serveur":
            instance.text=""


    def generateqrcode(self,instance):
        global msgconnect

        global lablink1,lablink2,choixconn

        choixconn=1

        ip_address=""
        imgqr=""

        mach=socket.gethostname()
        ips=socket.gethostbyname(mach)

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))  # Connecter à un serveur quelconque
                ip_address = s.getsockname()[0]

        except:
            pass

        try:
        
            #ips=ips.replace(".","@").replace("1","w")
            
            ip_address=ip_address.replace(".","@").replace("1","w")
    
        except:
            msg=Popup(title="FATAL ERROR!!",content=Button(text='Cette machine n est pas connectée à une Ressource reseau\Veuillez d abord vous connecter à un reseau puis ressayer'),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            qr.add_data(ip_address)
            qr.make(fit=True)

            img=qr.make_image(fill_color="black",back_color="white")

            img.save("imageqr.png")

            imgqr="imageqr.png"
        except:
            msg=Popup(title="FATAL ERROR!!",content=Button(text='ERROR!!'),size_hint=(.8,.5))
            msg.open()

        try:
            msgconnect.dismiss()
        except:
            pass
        
        cadcloss=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1 #221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')
        
        bt=Builder.load_string('''
Button:
    text:'Close'
    pos_hint:{'x':.75,'y':.1}
    size_hint:.2,.1
    bold:True
    color:'white'
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')

        bt.bind(on_release=lambda x:mggg.dismiss())

        imgg=Image(pos_hint={'center_x':.5,'center_y':.5},size_hint=(.5,.7),source=imgqr)

        try:
            cadcloss.add_widget(bt)
            cadcloss.add_widget(imgg)
        except:
            pass

        mggg=Popup(title="ADRESSE QR",content=cadcloss,size_hint=(1,1))
        mggg.open()


    def partageserveur(self,instance):
        global lablink1,lablink2,tlink,msgconnect,tlink,cadcloss

        cadcloss=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')
        labgen=Label(text="Qr Code",size_hint=(.1,.1),pos_hint={'x':.7,'y':.85},color='black',bold=True)
        
        cadsui=Builder.load_string('''
FloatLayout:
    size_hint:.14,.14
    pos_hint:{'x':.83,'y':.83}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
        ''')

        suitidqrcode=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'red'
    #active:True
    on_active:app.generateqrcode(self)
    
        ''')

        try:
            cadsui.add_widget(suitidqrcode)
            
        except:
            pass

        

        lablink1= Label(text="",font_size='15sp',color='blue',bold=True, pos_hint={'center_x':0.5, 'center_y':0.8},size_hint=(0.9,0.08))
        lablink2= Label(text="",font_size='15sp',color='blue',bold=True, pos_hint={'center_x':0.5, 'center_y':0.6},size_hint=(0.9,0.08))
        
        tlink=TextInput(text="L'adresse du serveur",font_size='13sp',pos_hint={'center_x':0.5, 'center_y':0.5},size_hint=(0.7,0.15))
        tlink.bind(focus=self.effacetextserveur)

        linkgener=Builder.load_string('''
Button:
    text:"[b]Generate Link[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.15,'y':0.1}
    size_hint:(0.35,0.11)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
        ''')
        
        linkgener.bind(on_press=self.generatorlink)

        qrkingener=Builder.load_string('''
Button:
    text:"[b]Connect[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.55,'y':0.1}
    size_hint:0.3,0.11
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')
        
        
        qrkingener.bind(on_press=self.connectetoserver)

        try:
            cadcloss.add_widget(lablink1)
            cadcloss.add_widget(lablink2)
            cadcloss.add_widget(linkgener)
            cadcloss.add_widget(qrkingener)
            cadcloss.add_widget(tlink)

            cadcloss.add_widget(labgen)
            cadcloss.add_widget(cadsui)

        except:
            pass

        msgconnect=Popup(title="GENERATEUR D ACCES",content=cadcloss,size_hint=(None, None), size=(400,250), background_color='black')
        msgconnect.open()

    def affnomprodv(self,instance_table,current_row):

        ident=str(current_row[0])

        try:
            self.cconnexion()
            cursor=con.cursor()
            query="select nom from produit where matricule='"+ident+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                nompro=results[0]

                cadcloss=MDFloatLayout()
                labri1= Label(text=nompro,font_size='15sp',color='white', pos_hint={'center_x':0.5, 'center_y':0.7},size_hint=(0.9,0.8))
                
                try:
                    cadcloss.add_widget(labri1)

                    msg=Popup(title="INFO",content=cadcloss,size_hint=(None, None), size=(400,100))
                    msg.open()

                except:
                    pass

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def restraindre(self,instance):
        
        global msgopen,msgauto1
        
        msgauto1.dismiss()
        msgopen.dismiss()

        if cheautoriclient.active==False:

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="update autorisation set etat=%s where id=%s"
                cursor.execute(query,('0','selecteur'))
                con.commit()
                self.cursor.close()
                con.close()

                msgauto1.dismiss()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def autorisefinravitaill(self,instance):

        global msgauto1,msgopen

        if chexportdirrect.active==True:

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="update autorisation set etat_ravitaillement=%s where id=%s"
                cursor.execute(query,('1','selecteur'))
                con.commit()
                self.cursor.close()
                con.close()

                msgauto1.dismiss()

                btss=Builder.load_string('''
Button:
    text:"Effectué"
    color:'black'

    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
                ''')

                msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(.4, .2))
                msg.open()

                try:
                    msgopen.dismiss()
                except:
                    pass

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:
            try:

                self.cconnexion()
                cursor=con.cursor()
                query="update autorisation set etat_ravitaillement=%s where id=%s"
                cursor.execute(query,('0','selecteur'))
                con.commit()
                self.cursor.close()
                con.close()

                msgauto1.dismiss()

                btss=Builder.load_string('''
Button:
    text:"Effectué"
    color:'black'

    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
                ''')

                msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(.4,.2))
                msg.open()

                try:
                    msgopen.dismiss()
                except:
                    pass

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()


    def autorisefin(self,instance):
        global msgauto1,msgopen  

        if cheautoriclient.active==True:

            try:

                self.cconnexion()
                cursor=con.cursor()
                query="update autorisation set etat=%s where id=%s"
                cursor.execute(query,('1','selecteur'))
                con.commit()
                self.cursor.close()
                con.close()

                msgauto1.dismiss()

                btss=Builder.load_string('''
Button:
    text:"Effectué"
    color:'black'

    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
                ''')

                msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(.4, .2))
                msg.open()

                try:
                    msgopen.dismiss()
                except:
                    pass

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:
            try:

                self.cconnexion()
                cursor=con.cursor()
                query="update autorisation set etat=%s where id=%s"
                cursor.execute(query,('0','selecteur'))
                con.commit()
                self.cursor.close()
                con.close()

                msgauto1.dismiss()

                btss=Builder.load_string('''
Button:
    text:"Effectué"
    color:'black'

    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
                ''')

                msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(.4,.2))
                msg.open()

                try:
                    msgopen.dismiss()
                except:
                    pass

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        
    def refus(self,instance):
        global msgopen,msgauto1

        try:
        
            msgauto1.dismiss()
        except:
            pass
        try:
            msgopen.dismiss()
        except:
            pass

        cheautoriclient.active=False

    def autorisertrav(self,instance):
        global msgauto1

        if instance.active==False:

            cadcloss=Builder.load_string('''    
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10] 

''')

            labri1= Label(text="Voulez-vous vraiment autoriser cette operation",font_size='15sp',color='black', pos_hint={'center_x':0.5, 'center_y':0.7},size_hint=(0.9,0.5))
            
            bval0=Button(text="[b]Autoriser[/b]",font_size='18sp', pos_hint={'x':0.65,'y':0.15},size_hint=(0.25,0.07),color='white',markup=True,background_color='red')
            bval0.bind(on_release=self.autorisefin)
            brefu=Button(text="[b]Refuser[/b]",font_size='18sp', pos_hint={'x':0.15,'y':0.15},size_hint=(0.25,0.07),color='white',markup=True,background_color='red')
            brefu.bind(on_release=self.refus)

            try:
                cadcloss.add_widget(labri1)
                cadcloss.add_widget(bval0)
                cadcloss.add_widget(brefu)

            except:
                pass

            msgauto1=Popup(title="CONFIG SYSTEM",content=cadcloss,background_color='blue',size_hint=(.5, .4))
            msgauto1.open()
            
        else:

            cadcloss=Builder.load_string('''    
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10] 

''')
            labri1= Label(text="Voulez-vous vraiment autoriser cette operation ?",font_size='15sp',color='black', pos_hint={'center_x':0.61, 'center_y':0.7},size_hint=(0.9,0.5))
            
            bval0=Button(text="[b]Autoriser[/b]",font_size='18sp', pos_hint={'x':0.65,'y':0.15},size_hint=(0.25,0.04),color='white',markup=True,background_color='red')
            bval0.bind(on_release=self.autorisefin)
            brefu=Button(text="[b]Refuser[/b]",font_size='18sp', pos_hint={'x':0.15,'y':0.15},size_hint=(0.25,0.04),color='white',markup=True,background_color='red')
            brefu.bind(on_release=self.refus)

            try:
                cadcloss.add_widget(labri1)
                cadcloss.add_widget(bval0)
                cadcloss.add_widget(brefu)

            except:
                pass

            msgauto1=Popup(title="CONFIG SYSTEM",content=cadcloss,background_color='blue',size_hint=(.5,.4))
            msgauto1.open()


    def autorisertravravitaillement(self,instance):
        global msgauto1 

        if instance.active==False:

            cadcloss=Builder.load_string('''    
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10] 

''')

            labri1= Label(text="Voulez-vous vraiment autoriser cette operation?",font_size='15sp',color='black', pos_hint={'center_x':0.5, 'center_y':0.7},size_hint=(0.9,0.5))
            
            bval0=Button(text="[b]Autoriser[/b]",font_size='18sp', pos_hint={'x':0.65,'y':0.15},size_hint=(0.25,0.07),color='white',markup=True,background_color='red')
            bval0.bind(on_release=self.autorisefinravitaill)
            brefu=Button(text="[b]Refuser[/b]",font_size='18sp', pos_hint={'x':0.15,'y':0.15},size_hint=(0.25,0.07),color='white',markup=True,background_color='red')
            brefu.bind(on_release=self.refus)

            try:
                cadcloss.add_widget(labri1)
                cadcloss.add_widget(bval0)
                cadcloss.add_widget(brefu)

            except:
                pass

            msgauto1=Popup(title="CONFIG SYSTEM",content=cadcloss,background_color='blue',size_hint=(.5, .4))
            msgauto1.open()
            
        else:

            cadcloss=Builder.load_string('''    
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10] 

''')
            labri1= Label(text="Voulez-vous vraiment autoriser cette operation ?",font_size='15sp',color='black', pos_hint={'center_x':0.61, 'center_y':0.7},size_hint=(0.9,0.5))
            
            bval0=Button(text="[b]Autoriser[/b]",font_size='18sp', pos_hint={'x':0.65,'y':0.15},size_hint=(0.25,0.04),color='white',markup=True,background_color='red')
            bval0.bind(on_release=self.autorisefinravitaill)
            brefu=Button(text="[b]Refuser[/b]",font_size='18sp', pos_hint={'x':0.15,'y':0.15},size_hint=(0.25,0.04),color='white',markup=True,background_color='red')
            brefu.bind(on_release=self.refus)

            try:
                cadcloss.add_widget(labri1)
                cadcloss.add_widget(bval0)
                cadcloss.add_widget(brefu)

            except:
                pass

            msgauto1=Popup(title="CONFIG SYSTEM",content=cadcloss,background_color='blue',size_hint=(.5,.4))
            msgauto1.open()


    def rechnompromodtp(self,instance):
        global tmodqt

        if tmodqt.text=="":
            pass
        else:
            instance.text="choisir"

            instance.values=("")
            
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select nom from produit where nom LIKE'%"+tmodqt.text +"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()
        

    def valimodifstock(self,instance):
        global qtmodauto,rechlikepromodqt

        try:
            int(qtmodauto.text)

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from verificateur_stock where nom_p='"+rechlikepromodqt.text+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    nomp=results[0]
                    datep=results[1]

                    msg=Popup(title="STATUT REQUETE",content=Button(text='Error!! Ce produit a été initié son stock le : '+str(datep)+'\n desormais, veuillez passer par ravitaillement !!'),size_hint=(None, None), size=(600,200))
                    msg.open()

                else:
                    
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update produit set stock=%s,stock_p=%s where nom=%s"
                    cursor.execute(query,(int(qtmodauto.text),int(qtmodauto.text),rechlikepromodqt.text))
                    con.commit()
                    self.cursor.close()
                    con.close()
                    
                    if query:
                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into verificateur_stock(nom_p,datess) values(%s,%s)"
                        dataa=(rechlikepromodqt.text,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                        cursor.execute(query,dataa)
                        con.commit()
                        self.cursor.close()
                        con.close()

                        msg=Popup(title="STATUT REQUETE",content=Button(text='Stock initié avec succes'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Quantité doit etre valeur numerique !!'),size_hint=(None, None), size=(400,200))
            msg.open()

    def modopentrav(self,instance):
        global qtmodauto,tmodqt,rechlikepromodqt

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select etat from autorisation where id='selecteur'")
            resultetatautorisa=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            etat=0

            if resultetatautorisa:
                etat=resultetatautorisa[0]
            
            if etat==1:

                cadcloss=Builder.load_string('''    
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10] 

''')

                tmodqt = MDTextField(hint_text="Recheche",line_color_normal='black', font_size='15sp',pos_hint={'x':0.1, 'y':0.35},size_hint=(0.3,0.2))
                qtmodauto = MDTextField(hint_text="Quantite",line_color_normal='black', font_size='15sp', pos_hint={'x':0.25, 'y':0.1},size_hint=(0.15,0.2))
                
                rechlikepromodqt=Spinner(text="[b]Choisir[/b]",pos_hint={'x':0.4, 'y':0.5},font_size='17sp',size_hint=(0.58,0.12),background_color="blue",markup=True, color="white")
                rechlikepromodqt.bind(on_release=self.rechnompromodtp)

                bprefo=Builder.load_string('''
Button:
    text:"[b]Valider[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.75,'y':0.15}
    size_hint:(0.25,0.2)
    color:'white'
    markup:True
    background_color:[0,0,0,0]


    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15] 
''')
                
                bprefo.bind(on_release=self.valimodifstock)
            
                try:
                    cadcloss.add_widget(qtmodauto)
                    cadcloss.add_widget(tmodqt)
                    cadcloss.add_widget(bprefo)
                    cadcloss.add_widget(rechlikepromodqt)
                except:
                    pass
                
                msgopen=Popup(title="CONFIG SYSTEM",content=cadcloss,background_color='blue',size_hint=(None, None), size=(600,200))
                msgopen.open()

            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='NOT PERMISS !!'),size_hint=(None, None), size=(400,200))
                msg.open()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='ERROR !!'),size_hint=(None, None), size=(400,200))
            msg.open()

    def chagepermisrav(self,instance):

        if instance.active==True:

            print("active")
        else:
            print("desactive")


    def openautorisation(self,instance):
        global msgg,msgopen

        global qtmodauto,tmodqt,rechlikepromodqt,cheautoriclient,chexportdirrect,msgopen

        try:
            msgg.dismiss()
        except:
            pass
            
        try:

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select etat,etat_ravitaillement from autorisation where id='selecteur'")
            resultetatautorisa=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            etat=0
            etatravitail=0

            if resultetatautorisa:
                etat=resultetatautorisa[0]
                etatravitail=resultetatautorisa[1]

            
            cadcloss=Builder.load_string('''
                
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

            
            cadbtnUsdCdfchange=Builder.load_string('''
FloatLayout:
    size_hint:.12,.12
    pos_hint:{'x':0.85,'y':0.85}

    canvas.before:
        Color:
            rgb:128/255,128/255,128/255
        RoundedRectangle:

            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')

            if etat==1:

                cheautoriclient=Builder.load_string('''
MDSwitch:
    pos_hint:{'center_x':0.5,'center_y':0.5}
    color_active:'red'
    active:True
    on_active:app.autorisertrav(self)      
        
            ''')
            else:
                cheautoriclient=Builder.load_string('''
MDSwitch:
    pos_hint:{'center_x':0.5,'center_y':0.5}
    color_active:'red'
    active:False
    on_active:app.autorisertrav(self)     
        
        ''')

            cadrerienn=Builder.load_string('''
FloatLayout:
    size_hint:.12,.12
    pos_hint:{'x':0.85,'y':0.69}
                                                   
    canvas.before:
        Color:
            rgb:128/255,128/255,128/255
        RoundedRectangle:

            size:self.size
            pos:self.pos

            radius:[15]
        
        ''')

            if etatravitail==1:

                chexportdirrect=Builder.load_string('''
MDSwitch:
    pos_hint:{'center_x':0.5,'center_y':0.5}
    color_active:'red'
    active:True
    on_active:app.autorisertravravitaillement(self)     
        
        ''')

            else:

                chexportdirrect=Builder.load_string('''
MDSwitch:
    pos_hint:{'center_x':0.5,'center_y':0.5}
    color_active:'red'
    active:False
    on_active:app.autorisertravravitaillement(self)     
        
        ''')
                

            try:
                cadbtnUsdCdfchange.add_widget(cheautoriclient) 
                cadrerienn.add_widget(chexportdirrect)
            except:
                pass

            #cheautoriclient=CheckBox(pos_hint={'x':0.8,'y':0.86},size_hint=(0.05,0.05))
            #cheautoriclient.bind(active=self.autorisertrav)

            #chexportdirrect=CheckBox(pos_hint={'x':0.8,'y':0.73},size_hint=(0.05,0.05))
            #checkmotif.bind(active=self.combinemotif)active=True,        

            laut1 = Label(text="Autoriser Stock-Initial",font_size='14sp',color='black', pos_hint={'x':0.55, 'y':0.85},size_hint=(0.15,0.1))
            laut2= Label(text="Autoriser Stock-Ravitaillé",font_size='14sp',color='black', pos_hint={'x':0.55, 'y':0.67},size_hint=(0.15,0.1))
            
            tmodqt = MDTextField(hint_text="Recherche",icon_right='card-search',line_color_normal='black', font_size='14sp',pos_hint={'x':0.05, 'y':0.44},size_hint=(0.3,0.2))
            qtmodauto = MDTextField(hint_text="Quantite",line_color_normal='black', font_size='14sp', pos_hint={'x':0.2, 'y':0.1},size_hint=(0.15,0.2))
            
            rechlikepromodqt=Builder.load_string('''
Spinner:
    text:"[b]Choisir[/b]"
    pos_hint:{'x':0.4, 'y':0.46}
    font_size:'15sp'
    size_hint:0.58,0.12
    background_color:[0,0,0,0]
    markup:True
    color:"white"

    canvas.before:
        Color:
            rgba:0,0,1,1

        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
            
            ''')
            
            
            rechlikepromodqt.bind(on_release=self.rechnompromodtp)

            bprefo=Builder.load_string('''
Button:
    text:"[b]Valider[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.73,'y':0.13}
    size_hint:(0.25,0.13)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
            
        
            bprefo.bind(on_release=self.valimodifstock)


            try:
                cadcloss.add_widget(laut1)
                cadcloss.add_widget(laut2)
                
                cadcloss.add_widget(rechlikepromodqt)

                cadcloss.add_widget(qtmodauto)
                cadcloss.add_widget(tmodqt)
                cadcloss.add_widget(bprefo)

            except:
                pass
            try:
                cadcloss.add_widget(cadrerienn)
                cadcloss.add_widget(cadbtnUsdCdfchange)
            except:
                pass
        
            
            msgopen=Popup(title="CONFIG SYSTEM",content=cadcloss,background_color='black',size_hint=(.5,.4))
            msgopen.open()

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def calculebenefice(self,instance):
        global tauxachat,listventecombine,interval,totben
        
        if checkgobal.active==True:

            som=0
            
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select SUM(PU) from achat")
            resultssom=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if resultssom:
                som=resultssom[0]

            if som==0:

                tot=0

                try:
                    #listetaux=tauxachat.text.split()

                    #for i in listetaux:
                        #tot+=int(i)

                    #moytaux=tot/len(listetaux)

                    if interval==0:

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir":
                                
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                #self.cursor.execute("select sum((PT/Qte-'"+str(moytaux)+"'*produit.pu) * Qte) from achat,produit where produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()
                                
                                if results:
                                    totben.text=str(math.ceil(results[0]))+" USD"
                                        
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'") 
                                #self.cursor.execute("select sum((PT/Qte-'"+str(moytaux)+"'*produit.pu) * Qte) from achat,produit where produit.matricule=achat.ID_Produit and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    totben.text=str(math.ceil(results[0]))+" USD"
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir":

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    totben.text=str(math.ceil(results[0]))+" USD"
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo1.text!="choisir" and combotrav.text !="choisir":

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    totben.text=str(math.ceil(results[0]))+" USD"
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        totben.color='white'

                    elif interval==1:

                        try:
                            datlimite=datetime.strptime(combanneintervalvente.text+"-"+combmoisintervalveny.text+"-"+combjourintervalvente.text,'%Y-%m-%d')
                            datelimnew=datlimite.strftime('%Y-%m-%d')
                        except:
                            datelimnew='0000-00-00'
                            datelimnew=datelimnew.strftime('%Y-%m-%d')

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:
                                    totben.text=str(math.ceil(results[0]))+" USD"

                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    totben.text=str(math.ceil(results[0]))+" USD"
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir":

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    totben.text=str(math.ceil(results[0]))+" USD"
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo1.text!="choisir" and combotrav.text !="choisir":

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from achat,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=achat.ID_Produit and id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    totben.text=str(math.ceil(results[0]))+" USD"
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        totben.color='seagreen'
                        interval=0
                    
                    tauxachat.text="[-1,85....+1,85]"

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            else:

                msg=Popup(title="STATUT REQUETE",content=Button(text='Pour calculer le benefice global de la journée\nIl faut d abord cloturer la journé et plus proceder !!'),size_hint=(None, None), size=(400,200))
                msg.open()
        
        elif checkgobal.active==False:

            tot=0

            try:
                #listetaux=tauxachat.text.split()

                #for i in listetaux:
                 #   tot+=int(i)

                #moytaux=tot/len(listetaux)

                if interval==0:

                    if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()
                            
                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()
                        
                    elif combo1.text!="choisir" and combo2.text!="choisir": 
                        
                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                    elif combo2.text!="choisir" and combotrav.text !="choisir": 

                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                    elif combo1.text!="choisir" and combotrav.text !="choisir": 

                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                    totben.color='white'

                elif interval==1:

                    try:
                        datlimite=datetime.strptime(combanneintervalvente.text+"-"+combmoisintervalveny.text+"-"+combjourintervalvente.text,'%Y-%m-%d')
                        datelimnew=datlimite.strftime('%Y-%m-%d')
                    except:
                        datelimnew='0000-00-00'
                        datelimnew=datelimnew.strftime('%Y-%m-%d')

                    if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir":

                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:
                                totben.text=str(math.ceil(results[0]))+" USD"

                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()
                        
                    elif combo1.text!="choisir" and combo2.text!="choisir": 
                        
                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                    elif combo2.text!="choisir" and combotrav.text !="choisir": 

                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                    elif combo1.text!="choisir" and combotrav.text !="choisir": 

                        try:
                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("select sum(((PT/Qte/taux)-((PT/Qte/taux)/valeur)) * Qte) from historique,produit,tauxchange,indice where indice.id_ind='indice' and tauxchange.num=1 and produit.matricule=historique.ID_Produit and id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                            results=self.cursor.fetchone()
                            self.cursor.close()
                            con.close()

                            if results:

                                totben.text=str(math.ceil(results[0]))+" USD"
                                
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                    totben.color='seagreen'
                    interval=0

                tauxachat.text="[-1,85....+1,85]"

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def configbenefice(self,instance):
        global tauxachat,totben

        cadcloss=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]

''')

        totben = Label(text=" USD",font_size='17sp',color='blue', pos_hint={'x':0.7, 'y':0.8},size_hint=(0.3,0.1))
        tauxachat = Label(color='blue',text="",font_size='20sp', pos_hint={'center_x':0.5, 'center_y':0.5},size_hint=(0.6,0.1))
        bprefo=Builder.load_string('''
Button:
    text:"[b]Calculer[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.7,'center_y':0.2}
    size_hint:(0.25,0.2)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')        
        
        
        bprefo.bind(on_release=self.calculebenefice)

        try:
            cadcloss.add_widget(totben)
            cadcloss.add_widget(tauxachat)
            cadcloss.add_widget(bprefo)
        except:
            pass

        msg=Popup(title="CALCUL DE REVENU ",content=cadcloss,background_color='blue',size_hint=(None, None), size=(600,200))
        msg.open()
    
    def bypasspro(self,instance,value):

        if instance.text.lower()=="@@ww#ww@@":

            listecompte=[]

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("delete from session")
                con.commit()
                self.cursor.close()
                con.close()

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from compte")
                listecompte=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                #print(listecompte)
                
                discourant=os.path.dirname(__file__)
                partibien=discourant[0:2]
                partibien=partibien+"\\"

                chmc=os.path.join(partibien,"RAPPORT_PHARMA")

                try:
                    os.makedirs(chmc)
                except:
                    pass

                chfichier=os.path.join(chmc,"rapport.txt")

                try:
                    os.remove(chfichier)
                except:
                    pass

                try:
                    with open(chfichier,'w') as f:
                
                        for linn in listecompte:

                            f.write(str(linn)+"\n")

                    msg=Popup(title="STATUT REQUETE",content=Button(text='Table generée avec succes'),size_hint=(None, None), size=(300,200))
                    msg.open()

                except:
                    pass

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur a été capturée veuillez ressayer!!'),size_hint=(None, None), size=(300,200))
                msg.open()
    
    def supsession(self,instance):
        global codebypass

        cadcloss=Builder.load_string('''

FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]
''')

        codebypass = MDTextField(hint_text="CODE BYPASS",password=True,line_color_normal='black', font_size='15sp', pos_hint={'center_x':0.5, 'center_y':0.5},size_hint=(0.3,0.1))
        codebypass.bind(text=self.bypasspro)
        bprefo=Builder.load_string('''
Button:
    text:"[b]Valider[/b]"
    font_size:'18sp'
    pos_hint:{'x':0.7,'center_y':0.5}
    size_hint:(0.25,0.2)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
    

        ''')
        bprefo.bind(on_release=self.suppsession)

        try:
            cadcloss.add_widget(codebypass)
            cadcloss.add_widget(bprefo)
        except:
            pass

        msg=Popup(title="CODE BYPASS",content=cadcloss,background_color='aliceblue',size_hint=(None, None), size=(400,200))
        msg.open()

    def suppsession(self,instance):
        global codebypass

        if codebypass.text=="askyastriangle":

            try:

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("delete from session")
                con.commit()
                self.cursor.close()
                con.close()

                msg=Popup(title="STATUT REQUETE",content=Button(text='Toutes les sessions ont été supprimé \navec succes !!',color='white',background_color='blue'),size_hint=(None, None), size=(300,200))
                msg.open()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur a été capturée veuillez ressayer!!'),size_hint=(None, None), size=(300,200))
                msg.open()

    def ajusterpt(self,instance):

        totgen=0.0

        try:

            for ligtot in tabvente1.row_data:
                totgen+=float(ligtot[5])

            labnetpayer.text=str(math.ceil(totgen))
            labnetpayer.color='blue'

            msg=Popup(title="STATUT REQUETE",content=Button(text='Absolu !!',color='white',background_color='blue'),size_hint=(None, None), size=(400,200))
            msg.open()
        
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='L ajusteur systeme a rencontré un probleme ...veuillez redemarrer le systeme et ressayer plus tard !!'),size_hint=(None, None), size=(400,200))
            msg.open()
    
    

    def excel_to_image(self,excel_file):
            
        try:

            from PIL import Image, ImageDraw, ImageFont

            wb = load_workbook(excel_file)
            ws = wb.active
            max_row = ws.max_row
            max_col = ws.max_column

            capacite=200+(max_row-8)*25

            # Définir la taille de l'image et la police
            img = Image.new('RGB', (315,capacite ), color = (255, 255, 255))
            d = ImageDraw.Draw(img)
            font = ImageFont.load_default()

            # Dessiner les données sur l'image
            for i in range(1, max_row + 1):
                for j in range(1, max_col + 1):
                    cell_value = ws.cell(row=i, column=j).value
                    d.text((47*j, 20*i), str(cell_value), fill=(0, 0, 0), font=font)

            return img
        
        except:
            pass

    def supptext(self,instance,value):

        if instance.text=="Nom du client":
            instance.text=""

    def imprissionpreforma(self,instance):
        global nomcclientprefo,chproff

        cadcloss=Builder.load_string('''
        
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]
    ''')

        nomcclientprefo = TextInput(text="Nom du client", font_size='15sp', pos_hint={'center_x':0.5, 'center_y':0.5},size_hint=(0.5,0.24))
        nomcclientprefo.bind(focus=self.supptext)

        bprefo=Builder.load_string('''
Button:
    text:"[b]Valider[/b]"
    font_size:'15sp'
    pos_hint:{'x':0.8,'center_y':0.5}
    size_hint:(0.2,0.2)
    color:'white'
    markup:True
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')
        bprefo.bind(on_release=self.impreformok)

        labimpr=Label(text='[b]Imprimer[/b]',font_size='13sp',color='black',pos_hint={'x':0.84,'y':0.9},size_hint=(0.1,0.05),markup=True)
        chproff=CheckBox(active=True,pos_hint={'x':0.95,'y':0.9},size_hint=(0.06,0.06)) 

        try:
            cadcloss.add_widget(nomcclientprefo)
            cadcloss.add_widget(bprefo)
            cadcloss.add_widget(labimpr)
            cadcloss.add_widget(chproff)
        except:
            pass

        msg=Popup(title="NOM DU CLIENT",content=cadcloss,background_color='blue',size_hint=(None, None), size=(600,200))
        msg.open()
    
    def proforma(self,instance):
        global trechproforma,sepp,combproforma

        if sepp==8:

            cadcloss=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]
            
''')

            trechproforma = MDTextField(hint_text="Rechecher client",line_color_normal='black', font_size='15sp', pos_hint={'x':0.3, 'center_y':0.5},size_hint=(0.2,0.08))
            combproforma=Spinner(text="Choisir",pos_hint={'x':0.6, 'center_y':0.5},size_hint=(0.35,0.12),background_color="blue", color="white")
            combproforma.bind(on_release=self.rechidproforma)
            combproforma.bind(text=self.affproforcoupon)

            try:
                cadcloss.add_widget(trechproforma)
                cadcloss.add_widget(combproforma)
            except:
                pass

            msg=Popup(title="REGISTRE DE PROFORMAT",content=cadcloss,background_color='blue',size_hint=(None, None), size=(600,200))
            msg.open()

        elif sepp==1:
                
                cadcloss=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]
            
''')

                combproforma=Spinner(text="Choisir Date",pos_hint={'center_x':0.5, 'center_y':0.5},size_hint=(0.3,0.04),background_color="blue", color="white")
                combproforma.bind(on_release=self.rechdateproformaadmin)
                bprefo=Button(text="[b] Vider ?[/b]",font_size='18sp', pos_hint={'x':0.8,'center_y':0.3},size_hint=(0.15,0.04),color='white',markup=True,background_color='blue')
                bprefo.bind(on_release=self.supreformadmin)

                try:
                    cadcloss.add_widget(bprefo)
                    cadcloss.add_widget(combproforma)
                except:
                    pass

                msg=Popup(title="REGISTRE DE PROFORMAT",content=cadcloss,background_color='blue',size_hint=(None, None), size=(600,200))
                msg.open()

    def affproforcoupon(self,instance,value):
        global netpayer

        idprofonew=[]

        try:

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select id_prod,nom,CEILING(pu*taux),qt,CEILING((pu*taux)*qt) from preforma,produit,tauxchange where nom_client ='"+instance.text+"' and matricule=id_prod")
            idprofo=self.cursor.fetchall()
            self.cursor.close()
            con.close()

            numprefo=()
            coupreforma=()
            couponprefo=[]
            couponprefonew=[]

            for ik in range(len(idprofo)):
                numprefo +=(ik+1,)

            for j in range(len(idprofo)):

                coupreforma=(numprefo[j],)+(idprofo[j])

                couponprefo.append(coupreforma)
            
                #for liggn in couponprefo:
                 #   a,b,c,d,e,f=liggn

                  #  liggnew=(a,b,c,int(d),e,int(f))

                #couponprefonew.append(liggnew)

            tabvente1.row_data=couponprefo
            netpayer=0
            labnetpayer.color='black'

            for ligncup in couponprefo:
                
                netpayer+=int(ligncup[5])

            labnetpayer.text=str(netpayer)
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def rechidproforma(self,instance):
        global trechproforma
        idprofo=[]
        instance.values=""
    
        try:

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select distinct nom_client from preforma where nom_client like'%"+trechproforma.text+"%'")
            idprofo=self.cursor.fetchall()
            self.cursor.close()
            con.close()

            for  i in  idprofo:
                instance.values.append(str(i).replace("('","").replace("',)",""))
    
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def rechdateproformaadmin(self,instance):
        global trechproforma

        results=[]
        instance.values=""
    
        try:

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select distinct date from preforma order by date DESC")
            results=self.cursor.fetchall()
            datat=[resulat[0].strftime('%Y-%m-%d %H:%M:%S') for resulat in results]
            self.cursor.close()
            con.close()

            for  i in  datat:
                instance.values.append(str(i))
    
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
    
    def supreformadmin(self,instance):
        global combproforma

        if combproforma.text=="Choisir Date":
            pass
        else:

            try:

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("delete from preforma where date<'"+combproforma.text+"'")
                con.commit()
                self.cursor.close()
                con.close()

                msg=Popup(title="STATUT REQUETE",content=Button(text='Absolu !!'),size_hint=(None, None), size=(400,200))
                msg.open()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
    
    def fonctsuit2(self,instance):
        global suit1,suit2

        if instance.active==True:
            suit1.active=False

    def fonctsuit1(self,instance):
        global suit1,suit2
        
        if instance.active==True:
            suit2.active=False

        
    def valimprission(self,instance):
        global selimprime

        if suit1.active==True:
            if selimprime==1:

                self.impressionfacjournal()

                selimprime=0
        
        elif suit2.active==True:

            if selimprime==1:

                self.impressionprofessionnelle()

                selimprime=0

    def imprissionfact(self,instance):
        global suit1,suit2,msgimpre

        cax=Builder.load_string('''
FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        ''')

        lab1=Label(text="Impression Normale",pos_hint={'x':.15,'center_y':.5},size_hint=(.1,.1),color='black',bold=True)

        cadresuit1=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.35,'center_y':.5}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suit1=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:True
    on_active:app.fonctsuit1(self)
''')

        lab2=Label(text="Impression Professionnelle",pos_hint={'x':.6,'center_y':.5},size_hint=(.1,.1),color='black',bold=True)

        cadresuit2=Builder.load_string('''
FloatLayout:
    size_hint:.05,.05
    pos_hint: {'x':.85,'center_y':.5}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

        suit2=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.fonctsuit2(self)
''')

        btval=Builder.load_string('''
Button: 
    text:"Valider"
    pos_hint:{'x':.65,'y':.1}
    size_hint:.25,.15
    bold:True
    background_color:[0,0,0,0]
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15]
        
        ''')

        btval.bind(on_release=self.valimprission)



        try:
            cadresuit2.add_widget(suit2)
            cadresuit1.add_widget(suit1)
        except:
            pass


        try:
            cax.add_widget(lab1)
            cax.add_widget(lab2)

            cax.add_widget(cadresuit2)
            cax.add_widget(cadresuit1)

            cax.add_widget(btval)

        except:
            pass

        msgimpre=Popup(title="IMPRESSION",content=cax,size_hint=(.5,.3))
        msgimpre.open()
        

            

    def quiteprogramme(self,instance):
        self.stop()

    def tester(self,instance):
        global chexport2,chexport1,separstock,resultsperime,listfini,sepp,listventecombine

        if sepp==3:

            self.exportateurvente("VENTE DES PRODUITS",listventecombine)

        elif sepp==4:

            if hautlab1.text=="[b]ANALYSEUR DE PERFORMANCE[/b]":

                cadcloss=MDFloatLayout()
                bvalexport=Button(text="[b]Valider[/b]", background_color='red',pos_hint={'x':0.6,'y':0.2},size_hint=(0.3,0.05),markup=True,color='white')
                bvalexport.bind(on_release=self.exportannalyseur)
                l1export=Label(text="[b]Situation Normale[/b]",markup=True,color='white',pos_hint={'x':0.2, 'y':0.5},font_size='15sp',size_hint=(0.25,0.07))
                l2export=Label(text="[b]Situation Critique [/b]",markup=True,color='white',pos_hint={'x':0.6, 'y':0.5},font_size='15sp',size_hint=(0.25,0.07))
                
                chexport1=CheckBox(pos_hint={'x':0.47,'y':0.5},size_hint=(0.05,0.05))
                chexport1.bind(active=self.exptype1)

                chexport2=CheckBox(pos_hint={'x':0.87,'y':0.5},size_hint=(0.05,0.05),active=True)
                chexport2.bind(active=self.exptype2)

                try:
                    cadcloss.add_widget(bvalexport)
                    cadcloss.add_widget(l2export)
                    cadcloss.add_widget(l1export)
                    cadcloss.add_widget(chexport1)
                    cadcloss.add_widget(chexport2)
                except:
                    pass

                msg=Popup(title="EXPORT VERS EXCEL",content=cadcloss,background_color='blue',size_hint=(None, None), size=(600,200))
                msg.open()

            elif hautlab1.text=="[b]STOCK EPUISE[/b]":

                self.exportateurstock("PRODUITS EPUISES",listfini)

            elif hautlab1.text=="[b]GESTION DE STOCK [/b]":

                lisproexportt=[]

                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from produit")
                    lisproexportt=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    self.exportateurstock("LISTE DES PRODUITS ",lisproexportt)

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            else:
                if separstock==0:
                    self.exportateurstock("PRODUITS EN VOIE DE PEREMPTION",resultsperime)
     
    def exportannalyseur(self,instance):
        global typeexport,listecritique,listenormale

        if typeexport=="critique":

            self.exportateurstock("PRODUITS EN SITUATION CRITIQUE",listecritique)

        elif typeexport=="normale":

            self.exportateurstock("PRODUITS EN SITUATION NORMALE",listenormale)

    def exportfacture(self,liste):
        tabdonne=liste
        

        wb=Workbook()

        feuille=wb.active

        discourant=os.path.dirname(__file__)

        chfichier=os.path.join(discourant,"facture.xlsx")

        try:
            os.remove(chfichier)
        except:
            pass

        feuille.append([".","MERCIRA",".","PHARMA","."])
        feuille.append(["RCCM","KNM/","RCCM/18","/18-A-01","319"])
        feuille.append([".",".",".","Fac.","ID:"+str(random.randint(0,300))])
        feuille.append(["ID","Nom","PU","Qte","PT"])

        listeprefoknew=[]
                
        for ligg in tabdonne:
            
            a,b,c,d,e=ligg
            k=str(b[:6])+".."
            liggnew=a,k,c,d,e

            listeprefoknew.append(liggnew)
        
        for ligne in listeprefoknew:
            feuille.append(ligne)
        
        feuille.append(["-","-","-","NET",labtot2.text])
        feuille.append(["-","-","-","Trav_ID:",tidconn.text])
        feuille.append(["-----","-----","------","-------","------"])
        feuille.append(["Client(e)",combnomclient.text,"kin,le",str(datetime.now().strftime('%m-%d')),str(datetime.now().strftime('%H:%M:%S'))])

        try:
            wb.save(chfichier) 

            excel_image = self.excel_to_image(chfichier) 
            excel_image.save('preforma.jpeg')

            msg=Popup(title="ETAT CONNEXION",content=Button(text='Impression demarre !!'),background_color='blue',size_hint=(None, None), size=(500,200))
            msg.open()

        except:
            msg=Popup(title="ETAT CONNEXION",content=Button(text='Le Generateur de facture a echoué, il faut verifier les données \nEt réssayer plus tard'),background_color='blue',size_hint=(None, None), size=(500,200))
            msg.open()
        
        try:

            printres=win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL,None,1)
            fills='preforma.jpeg'

            printer_name = win32print.GetDefaultPrinter()

            file_handle=open(fills,'rb')
            print_handle=win32print.OpenPrinter(printer_name)

            job_info=win32print.StartDocPrinter(print_handle,1,(fills,None,"RAW"))

            win32print.StartPagePrinter(print_handle)

            win32print.WritePrinter(print_handle,file_handle.read())
            win32print.EndPagePrinter(print_handle)
            win32print.EndDocPrinter(print_handle)

            win32print.ClosePrinter(print_handle)

            file_handle.close()

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur de l impression'),size_hint=(None, None), size=(400,200))
            msg.open()

    def exportBackUpGeneral(self,listcompte,listdataProduit,listahistogramme,listachat,listcommandefacture,listMotifsignaler,listPresceiption,listPrisecharge,listRgistreFlux): 
    
        etatbackUp=False

        wb=Workbook()
        feuille=wb.active

        discourant=os.path.dirname(__file__)
        partibien=discourant[0:2]
        partibien=partibien+"\\"

        chmc=os.path.join(partibien,"BackUPharma")

        try:
            os.makedirs(chmc)
        except:
            pass

        chfichier1=os.path.join(chmc,"compteBakUp.xlsx")
        chfichier2=os.path.join(chmc,"produitBakUp.xlsx")
        chfichier3=os.path.join(chmc,"historiqueBakUp.xlsx")
        chfichier4=os.path.join(chmc,"achatBakUp.xlsx")
        chfichier5=os.path.join(chmc,"commandeFactureBakUp.xlsx")
        chfichier6=os.path.join(chmc,"motifBakUp.xlsx")
        chfichier7=os.path.join(chmc,"priseChargeFactureBakUp.xlsx")
        chfichier8=os.path.join(chmc,"prescriptionBakUp.xlsx")
        chfichier9=os.path.join(chmc,"fluxCloudBakUp.xlsx")

        try:
            os.remove(chfichier1)
        except:
            pass
        try:
            os.remove(chfichier2)
        except:
            pass
        try:
            os.remove(chfichier3)
        except:
            pass
        try:
            os.remove(chfichier4)
        except:
            pass
        try:
            os.remove(chfichier5)
        except:
            pass
        try:
            os.remove(chfichier6)
        except:
            pass
        try:
            os.remove(chfichier7)
        except:
            pass
        try:
            os.remove(chfichier8)
        except:
            pass
        try:
            os.remove(chfichier9)
        except:
            pass
        
        feuille["A1"]="N1"
        feuille["B1"]="N2"
        feuille["C1"]="N3"
        feuille["D1"]="N4"
        feuille["E1"]="N5"
        feuille["F1"]="N6"
        feuille["G1"]="N7"
        feuille["H1"]="N8"
        
        for ligne in listcompte:

            a,b,c,d,e,f,g,h=ligne

            feuille.append([str(a),str(b),str(c),str(d),str(e),str(f),str(g),str(h)])
            
        try:
            wb.save(chfichier1) 
            etat1=True
        except Exception as e:
            etat1=False
        
        wb=Workbook()
        feuille2=wb.active

        feuille2["A1"]="N1"
        feuille2["B1"]="N2"
        feuille2["C1"]="N3"
        feuille2["D1"]="N4"
        feuille2["E1"]="N5"
        
        for ligne in listdataProduit:

            a,b,c,d,e=ligne

            feuille2.append([str(a),str(b),str(c),str(d),str(e)])
            
        try:
            wb.save(chfichier2) 
            etat2=True
        except Exception as e:
            etat2=False

        wb=Workbook()
        feuille3=wb.active

        feuille3["A1"]="N1"
        feuille3["B1"]="N2"
        feuille3["C1"]="N3"
        feuille3["D1"]="N4"
        feuille3["E1"]="N5"
        feuille3["F1"]="N6"
        feuille3["G1"]="N7"
        feuille3["H1"]="N8"
        
        for ligne in listahistogramme:

            a,b,c,d,e,f,g,h=ligne

            feuille3.append([str(a),str(b),str(c),str(d),str(e),str(f),str(g),str(h)])
            
        try:
            wb.save(chfichier3) 
            etat3=True
        except Exception as e:
            etat3=False

        wb=Workbook()
        feuille4=wb.active
        

        feuille4["A1"]="N1"
        feuille4["B1"]="N2"
        feuille4["C1"]="N3"
        feuille4["D1"]="N4"
        feuille4["E1"]="N5"
        feuille4["F1"]="N6"
        feuille4["G1"]="N7"
        feuille4["H1"]="N8"
        
        for ligne in listachat:

            a,b,c,d,e,f,g,h=ligne

            feuille4.append([str(a),str(b),str(c),str(d),str(e),str(f),str(g),str(h)])
            
        try:
            wb.save(chfichier4) 
            etat4=True
        except Exception as e:
            etat4=False

        wb=Workbook()
        feuille5=wb.active        

        feuille5["A1"]="N1"
        feuille5["B1"]="N2"
        feuille5["C1"]="N3"
        feuille5["D1"]="N4"
        feuille5["E1"]="N5"
        feuille5["F1"]="N6"
        feuille5["G1"]="N7"
        feuille5["H1"]="N8"
        
        for ligne in listcommandefacture:

            a,b,c,d,e,f,g,h=ligne

            feuille5.append([str(a),str(b),str(c),str(d),str(e),str(f),str(g),str(h)])
            
        try:
            wb.save(chfichier5) 
            etat5=True
        except Exception as e:
            etat5=False

        wb=Workbook()
        feuille6=wb.active

        feuille6["A1"]="N1"
        feuille6["B1"]="N2"
        feuille6["C1"]="N3"
        feuille6["D1"]="N4"
        feuille6["E1"]="N5"
        feuille6["F1"]="N6"
        
        
        for ligne in listMotifsignaler:

            a,b,c,d,e,f=ligne

            feuille6.append([str(a),str(b),str(c),str(d),str(e),str(f)])
            
        try:
            wb.save(chfichier6) 
            etat6=True
        except Exception as e:
            etat6=False

        wb=Workbook()
        feuille7=wb.active

        feuille7["A1"]="N1"
        feuille7["B1"]="N2"
        feuille7["C1"]="N3"
        feuille7["D1"]="N4"
        
        
        for ligne in listPresceiption:

            a,b,c,d=ligne

            feuille7.append([str(a),str(b),str(c),str(d)])
            
        try:
            wb.save(chfichier7) 
            etat7=True
        except Exception as e:
            etat7=False

        wb=Workbook()
        feuille8=wb.active

        feuille8["A1"]="N1"
        feuille8["B1"]="N2"
        feuille8["C1"]="N3"
        feuille8["D1"]="N4"
        feuille8["E1"]="N5"
        feuille8["F1"]="N6"
        feuille8["G1"]="N7"
        feuille8["H1"]="N8"
        
        for ligne in listPrisecharge:

            a,b,c,d,e,f,g,h=ligne

            feuille8.append([str(a),str(b),str(c),str(d),str(e),str(f),str(g),str(h)])
            
        try:
            wb.save(chfichier8) 
            etat8=True
        except Exception as e:
            etat8=False

        wb=Workbook()
        feuille9=wb.active

        feuille9["A1"]="N1"
        feuille9["B1"]="N2"
        feuille9["C1"]="N3"
        feuille9["D1"]="N4"
     
        
        for ligne in listRgistreFlux:

            a,b,c,d=ligne

            feuille9.append([str(a),str(b),str(c),str(d)])
            
        try:
            wb.save(chfichier9) 
            etat9=True
        except Exception as e:
            etat9=False

        return etatbackUp


    def exportBackUp(self,listes):

        etatbackUp=False

        wb=Workbook()

        feuille=wb.active

        discourant=os.path.dirname(__file__)
        partibien=discourant[0:2]
        partibien=partibien+"\\"

        chmc=os.path.join(partibien,"BackUPharma")

        try:
            os.makedirs(chmc)
        except:
            pass

        chfichier=os.path.join(chmc,"produitBakUp.xlsx")

        try:
            os.remove(chfichier)
        except:
            pass
        
        feuille["A1"]="ID"
        feuille["B1"]="NOM"
        feuille["C1"]="PU"
        feuille["D1"]="STOCK"
        feuille["E1"]="EXPIRATION"
        
        for ligne in listes:

            a,b,c,d,e=ligne


            feuille.append([str(a),str(b),str(c),str(d),str(e)])
            
        try:

            wb.save(chfichier) 

            etatbackUp=True

        except Exception as e:

            print(e)
            etatbackUp=False
        
        return etatbackUp

    def exportateuranalyse(self,motif,listproderreur,listsomerreur,listdiffvrai,listdiff):

        refop=motif

        tab1=listproderreur
        tab2=listsomerreur
        tab3=listdiffvrai
        tab4=listdiff

        wb=Workbook()

        feuille=wb.active

        discourant=os.path.dirname(__file__)
        partibien=discourant[0:2]
        partibien=partibien+"\\"

        chmc=os.path.join(partibien,"RAPPORT_PHARMA")
        try:
            os.makedirs(chmc)
        except:
            pass

        chfichier=os.path.join(chmc,"rapport.xlsx")

        try:
            os.remove(chfichier)
        except:
            pass
        
        feuille["B1"]=" MOTIF_REF : "
        feuille["C1"]=refop
        feuille["H1"]="Kin, le "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        feuille.append(["ID PRODUIT","VRAIE QTE VENDUE","RESTE DE QTE CORRECTE","RESTE QTE ERRONNEE"])

        igen=1
    
        for igen in range(len(tab1)):

            feuille.append([tab1[igen],tab2[igen],tab3[igen],tab4[igen]])
            
        try:
            wb.save(chfichier) 

            msg=Popup(title="ETAT CONNEXION",content=Button(text='Absolu !!'),background_color='blue',size_hint=(None, None), size=(500,200))
            msg.open()

        except:
            msg=Popup(title="ETAT CONNEXION",content=Button(text='Le Generateur de rapport a echoué, il faut verifier\nsi ce fichier ou ce dossier n est pas occupé par un autre service'),background_color='blue',size_hint=(None, None), size=(500,200))
            msg.open()
    
    def exportateurvente(self,motif,listinfo):

        refop=motif
        tabdonne=listinfo

        wb=Workbook()

        feuille=wb.active

        discourant=os.path.dirname(__file__)
        partibien=discourant[0:2]

        partibien=partibien+"\\"
        
        chmc=os.path.join(partibien,"RAPPORT_PHARMA")
        try:
            os.makedirs(chmc)
        except:
            pass

        chfichier=os.path.join(chmc,"rapport.xlsx")

        try:
            os.remove(chfichier)
        except:
            pass
        
        feuille["B1"]=" MOTIF_REF : "
        feuille["C1"]=refop
        feuille["H1"]="Kin, le "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        tete=["ID PRODUIT","P.U","Qte"," P.T "," NOM DU CLIENT ","DATE","DATE ET HEURE","ID TRAVAILLEUR"]

        feuille.append(tete)
        
        for ligne in tabdonne:
            feuille.append(ligne)

        try:
            wb.save(chfichier) 

            msg=Popup(title="ETAT CONNEXION",content=Button(text='Absolu !!'),background_color='blue',size_hint=(None, None), size=(500,200))
            msg.open()

        except:
            msg=Popup(title="ETAT CONNEXION",content=Button(text='Le Generateur de rapport a echoué, il faut verifier\nsi ce fichier ou ce dossier n est pas occupé par un autre service'),background_color='blue',size_hint=(None, None), size=(500,200))
            msg.open()

    def exportateurstock(self,motif,listinfo):
        refop=motif
        tabdonne=listinfo

        if refop=="PRODUITS EN SITUATION NORMALE" or refop=="PRODUITS EN SITUATION CRITIQUE":
            
            wb=Workbook()

            feuille=wb.active

            discourant=os.path.dirname(__file__)
            partibien=discourant[0:2]
            
            partibien=partibien+"\\"

            chmc=os.path.join(partibien,"RAPPORT_PHARMA")
            try:
                os.makedirs(chmc)
            except:
                pass

            chfichier=os.path.join(chmc,"rapport.xlsx")

            try:
                os.remove(chfichier)
            except:
                pass
            
            feuille["B1"]=" MOTIF_REF : "
            feuille["C1"]=refop
            feuille["H1"]="Kin, le "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            tete=["ID PRODUIT","NOM","CATEGORIE"," P.U "," DATE ","STOCK INITIAL","STOCK COURANT"]

            feuille.append(tete)
            
            for ligne in tabdonne:
                feuille.append(ligne)

            try:
                wb.save(chfichier) 

                msg=Popup(title="ETAT CONNEXION",content=Button(text='Absolu !!'),background_color='blue',size_hint=(None, None), size=(500,200))
                msg.open()

            except:
                msg=Popup(title="ETAT CONNEXION",content=Button(text='Le Generateur de rapport a echoué, il faut verifier\nsi ce fichier ou ce dossier n est pas occupé par un autre service'),background_color='blue',size_hint=(None, None), size=(500,200))
                msg.open()

        else:
    
            wb=Workbook()

            feuille=wb.active

            discourant=os.path.dirname(__file__)
            partibien=discourant[0:2]
            
            partibien=partibien+"\\"

            chmc=os.path.join(partibien,"RAPPORT_PHARMA")
            try:
                os.makedirs(chmc)
            except:
                pass

            chfichier=os.path.join(chmc,"rapport.xlsx")

            try:
                os.remove(chfichier)
            except:
                pass
            
            feuille["D1"]=" MOTIF_REF : "
            feuille["E1"]=refop
            feuille["M1"]="Kin, le "+ datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            tete=["ID PRODUIT","NOM","CATEGORIE","MALADIE INSUPORTABLE","MALADIE TRAITEE","POSOLOGIE","AGE","PU","STOCK INITIAL","DATES","STOCK COURANT"]

            feuille.append(tete)
            
            for ligne in tabdonne:
                feuille.append(ligne)

            try:
                wb.save(chfichier) 

                msg=Popup(title="ETAT CONNEXION",content=Button(text='Absolu !!'),background_color='blue',size_hint=(None, None), size=(500,200))
                msg.open()

            except:
                msg=Popup(title="ETAT CONNEXION",content=Button(text='Le Generateur de rapport a echoué, il faut verifier\nsi ce fichier ou ce dossier n est pas occupé par un autre service'),background_color='blue',size_hint=(None, None), size=(500,200))
                msg.open()
                    
    def exptype1(self,instance,value):
        global typeexport,chexport2

        if instance.active==True:
            typeexport="normale"
            chexport2.active=False
    
    def exptype2(self,instance,value):
        global typeexport,chexport1

        if instance.active==True:
            typeexport="critique"
            chexport1.active=False

    def misajouradmin(self,instance):
        global lbmsg,check1mod,check2mod,listidcommute,dfadmin,modcommutation,proepuisedirrect,listproravitail,listfini

        if modcommutation==0:

            lbmsg.text="Chargement encours..."

            try:
                self.cconnexion()
                query="select * from produit"
                dfadmin=pd.read_sql(query,con)
                con.close()
                lbmsg.text="Chargement reussi : "+str(len(dfadmin))

            except:
                msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de chargement '),size_hint=(None, None), size=(400,200))
                msg.open()
                lbmsg.text="Error"

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75")
                results=self.cursor.fetchall()
                listfini=listproravitail=results
                tablstockfini.row_data=results
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:
            pass
    
    def commutationadmin(self,instance):
        global lbmsg,check2mod,check1mod
    
        cadclos=MDFloatLayout()

        lbm=Label(text="Cette fonctionnalité 'Deconnecté' favorise l optimisation de la machine,Il est surtout\nrecommandée pour des machines non puissantes car ca charge toutes les informations \nutiles afin d etre rapide NB: sa mise à jour est obligatoire apres un temps",font_size='14sp',pos_hint={'center_x':0.5,'center_y':0.7},color='white',size_hint=(0.5,0.15))
        bb1m=Button(text="[b]Mise à jour[/b]", background_color='red',pos_hint={'x':0.73,'y':0.2},size_hint=(0.2,0.05),markup=True,color='white')
        bb1m.bind(on_release=self.misajouradmin)

        modcon=Label(text="[b]Mode connecté[/b]",markup=True,color='white',pos_hint={'x':0.2, 'y':0.4},font_size='15sp',size_hint=(0.25,0.07))
        moddecon=Label(text="[b]Mode deconnecté[/b]",markup=True,color='white',pos_hint={'x':0.6, 'y':0.4},font_size='15sp',size_hint=(0.25,0.07))
        
        check1mod=CheckBox(pos_hint={'x':0.47,'y':0.4},size_hint=(0.05,0.05))
        check1mod.bind(active=self.modcheck1)

        check2mod=CheckBox(pos_hint={'x':0.87,'y':0.4},size_hint=(0.05,0.05),active=True)
        check2mod.bind(active=self.modcheck2)

        lbmsg=Label(text="",color='white',pos_hint={'center_x':0.5, 'y':0.1},font_size='10sp',size_hint=(0.25,0.07))

        try:
            cadclos.add_widget(lbmsg)
            cadclos.add_widget(check2mod)
            cadclos.add_widget(check1mod)
            cadclos.add_widget(lbm)
            cadclos.add_widget(bb1m)
            cadclos.add_widget(modcon)
            cadclos.add_widget(moddecon)
        except:
            pass

        msg=Popup(title="MODE DE COMMUTATION",content=cadclos,background_color='blue',size_hint=(None, None), size=(700,300))
        msg.open()

    def combinemotif(self,instance,value):

        tablmotiftravil.row_data=[]
        labtotmotif.text="TOTAL :  "

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from motif_signaler where id_trav='"+combidmotif.text+"' and date_motif='"+combdatmotif.text+"' order by date_timemotif DESC")
            results=self.cursor.fetchall()
            tablmotiftravil.row_data=results
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select SUM(montant) from motif_signaler where id_trav='"+combidmotif.text+"' and date_motif='"+combdatmotif.text+"'")
            resultstotmotif=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if resultstotmotif:
                labtotmotif.text="TOTAL :  " + str(resultstotmotif[0])

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Sommation NOT FOUND !!'),size_hint=(None, None), size=(400,200))
            msg.open()
    
    def affmotifdate(self,instance,value):

        tablmotiftravil.row_data=[]

        if instance.text=="Toutes":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from motif_signaler order by date_timemotif DESC")
                results=self.cursor.fetchall()
                tablmotiftravil.row_data=results
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(montant) from motif_signaler")
                resultstotmotif=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if resultstotmotif:
                    labtotmotif.text="TOTAL :  " + str(resultstotmotif[0])

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Sommation NOT FOUND !!'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from motif_signaler where date_motif='"+instance.text+"'order by date_timemotif DESC")
                results=self.cursor.fetchall()
                tablmotiftravil.row_data=results
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(montant) from motif_signaler where date_motif='"+instance.text+"'")
                resultstotmotif=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if resultstotmotif:
                    labtotmotif.text="TOTAL :  " + str(resultstotmotif[0])

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Sommation NOT FOUND !!'),size_hint=(None, None), size=(400,200))
                msg.open()

    def affmotifidtrav(self,instance,value):

        tablmotiftravil.row_data=[]

        if instance.text=="Tous":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from motif_signaler order by date_timemotif DESC")
                results=self.cursor.fetchall()
                tablmotiftravil.row_data=results
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(montant) from motif_signaler")
                resultstotmotif=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if resultstotmotif:
                    labtotmotif.text="TOTAL :  " + str(resultstotmotif[0])

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Sommation NOT FOUND !!'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from motif_signaler where id_trav='"+instance.text+"'order by date_timemotif DESC")
                results=self.cursor.fetchall()
                tablmotiftravil.row_data=results
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(montant) from motif_signaler where id_trav='"+instance.text+"'")
                resultstotmotif=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if resultstotmotif:
                    labtotmotif.text="TOTAL :  " + str(resultstotmotif[0])

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Sommation NOT FOUND !!'),size_hint=(None, None), size=(400,200))
                msg.open()


    def rechidmotif(self,instance):

        instance.values=("")
        j="Tous"
        instance.values.append(j)
        self.cconnexion()
        try:
            self.cursor=con.cursor()
            self.cursor.execute("select distinct id_trav from motif_signaler")
            results=self.cursor.fetchall()
            self.cursor.close()
            con.close()
            for  i in  results:
                instance.values.append(str(i).replace("('","").replace("',)",""))
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
            msg.open()
        

    def rechdatemotif(self, instance):

        instance.values=("")
        j="Toutes"
        instance.values.append(j)
        self.cconnexion()
        try:
            self.cursor=con.cursor()
            self.cursor.execute("select distinct date_motif from motif_signaler")
            results=self.cursor.fetchall()
            datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
            self.cursor.close()
            con.close()
            for  i in  datat:
                instance.values.append(str(i))
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
            msg.open()


    def affmotif(self,instance,current_row):

        identid=""

        try:
            identid=str(current_row[2])
            self.cconnexion()
            cursor=con.cursor()
            query="select nom,postnom,prenom,sexe,id,pwd from compte where id='"+identid+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()
            if results:
                t2.text=str(results[0])
                t3.text=str(results[1])
                t4.text=str(results[2])
                t5.text=str(results[3])
                t1.text=str(results[4])
                t6.text=str(results[5])
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def gestionuserrs(self,instance):

        tabl.row_data=[]

        labmod.text="[b]Gestion des Travailleurs[b]"

        configserveur.pos_hint={'x':0.9,'y':0.8}
        configserveur.size_hint=(0.07,0.1)

        try:
            cadre.add_widget(gesttrav)
        except:
            pass

        try:
            cadre.add_widget(gestmotif)
        except:
            pass
        
        try:
            cadre.add_widget(tabl)
        except:
            pass
        try:
            cadre.add_widget(bgestionuser)
        except:
            pass

        try:
            cadre.add_widget(bgestionuserchanger)
        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from compte order by dates DESC")
            results=self.cursor.fetchall()
            tabl.row_data=results
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            cadre.remove_widget(tablmotiftravil)
        except:
            pass

        try:
            cadre.remove_widget(labdatmotif)
        except:
            pass
        try:
            cadre.remove_widget(combdatmotif)
        except:
            pass
        try:
            cadre.remove_widget(labidmotif)
        except:
            pass
        try:
            cadre.remove_widget(combidmotif)
        except:
            pass
        try:
            cadre.remove_widget(tabtotmotif)
        except:
            pass
        try:
            tabtotmotif.remove_widget(labtotmotif)
        except:
            pass

        try:
            cadre.remove_widget(labcombinmotif)
        except:
            pass
        try:
            cadre.remove_widget(checkmotif)
        except:
            pass
    
        
    def gestionmotif(self,instance):
        tablmotiftravil.row_data=[]

        labmod.text="[b]Gestion des Motifs Travailleurs[b]"

        try:
            cadre.add_widget(gesttrav)
        except:
            pass
        
        try:
            cadre.add_widget(gestmotif)
        except:
            pass

        try:
            cadre.add_widget(tablmotiftravil)
        except:
            pass

        
        try:
            cadre.add_widget(labdatmotif)
        except:
            pass
        try:
            cadre.add_widget(combdatmotif)
        except:
            pass
        try:
            cadre.add_widget(labidmotif)
        except:
            pass
        try:
            cadre.add_widget(combidmotif)
        except:
            pass

        try:
            cadre.add_widget(tabtotmotif)
        except:
            pass
        try:
            tabtotmotif.add_widget(labtotmotif)
        except:
            pass

        try:
            cadre.add_widget(labcombinmotif)
        except:
            pass
        try:
            cadre.add_widget(checkmotif)
        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from motif_signaler order by date_timemotif DESC")
            results=self.cursor.fetchall()
            tablmotiftravil.row_data=results
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            cadre.remove_widget(tabl)
        except:
            pass

        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        try:
            cadre.remove_widget(bgestionuserchanger)
        except:
            pass


    def checkmotif(self,instance,value):
        global combsigale

        if instance.text =="Autres à preciser":
            try:
                cadclos.remove_widget(combsigale)
            except:
                pass

            try:
                cadclos.add_widget(textdetailmotif)
            except:
                pass

            try:
                cadclos.remove_widget(ptmotif)
            except:
                pass

            try:
                cadclos.remove_widget(idprodmotif)
            except:
                pass
 
        elif instance.text=="Retournement produit":
            try:
                cadclos.add_widget(combsigale)
            except:
                pass

            try:
                cadclos.add_widget(ptmotif)
            except:
                pass

            try:
                cadclos.add_widget(idprodmotif)
            except:
                pass
        
        elif instance.text=="Sortie d argent":
            try:
                cadclos.remove_widget(combsigale)
            except:
                pass

            try:
                cadclos.add_widget(ptmotif)
            except:
                pass

            try:
                cadclos.remove_widget(idprodmotif)
            except:
                pass
        elif instance.text=="Rupture de stock":
            try:
                cadclos.add_widget(combsigale)
            except:
                pass

            try:
                cadclos.remove_widget(ptmotif)
            except:
                pass

            try:
                cadclos.add_widget(idprodmotif)
            except:
                pass

    
    def signeprobleme(self,instance):
        global cadclos,textdetailmotif,idprodmotif,ptmotif,bnmotifs,combmotif,msgmotif, combsigale

        cadclos=MDFloatLayout()
        
        tabclos=MDDataTable(column_data=[], row_data=[],size_hint=(0.6,0.1),pos_hint={'x':0.2,'y':0.85})

        labchek=Label(text="[b]SIGNALER UN PROBLEME[/b]",markup=True,color='red',pos_hint={'center_x':0.5, 'center_y':0.5},font_size='20sp',size_hint=(0.15,0.1))                  

        lb=Label(text="[b]Motif[/b]",markup=True,font_size='15sp',pos_hint={'x':0.3,'y':0.72},color='white',size_hint=(0.1,0.08))
        
        combmotif=Spinner(text="[b]Choisir[/b]",markup=True,pos_hint={'x':0.6, 'y':0.72},size_hint=(0.35,0.04),background_color="red", color="white")
        combmotif.bind(on_release=self.rechmotif)
        combmotif.bind(text=self.checkmotif)

        textdetailmotif=TextInput(text="Le detail du motif stp !!",size_hint=(0.9,0.3),pos_hint={'center_x':0.5, 'y':0.3},font_size='15sp')
        textdetailmotif.bind(focus=self.resetdetail)

        idprodmotif=MDTextField(hint_text="NOM PRODUIT",line_color_normal='white', font_size='15sp', size_hint=(0.3,0.15),pos_hint={'x':0.15,'y':0.05})
        
        ptmotif=MDTextField(hint_text="MONTANT",line_color_normal='white', font_size='15sp', size_hint=(0.2,0.15),pos_hint={'x':0.5,'y':0.05})

        bnmotifs=Button(text="[b]Soumettre[/b]", markup=True, font_size='15sp',background_color="red",color='white',size_hint=(0.15,0.08),pos_hint={'x':0.8,'y':0.08})
        bnmotifs.bind(on_release=self.soumettre)

        combsigale=Spinner(text="Choisir",font_size='11sp',pos_hint={'x':0.15, 'y':0},size_hint=(0.3,0.1),background_color="seagreen", color="white")
        combsigale.bind(on_release=self.rechsignalproblem)
        combsigale.bind(text=self.televersersignal)
    
        try:
            tabclos.add_widget(labchek)
            cadclos.add_widget(tabclos)
            cadclos.add_widget(lb)

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,20))
            msg.open()
        
        try:
            cadclos.add_widget(bnmotifs)
        except:
            pass

        try:
            cadclos.add_widget(combmotif)
        except:
            pass
        try:
            cadclos.add_widget(textdetailmotif)
        except:
            pass

        msgmotif=Popup(title="CAHIER D'INFORMATION",background_color='blue',content=cadclos,size_hint=(None, None), size=(600,300))
        msgmotif.open()
    
    def televersersignal(self,instance,value):
        global idprodmotif
        
        idprodmotif.text=instance.text
    
    def rechsignalproblem(self,instance):
        global idprodmotif

        if idprodmotif.text=="":
            pass
        else:
            instance.values=""
            
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select nom from produit where nom LIKE'%"+idprodmotif.text+"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()

    def soumettre(self,instance):
        global combmotif,msgmotif,idprodmotif,ptmotif

        detailfin=""

        if instance.text=="[b]Terminez[/b]":
            msgmotif.dismiss()
        else:
            if textdetailmotif.text=="Le detail du motif stp !!" or textdetailmotif.text=="":
                pass
            else:

                detailfin= textdetailmotif.text +" Réf_Produit: "+idprodmotif.text

                if combmotif.text =="Autres à preciser":
                    try:

                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                        cursor.execute(query,(combmotif.text,textdetailmotif.text,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),0))
                        con.commit()
                        self.cursor.close()
                        con.close()

                        if query:

                            instance.text="[b]Terminez[/b]"

                            idprodmotif.text=""
                            ptmotif.text=""
                            textdetailmotif.text=""

                    except:
                        instance.text="[b]Error[/b]"

                elif combmotif.text=="Sortie d argent":

                    try:
                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                        cursor.execute(query,(combmotif.text,textdetailmotif.text,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),int(ptmotif.text)))
                        con.commit()
                        self.cursor.close()
                        con.close()

                        if query:

                            instance.text="[b]Terminez[/b]"
                            idprodmotif.text=""
                            ptmotif.text=""
                            textdetailmotif.text=""

                    except:
                        instance.text="[b]Error[/b]"

                else:

                    idmotifin=None

                    self.cconnexion()
                    cursor=con.cursor()
                    query="select nom from produit where nom='"+idprodmotif.text+"'"
                    cursor.execute(query)
                    resultsmotif=cursor.fetchone()
                    self.cursor.close()
                    con.close()
                    if resultsmotif:
                        idmotifin=resultsmotif[0]

                        if combmotif.text=="Retournement produit":

                            try:
                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                                cursor.execute(query,(combmotif.text,detailfin,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),int(ptmotif.text)))
                                con.commit()
                                self.cursor.close()
                                con.close()

                                if query:

                                    instance.text="[b]Terminez[/b]"
                                    idprodmotif.text=""
                                    ptmotif.text=""
                                    textdetailmotif.text=""

                            except:
                                instance.text="[b]Error[/b]"

                        elif combmotif.text=="Rupture de stock":
                            try:
                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                                cursor.execute(query,(combmotif.text,detailfin,tidconn.text,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),(0)))
                                con.commit()
                                self.cursor.close()
                                con.close()

                                if query:

                                    instance.text="[b]Terminez[/b]"
                                    idprodmotif.text=""
                                    ptmotif.text=""
                                    textdetailmotif.text=""

                            except:
                                instance.text="[b]Error[/b]"

                    else:
                        idprodmotif.line_color_normal='red'
                        idprodmotif.focus=True

    def effprodmot(self,instance,value):
        if instance.text=="ID Produit":
            instance.text=""
    def effptmotif(self,instance,value):

        if instance.text=="Montant concerné":
            instance.text=""

    def resetdetail(self,instance,value):
        if instance.text=="Le detail du motif stp !!":
            instance.text=""
    
            
    def rechmotif(self,instance):
        global combmotif

        combmotif.values=''

        combmotif.values.append("Rupture de stock")
        combmotif.values.append("Retournement produit")
        combmotif.values.append("Sortie d argent")
        combmotif.values.append("Autres à preciser")
    
    def contactprogrammeur(self,instance):
        
        cadclos=MDFloatLayout()

        lb=Label(text="[b]Informations de contact rapide du programmeur : \nWatsapp/Tel : 0970494397\nTel : 0823382732\nGmail : askyas2001@gmail.com[/b]",markup=True,font_size='20sp',pos_hint={'center_x':0.5,'center_y':0.5},color='white',size_hint=(0.5,0.15))
        
        tabclos=MDDataTable(column_data=[], row_data=[],size_hint=(0.6,0.1),pos_hint={'x':0.2,'y':0.8})

        labchek=Label(text="[b]CONTACT DU PROGRAMMEUR[/b]",markup=True,color='red',pos_hint={'center_x':0.5, 'center_y':0.5},font_size='20sp',size_hint=(0.15,0.1))                  
        
        bnmotifs=Button(size_hint=(0.19,0.6),pos_hint={'x':0.8,'y':0.},background_normal="ma photo.jpg")
        
        try:
            cadclos.add_widget(bnmotifs)
        except:
            pass

        try:
            tabclos.add_widget(labchek)
            cadclos.add_widget(tabclos)
            cadclos.add_widget(lb)
        
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,20))
            msg.open()

        msg=Popup(title="INFO FOR ENGINNER PROGRAMMING",background_color='blue',content=cadclos,size_hint=(None, None), size=(600,300))
        msg.open()
    
    def affdonnravitail(self,instance,value):
        global idprodrav

        tb1.text=""
        tb2.text=""
        tb3.text=""
        tb4.text=""

        self.cconnexion()

        try:
            
            cursor=con.cursor()
            query="select matricule,nom,pu,stock,stock_p from produit where nom='"+instance.text+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()
            if results:
                idprodrav=str(results[0])
                tb1.text=str(results[1])
                tb2.text=str(results[2])
                tb4.text=str(results[3])
                tb3.text=str(results[4])

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    
    def rechidproravitail(self,instance):

        instance.text="Choisir"

        instance.values=("")

        if trecravitail.text=="":
            pass
        else:
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select nom from produit where nom LIKE'%"+trecravitail.text+"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()


    def chargeinfomod(self,instance,value):
        global tauxjour

        t1.text=""
        t2.text=""
        t3.text=""
        t4.text=""
        t5.text=""
        t6.text=""
        t7.text=""
        t8.text=""
        t9.text=""
        t10.text=""

        try:

            self.cconnexion()
            cursor=con.cursor()
            query="select * from produit where nom='"+instance.text+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                t1.text=results[0]
                t2.text=results[1]
                t3.text=results[2]
                t4.text=results[3]
                t5.text=results[4]
                t6.text=results[5]
                t7.text=results[6]
                t8.text=str(results[7])#* tauxjour
                t9.text=str(results[8])
                t10.text=str(results[9])

                try:
                    cadre.add_widget(photoproduit) 
                except:
                    pass

                try:
                    discourant=os.path.dirname(__file__)
                    disprod=os.path.join(discourant,"ftx",t1.text)

                    photoproduit.source= disprod + ".jpg"
                    
                except:
                    pass

            t10.disabled=True  
            t9.disabled=True  
            t1.disabled=True
            t1.helper_text=""
            t10.helper_text=""
            t9.helper_text=""

            
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la lecture de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def rechlikeproduimodif(self,instance):
        instance.text="Choisir"
        try:
            instance.values=("")
        except:
            pass

        if trech.text=="":
            pass
        else:
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select nom from produit where nom LIKE'%"+trech.text+"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()

        
    def clotureok(self,instance):

        global msgclos,combselid,betat

        listidprodday=[]
        betat.background_color='gray'
        
        try:
        
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select distinct ID_Produit from achat")
            listidprodday=self.cursor.fetchall()
            self.cursor.close()
            con.close()

            jk=0
            i=0

            listqtnew=[]
            listotnew=[]

            for jk in range(len(listidprodday)):

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+ str(listidprodday[jk]).replace("('","").replace("',)","")+"' and id_travailleur='"+ combselid.text +"'")
                resuday=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                idpr=str(listidprodday[jk]).replace("('","").replace("',)","")
                
                if resuday:
                    listqtnew.append(resuday[0])
                    listotnew.append(resuday[1])

                    qtday=listqtnew[jk]
                    totday=listotnew[jk]

                    try: 
                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into historique(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) select ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat where ID_Produit='"+ str(listidprodday[jk]).replace("('","").replace("',)","")+"' and id_travailleur='"+ combselid.text +"' and Nom_client <> 'global'"
                        cursor.execute(query)

                        query1="delete from achat where ID_Produit='"+ str(listidprodday[jk]).replace("('","").replace("',)","")+"' and id_travailleur='"+ combselid.text +"' and Nom_client <> 'global'"
                        cursor.execute(query1)

                        con.commit()
                        self.cursor.close()
                        con.close()

                    except:
                        pass

                    identifqt=None
                    resverif=None

                    dtanew=datetime.now().strftime('%Y-%m-%d')

                    if query:

                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select Nom_client,Dates from achat where ID_Produit='"+ str(listidprodday[jk]).replace("('","").replace("',)","")+"' and id_travailleur='"+ combselid.text +"'")
                        resverif=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if resverif:
                            nomclnew=resverif[0]
                            datnew=resverif[1]

                            if nomclnew=='global' and datnew == datetime.strptime(dtanew,'%Y-%m-%d').date():
                                
                                pass
                                
                            elif nomclnew=='global' and datnew < datetime.strptime(dtanew,'%Y-%m-%d').date():

                                self.cconnexion()
                                cursor=con.cursor()
                                query="update achat set Qte=%s,PT=%s,Dates=%s,Dats_id=%s where ID_Produit=%s and id_travailleur=%s"
                                cursor.execute(query,(qtday,totday,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),str(listidprodday[jk]).replace("('","").replace("',)",""),combselid.text ))
                                con.commit()
                                self.cursor.close()
                                con.close()

                                betat.background_color='blue'
                                
                            else:
                                pass    

                        else:
                            
                            try:
                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idpr,0,qtday,totday,"global",datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),combselid.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                self.cursor.close()
                                con.close()

                                betat.background_color='blue'

                            except:
                                pass
        
        except:

            betat.background_color='red'                        
                        
    def chargeidtrav(self,instance):
        global betat,bckeck,bcorr

        instance.values=''
        betat.background_color='gray'
        bckeck.background_color='gray'
        bcorr.background_color='gray'

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select distinct id_travailleur from achat")
            listidtravday=self.cursor.fetchall()
            self.cursor.close()
            con.close()

            for i in listidtravday:
                instance.values.append(str(i).replace("('","").replace("',)",""))


        except:

            msg=Popup(title="STATUT REQUETE",content=Button(text=' Erreur '),size_hint=(None, None), size=(400,200))
            msg.open()

    def modcheck1(self,instance,value):
        global modcommutation,check2mod,modcommutationadmin

        check2mod.active=False

        if instance.active==True:

            modcommutation=1
            modcommutationadmin=1

        
    def modcheck2(self,instance,value):
        global modcommutation,check1mod,modcommutationadmin

        check1mod.active=False

        if instance.active==True:

            modcommutation=0
            modcommutationadmin=0
        
    def misajour(self,instance):
        global lbmsg,check1mod,check2mod,listidcommute,df

        if check2mod.active==True:

            lbmsg.text="Chargement encours..."

            try:
                self.cconnexion()
                query="select nom from produit"
                df=pd.read_sql(query,con)
                con.close()
                lbmsg.text="Chargement reussi : "+str(len(df))

            except:
                msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de chargement '),size_hint=(None, None), size=(400,200))
                msg.open()
                lbmsg.text="Error"


        else:
            pass
    def corrigererror(self,instance):
        global listiderrorqt,bckeck,bcorr

        bckeck.background_color='gray'
        bcorr.background_color='gray'

        qtprovrai=0
        qtachnew=0

        kic=0

        try:

            for kic in range(len(listiderrorqt)):

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(Qte) from achat where ID_Produit='"+ listiderrorqt[kic] +"'")
                qtachatss=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if qtachatss:
                    qtachnew=qtachatss[0]
                
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select stock-stock_p from produit where matricule='"+ listiderrorqt[kic] +"'")
                    listqtvenduuss=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if listqtvenduuss:
                        qtprovrai=listqtvenduuss[0]

                        if qtprovrai==qtachnew:
                            pass
                        else:
                            if qtprovrai>qtachnew:
                                qtmarge=qtprovrai-qtachnew
                            else:
                                qtmarge=qtprovrai-qtachnew

                            self.cconnexion()
                            self.cursor=con.cursor()
                            self.cursor.execute("insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur)values(%s,%s,%s,%s,%s,%s,%s,%s)",(listiderrorqt[kic],0,qtmarge,0,'global',datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'marge'))                       
                            con.commit()
                            self.cursor.close()
                            con.close()

                            instance.background_color='blue'

        except:
            instance.background_color='red'

    def checkingerror(self,instance):
        global listiderrorqt,bckeck,bcorr

        listidprodcheck=[]
        listiderrorqt=[]
        bckeck.background_color='gray'
        bcorr.background_color='gray'

        it=0
        qtcorrectprod=0
        qtcorrectachats=0
        
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select distinct ID_Produit from achat")
            listidprodcheck=self.cursor.fetchall()
            self.cursor.close()
            con.close()

            for it in range(len(listidprodcheck)):

                idprods=str(listidprodcheck[it]).replace("',)","").replace("('","")
                
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(Qte) from achat where ID_Produit='"+ idprods +"'")
                qtachats=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if qtachats:
                    qtcorrectachats=qtachats[0]
                
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select stock-stock_p from produit where matricule='"+ str(listidprodcheck[it]).replace("',)","").replace("('","") +"'")
                listqtvenduus=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if listqtvenduus:
                    qtcorrectprod=listqtvenduus[0]
                
                    if qtcorrectachats==qtcorrectprod:
                        pass
                    else:
                        #print("qt vente ",qtcorrectprod, " qt poroduit : ",qtcorrectachats)
                        listiderrorqt.append(idprods)

            if len(listiderrorqt)>0:
                bckeck.background_color='red'
                
            else:
                bckeck.background_color='blue'

        except:
            pass
            
  
    def cloturejourne(self,instance):

        global msgclos,combselid,betat,sepp,check1mod,check2mod,lbmsg,bckeck,bcorr

        if sepp==1:

            heure=datetime.now().strftime('%H:%M:%S')

            if heure > '18:00:00':

                cadclos=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                lb=Label(text="Veuillez choisir un travailleur puis cloturez ainsi de suite ! ! \nAvant de faire cette operation il faut redemarrer la machine\net verifier si aucune autre fenetre n est ouverte pour eviter les erreurs",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.8},color='black',size_hint=(0.9,0.15))
                
                bb1=Builder.load_string('''

Button:
    text:"[b]OK[/b]"
    background_color:[1,0,0,1]
    pos_hint:{'x':0.85,'y':0.4}
    size_hint:(0.15,0.1)
    markup:True
    color:'white'
                      
''')
                
                bb1.bind(on_release=self.clotureok)

                betat=Button(text="[b]ETAT[/b]" ,background_color='gray',pos_hint={'x':0.9,'y':0.85},size_hint=(0.1,0.14),markup=True,color='white')

                labselid=Label(text="[b]Travailleur[/b]",markup=True,color='black',pos_hint={'x':0.2, 'y':0.5},font_size='20sp',size_hint=(0.15,0.07))
                combselid=Spinner(text="Choisir",pos_hint={'x':0.5, 'y':0.5},size_hint=(0.25,0.11),background_color="blue", color="white")
                combselid.bind(on_release=self.chargeidtrav)

                tabclos=MDDataTable(column_data=[], row_data=[],size_hint=(0.6,0.1),pos_hint={'center_x':0.5,'center_y':0.3})

                labchek=Label(text="[b]CHECKING DATA[/b]",markup=True,color='black',pos_hint={'center_x':0.5, 'center_y':0.5},font_size='20sp',size_hint=(0.15,0.1))

                bckeck=Button(text="[b]Checker[/b]", background_color='gray',pos_hint={'x':0.2,'y':0.01},size_hint=(0.2,0.14),font_size='20sp',markup=True,color='white')
                bckeck.bind(on_release=self.checkingerror)

                bcorr=Button(text="[b]Corriger[/b]", background_color='gray',pos_hint={'x':0.6,'y':0.01},size_hint=(0.2,0.14),font_size='20sp',markup=True,color='white')
                bcorr.bind(on_release=self.corrigererror)

                try:
                    cadclos.add_widget(bcorr)
                except:
                    pass

                try:
                    cadclos.add_widget(bckeck)
                except:
                    pass

                try:
                    tabclos.add_widget(labchek)
                except:
                    pass   
                try:
                    cadclos.add_widget(tabclos)   
                except:
                    pass                     

                try:
                    cadclos.add_widget(betat)
                    cadclos.add_widget(lb)
                    cadclos.add_widget(bb1)
                    cadclos.add_widget(labselid)
                    cadclos.add_widget(combselid)
                
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                    msg.open()

                msgclos=Popup(title="PARAMETERS CLOSING",content=cadclos,size_hint=(None, None), size=(600,350))
                msgclos.open()

            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Impossible de cloturer le service à cette heure\nCe ne pas permis !! veuillez ressayer au delà de 18h:00:00 '),size_hint=(None, None), size=(400,200))
                msg.open()

        elif sepp==8:

            cadclos=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')
            
            lbm=Label(text="Cette fonctionnalité 'Deconnecté' favorise l optimisation de la machine,Il est surtout\nrecommandée pour des machines non puissantes car ca charge toutes les informations \nutiles afin d etre rapide NB: sa mise à jour est obligatoire apres un temps",font_size='14sp',pos_hint={'center_x':0.5,'center_y':0.7},color='black',size_hint=(0.5,0.15))
            bb1m=Builder.load_string('''   
Button:
    text:"[b]Mise à jour[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.73,'y':0.2}
    size_hint:(0.25,0.12)
    markup:True
    font_size:'15sp'
    color:'white' 

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]            

''')      
            
            bb1m.bind(on_release=self.misajour)

            modcon=Label(text="[b]Mode connecté[/b]",markup=True,color='black',pos_hint={'x':0.2, 'y':0.4},font_size='15sp',size_hint=(0.25,0.07))
            moddecon=Label(text="[b]Mode deconnecté[/b]",markup=True,color='black',pos_hint={'x':0.6, 'y':0.4},font_size='15sp',size_hint=(0.25,0.07))
            
            check1mod=Builder.load_string('''

CheckBox:
    pos_hint:{'x':0.47,'y':0.4}
    size_hint:0.05,0.05

    canvas.before:
        Color:
            rgba:0,0,1,1
        Rectangle:
            size:self.size
            pos:self.pos

''')
            check1mod.bind(active=self.modcheck1)

            check2mod=Builder.load_string('''
CheckBox:
    pos_hint:{'x':0.87,'y':0.4}
    size_hint:(0.05,0.05)
    active:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        Rectangle:
            size:self.size
            pos:self.pos

''')
            check2mod.bind(active=self.modcheck2)

            lbmsg=Label(text="",color='red',pos_hint={'center_x':0.5, 'y':0.1},font_size='10sp',size_hint=(0.25,0.07))

            try:
                cadclos.add_widget(lbmsg)
                cadclos.add_widget(check2mod)
                cadclos.add_widget(check1mod)
                cadclos.add_widget(lbm)
                cadclos.add_widget(bb1m)
                cadclos.add_widget(modcon)
                cadclos.add_widget(moddecon)
            except:
                pass

            msg=Popup(title="MODE DE COMMUTATION",content=cadclos,size_hint=(None, None), size=(700,300))
            msg.open()

    def arrondir(self,instance,value):

        try:
            nbr=float(instance.text)
            instance.text=str(math.ceil(nbr))
        except:
            pass

    def modtaux(self,instance):

        global labselid,ttaux,tauxjour,indicetext,indicateur,indicateurlab

        
        if tablravmultiple.row_data:

            cadclos=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]

        
        ''')

            lb=Label(text="Le controleur detecte les commandes d achat non sauvégardées\n dans la page de ravitaillement multiple\nNB:veuillez les sauvegarder puis revenir pour proceder cette operaton ",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.85,0.15))
            
            bb1=Builder.load_string('''
Button:
    text:"[b]Close[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'y':0.1}
    size_hint:0.3,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')
            bb1.bind(on_release=lambda x:mddgg.dismiss())

            try:
                
                cadclos.add_widget(bb1)
                cadclos.add_widget(lb)

                mddgg=Popup(title="CONTROLEUR",content=cadclos,size_hint=(.6,.4))
                mddgg.open()
            except:
                pass

        else:

            if indicetext.text !="" or ttaux.text !="":

                cadclos=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]

        
        ''')

                lb=Label(text="Voulez-vous vraiment confirmer cette operation \nNB: Cette operation forcera le programme de redemarrer \npour mettre à jour de nouvelles donnees",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.85,0.15))
                
                bb1=Builder.load_string('''
Button:
    text:"[b]Confirmer[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.6,'y':0.1}
    size_hint:0.3,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')
                bb1.bind(on_release=self.modtauxfin)

                bb2=Builder.load_string('''

Button:
    text:"[b]Annuler[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.1,'y':0.1}
    size_hint:0.3,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

''')

                bb2.bind(on_release=lambda x: msggss.dismiss())
                
                try:
                    cadclos.add_widget(bb1)
                    cadclos.add_widget(bb2)

                    cadclos.add_widget(lb)
                    
                except:
                    pass

                msggss=Popup(title="CONTROL",content=cadclos, size_hint=(.6,.4))
                msggss.open()

    
    def modtauxfin(self,instance):
        
        global labselid,ttaux,tauxjour,indicetext,indicateur,indicateurlab

        v1=0
        v2=0

        try:
            if int(ttaux.text)>0:
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update tauxchange set taux=%s where num=%s"
                    cursor.execute(query,(ttaux.text,1))
                    con.commit()
                    self.cursor.close()
                    con.close()

                    v1=1

                except:
                    msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de la modification '),size_hint=(None, None), size=(400,200))
                    msg.open()
        except:
            pass
        
        try:
            if float(indicetext.text)>0.0:
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="update indice set valeur=%s where id_ind=%s"
                    cursor.execute(query,(indicetext.text,'indice'))
                    con.commit()
                    self.cursor.close()
                    con.close()

                    v2=1

                except:
                    msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de la modification '),size_hint=(None, None), size=(400,200))
                    msg.open()
            
        except:
            pass

        if v1==1 or v2==1:

            self.deconnsimple()


    def chargetauxadmin(self,instance):

        global labselid,ttaux,sepp,indicevaleur,indicetext,indicateur,indicateurlab

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select valeur from indice where id_ind='indice'")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                indicevaleur=str(results[0])
        except:
            msg=Popup(title="ETAT REQUETE",content=Button(text=' Indice NOT FOUND!! ERROR '),size_hint=(None, None), size=(400,200))
            msg.open()

        cadclos=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]

        
        ''')

        lb=Label(text="Veuillez mettre à jour le taux du marché !! Attention! Cette\nvaleur sera imposée pour calculer le prix courant de chaque produit.",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.7,0.15))
        
        bb1=Builder.load_string('''

Button:
    text:"[b]Mettre à jour[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.75,'y':0.15}
    size_hint:0.2,0.15
    markup:True
    color:'white'


    canvas.before:
        Color:
            rgba:1,0,0,1
        
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]


''')
        bb1.bind(on_release=self.modtaux)

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select taux from tauxchange where num=1")
            resultss=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if resultss:
                #labselid.text= " $ " + str(resultss[0])
                tauxjour=resultss[0]
            
            #ttaux.text=""
        except:
            msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de l affichage '),size_hint=(None, None), size=(400,200))
            msg.open()

        ttaux = MDTextField(hint_text="Taux du marché",icon_right='currency-eur', helper_text="F=$",font_size='25sp',helper_text_mode="on_focus",line_color_normal='black', pos_hint={'center_x':0.25, 'center_y':0.3},size_hint=(0.25,0.1))
        indicetext = MDTextField(hint_text="Indice",icon_right='fleur-de-lis', helper_text="F=$",font_size='25sp',helper_text_mode="on_focus",line_color_normal='black', pos_hint={'center_x':0.6, 'center_y':0.3},size_hint=(0.25,0.1))
    
        labselid=Label(text="[b]$[/b]"+str(tauxjour),markup=True,color='black',pos_hint={'x':0.85, 'y':0.9},font_size='15sp',size_hint=(0.1,0.05))
        indicateurlab=Label(text=str(indicevaleur+"%"),markup=True,color='red',pos_hint={'x':0.85, 'y':0.75},font_size='15sp',size_hint=(0.1,0.05))
        
        try:
            cadclos.add_widget(indicetext)
            cadclos.add_widget(indicateurlab)
            cadclos.add_widget(ttaux)
            cadclos.add_widget(lb)
            cadclos.add_widget(bb1)
            cadclos.add_widget(labselid)
        
        except:
            msg=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
            msg.open()

        msg=Popup(title="TAUX DU MARCHE",content=cadclos,size_hint=(None, None), size=(600,200))
        msg.open()
        
    def chargetaux(self,instance):

        global labselid,ttaux,sepp,indicevaleur,indicetext,indicateur,indicateurlab

        try:

            if sepp==1:

                pass

            elif sepp==8:
                
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select taux from tauxchange where num=1")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        taux.text=str(results[0])
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur inettendue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def idlocall(self,instance,value):
        global idlocal

        if instance.active==True:
            idlocal=1
        elif instance.active==False:
            idlocal=0

    def depl1(self,instance):
        
        if instance.hint_text=="Nom":
            t3.focus=True
        elif instance.hint_text=="Catégorie":
            t4.focus=True
        elif instance.hint_text=="Anti":
            t5.focus=True
        elif instance.hint_text=="Ca traite":
            t6.focus=True
        elif instance.hint_text=="Posologie":
            t7.focus=True
        elif instance.hint_text=="Echeance d'age":
            t8.focus=True
        else:
            t9.focus=True
        

    def rechcombine(self,instance):

        global listventecombine,interval

        if combo1.text=="Toutes":
            combo1.text="choisir"

        if combo2.text=="Tous":
            combo2.text="choisir"

        if combotrav.text=="Tous":
            combotrav.text="choisir"

        if combohaut3.text=='Graphique': 

            if combo1.text!="Toutes" and combo2.text!="Tous" and combotrav.text !="Tous":

                if checkgobal.active==True:

                    if interval==0:

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()


                    elif interval==1:

                        try:
                            datlimite=datetime.strptime(combanneintervalvente.text+"-"+combmoisintervalveny.text+"-"+combjourintervalvente.text,'%Y-%m-%d')
                            datelimnew=datlimite.strftime('%Y-%m-%d')
                        except:
                            datelimnew='0000-00-00'

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        interval=0

                elif checkgobal.active==False:
                    
                    if interval==0:

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        
                    elif interval==1:

                        try:
                            datlimite=datetime.strptime(combanneintervalvente.text+"-"+combmoisintervalveny.text+"-"+combjourintervalvente.text,'%Y-%m-%d')
                            datelimnew=datlimite.strftime('%Y-%m-%d')
                        except:
                            datelimnew='0000-00-00'

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()


                        interval=0
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Spécifie la requete stp!! remplaces\n "tous","toutes" par "choisir"'),size_hint=(None, None), size=(400,200))
                msg.open()

        elif combohaut3.text=='Libre Export':

            if combo1.text!="Toutes" and combo2.text!="Tous" and combotrav.text !="Tous":

                if checkgobal.active==True:

                    if interval==0:

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()


                    elif interval==1:

                        try:
                            datlimite=datetime.strptime(combanneintervalvente.text+"-"+combmoisintervalveny.text+"-"+combjourintervalvente.text,'%Y-%m-%d')
                            datelimnew=datlimite.strftime('%Y-%m-%d')
                        except:
                            datelimnew='0000-00-00'

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        interval=0

                elif checkgobal.active==False:
                    
                    if interval==0:

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where ID_Produit='"+combo2.text+"' and Dates='"+combo1.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        
                    elif interval==1:

                        try:
                            datlimite=datetime.strptime(combanneintervalvente.text+"-"+combmoisintervalveny.text+"-"+combjourintervalvente.text,'%Y-%m-%d')
                            datelimnew=datlimite.strftime('%Y-%m-%d')
                        except:
                            datelimnew='0000-00-00'

                        if combo1.text!="choisir" and combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                        
                        elif combo1.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            
                        elif combo1.text!="choisir" and combo2.text!="choisir": 
                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where ID_Produit='"+combo2.text+"' and Dates>='"+combo1.text+"' and Dates<='"+datelimnew+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        elif combo2.text!="choisir" and combotrav.text !="choisir": 

                            tablegestionvente.row_data=[]
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                                results=self.cursor.fetchall()
                                listventecombine=results
                                #tablegestionvente.row_data=results
                                self.cursor.close()
                                con.close()
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()
                            try:
                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"' and ID_Produit='"+combo2.text+"'")
                                results=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if results:

                                    qt.text=str(results[0])
                                    tot.text=str(results[1])
                                    
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()


                        interval=0
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Spécifie la requete stp!! remplaces\n "tous","toutes" par "choisir"'),size_hint=(None, None), size=(400,200))
                msg.open()


    def bas(self,instance):
        global selid

        if selid=="b":

            hautlab1.text="[b]GESTION DE STOCK[/b]"

            try:
                cadre.remove_widget(tablstock)
            except:
                pass

            try:
                cadre.remove_widget(labstockfini)
            except:
                pass

            try:
                cadre.remove_widget(tablstockfini)
            except:
                pass
            
            try:
                cadre.add_widget(tablstocktotal)
            except:
                pass

            tablstocktotal.size_hint=(0.9,0.73)
            tablstocktotal.pos_hint={'x':0.05,'y':0.13}

        
    def centre(self,instance):
        global selid

        if selid=="b":

            hautlab1.text="[b]GESTION DE STOCK[/b]"
            tablstockfini.size_hint=(0.9,0.25)
            tablstockfini.pos_hint={'x':0.05,'y':0.13}

            tablstocktotal.size_hint=(0.9,0.46)
            tablstocktotal.pos_hint={'x':0.05,'y':0.45}

            try:
                cadre.remove_widget(tablstock)
            except:
                pass

            try:
                cadre.add_widget(labstockfini)
            except:
                pass

            try:
                cadre.add_widget(tablstockfini)
            except:
                pass

            try:
                cadre.add_widget(tablstocktotal)
            except:
                pass


    def haut(self,instance):

        global selid

        if selid=="b":

            hautlab1.text="[b]STOCK EPUISE[/b]"

            try:
                cadre.remove_widget(tablstock)
            except:
                pass


            try:
                cadre.remove_widget(labstockfini)
            except:
                pass

            try:
                cadre.remove_widget(tablstocktotal)
            except:
                pass


            try:
                cadre.add_widget(tablstockfini)
            except:
                pass

            tablstockfini.size_hint=(0.9,0.73)
            tablstockfini.pos_hint={'x':0.05,'y':0.13}

    def corrigerreur(self,instance):
        
        if instance.text=='[b]Correction d erreur ?[/b]':
        
            i=0

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule from produit,achat where matricule=ID_Produit and id_travailleur='"+tidconn.text+"'")
                listmatriculeprod=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                for i in range(len(listmatriculeprod)):
                    qtproduit=None
                    differencee=None

                    idprod=str(listmatriculeprod[i]).replace("('","").replace("',)","")

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                    resultats=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if resultats:
                        qtproduit=resultats[0]
                        differencee=resultats[1]

                        self.cconnexion()
                        cursor=con.cursor()
                        query="update produit set stock_p=%s where matricule=%s"
                        cursor.execute(query,(differencee,idprod))
                        con.commit()
                        self.cursor.close()
                        con.close()

                msg=Popup(title="STATUT REQUETE",content=Button(text='La correction realisée avec succes'),size_hint=(None, None), size=(400,200))
                msg.open()
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                msg.open()
                

        elif instance.text=='[b]Analyseur d erreur[/b]':

            global msgs

            ii=0
            jj=0
            listrav=[]

            listproderreur=[]
            listsomerreur=[]
            listdiffvrai=[]
            listdiff=[]

            discoura=os.path.dirname(__file__)
            
            try: 

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select distinct ID_Produit from achat")
                listrav=self.cursor.fetchall()
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                msg.open()
                
            try:
                for idts in listrav:

                    idtravv=str(idts).replace("('","").replace("',)","")

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),stock-(select SUM(Qte) from achat where ID_Produit='"+idtravv+"'),stock_p from achat,produit where matricule=ID_Produit and ID_Produit='"+idtravv+"'")
                    resultattts=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if resultattts:
                        totv=resultattts[0]
                        diffv=resultattts[1]
                        diffvue=resultattts[2]

                        if diffv==diffvue:
                            jj+=1
                        else:
                            ii+=1

                            try:

                                self.cconnexion()
                                cursor=con.cursor()
                                query="update produit set stock_p=%s where matricule=%s"
                                cursor.execute(query,(diffv,idtravv))
                                con.commit()
                                self.cursor.close()
                                con.close()

                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors du redressage systeme, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                                msg.open()

                            listproderreur.append(idtravv)
                            listsomerreur.append(totv)
                            listdiffvrai.append(diffv)
                            listdiff.append(diffvue)

                ccad=MDFloatLayout()
                llab=Label(text="Monsieur/Madame, voici le rapport de votre systeme :\nNombre d article sans erreur :"+str(jj)+"\nNombre d article avec erreur :"+str(ii)+"\nVoulez-vous voir exactement le detail de donnees defectieuses ...., veuillez voir le fichier rapport.xls généré",pos_hint={'x':0.05,'y':0.3},size_hint=(0.98,0.6),color='black')
                
                btx2=Button(text="[b]ok[/b]",markup=True,color='white',background_color="seagreen",font_size='17sp',pos_hint={'x':0.6, 'y':0.1},size_hint=(0.3,0.08))
                btx2.bind(on_release=self.quits)

                ccad.add_widget(llab)
                
                ccad.add_widget(btx2)

                iii=0

                msgs=Popup(title="RAPPORT DE VERIFICATION",content=ccad,size_hint=(None, None), size=(800,300))
                msgs.open()

                self.exportateuranalyse("RAPPORT DU CHECKING",listproderreur,listsomerreur,listdiffvrai,listdiff)

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue'),size_hint=(None, None), size=(400,200))
                msg.open()
                        
    def quits(self,instance):
        global msgs

        msgs.dismiss()


    def liberinstance(self,instance):

        discourant=os.path.dirname(__file__)
        discrec=os.path.join(discourant,"ft")
    
        try:

            for fichier in os.listdir(discrec):
                f=os.path.join(discrec,fichier)
                if os.path.isfile(f):
                    try:
                        os.remove(f)
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
        
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def affpas_a_pasfin(self,dt):                            
                                        
        global l,lcont,motrappfin

        if len(motrappfin)<=1500:
            
            affresultat.text=affresultat.text[0:len(affresultat.text)-1]

            try:
                cadre.remove_widget(btsuitegenAI)
            except:
                pass
            
            if l < len(motrappfin):
                if lcont==130:
                    affresultat.text+="\n"
                    lcont=0

                affresultat.text += motrappfin[l]+"|"
                l += 1
                lcont+=1
            else:
                #bgenererresulat.background_color="seagreen"

                try:
                    cadre.add_widget(btsuitegenAI)
                    btsuitegenAI.text='[b]Oui[/b]'
                except:
                    pass
                
                return False  
            

    def affpas_a_pas(self,dt):
        global l,lcont,resuplainte,indiceaff,listplainte,repsuite,unitul,listedebut,listecharniere,listnom,listcategorie,listtraite,listanti,listposlogoie,listeage,listepuu
        global nomaff,categorieaff,taitaff,antaff,posologaff,agaff,paff,mot,listfin

        unitul=" je suis sur uqe c est oit qui m as fait ca  neamoins il faut comprendre que la vie evolue de la sorte das le cas que l amsi dis de n pas avoie une dent cotre toit mais tu le bois en te supectant dans les faaaires courangtes et dans les betises dans le domaine simple pure et esctat je suis sur uqe c est oit qui m as fait ca  mneamoins il faut comprendre que la vie evolue de la sorte das le cas que l amsi dis de n pas avoie une dent cotre toit mais tu le bois en te supectant dans les faaaires courangtes et dans les betises dans le domaine simple pure et esctat"
        

        if len(mot)<=1000:
            
            affresultat.text=affresultat.text[0:len(affresultat.text)-1]

            try:
                cadre.remove_widget(btsuitegenAI)
            except:
                pass
            
            if l < len(mot):
                if lcont==130:
                    affresultat.text+="\n"
                    lcont=0

                affresultat.text += mot[l]+"|"
                l += 1
                lcont+=1
            else:
                #bgenererresulat.background_color="seagreen"
                return False  
        else:
            
            if repsuite==0:

                if l <= 1000:

                    affresultat.text=affresultat.text[0:len(affresultat.text)-1]

                    if lcont==130:
                        affresultat.text+="\n"
                        lcont=0

                    affresultat.text += mot[l]+"|"
                    l += 1
                    lcont+=1

                    labelement.text=str(l)
                else:
                    try:
                        cadre.add_widget(btsuitegenAI)
                    except:
                        pass

                    return False
    
            elif repsuite==1:
                        
                if l > 1000 and l < len(mot):
                    affresultat.text=affresultat.text[0:len(affresultat.text)-1]

                    if lcont==130:
                        affresultat.text+="\n"
                        lcont=0

                    affresultat.text += mot[l]+"|"
                    l += 1
                    lcont+=1
                else:
                    #bgenererresulat.background_color="seagreen"
                    return False

    def generesultat(self,instance):
        global listeplainte,ki,l,lcont,listplainte,kj,resuplainte,indiceaff,unitul,listedebut,listecharniere,listnom,listcategorie,listtraite,listanti,listposlogoie,listeage,listepuu
        global nomaff,categorieaff,taitaff,antaff,posologaff,agaff,paff,mot,listfin, compfois,motrappfin,debsessionheure

        plainterecu=""
        motrappfin=""

        mot="Erreur a été générée, veuillez redemarrer le systeme "
        cherapp=0

        indicerapp=0
        
        try:

            plainterecu=texp1.text
            plainterecu=plainterecu.split()

            salutation=plainterecu[0].lower()
            genre=plainterecu[1].lower()
            nomopenai=plainterecu[2].lower()

            heurenow=datetime.now().strftime("%H:%M:%S")

            if salutation=="bonjour" or salutation=="bjr" or salutation=="bonsoir" or salutation=="bsr" or salutation=="bon_apres_midi":
            
                if genre=='monsieur' or genre=='mr' or genre=='madame':

                    if nomopenai=="askyas":

                        if heurenow < "12:00:00":
                            if salutation=="bonjour" or salutation=="bjr":

                                deccoup=texp1.text.split()
                                di=0
                                for di in range(len(deccoup)):
                                    if deccoup[di].lower()=="rapport-du-jour":
                                        cherapp=1
                                        break

                                if cherapp==1:

                                    indicerapp=random.randint(0,4)

                                    listdeburap=['Recupération des données du ','Extration des données du ','Structuration des données du ','Filtration des données du ','Lecture des données du ']
                                    listnomrap=[' Travailleur ',' Bosseur ',' Pharmacien(Travailleur) ',' Bookinneur ',' Coéquipier ']
                                    listfinrapp=[' tu es sur (e) de pouvoir mettre ce rapport au propre ? (repondez par : oui ou non)NB: oui, c-a-d on transmet sur le serveur et ta journée est cloturée',' es-tu pret (e) de que ce rapport soit transmis au serveur(Oui/Non)?? oui , c-a-d on transmet au gestionnaire et le processus est clos aujourdui',' je parie que  tu es pret (e) d envoyer ce rapport à l interface admin ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)',' je m imagine que  tu es sensible d envoyer ce dit rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, veut dire on transfert sur le serveur et ta journée est limité par ci)',' je me fait l ide du genre tu es deja pret (e) d envoyer ce rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)']
                                    
                                    listmotif=[' alors suite aux problemes que confronte la gestion, on a  sorti le montant  ',' aussi suite aux depenses liées à la gestion, on a  sorti une somme  ','  sous-pretexte du motif que demande la gestion demande, on a  depensé  ','  voyant les situations que la gestion, on a  sorti le montant  ','  sachant que la gestion oblige les imprevus voila une somme qui a été confrontée à la gestion  ']
                                    
                                    listfinrappo=['; Merci et n hésitez pas de me consulter encore si nécessaire.','; Humblement reconnaissant et je vous espère me consulter encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.','. Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.','. Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                    try:
                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select nom,prenom,sexe from compte where id='"+tidconn.text+"'")
                                        identitetrav=self.cursor.fetchone()
                                        self.cursor.close()
                                        con.close()

                                        if identitetrav:
                                            nomrap=identitetrav[0]
                                            prenomrap=identitetrav[1]
                                            sexerap=identitetrav[2]

                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                        debsession=self.cursor.fetchone()
                                        self.cursor.close()
                                        con.close()

                                        if debsession:
                                            debsessionheure=debsession[0]

                                        
                                        valmotif=0
                                        totrestant=0

                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select SUM(montant) from motif_signaler,commande where id_trav='"+tidconn.text+"' and date_motif=borne")
                                        montamotif=self.cursor.fetchone()
                                        self.cursor.close()
                                        con.close()

                                        if montamotif:
                                            valmotif=montamotif[0]


                                        self.cconnexion()
                                        self.cursor=con.cursor()
                                        self.cursor.execute("select SUM(PT) from achat,commande where id_travailleur='"+tidconn.text+"' and Dates=borne")
                                        totrapp=self.cursor.fetchone()
                                        self.cursor.close()
                                        con.close()

                                        if totrapp:

                                            totalrapp=totrapp[0]

                                            try:
                                                totrestant=int(totalrapp)-valmotif
                                            except:
                                                totrestant=totalrapp
                                        else:
                                            valmotif=0
                                            totrestant=0

                                        motrappfin=listdeburap[indicerapp]+listnomrap[indicerapp]+ " Nom : "+nomrap + " Prenom : "+prenomrap+ " Sexe : "+sexerap + " ta connexion ou bien session a été ouverte depuis :  "+str(debsessionheure) + " . Il sied de montrer que selon mes analyses et calculs, tu as vendu aujourdhui :" + str(totalrapp) +"  chargement encours.... "+ listmotif[indicerapp]+"[ "+ str(valmotif) +" ]  apres toutes les soustrations de charges officielles connues on realise t avoir en main : "+str(totrestant)+listfinrappo[indicerapp]+ listfinrapp[indicerapp]
                                    
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pasfin, 0.1)  
                                        

                                    except:
                                        msg=Popup(title="STATUT REQUETE",content=Button(text=' Le generateur du rapport a echoué, veuillez ressayer plus tard '),size_hint=(None, None), size=(400,200))
                                        msg.open()

                                else:

                                    if genre=='monsieur' or genre=='mr':


                                        compfois=0

                                        imgexpert.background_normal=''
                                        
                                        indiceaff=random.randint(0,4)

                                        #instance.background_color="red"

                                        plaintes=[]
                                        plaintes=listplainte

                                        if kj<=len(plaintes)-1:
                                            elementvalue=plaintes[kj]
                                            elementvalue=elementvalue[0:len(elementvalue)-1]

                                            labcompteur.text="[b]"+ str(kj+1) + "/"+ str(len(plaintes))+"[/b]"

                                            try:
                                                self.cconnexion()
                                                self.cursor=con.cursor()
                                                self.cursor.execute("select nom,categorie,anti,traite,posologie,age_utilisation,pu from produit where traite='"+ elementvalue +"'")
                                                resuplainte=self.cursor.fetchone()
                                                self.cursor.close()
                                                con.close()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                    
                                            if resuplainte:
                                                nomaff=resuplainte[0]
                                                categorieaff=resuplainte[1]
                                                taitaff=resuplainte[2]
                                                antaff=resuplainte[3]
                                                posologaff=resuplainte[4]
                                                agaff=resuplainte[5]
                                                paff=str(resuplainte[6])


                                                listedebut=[' Effectivement monsieur/madame, ',' Exactement monsieur/madame, ',' Franchement monsieur/madame, ',' Cela etant vrai monsieur/madame, ',' Extrêmement bien dit monsieur/madame , ']
                                                listecharniere=['. En effet, ','. En outre, ','. En réalité, ','. En connaissance de cause, ','. Selon ce dit ci-haut, ']
                                                
                                                listnom=[' tu es prié de prendre : ','  tu es conseillé d acheter : ','  tu es sous proprosition du produit tel que : ','  nous te suggerons le medicament : ',' Veuillez acheter le produit : ']
                                                listcategorie=[' ce dernier faisant de partie de ',' catégorié dans ',' classifié parmi ',' connu parmi ',' retrouvé dans la fammile de ']
                                                listtraite=[' ce produit traite ',' il est capable de traiter ',' il est reconnu pour la guerison de  ',' il va guerir', ' utiliser pour sa supere puissance de guerir']
                                                listanti=[' mais attention de ce produit !! car ne supporte pas  ',' néamoins attention de consommer ce produit si tu as ',' sois informé de ce produit que ca ne supporte pas ',' éveilles-toi, ce produit ne co-habite pas avec ',' franchement ce dernier ne supporte pas ']
                                                listposlogoie=[' voila comment ca s utilise ', ' regardes comment ca se prend ',' tu sais comment est son usage...? ',' ca s employe de la manière ', ' sa posologie normale montre ce qui suit ']
                                                listeage=[' tout en dependant avec cette repartition d âge ',' cadran avec ce decallage d âge ', ' en rapport de cet âge ', ' comme on le prevoit par âge', ' en tenant coompte de la fréquence d âge ']
                                                listepuu=['. Keba !!! tout depend de ta poche, voila le prix que revient ce produit ', '. Keba !!! c est la contrainte budgétaire qui conclut, voila tel est son prix ','. Keba !!! l unique et seule dernière decision c est ton budget, voila son prix ', '. Keba !!! tout se conclut avec ce prix ', '. Keba !!! tu nous sera le bienvenue que si tu disposes pour ce produit ' ]            

                                                listfin=[' Merci et n hésitez pas de consulter encore si nécessaire.   ',' Merci et j espère que vous me consultiez encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.  ',' . Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.  ',' . Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                                try:
                                                    mot="Recupération des plaintes ... "+str(plaintes) +"  decomposition encours... ressemblage... Generation OpenAI demarre! ."+ listedebut[indiceaff] + listnom[indiceaff]+nomaff + ","+ listcategorie[indiceaff]+ categorieaff+listtraite[indiceaff]+taitaff+ ", " + listanti[indiceaff]+antaff + ", "+ listposlogoie[indiceaff]+ ", "+ posologaff+listeage[indiceaff]+agaff+listepuu[indiceaff]+paff+ listfin[indiceaff]
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Génération/Ressamblage a échoué, veuillez recommancer '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                        
                                                try:

                                                    discourantt=os.path.dirname(__file__)
                                                    disprodd=os.path.join(discourantt,"ftx",nomaff)
                                                    imgexpert.background_normal= disprodd + ".jpg"

                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors du chargement de la photo'),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            
                                            kj+=1
                                        else:
                                            kj=0
                                        
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)


                                    elif genre=='madame':

                                        compfois +=1
                                        indicdmad= random.randint(0,3)
                                        listefemme=['Desolé Monsieur/Madame, je suis très inquiet de m avoir confondu  à une femme car une femme ne peut pas raisonner comme moi, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Wouaw !!! Monsieur/Madame, sur quel plan tu peux m accorder cette humilliation, je suis inconsolable de m avoir egalisé à une femme car une femme est une être reputée en incomprehension et impossible d imaginer meme me comparer avec elle, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Incroyable Monsieur/Madame, je ne suis pas d hummeur de m avoir confondu  à une femme car si j etais une femme, je ne pouvais pas meme te repondre à ce temps, de grace, je souhaite une considération de ta part, cela pourra me motiver et me donner la conviction de vous repondre favorablement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Merde !! Monsieur/Madame par quelle concentement tu peux me manquer ainsi ??, je suis très inquiet de m avoir rapproché  à une femme car une femme ne peut pas prendre en charge tous ce que je fais, de grace, j aime une considération de ta part, cela pourra me pousser et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ']
                                        mot=listefemme[indicdmad]

                                        #print(compfois)

                                        if compfois==4:
                                            pass  # arreter la machine ici

                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)

                            else:
                                indicdmad= random.randint(0,3)
                                listefemme=['Wouw!!! Desolé Madame/Monsieur, en rigueur de la politesse à cette heure, il est imperatif de se dire "Bonjour" avant d aborder n importe quel probleme','Wouff !! Vraiment Madame/Monsieur, tu es si realiste de me donner une salutation à cette heure si c n est "Bonjour" en terme de la politesse ?? ','Inconcevable mais vrai!!!  Madame/Monsieur, comment tu veux supposer me consulter avec une salutation à cette heure si ce n est pas  "Bonjour"','Ahh !! non pardon cher (e) Monsieur/Madame !! j ai droit à etre salué avant de tenir n importe quel discussion à ma personnalité, NB: à cette heure j attend rien d autre que  "Bonjour']
                                mot=listefemme[indicdmad]

                                affresultat.text = ""
                                l = 0
                                lcont=0

                                Clock.schedule_interval(self.affpas_a_pas, 0.1)                            

                        elif heurenow < "15:00:00":
                            if salutation=="bon_apres_midi":
                                if genre=='monsieur' or genre=='mr':

                                    deccoup=texp1.text.split()
                                    di=0
                                    for di in range(len(deccoup)):
                                        if deccoup[di].lower()=="rapport-du-jour":
                                            cherapp=1
                                            break

                                    if cherapp==1:
                                        
                                        indicerapp=random.randint(0,4)

                                        listdeburap=['Recupération des données du ','Extration des données du ','Structuration des données du ','Filtration des données du ','Lecture des données du ']
                                        listnomrap=[' Travailleur ',' Bosseur ',' Pharmacien(Travailleur) ',' Bookinneur ',' Coéquipier ']
                                        listfinrapp=[' tu es sur (e) de pouvoir mettre ce rapport au propre ? (repondez par : oui ou non)NB: oui, c-a-d on transmet sur le serveur et ta journée est cloturée',' es-tu pret (e) de que ce rapport soit transmis au serveur(Oui/Non)?? oui , c-a-d on transmet au gestionnaire et le processus est clos aujourdui',' je parie que  tu es pret (e) d envoyer ce rapport à l interface admin ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)',' je m imagine que  tu es sensible d envoyer ce dit rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, veut dire on transfert sur le serveur et ta journée est limité par ci)',' je me fait l ide du genre tu es deja pret (e) d envoyer ce rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)']
                                        
                                        listmotif=[' alors suite aux problemes que confronte la gestion, on a  sorti le montant  ',' aussi suite aux depenses liées à la gestion, on a  sorti une somme  ','  sous-pretexte du motif que demande la gestion demande, on a  depensé  ','  voyant les situations que soubit la gestion , on a  sorti le montant  ','  sachant que la gestion oblige les imprevus voila une somme qui a été confrontée à la gestion  ']
                                        listfinrappo=['. Merci et n hésitez pas de me consulter encore si nécessaire.','. Humblement reconnaissant et je vous espère me consulter encore à la prochaine.  ','. Je te remercie de m avoir consulté et je te serai toujours disponible.','. Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.','. Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                        
                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select nom,prenom,sexe from compte where id='"+tidconn.text+"'")
                                            identitetrav=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if identitetrav:
                                                nomrap=identitetrav[0]
                                                prenomrap=identitetrav[1]
                                                sexerap=identitetrav[2]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                            debsession=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if debsession:
                                                debsessionheure=debsession[0]

                                            valmotif=0
                                            totrestant=0

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(montant) from motif_signaler,commande where id_trav='"+tidconn.text+"' and date_motif=borne")
                                            montamotif=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if montamotif:

                                                valmotif=montamotif[0]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(PT) from achat,commande where id_travailleur='"+tidconn.text+"' and Dates=borne")
                                            totrapp=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if totrapp:
                                                totalrapp=totrapp[0]

                                                try:
                                                    totrestant=int(totalrapp)-valmotif
                                                except:
                                                    totrestant=totalrapp
                                            else:
                                                valmotif=0
                                                totrestant=0

                                            motrappfin=listdeburap[indicerapp]+listnomrap[indicerapp]+ " Nom : "+nomrap + " Prenom : "+prenomrap+ " Sexe : "+sexerap + " ta connexion ou bien session a été ouverte depuis :  "+str(debsessionheure) + " . Il sied de montrer que selon mes analyses et calculs, tu as vendu aujourdhui :" + str(totalrapp) +"  chargement encours.... "+ listmotif[indicerapp]+"[ "+ str(valmotif) +" ]  apres toutes les soustrations de charges officielles connues on realise t avoir en main : "+str(totrestant)+listfinrappo[indicerapp]+ listfinrapp[indicerapp]
                                    
                                            affresultat.text = ""
                                            l = 0
                                            lcont=0

                                            Clock.schedule_interval(self.affpas_a_pasfin, 0.1)  
                                            

                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text=' Le generateur du rapport a echoué, veuillez ressayer plus tard '),size_hint=(None, None), size=(400,200))
                                            msg.open()

                                    else:

                                        compfois=0

                                        imgexpert.background_normal=''
                                        
                                        indiceaff=random.randint(0,4)

                                        #instance.background_color="red"

                                        plaintes=[]
                                        plaintes=listplainte

                                        if kj<=len(plaintes)-1:
                                            elementvalue=plaintes[kj]
                                            elementvalue=elementvalue[0:len(elementvalue)-1]

                                            labcompteur.text="[b]"+ str(kj+1) + "/"+ str(len(plaintes))+"[/b]"

                                            try:
                                                self.cconnexion()
                                                self.cursor=con.cursor()
                                                self.cursor.execute("select nom,categorie,anti,traite,posologie,age_utilisation,pu from produit where traite='"+ elementvalue +"'")
                                                resuplainte=self.cursor.fetchone()
                                                self.cursor.close()
                                                con.close()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                    
                                            if resuplainte:
                                                nomaff=resuplainte[0]
                                                categorieaff=resuplainte[1]
                                                taitaff=resuplainte[2]
                                                antaff=resuplainte[3]
                                                posologaff=resuplainte[4]
                                                agaff=resuplainte[5]
                                                paff=str(resuplainte[6])


                                                listedebut=[' Effectivement monsieur/madame, ',' Exactement monsieur/madame, ',' Franchement monsieur/madame, ',' Cela etant vrai monsieur/madame, ',' Extrêmement bien dit monsieur/madame , ']
                                                listecharniere=['. En effet, ','. En outre, ','. En réalité, ','. En connaissance de cause, ','. Selon ce dit ci-haut, ']
                                                
                                                listnom=[' tu es prié de prendre : ','  tu es conseillé d acheter : ','  tu es sous proprosition du produit tel que : ','  nous te suggerons le medicament : ',' Veuillez acheter le produit : ']
                                                listcategorie=[' ce dernier faisant de partie de ',' catégorié dans ',' classifié parmi ',' connu parmi ',' retrouvé dans la fammile de ']
                                                listtraite=[' ce produit traite ',' il est capable de traiter ',' il est reconnu pour la guerison de  ',' il va guerir', ' utiliser pour sa supere puissance de guerir']
                                                listanti=[' mais attention de ce produit !! car ne supporte pas  ',' néamoins attention de consommer ce produit si tu as ',' sois informé de ce produit que ca ne supporte pas ',' éveilles-toi, ce produit ne co-habite pas avec ',' franchement ce dernier ne supporte pas ']
                                                listposlogoie=[' voila comment ca s utilise ', ' regardes comment ca se prend ',' tu sais comment est son usage...? ',' ca s employe de la manière ', ' sa posologie normale montre ce qui suit ']
                                                listeage=[' tout en dependant avec cette repartition d âge ',' cadran avec ce decallage d âge ', ' en rapport de cet âge ', ' comme on le prevoit par âge', ' en tenant coompte de la fréquence d âge ']
                                                listepuu=['. Keba !!! tout depend de ta poche, voila le prix que revient ce produit ', '. Keba !!! c est la contrainte budgétaire qui conclut, voila tel est son prix ','. Keba !!! l unique et seule dernière decision c est ton budget, voila son prix ', '. Keba !!! tout se conclut avec ce prix ', '. Keba !!! tu nous sera le bienvenue que si tu disposes pour ce produit ' ]            

                                                listfin=[' Merci et n hésitez pas de consulter encore si nécessaire.   ',' Merci et j espère que vous me consultiez encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.  ',' . Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.  ',' . Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                                try:
                                                    mot="Recupération des plaintes ... "+str(plaintes) +"  decomposition encours... ressemblage... Generation OpenAI demarre! ."+ listedebut[indiceaff] + listnom[indiceaff]+nomaff + ","+ listcategorie[indiceaff]+ categorieaff+listtraite[indiceaff]+taitaff+ ", " + listanti[indiceaff]+antaff + ", "+ listposlogoie[indiceaff]+ ", "+ posologaff+listeage[indiceaff]+agaff+listepuu[indiceaff]+paff+ listfin[indiceaff]
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Génération/Ressamblage a échoué, veuillez recommancer '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                        
                                                try:

                                                    discourantt=os.path.dirname(__file__)
                                                    disprodd=os.path.join(discourantt,"ftx",nomaff)
                                                    imgexpert.background_normal= disprodd + ".jpg"

                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors du chargement de la photo'),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            
                                            kj+=1
                                        else:
                                            kj=0
                                        
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)  

                                elif genre=='madame':
                                    compfois +=1
                                    indicdmad= random.randint(0,3)
                                    listefemme=['Desolé Monsieur/Madame, je suis très inquiet de m avoir confondu  à une femme car une femme ne peut pas raisonner comme moi, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Wouaw !!! Monsieur/Madame, sur quel plan tu peux m accorder cette humilliation, je suis inconsolable de m avoir egalisé à une femme car une femme est une être reputée en incomprehension et impossible d imaginer meme me comparer avec elle, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Incroyable Monsieur/Madame, je ne suis pas d hummeur de m avoir confondu  à une femme car si j etais une femme, je ne pouvais pas meme te repondre à ce temps, de grace, je souhaite une considération de ta part, cela pourra me motiver et me donner la conviction de vous repondre favorablement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Merde !! Monsieur/Madame par quelle concentement tu peux me manquer ainsi ??, je suis très inquiet de m avoir rapproché  à une femme car une femme ne peut pas prendre en charge tous ce que je fais, de grace, j aime une considération de ta part, cela pourra me pousser et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ']
                                    mot=listefemme[indicdmad]

                                    if compfois==4:
                                        pass  # arreter la machine ici

                                    affresultat.text = ""
                                    l = 0
                                    lcont=0

                                    Clock.schedule_interval(self.affpas_a_pas, 0.1)

                            else:

                                indicdmad= random.randint(0,3)
                                listefemme=['Wouw!!! Desolé Madame/Monsieur, sans mancher le mot à cette heure, il sied de se dire "Bon_apres_midi" avant d aborder n importe quel probleme','Wouff !! Vraiment Madame/Monsieur, tu es determiné de me donner une salutation à cette heure si c n est "Bon_apres_midi" en terme de la politesse ?? ','incroyable mais vrai!!!  Madame/Monsieur, comment tu veux supposer me consulter avec une salutation à cette heure si ce n est pas  "Bon_apres_midi"','Ahh !! non pardon cher (e) Monsieur/Madame !! j ai droit à etre salué avant de tenir n importe quel discussion à ma personnalité, NB: à cette heure j attend rien d autre que  "Bon_apres_midi']
                                mot=listefemme[indicdmad]

                                affresultat.text = ""
                                l = 0
                                lcont=0

                                Clock.schedule_interval(self.affpas_a_pas, 0.1)
                                

                        elif heurenow >= "15:00:00":
                            if salutation=="bonsoir" or salutation=="bsr":
                                if genre=='monsieur' or genre=='mr':
                                    
                                    deccoup=texp1.text.split()
                                    di=0
                                    for di in range(len(deccoup)):
                                        if deccoup[di].lower()=="rapport-du-jour":
                                            cherapp=1
                                            break

                                    if cherapp==1:

                                        indicerapp=random.randint(0,4)

                                        listdeburap=['Recupération des données du ','Extration des données du ','Structuration des données du ','Filtration des données du ','Lecture des données du ']
                                        listnomrap=[' Travailleur ',' Bosseur ',' Pharmacien(Travailleur) ',' Bookinneur ',' Coéquipier ']
                                        listfinrapp=[' tu es sur (e) de pouvoir mettre ce rapport au propre ? (repondez par : oui ou non)NB: oui, c-a-d on transmet sur le serveur et ta journée est cloturée',' es-tu pret (e) de que ce rapport soit transmis au serveur(Oui/Non)?? oui , c-a-d on transmet au gestionnaire et le processus est clos aujourdui',' je parie que  tu es pret (e) d envoyer ce rapport à l interface admin ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)',' je m imagine que  tu es sensible d envoyer ce dit rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, veut dire on transfert sur le serveur et ta journée est limité par ci)',' je me fait l ide du genre tu es deja pret (e) d envoyer ce rapport à l interface Gestionnaire ?? repondez par Oui/Non (oui, c-a-d on transfert sur le serveur et ta journée est cloturée)']
                                        listmotif=[' alors suite aux problemes que confronte la gestion, on a  sorti le montant  ',' aussi vus depenses liées à la gestion, on a  sorti une somme  ','  sous-pretexte du motif que demande la gestion demande, on a  depensé  ','  voyant les situations que presente gestion, on a  sorti le montant  ','  sachant que la gestion oblige les imprevus voila une somme qui a été confrontée à la gestion  ']
                                        listfinrappo=['; Merci et n hésitez pas de me consulter encore si nécessaire.','; Humblement reconnaissant et je vous espère me consulter encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.','. Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.','. Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']                                        

                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select nom,prenom,sexe from compte where id='"+tidconn.text+"'")
                                            identitetrav=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if identitetrav:
                                                nomrap=identitetrav[0]
                                                prenomrap=identitetrav[1]
                                                sexerap=identitetrav[2]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                            debsession=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if debsession:
                                                debsessionheure=debsession[0]
                                            

                                            valmotif=0
                                            totrestant=0

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(montant) from motif_signaler,commande where id_trav='"+tidconn.text+"' and date_motif=borne")
                                            montamotif=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if montamotif:
                                                valmotif=montamotif[0]

                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select SUM(PT) from achat,commande where id_travailleur='"+tidconn.text+"' and Dates=borne")
                                            totrapp=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()

                                            if totrapp:
                                                totalrapp=totrapp[0]

                                                try:
                                                    totrestant=int(totalrapp)-valmotif
                                                except:
                                                    totrestant=totalrapp
                                            else:
                                                valmotif=0
                                                totrestant=0

                                            motrappfin=listdeburap[indicerapp]+listnomrap[indicerapp]+ " Nom : "+nomrap + " Prenom : "+prenomrap+ " Sexe : "+sexerap + " ta connexion ou bien session a été ouverte depuis :  "+str(debsessionheure) + " . Il sied de montrer que selon mes analyses et calculs, tu as vendu aujourdhui :" + str(totalrapp) +"  chargament encours.... "+listmotif[indicerapp]+ " [ "+str(valmotif)+" ] apres toutes les soustrations de charges officielles connues on realise t avoir en main : "+str(totrestant)+listfinrappo[indicerapp]+ listfinrapp[indicerapp]
                                    
                                            affresultat.text = ""
                                            l = 0
                                            lcont=0

                                            Clock.schedule_interval(self.affpas_a_pasfin, 0.1)  
                                            

                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text=' Le generateur du rapport a echoué, veuillez ressayer plus tard '),size_hint=(None, None), size=(400,200))
                                            msg.open()

                                    else:
                                    
                                        imgexpert.background_normal=''

                                        compfois=0
                                        
                                        indiceaff=random.randint(0,4)

                                        #instance.background_color="red"

                                        plaintes=[]
                                        plaintes=listplainte

                                        if kj<=len(plaintes)-1:
                                            elementvalue=plaintes[kj]
                                            elementvalue=elementvalue[0:len(elementvalue)-1]

                                            labcompteur.text="[b]"+ str(kj+1) + "/"+ str(len(plaintes))+"[/b]"

                                            try:
                                                self.cconnexion()
                                                self.cursor=con.cursor()
                                                self.cursor.execute("select nom,categorie,anti,traite,posologie,age_utilisation,pu from produit where traite='"+ elementvalue +"'")
                                                resuplainte=self.cursor.fetchone()
                                                self.cursor.close()
                                                con.close()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                    
                                            if resuplainte:
                                                nomaff=resuplainte[0]
                                                categorieaff=resuplainte[1]
                                                taitaff=resuplainte[2]
                                                antaff=resuplainte[3]
                                                posologaff=resuplainte[4]
                                                agaff=resuplainte[5]
                                                paff=str(resuplainte[6])


                                                listedebut=[' Effectivement monsieur/madame, ',' Exactement monsieur/madame, ',' Franchement monsieur/madame, ',' Cela etant vrai monsieur/madame, ',' Extrêmement bien dit monsieur/madame , ']
                                                listecharniere=['. En effet, ','. En outre, ','. En réalité, ','. En connaissance de cause, ','. Selon ce dit ci-haut, ']
                                                
                                                listnom=[' tu es prié de prendre : ','  tu es conseillé d acheter : ','  tu es sous proprosition du produit tel que : ','  nous te suggerons le medicament : ',' Veuillez acheter le produit : ']
                                                listcategorie=[' ce dernier faisant de partie de ',' catégorié dans ',' classifié parmi ',' connu parmi ',' retrouvé dans la fammile de ']
                                                listtraite=[' ce produit traite ',' il est capable de traiter ',' il est reconnu pour la guerison de  ',' il va guerir', ' utiliser pour sa supere puissance de guerir']
                                                listanti=[' mais attention de ce produit !! car ne supporte pas  ',' néamoins attention de consommer ce produit si tu as ',' sois informé de ce produit que ca ne supporte pas ',' éveilles-toi, ce produit ne co-habite pas avec ',' franchement ce dernier ne supporte pas ']
                                                listposlogoie=[' voila comment ca s utilise ', ' regardes comment ca se prend ',' tu sais comment est son usage...? ',' ca s employe de la manière ', ' sa posologie normale montre ce qui suit ']
                                                listeage=[' tout en dependant avec cette repartition d âge ',' cadran avec ce decallage d âge ', ' en rapport de cet âge ', ' comme on le prevoit par âge', ' en tenant coompte de la fréquence d âge ']
                                                listepuu=['. Keba !!! tout depend de ta poche, voila le prix que revient ce produit ', '. Keba !!! c est la contrainte budgétaire qui conclut, voila tel est son prix ','. Keba !!! l unique et seule dernière decision c est ton budget, voila son prix ', '. Keba !!! tout se conclut avec ce prix ', '. Keba !!! tu nous sera le bienvenue que si tu disposes pour ce produit ' ]            

                                                listfin=[' Merci et n hésitez pas de consulter encore si nécessaire.   ',' Merci et j espère que vous me consultiez encore à la prochaine.  ',' Je te remercie de m avoir consulté et je te serai toujours disponible.  ',' . Je salue ta considération à ma faveur et prière de te renseigner prochainement à moi.  ',' . Je suis ravis d etre consulté et je te serai toujours pret à la prochaine.  ']
                                                
                                                try:
                                                    mot="Recupération des plaintes ... "+str(plaintes) +"  decomposition encours... ressemblage... Generation OpenAI demarre! ."+ listedebut[indiceaff] + listnom[indiceaff]+nomaff + ","+ listcategorie[indiceaff]+ categorieaff+listtraite[indiceaff]+taitaff+ ", " + listanti[indiceaff]+antaff + ", "+ listposlogoie[indiceaff]+ ", "+ posologaff+listeage[indiceaff]+agaff+listepuu[indiceaff]+paff+ listfin[indiceaff]
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Génération/Ressamblage a échoué, veuillez recommancer '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                                    
                                        
                                                try:

                                                    discourantt=os.path.dirname(__file__)
                                                    disprodd=os.path.join(discourantt,"ftx",nomaff)
                                                    imgexpert.background_normal= disprodd + ".jpg"

                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors du chargement de la photo'),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            
                                            kj+=1
                                        else:
                                            kj=0
                                        
                                        affresultat.text = ""
                                        l = 0
                                        lcont=0

                                        Clock.schedule_interval(self.affpas_a_pas, 0.1)  

                                elif genre=='madame':
                                    
                                    compfois +=1
                                    indicdmad= random.randint(0,3)
                                    listefemme=['Desolé Monsieur/Madame, je suis très inquiet de m avoir confondu  à une femme car une femme ne peut pas raisonner comme moi, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Wouaw !!! Monsieur/Madame, sur quel plan tu peux m accorder cette humilliation, je suis inconsolable de m avoir egalisé à une femme car une femme est une être reputée en incomprehension et impossible d imaginer meme me comparer avec elle, de grace, j aime une considération de ta part, cela pourra m encourager et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Incroyable Monsieur/Madame, je ne suis pas d hummeur de m avoir confondu  à une femme car si j etais une femme, je ne pouvais pas meme te repondre à ce temps, de grace, je souhaite une considération de ta part, cela pourra me motiver et me donner la conviction de vous repondre favorablement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ','Merde !! Monsieur/Madame par quelle concentement tu peux me manquer ainsi ??, je suis très inquiet de m avoir rapproché  à une femme car une femme ne peut pas prendre en charge tous ce que je fais, de grace, j aime une considération de ta part, cela pourra me pousser et me donner l amour de vous repondre corectement , En bref, appelles-moi "Monsieur OpenAI" et non "Madame OpenAI"  ']
                                    mot=listefemme[indicdmad]

                                    #print(compfois)

                                    if compfois==4:
                                        pass  # arreter la machine ici

                                    affresultat.text = ""
                                    l = 0
                                    lcont=0

                                    Clock.schedule_interval(self.affpas_a_pas, 0.1) 
                            else:
                                indicdmad= random.randint(0,3)
                                listefemme=['Wouw!!! Desolé Madame/Monsieur, au nom de la politesse à cette heure, il sied de se dire "Bonsoir" avant d aborder n importe quel probleme','Wouff !! Vraiment Madame/Monsieur, tu es serieux(se) de me donner une salutation à cette heure si c n est "Bonsoir" en terme de la politesse ?? ','Inconcevable Madame/Monsieur, comment tu veux supposer m aborder avec une salutation à cette heure si ce n est pas  "Bonsoir"','Ahh !! non pardon cher (e) Monsieur/Madame !! j ai droit à etre salué avant de tenir n importe quel discussion à ma personnalité, NB: à cette heure j attend rien d autre que  "Bonsoir']
                                mot=listefemme[indicdmad]

                                affresultat.text = ""
                                l = 0
                                lcont=0

                                Clock.schedule_interval(self.affpas_a_pas, 0.1)
                                
                        else:
                            pass
                    else:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Monsieur OpenAI detecte le manque son nom propre dans tes dires,\n pour ne pas l enerver, il faut utiliser le nom "Askyas" \nsuccedant le genre tels que : Mr,Monsieur '),size_hint=(None, None), size=(600,200))
                        msg.open()

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Monsieur OpenAI detecte le manque son genre dans tes dires,\npour ne pas l enerver, il faut utiliser les termes\nsuccedant la salutation tels que : Mr,Monsieur '),size_hint=(None, None), size=(600,200))
                    msg.open()

            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Monsieur OpenAI detecte le manque de salutation\ndans tes dires, par politesse, tout commence par :\nbonjour, bon_apres_midi ou soit bonsoir, veuillez '),size_hint=(None, None), size=(600,200))
                msg.open()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur intervenue'),size_hint=(None, None), size=(600,200))
            msg.open()
    
    def actualisergeneration(self,instance):
        global listplainte,kj

        listplainte=[]
        kj=0

        affresultat.text=""
        texp1.text=""

        #bgenererresulat.background_color="seagreen"
        labcompteur.text=""

        imgexpert.background_normal=''

        try:
            cadre.remove_widget(btsuitegenAI)
        except:
            pass

    def generesultatsuite(self,instance):
        global repsuite,debsessionheure

        listventeindividual=[]

        if instance.text=='[b]Oui[/b]':

            try:
                self.cconnexion()
                cursor=con.cursor()
                query="insert into controleur(id,datess,debut,finn) values(%s,%s,%s,%s)"
                dataa=(tidconn.text,datetime.now().strftime('%Y-%m-%d'),debsessionheure,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                cursor.execute(query,dataa)
                con.commit()
                self.cursor.close()
                con.close()

                l1=1

            except:

                l1=0
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees au controleur systeme'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                cursor=con.cursor()
                cursor.execute("delete from session where ids='"+tidconn.text+"'")
                con.commit()
                self.cursor.close()
                con.close()

                l2=1
            except:

                l2=0
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue car la session n a été supprimée comme prevue'),size_hint=(None, None), size=(400,200))
                msg.open()
            
            instance.text=='[b]Suite[/b]'

            try:
                cadre.remove_widget(instance)
            except:
                pass

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from achat where id_travailleur='"+ tidconn.text +"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                listventeindividual=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                self.exportateurvente("VENTE INDIVIDUELLE DES PRODUITS ",listventeindividual)

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , lors de le recupération des donnees à l indice voulu'),size_hint=(None, None), size=(400,200))
                msg.open()


            if l1==1 and l2==1:
                self.stop()
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text=' Erreur a été captée, c est une erreur qui cadre avec la fermeture de la session '),size_hint=(None, None), size=(400,200))
                msg.open()
 
        else:

            repsuite=1
            affresultat.text=''

            try:
                cadre.remove_widget(instance)
            except:
                pass

            Clock.schedule_interval(self.affpas_a_pas, 0.1)  
        

    def autre (self,instance):
        
        ki=ki+1

        if ki == "":#len(dec)-1:
            #try:
            instance.background_color="red"
            #labelement.text=dec[ki]
            #.replace("['","").replace("'","").replace("']","")

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select nom,categorie,anti,traite,posologie from produit where traite='"+labelement.text+"'")
            resultsgen=self.cursor.fetchone()
            self.cursor.close()
            con.close()
        
            if resultsgen:
                nom=resultsgen[0]
                categorie=resultsgen[1]
                anti=resultsgen[2]
                traite=resultsgen[3]
                posologie=resultsgen[4]

                #print("la ligne ",ki," : ",nom,categorie,anti,traite,posologie)
                #print(ki)
            
        else:
            instance.background_color="seagreen"
            #print("esili")
            ki=0         
        
    def affdonneesclaire(self,instance):

        if instance.background_normal=="vue cache.jpg":

            try:
                cadre.add_widget(cadbtsave)
            except:
                pass
                
            try:
                pass
                #cadre.add_widget(photoproduit)
            except:
                pass
            try:
                cadre.add_widget(t1)
            except:
                pass
            try:
                cadre.add_widget(t2)
            except:
                pass
            try:
                cadre.add_widget(t3)
            except:
                pass
            try:
                cadre.add_widget(t4)
            except:
                pass

            try:
                cadre.add_widget(t5)
            except:
                pass
            try:
                cadre.add_widget(t6)
            except:
                pass
            try:
                cadre.add_widget(t7)
            except:
                pass
            try:
                cadre.add_widget(t8)
            except:
                pass
            try:
                cadre.add_widget(t9)
            except:
                pass
            try:
                cadre.add_widget(t10)
            except:
                pass
            try:
                cadre.add_widget(tunitil)
            except:
                pass
            try:
                pass
                #cadre.add_widget(btncamera)
            except:
                pass

            
            try:
                cadre.add_widget(labremarque)
                cadre.add_widget(labremarque0)
            except:
                pass

            table.size_hint=(0.9,0.3)
            instance.background_normal="vue claire.jpg"

        elif instance.background_normal=="vue claire.jpg":

            try:
                cadre.remove_widget(cadbtsave)
            except:
                pass

            try:
                pass    
                #cadre.remove_widget(photoproduit)
            except:
                pass
            try:
                cadre.remove_widget(t1)
            except:
                pass
            try:
                cadre.remove_widget(t2)
            except:
                pass
            try:
                cadre.remove_widget(t3)
            except:
                pass
            try:
                cadre.remove_widget(t4)
            except:
                pass

            try:
                cadre.remove_widget(t5)
            except:
                pass
            try:
                cadre.remove_widget(t6)
            except:
                pass
            try:
                cadre.remove_widget(t7)
            except:
                pass
            try:
                cadre.remove_widget(t8)
            except:
                pass
            try:
                cadre.remove_widget(t9)
            except:
                pass
            try:
                cadre.remove_widget(t10)
            except:
                pass
            try:
                cadre.remove_widget(tunitil)
            except:
                pass
            try:
                cadre.remove_widget(btncamera)
            except:
                pass
            try:
                cadre.remove_widget(btncamera)
            except:
                pass

            
            try:
                cadre.remove_widget(labremarque)
                cadre.remove_widget(labremarque0)
            except:
                pass

            table.size_hint=(0.9,0.9)
            instance.background_normal="vue cache.jpg"

        
    def correcteur2(self,instance):
        global listplainte
        try:

            listplainte.append(instance.text + ",")
            
            listplainte=list(set(listplainte))
            #labelement.text=str(listplainte).replace("['","").replace("',","").replace("'","").replace("']","").replace("]","")
            
        except:
            pass

        try:
            tabnew=[]
            txtt1=texp1.text
            tabtext=txtt1.split()
            tabtext=list(tabtext)
            for i in range(len(tabtext)-1):
                tabnew.append(tabtext[i])
            tabnew.append(instance.text)

            texp1.text=""
            texp1.text=str(tabnew).replace("['","").replace("',","").replace("'","").replace("']","").replace("]","")
            texp1.focus=True
        except:
            pass    
 
    def correcteur3(self,instance):

        global listplainte
        try:
            listplainte.append(instance.text + ",")
            
            listplainte=list(set(listplainte))
            #labelement.text=str(listplainte).replace("['","").replace("',","").replace("'","").replace("']","").replace("]","")
            
        except:
            pass

        try:
            tabnew=[]
            txtt1=texp1.text
            tabtext=txtt1.split()
            tabtext=list(tabtext)
            for i in range(len(tabtext)-1):
                tabnew.append(tabtext[i])
            tabnew.append(instance.text)

            texp1.text=""
            texp1.text=str(tabnew).replace("['","").replace("',","").replace("'","").replace("']","").replace("]","")
            texp1.focus=True
        except:
            pass    
 
    def correcteur1(self,instance):

        global listplainte
        try:
            listplainte.append(instance.text + ",")

            listplainte=list(set(listplainte))
            #labelement.text=str(listplainte).replace("['","").replace("',","").replace("'","").replace("']","").replace("]","")
            
        except:
            pass

        try:
            tabnew=[]
            txtt1=texp1.text
            tabtext=txtt1.split()
            tabtext=list(tabtext)
            for i in range(len(tabtext)-1):
                tabnew.append(tabtext[i])
            tabnew.append(instance.text)

            texp1.text=""
            texp1.text=str(tabnew).replace("['","").replace("',","").replace("'","").replace("']","").replace("]","")
            texp1.focus=True
        except:
            pass    

    def separateurtexte(self,instance,value):
        global listeplainte

        if expcheck1.active==True:
            try:
                if len(instance.text)>=2:
                    textmot=instance.text
                    textx1=textmot.split()
                    indicevrai=textx1[len(textx1)-1]

                    if len(indicevrai)>=2:

                        bexpert1.text=""
                        bexpert2.text=""
                        bexpert3.text=""

                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select distinct traite from produit where traite LIKE'%"+indicevrai+"%' LIMIT 0,3")
                        listeplaint=self.cursor.fetchall()
                        self.cursor.close()
                        con.close()
                        if listeplaint:
                            try:
                                bexpert1.text=str(listeplaint[0]).replace("('","").replace("',)","")
                            except:
                                pass
                            try:
                                bexpert2.text=str(listeplaint[1]).replace("('","").replace("',)","")
                            except:
                                pass
                            try:
                                bexpert3.text=str(listeplaint[2]).replace("('","").replace("',)","")
                            except:
                                pass
                        
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:
            bexpert1.text=""
            bexpert2.text=""
            bexpert3.text=""

    def expch2(self,instance,value):
        if value:
            expcheck1.active=False
    def expch1(self,instance,value):
        if value:
            expcheck2.active=False

    def affnomclientjournal(self,instance,value):

        global selimprime

        tabventejournal.row_data=[]
        labtot2.text=""
        selimprime=1
        
        if instance.text=="Tous":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
     
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and Nom_client='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where  Nom_client='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def affidprodjournal(self,instance,value):
        tabventejournal.row_data=[]
        labtot2.text=""
        
        if instance.text=="Tous":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
     
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and ID_Produit='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and ID_Produit='"+instance.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def affdatejournal(self,instance,value):
        tabventejournal.row_data=[]
        labtot2.text=""
        #datform=datetime.strftime(instance.text,'%Y-%m-%d')
        
        if instance.text=="Aujourd hui":
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                self.cursor.close()
                con.close()
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select ID_Produit,nom,historique.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from historique,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and Dates='"+instance.text+"'")
                results=self.cursor.fetchall()
                tabventejournal.row_data=results
                self.cursor.close()
                con.close()
                
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from historique where id_travailleur='"+tidconn.text+"' and Dates='"+instance.text+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    labtot2.text=str(results[0])
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def rechnomclientjournal(self,instance):

        instance.text="choisir"

        if triercheckk4.active==True:
        
            if triercheck3.active==True:
                instance.values=("")
                j="Tous"
                instance.values.append(j)
                self.cconnexion()
                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Nom_client from achat where Nom_client LIKE'%"+tjourclientnom.text+"%' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                    results=self.cursor.fetchall()
                    #datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                    self.cursor.close()
                    con.close()
                    for  i in  results:
                        instance.values.append(str(i).replace("('","").replace("',)",""))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                    msg.open()
            else:
                instance.values=("")
                msg=Popup(title="STATUT REQUETE",content=Button(text="Impossible car le triage par Nom Client n a pas été autorisé"),size_hint=(None, None), size=(600,200))
                msg.open()

        elif triercheckk5.active==True:

            if triercheck3.active==True:
                instance.values=("")
                j="Tous"
                instance.values.append(j)
                self.cconnexion()
                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Nom_client from achat where Nom_client LIKE'%"+tjourclientnom.text+"%' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"' and id_travailleur='"+tidconn.text+"'")
                    results=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()
                    for  i in  results:
                        instance.values.append(str(i).replace("('","").replace("',)",""))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                    msg.open()
            else:
                instance.values=("")
                msg=Popup(title="STATUT REQUETE",content=Button(text="Impossible car le triage par Nom Client n a pas été autorisé"),size_hint=(None, None), size=(600,200))
                msg.open()

    def rechidjournal(self,instance):

        instance.text="choisir"

        if triercheck2.active==True:
            instance.values=("")
            j="Tous"
            instance.values.append(j)
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct ID_Produit from achat where ID_Produit LIKE'%"+tjourids.text+"%' and Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchall()
                #datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                self.cursor.close()
                con.close()
                for  i in  results:
                    instance.values.append(str(i).replace("('","").replace("',)",""))
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()
        else:
            instance.values=("")
            msg=Popup(title="STATUT REQUETE",content=Button(text="Impossible car le triage par ID Produit n a pas été autorisé"),size_hint=(None, None), size=(600,200))
            msg.open()

    def rechdatejournal(self,instance):

        instance.text="choisir"

        if triercheck1.active==True:
            instance.values=("")
            j="Aujourd hui"
            
            self.cconnexion()
            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct Dates from historique where id_travailleur='"+tidconn.text+"' order by Dates ASC")
                results=self.cursor.fetchall()
                datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                self.cursor.close()
                con.close()
                for  i in  datat:
                    instance.values.append(str(i))
                
                instance.values.append(j)
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text="l erreur survenue, veuillez ressayer plus tard "),size_hint=(None, None), size=(600,200))
                msg.open()
        else:
            instance.values=("")
            msg=Popup(title="STATUT REQUETE",content=Button(text="Impossible car le triage par date n a pas été autorisé"),size_hint=(None, None), size=(600,200))
            msg.open()
        
    def fchecktrie1(self,instance,value):
        if value:
            triercheck3.active=False
            triercheck2.active=False
            labtyp1.text="Date"
            

    def fchecktrie2(self,instance,value):
        if value:
            triercheck3.active=False
            triercheck1.active=False
            labtyp1.text="ID Produit"

    def fchecktrie3(self,instance,value):
        if value:
            triercheck1.active=False
            triercheck2.active=False  
            labtyp1.text="Nom Client"

    def fchecktrie4(self,instance,value):
        if value:
            triercheckk5.active=False  
            labtyp2.text="Frequentiel"
    def fchecktrie5(self,instance,value):
        if value:
            triercheckk4.active=False
            labtyp2.text="Sinusoidal"


    def affichevueclaire(self,instance):
        global verifsel

        if verifsel==0:
            if labvente.text=="[b]SUPER PHARMA[/b]":
                if instance.background_normal=="vue cache.jpg":
                    try:
                        cadre.add_widget(tquantite)
                    except:
                        pass
                    
                    try:
                        tabv.add_widget(lbv)
                        cadre.add_widget(tabv)
                        cadre.add_widget(bvente1)
                    except:
                        pass
                
                    try:
                        cadre.add_widget(bsystem)
                        cadre.add_widget(bjournal)
                        cadre.add_widget(bcoupcendr)
                    except:
                        pass

                    try:
                        cadre.add_widget(t1)
                        cadre.add_widget(t2)
                        cadre.add_widget(t3)
                        cadre.add_widget(t4)
                        cadre.add_widget(t5)
                        cadre.add_widget(t6)
                        cadre.add_widget(t7)
                        cadre.add_widget(t8)
                    except:
                        pass
                    
                    tabvente1.size_hint=(0.8,0.25)
                    instance.background_normal="vue claire.jpg"

                elif instance.background_normal=="vue claire.jpg":

                    try:
                        cadre.remove_widget(tquantite)
                    except:
                        pass
                    
                    try:
                        tabv.remove_widget(lbv)
                        cadre.remove_widget(tabv)
                        cadre.remove_widget(bvente1)
                    except:
                        pass
                
                    try:
                        cadre.remove_widget(bsystem)
                        cadre.remove_widget(bjournal)
                        cadre.remove_widget(bcoupcendr)
                    except:
                        pass

                    try:
                        cadre.remove_widget(t1)
                        cadre.remove_widget(t2)
                        cadre.remove_widget(t3)
                        cadre.remove_widget(t4)
                        cadre.remove_widget(t5)
                        cadre.remove_widget(t6)
                        cadre.remove_widget(t7)
                        cadre.remove_widget(t8)
                    except:
                        pass

                    tabvente1.size_hint=(0.8,0.8)
                    instance.background_normal="vue cache.jpg"
            elif labvente.text=="[b]JOURNAL D'OPERATION[/b]":

                if instance.background_normal=="vue cache.jpg":
                    
                    tabventejournal.pos_hint={'x':0.1,'y':0.58}
                    tabventejournal.size_hint=(0.8,0.32)
                    instance.background_normal="vue claire.jpg"
                    
                    
                elif instance.background_normal=="vue claire.jpg":

                    tabventejournal.size_hint=(0.8,0.8)
                    tabventejournal.pos_hint={'x':0.1,'y':0.1}
                    instance.background_normal="vue cache.jpg"


    def imprimefactureno(self,instance):
        global msgfac,msg

        labnetpayer.text="0"
        tabvente1.row_data=[]
        labnetpayer.color='black'

        try:
            msgfac.dismiss()
        except:
            pass
        try:
            msg.dismiss()
        except:
            pass

    def impreformok(self,instance):
        global chproff

        global n1,n2,n3,n4

        if chproff.active==True:


            listeprefo=[]
            listeprefonew=[]
        
                    
            try:

                listeprefo=tabvente1.row_data

                deb_lig=0
                fin_lig=len(listeprefo)

                deb_col=0
                fin_col=5

                for i in range(deb_lig,fin_lig):
                    soustab=listeprefo[i][1],listeprefo[i][4]

                    listeprefonew.append(soustab)

                for lignpref in listeprefonew:

                    a,b=lignpref

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into preforma(id_prod,qt,nom_client,date) values(%s,%s,%s,%s)"
                    dataa=(a,b,nomcclientprefo.text,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    cursor.execute(query,dataa)
                    con.commit()
                    self.cursor.close()
                    con.close()

                deb_pref=0
                finpref=len(listeprefo)

                listeprefok=[]

                for i in range(deb_pref,finpref):
                    ligv=listeprefo[i][2],listeprefo[i][3],listeprefo[i][4],listeprefo[i][5]

                    listeprefok.append(ligv)

                tab=listeprefok

                if len(tab)>=10:
                    largeur_px = 315
                    hauteur_px = 200+(15*len(tab))+30

                if len(tab)>1 and len(tab)<10:
                    largeur_px = 315
                    hauteur_px = 200+(15*len(tab))
                elif len(tab)==1:
                    largeur_px = 315
                    hauteur_px = 165

                largeur_pt = largeur_px * 0.75
                hauteur_pt = hauteur_px * 0.75

                c = canvas.Canvas("facture.pdf", pagesize=(largeur_pt, hauteur_pt))

                c.setFont('Helvetica',9)
                c.drawString(60,(hauteur_px-20)*0.75,n1) #'MERCIRAH PHARMA '
                c.drawString(33,(hauteur_px-40)*0.75,n2) #'RCCM KNM /RCCM/18-A-01 319'

                c.drawString(5,(hauteur_px-60)*0.75,n3)  #'N° IMPOT : A1702500M'
                c.drawString(110,(hauteur_px-60)*0.75,n4) #'ID NAT:01-G4701-N37871Z'

                c.drawString(5,(hauteur_px-80)*0.75,'ID_Trav')
                c.drawString(50,(hauteur_px-80)*0.75,tidconn.text)

                c.drawString(130,(hauteur_px-80)*0.75,'PRE-FACT N°: ')
                c.drawString(190,(hauteur_px-80)*0.75,str(random.randint(1,1500)))

                c.setFont('Helvetica',10)
                c.drawString(5,(hauteur_px-95)*0.75,'NOM')
                c.drawString(80,(hauteur_px-95)*0.75,'PU')
                c.drawString(120,(hauteur_px-95)*0.75,'QTE')
                c.drawString(160,(hauteur_px-95)*0.75,'PT')

                c.setFont('Helvetica',8)

                nom=""

                if len(nomcclientprefo.text)>10:
                    nom=nomcclientprefo.text[0:9]
                else:
                    nom=nomcclientprefo.text

                c.drawString(5,(hauteur_px-hauteur_px+15)*0.75,'Client(e)')
                c.drawString(50,(hauteur_px-hauteur_px+15)*0.75,nom)

                c.drawString(120,(hauteur_px-hauteur_px+35)*0.75,'NET')
                c.drawString(160,(hauteur_px-hauteur_px+35)*0.75,labnetpayer.text)

                c.drawString(120,(hauteur_px-hauteur_px+15)*0.75,'TVA')
                c.drawString(160,(hauteur_px-hauteur_px+15)*0.75,'0.15')

                c.line(2,(hauteur_px-84)*0.75,313,(hauteur_px-84)*0.75,)
                c.line(2,(hauteur_px-99)*0.75,313,(hauteur_px-99)*0.75,)

                haut=120

                for lig in tab:
                    x,y,t,u=lig

                    if len(x)>9:
                        xx=x[0:9]+"..."
                    else:
                        xx=x
                    
                    c.setFont('Helvetica',8)
                    c.drawString(5,(hauteur_px-haut)*0.75,xx)
                    c.drawString(80,(hauteur_px-haut)*0.75,str(y))
                    c.drawString(120,(hauteur_px-haut)*0.75,str(t))
                    c.drawString(160,(hauteur_px-haut)*0.75,str(u)) 

                    c.setFont('Helvetica',6)

                    c.drawString(5,(hauteur_px-hauteur_px+35)*0.75,'Kin, le '+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                    

                    haut+=20   

                c.save()

                license = pdf.License()
                viewer = pdf.facades.PdfViewer()

                viewer.bind_pdf("facture.pdf")

                viewer.print_document()
                    
                tabvente1.row_data=[]
                labnetpayer.text=str(0)
                labnetpayer.color='black'

                msg=Popup(title="STATUT REQUETE",content=Button(text='Absolu!!',color='white',background_color='blue'),background_color='blue',size_hint=(None, None), size=(400,200))
                msg.open()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors, veuillez ressayer plus tard'),size_hint=(None, None),background_color='blue', size=(400,200))
                msg.open()
            
            #try:

                #discourant=os.path.dirname(__file__)

                    #chfichier=os.path.join(discourant,"préforma.xlsx")

                    #try:
                        #   os.remove(chfichier)
                    #except:
                        #   pass
                    #wb=Workbook()

                    #feuille=wb.active

                    #feuille.append([".","MERCIRA",".","PHARMA","."])
                    #feuille.append(["RCCM","KNM/","RCCM/18","/18-A-01","319"])
                    #feuille.append([".",".",".","PreFac.","Ref:"+str(random.randint(0,300))])
                    #feuille.append(["ID","Nom","PU","Qte","PT"])

                    #listeprefoknew=[]
                    
                    #for ligg in listeprefok:
                        
                        #   a,b,c,d,e=ligg
                        #  k=str(b[:6])+".."
                        # liggnew=a,k,c,d,e

                        #   listeprefoknew.append(liggnew)
                    
                    #for ligne in listeprefoknew:
                        #   feuille.append(ligne)
                    
                    #feuille.append(["-","-","-","NET",labnetpayer.text])
                    #feuille.append(["-","-","-","Trav_ID:",tidconn.text])
                    #feuille.append(["-----","-----","------","-------","------"])
                    #feuille.append(["Client(e)",nomcclientprefo.text,"kin,le",str(datetime.now().strftime('%m-%d')),str(datetime.now().strftime('%H:%M:%S'))])
                    
                #try:
                    #   wb.save(chfichier) 

                    #  excel_image = self.excel_to_image(chfichier)
                        
                    # excel_image.save('preforma.jpeg')

                    
                    #msg=Popup(title="ETAT CONNEXION",content=Button(text='Impression encours !!'),background_color='blue',size_hint=(None, None), size=(500,200))
                    #msg.open()

                #printres=win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL,None,1)
                #fills='preforma.jpeg'

                #printer_name = win32print.GetDefaultPrinter()

                #file_handle=open(fills,'rb')
                #print_handle=win32print.OpenPrinter(printer_name)

                #job_info=win32print.StartDocPrinter(print_handle,1,(fills,None,"RAW"))

                #win32print.StartPagePrinter(print_handle)

                #win32print.WritePrinter(print_handle,file_handle.read())
                #win32print.EndPagePrinter(print_handle)
                #win32print.EndDocPrinter(print_handle)

                #win32print.ClosePrinter(print_handle)
                #file_handle.close()

            #except:
             #   msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur de l impression'),size_hint=(None, None), size=(400,200))
              #  msg.open()
        else:

            listeprefo=[]
            listeprefonew=[]
        
            try:

                listeprefo=tabvente1.row_data

                deb_lig=0
                fin_lig=len(listeprefo)

                deb_col=0
                fin_col=5

                for i in range(deb_lig,fin_lig):
                    soustab=listeprefo[i][1],listeprefo[i][4]

                    listeprefonew.append(soustab)

                for lignpref in listeprefonew:

                    a,b=lignpref

                    self.cconnexion()
                    cursor=con.cursor()
                    query="insert into preforma(id_prod,qt,nom_client,date) values(%s,%s,%s,%s)"
                    dataa=(a,b,nomcclientprefo.text,datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    cursor.execute(query,dataa)
                    con.commit()
                    self.cursor.close()
                    con.close()
                
                msg=Popup(title="STATUT REQUETE",content=Button(text='Souche etabie avec succes'),size_hint=(None, None), size=(400,200))
                msg.open()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='ERROR'),size_hint=(None, None), size=(400,200))
                msg.open()


    def impressionprofessionnelle(self):
        global msgimpre

        global n1,n2,n3,n4

        listeprefo=[]
        listeprefonew=[]
        net=0
        ii=""
        
        try:
            listeprefo=tabventejournal.row_data

            for lignnn in listeprefo:
                a,b,ff,d,e,f,g,h,ii=lignnn

                net+=int(e)

            deb_lig=0
            fin_lig=len(listeprefo)

            deb_col=0
            fin_col=5

            for i in range(deb_lig,fin_lig):
                soustab=listeprefo[i][1],listeprefo[i][4]

                listeprefonew.append(soustab)

            deb_pref=0
            finpref=len(listeprefo)

            listeprefok=[]

            for i in range(deb_pref,finpref):
                ligv=listeprefo[i][1],listeprefo[i][2],listeprefo[i][3],listeprefo[i][4]

                listeprefok.append(ligv)

            tab=listeprefok

            if len(tab)>=10:
                largeur_px = 800 #315
                hauteur_px = 500+(15*len(tab))+30

            if len(tab)>1 and len(tab)<10:
                largeur_px = 800
                hauteur_px = 500+(15*len(tab))
            elif len(tab)==1:
                largeur_px = 800
                hauteur_px = 500


            largeur_pt = largeur_px * 0.75
            hauteur_pt = hauteur_px * 0.75



            c = canvas.Canvas("facturePro.pdf", pagesize=(largeur_pt, hauteur_pt))

            c.setFont('Helvetica',14)
            c.drawString(250,(hauteur_px-20)*0.75,n1) #'MERCIRAH PHARMA '
            c.drawString(150,(hauteur_px-50)*0.75,n2) #'RCCM KNM /RCCM/18-A-01 319'

            c.drawString(300,(hauteur_px-75)*0.75,n3)#'N° IMPOT : A1702500M'
            c.drawString(80,(hauteur_px-75)*0.75,n4)#'ID NAT:01-G4701-N37871Z'

            c.drawString(30,(hauteur_px-115)*0.75,'ID_Trav')
            c.drawString(100,(hauteur_px-115)*0.75,str(ii))

            c.drawString(350,(hauteur_px-115)*0.75,'FACTURE N°: ')
            c.drawString(500,(hauteur_px-115)*0.75,str(random.randint(1,1500)))

            c.setFont('Helvetica',13)
            c.drawString(30,(hauteur_px-140)*0.75,'NOM')
            c.drawString(200,(hauteur_px-140)*0.75,'PU')
            c.drawString(300,(hauteur_px-140)*0.75,'QTE')
            c.drawString(450,(hauteur_px-140)*0.75,'PT')

            c.setFont('Helvetica',12)

            nom=""

            if len(combnomclient.text)>10:
                nom=combnomclient.text[0:9]
            else:
                nom=combnomclient.text

            c.drawString(80,(hauteur_px-hauteur_px+15)*0.75,'Client(e)')
            c.drawString(150,(hauteur_px-hauteur_px+15)*0.75,nom)

            c.drawString(300,(hauteur_px-hauteur_px+40)*0.75,'NET')
            c.drawString(450,(hauteur_px-hauteur_px+40)*0.75,str(net))

            c.drawString(300,(hauteur_px-hauteur_px+20)*0.75,'TVA')
            c.drawString(450,(hauteur_px-hauteur_px+20)*0.75,'0.15')

            c.line(2,(hauteur_px-125)*0.75,800,(hauteur_px-125)*0.75,)
            c.line(2,(hauteur_px-145)*0.75,800,(hauteur_px-145)*0.75,)

            haut=160
            xx=""

            for lig in tab:
                x,y,t,u=lig

                if len(x)>9:
                    xx=x[0:9]+"..."
                else:
                    xx=x
                
                c.setFont('Helvetica',11)
                c.drawString(20,(hauteur_px-haut)*0.75,xx)
                c.drawString(190,(hauteur_px-haut)*0.75,str(y))
                c.drawString(300,(hauteur_px-haut)*0.75,str(t))
                c.drawString(450,(hauteur_px-haut)*0.75,str(u)) 

                c.setFont('Helvetica',10)

                c.drawString(100,(hauteur_px-hauteur_px+50)*0.75,'Kin, le '+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

                haut+=35   

            c.save()

            
            labnetpayer.text="0"
            tabvente1.row_data=[]
            labnetpayer.color='black'

            try:
                msgimpre.dismiss()
            except:
                pass

            try:
                webbrowser.open("facturePro.pdf")
            except:
                pass

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Le Generateur de Facture a echoué'),size_hint=(None, None), size=(400,200))
            msg.open()

    def impressionfacjournal(self):
        global n1,n2,n3,n4,msgimpre

        listeprefo=[]
        listeprefonew=[]
        net=0
        ii=""

        

        try:
            listeprefo=tabventejournal.row_data

            for lignnn in listeprefo:
                a,b,ff,d,e,f,g,h,ii=lignnn

                net+=int(e)

            deb_lig=0
            fin_lig=len(listeprefo)

            deb_col=0
            fin_col=5

            for i in range(deb_lig,fin_lig):
                soustab=listeprefo[i][1],listeprefo[i][4]

                listeprefonew.append(soustab)

            deb_pref=0
            finpref=len(listeprefo)

            listeprefok=[]

            for i in range(deb_pref,finpref):
                ligv=listeprefo[i][1],listeprefo[i][2],listeprefo[i][3],listeprefo[i][4]

                listeprefok.append(ligv)

            tab=listeprefok

            if len(tab)>=10:
                largeur_px = 315
                hauteur_px = 200+(15*len(tab))+30

            if len(tab)>1 and len(tab)<10:
                largeur_px = 315
                hauteur_px = 200+(15*len(tab))
            elif len(tab)==1:
                largeur_px = 315
                hauteur_px = 165


            largeur_pt = largeur_px * 0.75
            hauteur_pt = hauteur_px * 0.75

            c = canvas.Canvas("facturev.pdf", pagesize=(largeur_pt, hauteur_pt))

            c.setFont('Helvetica',9)
            c.drawString(60,(hauteur_px-20)*0.75,n1) #'MERCIRAH PHARMA '
            c.drawString(33,(hauteur_px-40)*0.75,n2) #'RCCM KNM /RCCM/18-A-01 319'

            c.drawString(5,(hauteur_px-60)*0.75,n3)#'N° IMPOT : A1702500M'
            c.drawString(110,(hauteur_px-60)*0.75,n4)#'ID NAT:01-G4701-N37871Z'

            c.drawString(5,(hauteur_px-80)*0.75,'ID_Trav')
            c.drawString(50,(hauteur_px-80)*0.75,str(ii))

            c.drawString(130,(hauteur_px-80)*0.75,'FACTURE N°: ')
            c.drawString(195,(hauteur_px-80)*0.75,str(random.randint(1,1500)))

            c.setFont('Helvetica',10)
            c.drawString(5,(hauteur_px-95)*0.75,'NOM')
            c.drawString(80,(hauteur_px-95)*0.75,'PU')
            c.drawString(120,(hauteur_px-95)*0.75,'QTE')
            c.drawString(160,(hauteur_px-95)*0.75,'PT')

            c.setFont('Helvetica',8)

            nom=""

            if len(combnomclient.text)>10:
                nom=combnomclient.text[0:9]
            else:
                nom=combnomclient.text

            c.drawString(5,(hauteur_px-hauteur_px+15)*0.75,'Client(e)')
            c.drawString(50,(hauteur_px-hauteur_px+15)*0.75,nom)

            c.drawString(120,(hauteur_px-hauteur_px+30)*0.75,'NET')
            c.drawString(160,(hauteur_px-hauteur_px+30)*0.75,str(net))

            c.drawString(120,(hauteur_px-hauteur_px+11)*0.75,'TVA')
            c.drawString(160,(hauteur_px-hauteur_px+10)*0.75,'0.15')

            c.line(2,(hauteur_px-84)*0.75,313,(hauteur_px-84)*0.75,)
            c.line(2,(hauteur_px-99)*0.75,313,(hauteur_px-99)*0.75,)

            haut=120
            xx=""

            for lig in tab:
                x,y,t,u=lig

                if len(x)>9:
                    xx=x[0:9]+"..."
                else:
                    xx=x
                
                c.setFont('Helvetica',8)
                c.drawString(5,(hauteur_px-haut)*0.75,xx)
                c.drawString(80,(hauteur_px-haut)*0.75,str(y))
                c.drawString(120,(hauteur_px-haut)*0.75,str(t))
                c.drawString(160,(hauteur_px-haut)*0.75,str(u)) 

                c.setFont('Helvetica',6)

                c.drawString(5,(hauteur_px-hauteur_px+30)*0.75,'Kin, le '+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

                haut+=20   

            c.save()

            license = pdf.License()
            viewer = pdf.facades.PdfViewer()

            viewer.bind_pdf("facturev.pdf")

            viewer.print_document()

            labnetpayer.text="0"
            tabvente1.row_data=[]
            labnetpayer.color='black'

            bt=Builder.load_string('''

Button:
    text:'Impression encours...!!'
    color:'black'
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
            
            ''')

            msg=Popup(title="STATUT REQUETE",content=bt,size_hint=(.5,.3))
            msg.open()

            try:
                msgimpre.dismiss()
            except:
                pass

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Le Generateur de Facture a echoué'),size_hint=(None, None), size=(400,200))
            msg.open()
  
    def imprimerfacture(self,instance):

        global n1,n2,n3,n4,msgimpre

        global msgfac,suitsavepriseuser
        
        listeprefo=[]
        listeprefonew=[]

    
        try:
            listeprefo=tabvente1.row_data
            deb_lig=0
            fin_lig=len(listeprefo)

            deb_col=0
            fin_col=5

            for i in range(deb_lig,fin_lig):
                soustab=listeprefo[i][1],listeprefo[i][4]

                listeprefonew.append(soustab)

            deb_pref=0
            finpref=len(listeprefo)

            listeprefok=[]

            for i in range(deb_pref,finpref):
                ligv=listeprefo[i][2],listeprefo[i][3],listeprefo[i][4],listeprefo[i][5]

                listeprefok.append(ligv)

            tab=listeprefok

            if len(tab)>=10:
                largeur_px = 315
                hauteur_px = 200+(15*len(tab))+30

            if len(tab)>1 and len(tab)<10:
                largeur_px = 315
                hauteur_px = 200+(15*len(tab))
            elif len(tab)==1:
                largeur_px = 315
                hauteur_px = 165

            largeur_pt = largeur_px * 0.75
            hauteur_pt = hauteur_px * 0.75

            c = canvas.Canvas("facturev.pdf", pagesize=(largeur_pt, hauteur_pt))

            c.setFont('Helvetica',9)
            c.drawString(60,(hauteur_px-20)*0.75,n1)#'MERCI PHARMA'
            c.drawString(33,(hauteur_px-40)*0.75,n2)  #'RCCM KNM /RCCM/18-A-01 319'

            c.drawString(5,(hauteur_px-60)*0.75,n3)   #'N° IMPOT : A1702500M'
            c.drawString(110,(hauteur_px-60)*0.75,n4)  #'ID NAT:01-G4701-N37871Z'

            c.drawString(5,(hauteur_px-80)*0.75,'ID_Trav')
            c.drawString(50,(hauteur_px-80)*0.75,tidconn.text)

            c.drawString(130,(hauteur_px-80)*0.75,'FACTURE N°: ')
            c.drawString(195,(hauteur_px-80)*0.75,str(random.randint(1,1500)))

            c.setFont('Helvetica',10)
            c.drawString(5,(hauteur_px-95)*0.75,'NOM')
            c.drawString(80,(hauteur_px-95)*0.75,'PU')
            c.drawString(120,(hauteur_px-95)*0.75,'QTE')
            c.drawString(160,(hauteur_px-95)*0.75,'PT')

            c.setFont('Helvetica',8)

            nom=""

            if suitsavepriseuser.active==True:

                txtnom.text=comchoix.text

            else:
                
                txtnom.text=txtnom.text

            if len(txtnom.text)>10:
                nom=txtnom.text[0:9]
            else:
                nom=txtnom.text

            c.drawString(5,(hauteur_px-hauteur_px+15)*0.75,'Client(e)')
            c.drawString(50,(hauteur_px-hauteur_px+15)*0.75,nom)

            c.drawString(120,(hauteur_px-hauteur_px+35)*0.75,'NET')
            c.drawString(160,(hauteur_px-hauteur_px+35)*0.75,labnetpayer.text)

            c.drawString(120,(hauteur_px-hauteur_px+15)*0.75,'TVA')
            c.drawString(160,(hauteur_px-hauteur_px+15)*0.75,'0.15')

            c.line(2,(hauteur_px-84)*0.75,313,(hauteur_px-84)*0.75,)
            c.line(2,(hauteur_px-99)*0.75,313,(hauteur_px-99)*0.75,)

            haut=120

            for lig in tab:
                x,y,t,u=lig

                if len(x)>9:
                    xx=x[0:9]+"..."
                else:
                    xx=x
                
                c.setFont('Helvetica',8)
                c.drawString(5,(hauteur_px-haut)*0.75,xx)
                c.drawString(80,(hauteur_px-haut)*0.75,str(y))
                c.drawString(120,(hauteur_px-haut)*0.75,str(t))
                c.drawString(160,(hauteur_px-haut)*0.75,str(u)) 

                c.setFont('Helvetica',6)

                c.drawString(5,(hauteur_px-hauteur_px+35)*0.75,'Kin, le '+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
                

                haut+=20   

            c.save()

            license = pdf.License()
            viewer = pdf.facades.PdfViewer()

            viewer.bind_pdf("facturev.pdf")

            viewer.print_document()

            labnetpayer.text="0"
            tabvente1.row_data=[]
            labnetpayer.color='black'

            try:
                msgfac.dismiss()
            except:
                pass
            

            try:
                msgimpre.dismiss()
            except:
                pass

            bt=Builder.load_string('''

Button:
    text:'Impression encours...!!'
    color:'black'
    background_color:[0,0,0,0]

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255

        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
            
            ''')

            msg=Popup(title="STATUT REQUETE",content=bt,size_hint=(.5,.4))
            msg.open()

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Le Generateur de Facture a echoué'),size_hint=(None, None), size=(400,200))
            msg.open()
  
    def enregistrecoupon(self,instance):
        global num,netpayer,msg,txtnom,daatts,daattimes,tidconn,quantiterestant,listeqt,datemodel,imprr,labnetpayer,txtnom
        global msgfac

        global lbnom,trechlike,comchoix,cadd,tnomdocta,suitsavepriseuser

        if suitsavepriseuser.active==True:
            
            if imprr.active==True:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                msg.dismiss()

                datatot=tabvente1.row_data
                i=0

                if datemodel<datetime.now():
                
                    datemodel=datetime.now()

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,comchoix.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                    self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="insert into prescription(id_prise,id_achat,docteur,datees) values(%s,%s,%s,%s)"
                                    dataa=(comchoix.text,daattimes,tnomdocta.text,daatts)
                                    cursor.execute(query,dataa)
                                    con.commit()
                                    self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d'imortalisation de la prise en charge"),size_hint=(None, None), size=(600,200))
                                    msg.open()

                            
                            
                            cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                            labb1a=Label(text=" le (s) produit (s) vendu avec succces\nVoulez-vous Imprimer la Facture !",font_size='20sp',pos_hint={'center_x':0.5,'center_y':0.5},color='black',size_hint=(0.8,0.3))
                            bbb1=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.6,'center_y':0.1}
    size_hint:0.25,0.15
    markup:True
    color:'white'  

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

                            ''')
                            
                            bbb1.bind(on_release=self.imprimerfacture)

                            bbb2=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.1}
    size_hint:0.25,0.15
    markup:True
    color:'white'


    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
                            bbb2.bind(on_release=self.imprimefactureno)

                            try:
                                cad.add_widget(labb1a)
                                cad.add_widget(bbb1)
                                cad.add_widget(bbb2)
                            except:
                                pass

                            msgfac=Popup(title="STATUT REQUETE",content=cad,size_hint=(None, None), size=(500,200),background_color="blue")
                            msgfac.open()
                            
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()
            
            else:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                msg.dismiss()

                datatot=tabvente1.row_data
                i=0

                
                if datemodel<datetime.now():

                    datemodel=datetime.now()
                    

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,comchoix.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                    self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="insert into prescription(id_prise,id_achat,docteur,datees) values(%s,%s,%s,%s)"
                                    dataa=(comchoix.text,daattimes,tnomdocta.text,daatts)
                                    cursor.execute(query,dataa)
                                    con.commit()
                                    self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d'imortalisation de la prise en charge"),size_hint=(None, None), size=(600,200))
                                    msg.open()

                            msg=Popup(title="STATUT REQUETE",content=Button(text="le (s) produit (s) vendu avec succces"),size_hint=(None, None), size=(600,200))
                            msg.open()

                            labnetpayer.text="0"
                            tabvente1.row_data=[]
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()

        else:

            if imprr.active==True:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                msg.dismiss()

                datatot=tabvente1.row_data
                i=0

                if datemodel<datetime.now():
                
                    datemodel=datetime.now()

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,txtnom.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                    self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()
                            
                            cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                            labb1a=Label(text=" le (s) produit (s) vendu avec succces \nVoulez-vous Imprimer la Facture !",font_size='20sp',pos_hint={'center_x':0.5,'center_y':0.5},color='black',size_hint=(0.8,0.3))
                            
                            bbb1=Builder.load_string('''

Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.6,'center_y':0.1}
    size_hint:0.25,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]            
''')     
                            bbb1.bind(on_release=self.imprimerfacture)

                            bbb2=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.1}
    size_hint:0.25,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]            
''')  
                            
                            bbb2.bind(on_release=self.imprimefactureno)

                            try:
                                cad.add_widget(labb1a)
                                cad.add_widget(bbb1)
                                cad.add_widget(bbb2)
                            except:
                                pass

                            msgfac=Popup(title="STATUT REQUETE",content=cad,size_hint=(None, None), size=(500,200),background_color="blue")
                            msgfac.open()
                            
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()
            
            else:

                idprod=""
                qtprod=""
                puprod=""
                ptprod=""
                qtnew=0

                msg.dismiss()

                datatot=tabvente1.row_data
                i=0

                
                if datemodel<datetime.now():

                    datemodel=datetime.now()
                    

                    if tabvente1.row_data:
                            
                        try:

                            for indice,i in enumerate(datatot):

                                differencee=None

                                ligne=i

                                idprod=ligne[1]
                                puprod=ligne[3]
                                qtprod=ligne[4]
                                ptprod=ligne[5]

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                                dataa=(idprod,puprod,qtprod,ptprod,txtnom.text,daatts,daattimes,tidconn.text)
                                cursor.execute(query,dataa)
                                con.commit()
                                self.cursor.close()
                                con.close()


                                self.cconnexion()
                                self.cursor=con.cursor()
                                self.cursor.execute("select SUM(Qte), stock-(select SUM(Qte) from achat where ID_Produit='"+idprod+"') from achat,produit where matricule=ID_Produit and ID_Produit='"+idprod+"'") #and id_travailleur='"+tidconn.text+"'
                                resultss=self.cursor.fetchone()
                                self.cursor.close()
                                con.close()

                                if resultss:
                                    som=resultss[0]
                                    differencee=resultss[1]                
                                
                                try:
                                    self.cconnexion()
                                    cursor=con.cursor()
                                    query="update produit set stock_p=%s where matricule=%s"
                                    cursor.execute(query,(differencee,idprod))
                                    con.commit()
                                    self.cursor.close()
                                    con.close()
                                except:
                                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d ajustement de stock systeme pour le produit : " + idprod),size_hint=(None, None), size=(600,200))
                                    msg.open()

                            msg=Popup(title="STATUT REQUETE",content=Button(text="le (s) produit (s) vendu avec succces"),size_hint=(None, None), size=(600,200))
                            msg.open()

                            labnetpayer.text="0"
                            tabvente1.row_data=[]
                        except: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur survenue, veuillez ressayer plus tard"),size_hint=(None, None), size=(600,200))
                            msg.open()
                            
                    num=0
                    netpayer=0

                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text="Erreur d Horloge , veuillez regler bien votre date et ressayer plus tard"),size_hint=(None, None), size=(600,200))
                    msg.open()
                        
    def recuperationnomclient(self,instance):
        global msg,daatts,daattimes,imprr

        global lbnom,txtnom,trechlike,comchoix,cadd,tnomdocta,suitsavepriseuser

        if suitsavepriseuser.active==True:

            if comchoix.text=="Choisir" or tnomdocta.text=="":

                btxx=Builder.load_string('''
Button:
    text:" Choisissez l'adresse Gmail correctement, puis Saisissez le nom du docteur consultant !!"
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                    
''')
                msg=Popup(title="ERROR",content=btxx,size_hint=(.7,.25))
                msg.open()
            
            else:
                cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                labb1=Label(text="voulez vous vraiment confirmer cette opération??\n(repondez par Oui ou Non)",font_size='18sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.5,0.15))
                bb1=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                
''')
                bb1.bind(on_release=self.confirsuppressoff)

                labimpp=Label(text="[b]Imprimer[b]",font_size='18sp',pos_hint={'x':0.6,'y':0.8},color='black',size_hint=(0.1,0.15),markup=True)
                imprr=CheckBox(pos_hint={'x':0.8,'y':0.8},size_hint=(0.05,0.05),active=True)
                
                
                bb2=Builder.load_string('''

Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.8,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
''')
                
                bb2.bind(on_release=self.enregistrecoupon)

                try:
                    cad.add_widget(labb1)
                    cad.add_widget(bb2)
                    cad.add_widget(bb1)
                    cad.add_widget(imprr)
                    cad.add_widget(labimpp)
                except:
                    pass

                msg=Popup(title="Confirmation",content=cad,size_hint=(None, None), size=(600,200))
                msg.open()

                daatts=datetime.now().strftime('%Y-%m-%d')
                daattimes=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
        else:

            if txtnom.text !="":

                msg.dismiss()

                if txtnom.text.upper()=="GLOBAL":

                    btxx=Builder.load_string('''
Button:
    text:"MOT RESERVE !!, Veuillez changer le nom"
    background_color:[0,0,0,0]
    color:'black'

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                    
''')
                    msg=Popup(title="STATUT REQUETE",content=btxx,size_hint=(None, None), size=(600,200))
                    msg.open()
                else:

                    cad=Builder.load_string('''          
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

                    labb1=Label(text="voulez vous vraiment confirmer cette opération??\n(repondez par Oui ou Non)",font_size='18sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.5,0.15))
                    bb1=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
                    
''')
                    bb1.bind(on_release=self.confirsuppressoff)

                    labimpp=Label(text="[b]Imprimer[b]",font_size='18sp',pos_hint={'x':0.6,'y':0.8},color='black',size_hint=(0.1,0.15),markup=True)
                    imprr=CheckBox(pos_hint={'x':0.8,'y':0.8},size_hint=(0.05,0.05),active=True)
                    
                    
                    bb2=Builder.load_string('''

Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.8,'center_y':0.25}
    size_hint:0.2,0.15
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
''')
                    
                    bb2.bind(on_release=self.enregistrecoupon)

                    try:
                        cad.add_widget(labb1)
                        cad.add_widget(bb2)
                        cad.add_widget(bb1)
                        cad.add_widget(imprr)
                        cad.add_widget(labimpp)
                    except:
                        pass

                    msg=Popup(title="Confirmation",content=cad,size_hint=(None, None), size=(600,200))
                    msg.open()

                    daatts=datetime.now().strftime('%Y-%m-%d')
                    daattimes=datetime.now().strftime('%Y-%m-%d %H:%M:%S')


    def prisechargemode(self,instance):
        global lbnom,txtnom,trechlike,comchoix,cadd,tnomdocta

        if instance.active==True:

            try:
                cadd.remove_widget(txtnom)
                cadd.remove_widget(lbnom)
                
            except:
                pass
        
            try:
                cadd.add_widget(comchoix)
                cadd.add_widget(trechlike)
                cadd.add_widget(tnomdocta)
            except:
                pass

        else:

            try:
                cadd.add_widget(txtnom)
                cadd.add_widget(lbnom)
                
            except:
                pass

            try:
                cadd.remove_widget(comchoix)
                cadd.remove_widget(trechlike)
                cadd.remove_widget(tnomdocta)
                
            except:
                pass


    def validecoupon(self,instance):
        global msg,txtnom,verifsel,lbnom,trechlike,comchoix,cadd,tnomdocta,suitsavepriseuser

        cadd=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')

        if verifsel==0:

            labrienxx=Label(text="Prise en charge",color='black',pos_hint={'x':.65,'y':.85} ,size_hint=(.2,.1))

            cadresuitchmorruser=Builder.load_string('''
FloatLayout:
    size_hint:.1,.2
    pos_hint: {'x':.85,'y':.825}  
                                                                                                        
    canvas.before:
        Color:
            rgb:168/255,168/255,168/255 #202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''')

            suitsavepriseuser=Builder.load_string('''
MDSwitch:
    pos_hint: {'center_x': .5, 'center_y': .5}
    color_active:'blue'
    active:False
    on_active:app.prisechargemode(self)
''')
            
            try:
                cadresuitchmorruser.add_widget(suitsavepriseuser)
            except:
                pass

            lbnom=Label(text="[b]Nom du client[b]",font_size='18sp',pos_hint={'center_x':0.2,'center_y':0.4},color='black',size_hint=(0.1,0.1),markup=True)
            txtnom=TextInput(font_size='18sp',pos_hint={'center_x':0.6,'center_y':0.45},size_hint=(0.5,0.25))
            

            trechlike=MDTextField(hint_text="Recherche via Gmail",pos_hint={'x':.05,'center_y':.5},size_hint=(.4,.2), icon_right='gmail')
            tnomdocta=MDTextField(hint_text="Docteur Consultant",pos_hint={'x':.05,'center_y':.15},size_hint=(.4,.2), icon_right='text')
            
            comchoix=Builder.load_string('''
Spinner:
    text:"Choisir"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.55,'center_y':0.5}
    size_hint:(0.4,0.16)
    bold:True
    color:'white'

    canvas.before:

        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            
            size:self.size
            pos:self.pos

            radius:[15]    
''')
            comchoix.bind(on_release=self.chargegmailprise)

            bbval1=Builder.load_string('''
Button:
    text:"[b]Suivant[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.85,'center_y':0.15}
    size_hint:(0.15,0.16)
    markup:True
    color:'white'

    canvas.before:

        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            
            size:self.size
            pos:self.pos

            radius:[15]    
''')
            
            
            bbval1.bind(on_release=self.recuperationnomclient)

            try:
                cadd.add_widget(labrienxx)
                cadd.add_widget(cadresuitchmorruser)
            except:
                pass

            try:
                cadd.add_widget(lbnom)
                cadd.add_widget(txtnom)
                cadd.add_widget(bbval1)
            except:
                pass

            msg=Popup(title="RECUPERATION",content=cadd,size_hint=(None, None), size=(600,200))
            msg.open()

    def retirecoup(self,instance):
        global retetat,verifsel

        if verifsel==0:
        
            try:
                retetat=1
                bretireelementcoupon.background_color="red"
            except:
                pass

    def retirecoupon(self,instance_table,current_row):
        global retetat,num,netpayer,listeqt
        listeqtfaux=[]
        i=0
        k=0
        j=0

        if retetat==1:
            try:
                for i in range(len(listeqt)-1):
                    listeqtfaux.append(listeqt[i])

                listeqt=[]
                listeqt=listeqtfaux

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            datatott=tabvente1.row_data
            
            try:
                if tabvente1.row_data:
                    
                    #for indice,k in enumerate(datatott):
                    #    j=indice
                
                    selll=current_row[0]
                    selll=int(selll)

                    suprelement=tabvente1.row_data.pop(selll-1)

                    retetat=0
                    bretireelementcoupon.background_color=[0,0,1,1]

                    netpayer=netpayer-float(suprelement[5])

                    labnetpayer.text=str(math.ceil(netpayer))

                    try:
                        t1.text=suprelement[1]
                        t2.text=suprelement[2]
                        t8.text=suprelement[3]
                        tquantite.text=suprelement[4]
                    except:
                        pass

                    t3.text="-"
                    t4.text="-"
                    t5.text="-"
                    t6.text="-"
                    t7.text="-"

                    couponnew=[]

                    ik=1

                    for lign in datatott:
                        if ik <= len(datatott):
                    
                            new_tuple =(ik,) + lign[1:]

                            ik+=1

                        couponnew.append(new_tuple)

                        tabvente1.row_data=[]
                        tabvente1.row_data=couponnew
                        
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def suprimercoupon(self,instance):
        global netpayer,msg,num,verifsel

        cad=Builder.load_string('''
            
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[1,1,10,10]            
''')


        if verifsel==0:

            labb1=Label(text="voulez vous vraiment confirmer cette opération??\n(repondez par Oui ou Non)",font_size='18sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.5,0.15))
            bb1=Builder.load_string('''
Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.3,'center_y':0.25}
    size_hint:(0.1,0.2)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')
            
            
            bb1.bind(on_release=self.confirsuppressoff)
            
            bb2=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.8,'center_y':0.25}
    size_hint:(0.1,0.2)
    markup:True
    color:'white'
    
    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[10]
            
''')
            
            
            bb2.bind(on_release=self.confirsuppression)

            try:
                cad.add_widget(labb1)
                cad.add_widget(bb2)
                cad.add_widget(bb1)

                
                msg=Popup(title="Confirmation",content=cad,size_hint=(None, None), size=(600,200))
                msg.open()
                num=0
                labnetpayer.text="0"

            except:
                pass

    def confirsuppressoff(self,instance):
        global msg
        msg.dismiss()

    def confirsuppression(self,instance):
        global netpayer,msg,bb2,listeqt
        netpayer=0
        labnetpayer.text=str(netpayer)

        t1.text=""
        t2.text=""
        t3.text=""
        t4.text=""
        t5.text=""
        t6.text=""
        t7.text=""
        t8.text=""
        t9.text=""
        t10.text=""

        try:

            listeqt=[]

        except:
            pass

        try:
            tabvente1.row_data=[]
            msg.dismiss()
        except:
            pass

    def recherchventeproduitspinneur(self,instance,value):
        t1.text=""
        t2.text=""
        t3.text=""
        t4.text=""
        t5.text=""
        t6.text=""
        t7.text=""
        t8.text=""
        t9.text=""
        t10.text=""

        t8.hint_text="Prix unitaire CDF"

        try:
            if int(taux.text)>0:
                
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="select * from produit where nom='"+instance.text+"'"
                    cursor.execute(query)
                    results=cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        t1.text=results[0]
                        t2.text=results[1]
                        t3.text=results[2]
                        t4.text=results[3]
                        t5.text=results[4]
                        t6.text=results[5]
                        t7.text=results[6]
                        t8.text=str(results[7]*int(taux.text))
                        t9.text=str(results[8])
                        t10.text=str(results[9])
                        abbas=str(results[10])

                        t1.disabled=True
                        t2.disabled=True
                        t3.disabled=True
                        t4.disabled=True
                        t5.disabled=True
                        t6.disabled=True
                        t7.disabled=True
                        t8.disabled=True
                        t9.disabled=True
                        t10.disabled=True

                        tquantite.hint_text="QUANTITE [< " + abbas +" ]"

                        tquantite.focus=True

                        try:
                            nbr=float(t8.text)
                            t8.text=str(math.ceil(nbr))
                        except:
                            pass

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    discourant=os.path.dirname(__file__)
                    disprod=os.path.join(discourant,"ftx",t1.text)

                    photoproduit.background_normal= disprod + ".jpg"
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur, la photo n a pas ete chargée correctement, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur, le taux de change genere le probleme'),size_hint=(None, None), size=(400,200))
                msg.open()    
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Le taux de change releve un probleme, veuillez redemarrer ou consulter le gestionnaire si le probleme persiste'),size_hint=(None, None), size=(400,200))
            msg.open()

    def recherchventeproduit(self,instance):

        t1.text=""
        t2.text=""
        t3.text=""
        t4.text=""
        t5.text=""
        t6.text=""
        t7.text=""
        t8.text=""
        t9.text=""
        t10.text=""

        

        try:
            if int(taux.text)>0:

                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="select * from produit where nom='"+trechvente.text+"'"
                    cursor.execute(query)
                    results=cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:

                        t1.text=results[0]
                        t2.text=results[1]
                        t3.text=results[2]
                        t4.text=results[3]
                        t5.text=results[4]
                        t6.text=results[5]
                        t7.text=results[6]
                        t8.text=str(results[7]*int(taux.text))
                        t9.text=str(results[8])
                        t10.text=str(results[9])
                        abbas=str(results[10])

                        t1.disabled=True
                        t2.disabled=True
                        t3.disabled=True
                        t4.disabled=True
                        t5.disabled=True
                        t6.disabled=True
                        t7.disabled=True
                        t8.disabled=True
                        t9.disabled=True
                        t10.disabled=True

                        trechvente.text="Rechercher"
                        trechventlike.text="Choisir"
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                
                try:
                    discourant=os.path.dirname(__file__)
                    disprod=os.path.join(discourant,"ftx",t1.text)

                    photoproduit.background_normal= disprod + ".jpg"
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur, la photo n a pas ete chargée correctement, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur, le taux de change genere le probleme'),size_hint=(None, None), size=(400,200))
                msg.open()    
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Le taux de change releve un probleme, veuillez redemarrer ou consulter le gestionnaire si le probleme persiste'),size_hint=(None, None), size=(400,200))
            msg.open()

    def rechlikeproduit(self,instance):
        global listidcommute,df

        instance.text="choisir"

        if modcommutation==1:

            try:
                pass


            except:
                pass

            if trechvente.text=="":
                pass

            else:

                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select nom from produit where nom like '%" + trechvente.text + "%'")
                            
                    results=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()
                    for  i in  results:
                        trechventlike.values.append(str(i).replace("(","").replace(")","").replace("'","").replace(",",""))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

        elif modcommutation==0:
            tabcomm=[]

            try:
                if trechvente.text=="":
                    pass
                
                else:

                    if len(df)<1:

                        pass

                    else:
                        trechventlike.values=""
                        
                        resucom=df[df['nom'].str.contains(trechvente.text,case=False)]

                        tabcomm=resucom.values

                        icom=0

                        for icom in range(len(tabcomm)):
                            trechventlike.values.append(str(tabcomm[icom]).replace("['","").replace("']",""))
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
       
    
    def ajoutdanscoupon(self,instance):
        global num,netpayer,quantiterestant,listeqt
        pt=0

        try:
            self.cconnexion()
            cursor=con.cursor()
            query="select stock_p from produit where matricule='"+t1.text+"'"
            cursor.execute(query)
            resul=cursor.fetchone()
            self.cursor.close()
            con.close()

            if resul:
                quantiterestant=resul[0]
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard '),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            if quantiterestant >= int(tquantite.text):
                try:
                    if int(tquantite.text)<=0:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='La quantité doit etre supérieure ou egale à 1',color='white',background_color='blue'),size_hint=(None, None), size=(400,200))
                        msg.open()
                        tquantite.line_color_normal='red'
                    else:
                        num=len(tabvente1.row_data)+1

                        pt=math.ceil(float(tquantite.text)*float(t8.text))
                        datanew=(str(num),t1.text,t2.text,t8.text,tquantite.text,str(pt))
                        tabvente1.row_data.append(datanew)

                        netpayer=netpayer+pt

                        listeqt.append(quantiterestant)

                        btss=Builder.load_string('''          
Button:
    text:'Effectué !! '
    color:'black'
    background_color:[0,0,0,0] 

    canvas.before:
        Color:
            rgb:221/255,221/255,221/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]            
''')

                        msg=Popup(title="STATUT REQUETE",content=btss,size_hint=(.4, .25))
                        msg.open()

                        tquantite.line_color_normal='black'
                        trechventlike.text="Choisir"

                        t1.text=""
                        t2.text=""
                        t3.text=""
                        t4.text=""
                        t5.text=""
                        t6.text=""
                        t7.text=""
                        t8.text=""
                        t9.text=""
                        t10.text=""
                        tquantite.text=""

                        totgen=0.0

                        for ligtot in tabvente1.row_data:
                            totgen+=float(ligtot[5])

                        if netpayer==totgen:
                            labnetpayer.text=str(netpayer)
                            labnetpayer.color='blue'
                        else:
                            labnetpayer.text=str(netpayer)
                            labnetpayer.color='red'
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Echec lors du traitement des valeurs recues'),size_hint=(None, None), size=(400,200))
                    msg.open()
                    tquantite.line_color_normal='red'
            else:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Le stock ne permet pas de vendre cette quantité',color='white',background_color='blue'),size_hint=(None, None), size=(400,200))
                msg.open() 
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Error'),size_hint=(None, None), size=(400,200))
            msg.open()  


    def chargeinfo(self,instance):
        global sepp,save_path,idlocal,tauxjour

        if check1.active==True:

            datids=str(datetime.now().strftime('%H:%M:%S'))

            idloc=datids.replace(":","").replace(" ","").replace("-","")

            t1.text=idloc

            if sepp==1 and idlocal==1:

                datids=str(datetime.now().strftime('%H:%M:%S'))

                idloc=datids.replace(":","").replace(" ","").replace("-","")

                t1.text=idloc

                #print(idloc)

                treceve.text=""
                t2.focus=True

                try:
                    cadre.add_widget(photoproduit) 
                except:
                    pass
                
                try:

                    photoproduit.background_normal= save_path     

                except:
                    pass
            
            if sepp==1 and idlocal==0:
                t1.text=treceve.text
                treceve.text=""
                t2.focus=True

                try:
                    cadre.add_widget(photoproduit) 
                except:
                    pass
                
                try:

                    photoproduit.background_normal= save_path     

                except:
                    pass
                
            elif sepp==2:
                                 
                t1.text=""
                t2.text=""
                t3.text=""
                t4.text=""
                t5.text=""
                t6.text=""
                t7.text=""
                t8.text=""
                t9.text=""
                t10.text=""

                t2.focus=True
                
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="select * from produit where matricule='"+treceve.text+"'"
                    cursor.execute(query)
                    results=cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        t1.text=results[0]
                        t2.text=results[1]
                        t3.text=results[2]
                        t4.text=results[3]
                        t5.text=results[4]
                        t6.text=results[5]
                        t7.text=results[6]
                        t8.text=str(results[7]*tauxjour)
                        t9.text=str(results[8])
                        t10.text=str(results[9])
                        abbas=str(results[10])

                        treceve.text=""
                        t1.disabled=True
                        t9.disabled=True
                        t10.disabled=True


                        try:
                            cadre.add_widget(photoproduit) 
                        except:
                            pass 

                        try:
                            discourant=os.path.dirname(__file__)
                            disprod=os.path.join(discourant,"ftx",t1.text)

                            photoproduit.background_normal= disprod + ".jpg"

                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur, la photo n a pas ete chargée correctement, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur lors du chargement de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                

            elif sepp==8:
                t1.text=""
                t2.text=""
                t3.text=""
                t4.text=""
                t5.text=""
                t6.text=""
                t7.text=""
                t8.text=""
                t9.text=""
                t10.text=""

                
                try:
                    self.cconnexion()
                    cursor=con.cursor()
                    query="select * from produit where matricule='"+treceve.text+"'"
                    cursor.execute(query)
                    results=cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        t1.text=results[0]
                        t2.text=results[1]
                        t3.text=results[2]
                        t4.text=results[3]
                        t5.text=results[4]
                        t6.text=results[5]
                        t7.text=results[6]
                        t8.text=str(results[7]*int(taux.text))
                        t9.text=str(results[8])
                        t10.text=str(results[9])
                        abbas=str(results[10])

                        try:
                            cadre.add_widget(photoproduit) 
                        except:
                            pass
                                

                        try:
                            discourant=os.path.dirname(__file__)
                            disprod=os.path.join(discourant,"ftx",t1.text)

                            photoproduit.background_normal= disprod + ".jpg"

                            photoproduit.pos_hint={'x':0.01,'y':0.6}
                            photoproduit.size_hint=(0.1,0.2)  
                            
                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors du chargement de la photo, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                        treceve.text=""

                        t1.disabled=True
                        t2.disabled=True
                        t3.disabled=True

                        t4.disabled=True
                        t5.disabled=True
                        t6.disabled=True
                        
                        t7.disabled=True
                        t8.disabled=True
                        t9.disabled=True

                        t10.disabled=True                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de chargement des données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

        else:
            msg=Popup(title="STATUT REQUETE",content=Button(text='La connexion entrante n a pas été activé, veuillez activer et ressayer'),size_hint=(None, None), size=(400,200))
            msg.open()

    def chargerdonneeqr(self,instance):
        pass
        
    def selcam(self,instance,value):
        global idcam
        if instance.text=="Caméra normale":
            idcam=0
        elif instance.text=="Caméra Externe":
            idcam=1

    def arretserveur(self,instance):
        global idcam,camera,idt
        
        idt=0

        if idcam==1:
            threading.Thread(target=self.handle_client_connection).start()
        elif idcam==0:
            try:
                pass 
                
            except:
                pass 

    def demarreserveur(self,instance):
        global idcam,camera,idt,save_path

        idt=1

        if idcam==1:
            msg=Popup(title="ETAT",content=Button(text='Server online'),size_hint=(None, None), size=(250,200))
            msg.open()
            threading.Thread(target=self.handle_client_connection).start()
        elif idcam==0:
            try:
                pass
                #camera=Builder.load_string(KV)
                #cadre.add_widget(camera)
            except:
                pass            
    
    def handle_client_connection(self):
        global idt,client_socket,message,save_path

        discourant=os.path.dirname(__file__)
        discrec=os.path.join(discourant,"ft")
                        
    
        try:
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

            if typee=='0':
                try:
                    server_socket.bind(('127.0.0.1', 5566))
                    server_socket.listen(5)
                    labcheck.text="True" 

                    while True:
                        client_socket, address = server_socket.accept()
                        message = client_socket.recv(1024).decode("utf8")
                        treceve.text=message
                except:
                    msg=Popup(title="ERROR",content=Button(text='Erreur survenue'),size_hint=(None, None), size=(250,200))
                    msg.open()
                    
                    
            elif typee=='1':

                try:
            
                    if idt==1:
                        server_socket.bind(('127.0.0.1', 5566))
                        server_socket.listen(5)
                        labcheck.text="True" 

                        while True:
                            client_socket, address = server_socket.accept()
                            message = client_socket.recv(1024).decode("utf8")
                            treceve.text=message
                            #client_socket.send("Message reçu par le serveur".encode("utf8"))

                            taillpho=int.from_bytes(client_socket.recv(4),byteorder='big')
                            
                            labvente.text=str(taillpho)

                            photo_data=b''
                            while len(photo_data)< taillpho:
                                chuk=client_socket.recv(1024)
                                if not chuk:
                                    break
                                photo_data += chuk

                                doscourant=os.path.dirname(__file__)
                                nomft=message+".jpg"
                                #print(str(doscourant))
                                save_path=os.path.join(doscourant,"ft",nomft)
                                                    
                            with open(save_path,'wb') as photo_file:
                                photo_file.write(photo_data)
                                
                            client_socket.close() 
                            
                    elif idt==0:
                        pass    

                except:
                    msg=Popup(title="ERROR",content=Button(text='Erreur survenue'),size_hint=(None, None), size=(250,200))
                    msg.open()
                    
        except:
            labcheck.text="False"
            
    def fcheck1(self,instance,value):
        global conentrant
        if value:
            check2.active=False
            conentrant=1
    def fcheck2(self,instance,value):
        global conentrant
        if value:
            check1.active=False
            conentrant=0

    def vendre(self,instance):
        global verifsel
        
        if verifsel==0:
            
            trechvente.text="Rechercher"
            
            try:
                cadre.remove_widget(bimpression)
            except:
                pass
            
            try:
                cadre.remove_widget(btsuitegenAI)
            except:
                pass

            try:
                cadre.remove_widget(bactualiser)
            except:
                pass

            try:
                cadre.remove_widget(labcompteur)
            except:
                pass

            try:
                cadre.remove_widget(imgexpert)
            except:
                pass

            try:
                scrol.remove_widget(affresultat)
                cadre.remove_widget(scrol)
            except:
                pass

            try:
                cadre.remove_widget(photoproduit) 
            except:
                pass
            
            try:
                cadre.add_widget(bimpressionpreforma)
            except:
                pass

            photoproduit.pos_hint={'x':0.01,'y':0.7}
            photoproduit.size_hint=(0.1,0.2)

            try:
                cadre.remove_widget(labelement)
            except:
                pass
            try:
                cadre.remove_widget(bgenererresulat)
            except:
                pass
            
            try:
                cadre.remove_widget(bexpert1)
                cadre.remove_widget(bexpert2)
                cadre.remove_widget(bexpert3)
            except:
                pass
            try:   
                cadre.remove_widget(expcheck2)
                cadre.remove_widget(expcheck1)
                cadre.remove_widget(labcheckexp2)
                cadre.remove_widget(labcheckexp1)
            except:
                pass
            try:
                cadre.remove_widget(labexp2)
                cadre.remove_widget(texp1)
                cadre.remove_widget(labexp1) 
            except:
                pass

            try:
                cadre.add_widget(bretireelementcoupon)
                cadre.add_widget(bsuprimercoupon)
                cadre.add_widget(bvalidercoupon)
            except:
                pass

            try:
                cadre.remove_widget(combnomclient)
                cadre.remove_widget(tjourclientnom)
                cadre.remove_widget(combids)
                cadre.remove_widget(tjourids)
                cadre.remove_widget(combdats)
                cadre.remove_widget(labdats)
            except:
                pass

            try:
                cadre.remove_widget(labtot1)
                cadre.remove_widget(labtot2)
            except:
                pass

            try:
                cadre.remove_widget(labtypp)
                cadre.remove_widget(labtypp1)
                cadre.remove_widget(labtypp2)
            except:
                pass

            try:
                cadre.remove_widget(labtyp)
                cadre.remove_widget(labtyp1)
                cadre.remove_widget(labtyp2)
            except:
                pass

            try:
                
                cadre.remove_widget(labcheckk4)
                cadre.remove_widget(triercheckk4)
                cadre.remove_widget(labcheckk5)
                cadre.remove_widget(triercheckk5)
                cadre.remove_widget(trilabb)
            except:
                pass
            
            try:
                cadre.remove_widget(triercheck3)
                cadre.remove_widget(triercheck2)
                cadre.remove_widget(triercheck1)
                cadre.remove_widget(trilab)

                cadre.remove_widget(labcheck1)
                cadre.remove_widget(labcheck2)
                cadre.remove_widget(labcheck3)
            except:
                pass

            try:
                cadre.add_widget(imgtaux)
            except:
                pass
            try:
                cadre.add_widget(taux)
            except:
                pass

            try:
                cadre.add_widget(labnet)
                cadre.add_widget(labnetpayer)
            except:
                pass

            try:
                cadre.add_widget(bscanneur)
                cadre.add_widget(trechvente)
                cadre.add_widget(trechventlike)
                cadre.add_widget(bcharger)
            except:
                pass
            try:
                cadre.add_widget(tquantite)
            except:
                pass
            lbv.text="[b]NOUVEAU COUPON[/b]"
            
            try:
                
                cadre.add_widget(bvente1)
            except:
                pass
            try:
                cadre.add_widget(tabvente1)
            except:
                pass

            try:
                cadre.add_widget(t1)
                cadre.add_widget(t2)
                cadre.add_widget(t3)
                cadre.add_widget(t4)
                cadre.add_widget(t5)
                cadre.add_widget(t6)
                cadre.add_widget(t7)
                cadre.add_widget(t8)
            except:
                pass

            try:
                cadre.remove_widget(tabventejournal)
            except:
                pass
            
            labvente.text="[b]SUPER PHARMA[/b]"
            try:
                cadre.add_widget(btirehaut)
            except:
                pass

            try:
                cadre.add_widget(bvueclaire)
            except:
                pass

    def journal(self,instance):
        global verifsel
        
        if verifsel==0:

            try:
                cadre.remove_widget(bimpressionpreforma)
            except:
                pass

            try:
                cadre.add_widget(bimpression)
            except:
                pass

            try:
                cadre.remove_widget(btsuitegenAI)
            except:
                pass

            try:
                cadre.remove_widget(imgtaux)
            except:
                pass
            try:
                cadre.remove_widget(taux)
            except:
                pass

            try:
                cadre.remove_widget(bactualiser)
            except:
                pass

            try:
                cadre.remove_widget(labcompteur)
            except:
                pass

            try:
                cadre.remove_widget(imgexpert)
            except:
                pass

        
            try:
                scrol.remove_widget(affresultat)
                cadre.remove_widget(scrol)
            except:
                pass
                
            try:
                cadre.remove_widget(photoproduit) 
            except:
                pass

            try:
                cadre.remove_widget(labelement)
            except:
                pass
            
            try:
                cadre.remove_widget(bgenererresulat)
            except:
                pass

            try:
                cadre.remove_widget(bexpert1)
                cadre.remove_widget(bexpert2)
                cadre.remove_widget(bexpert3)
            except:
                pass
            
            try:
                cadre.remove_widget(expcheck2)
                cadre.remove_widget(expcheck1)
                cadre.remove_widget(labcheckexp2)
                cadre.remove_widget(labcheckexp1)
            except:
                pass

            try:

                cadre.remove_widget(labexp2)
                cadre.remove_widget(texp1)
                cadre.remove_widget(labexp1)
            except:
                pass

            try:
                cadre.remove_widget(bretireelementcoupon)
                cadre.remove_widget(bsuprimercoupon)
                cadre.remove_widget(bvalidercoupon)
            except:
                pass

            try:
                cadre.add_widget(combnomclient)
                cadre.add_widget(tjourclientnom)
                cadre.add_widget(combids)
                cadre.add_widget(tjourids)
                cadre.add_widget(combdats)
                cadre.add_widget(labdats)
            except:
                pass

            try:
                cadre.add_widget(labtot1)
                cadre.add_widget(labtot2)
            except:
                pass

            try:
                cadre.add_widget(labtypp)
                cadre.add_widget(labtypp1)
                cadre.add_widget(labtypp2)
            except:
                pass
            try:
                cadre.add_widget(labtyp)
                cadre.add_widget(labtyp1)
                cadre.add_widget(labtyp2)
            except:
                pass

            try:
                
                cadre.add_widget(labcheckk4)
                cadre.add_widget(triercheckk4)
                cadre.add_widget(labcheckk5)
                cadre.add_widget(triercheckk5)
                cadre.add_widget(trilabb)
            except:
                pass
            try:
                cadre.add_widget(triercheck3)
                cadre.add_widget(triercheck2)
                cadre.add_widget(triercheck1)
                cadre.add_widget(trilab)
                
                cadre.add_widget(labcheck1)
                cadre.add_widget(labcheck2)
                cadre.add_widget(labcheck3)
            except:
                pass
            try:
                cadre.remove_widget(labnet)
                cadre.remove_widget(labnetpayer)
            except:
                pass

            try:
                cadre.remove_widget(bscanneur)
                cadre.remove_widget(trechvente)
                cadre.remove_widget(trechventlike)
                cadre.remove_widget(bcharger)
            except:
                pass
            
            try:
                cadre.remove_widget(tquantite)
            except:
                pass
            lbv.text="[b]ANALYSEUR[/b]"

            try:
                
                cadre.remove_widget(bvente1)
            except:
                pass
            try:
                cadre.remove_widget(tabvente1)
            except:
                pass
        
            try:
                cadre.remove_widget(t1)
                cadre.remove_widget(t2)
                cadre.remove_widget(t3)
                cadre.remove_widget(t4)
                cadre.remove_widget(t5)
                cadre.remove_widget(t6)
                cadre.remove_widget(t7)
                cadre.remove_widget(t8)
            except:
                pass
            try:
                
                cadre.add_widget(tabventejournal)

            except:
                pass
            
            #try:
                #self.cconnexion()
                #self.cursor=con.cursor()
                #self.cursor.execute("select ID_Produit,nom,achat.PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur from achat,produit where ID_Produit=matricule and id_travailleur='"+tidconn.text+"' and achat.Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                #results=self.cursor.fetchall()
                #tabventejournal.row_data=results
                #self.cursor.close()
                #con.close()
                
            #except:
             #   msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
              #  msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+tidconn.text+"' and achat.Dates='"+datetime.now().strftime('%Y-%m-%d')+"'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()
                if results:
                    labtot2.text=str(results[0])
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            labvente.text="[b]JOURNAL D'OPERATION[/b]"

            try:
                cadre.remove_widget(btirehaut)
            except:
                pass

            try:
                cadre.add_widget(bvueclaire)
            except:
                pass

    def modexpert(self,instance):
        global verifsel,listeplainte
        
        if verifsel==0:

            try:
                cadre.remove_widget(bimpressionpreforma)
            except:
                pass

            try:
                cadre.remove_widget(bimpression)
            except:
                pass

            try:
                cadre.add_widget(bactualiser)
            except:
                pass

            try:
                cadre.add_widget(labcompteur)
            except:
                pass

            try:
                cadre.add_widget(imgexpert)
            except:
                pass

            try:
                scrol.add_widget(affresultat)
                cadre.add_widget(scrol)
            except:
                pass
            
            try:
                cadre.remove_widget(photoproduit) 
            except:
                pass

            try:
                cadre.add_widget(labelement)
            except:
                pass
            
            labcheckexp2.active=True
            try:
                cadre.add_widget(bgenererresulat)
            except:
                pass
    
            try:
                cadre.add_widget(bexpert1)
                cadre.add_widget(bexpert2)
                cadre.add_widget(bexpert3)
            except:
                pass

            try:
                cadre.add_widget(expcheck2)
                cadre.add_widget(expcheck1)
                cadre.add_widget(labcheckexp2)
                cadre.add_widget(labcheckexp1)
            except:
                pass

            try:
                cadre.add_widget(labexp2)
                cadre.add_widget(texp1)
                cadre.add_widget(labexp1)
            except:
                pass

            try:
                cadre.add_widget(bretireelementcoupon)
                cadre.add_widget(bsuprimercoupon)
                cadre.add_widget(bvalidercoupon)
            except:
                pass

            try:
                cadre.remove_widget(imgtaux)
            except:
                pass
            try:
                cadre.remove_widget(taux)
            except:
                pass

            
            try:
                cadre.remove_widget(combnomclient)
                cadre.remove_widget(tjourclientnom)
                cadre.remove_widget(combids)
                cadre.remove_widget(tjourids)
                cadre.remove_widget(combdats)
                cadre.remove_widget(labdats)
            except:
                pass

            try:
                cadre.remove_widget(labtot1)
                cadre.remove_widget(labtot2)
            except:
                pass

            try:
                cadre.remove_widget(labtypp)
                cadre.remove_widget(labtypp1)
                cadre.remove_widget(labtypp2)
            except:
                pass

            try:
                cadre.remove_widget(labtyp)
                cadre.remove_widget(labtyp1)
                cadre.remove_widget(labtyp2)
            except:
                pass

            try:
                
                cadre.remove_widget(labcheckk4)
                cadre.remove_widget(triercheckk4)
                cadre.remove_widget(labcheckk5)
                cadre.remove_widget(triercheckk5)
                cadre.remove_widget(trilabb)
            except:
                pass

            try:
                cadre.remove_widget(triercheck3)
                cadre.remove_widget(triercheck2)
                cadre.remove_widget(triercheck1)
                cadre.remove_widget(trilab)

                cadre.remove_widget(labcheck1)
                cadre.remove_widget(labcheck2)
                cadre.remove_widget(labcheck3)
            except:
                pass
            try:
                cadre.remove_widget(labnet)
                cadre.remove_widget(labnetpayer)
            except:
                pass

            try:
                cadre.remove_widget(bscanneur)
                cadre.remove_widget(trechvente)
                cadre.remove_widget(trechventlike)
                cadre.remove_widget(bcharger)
            except:
                pass
            
            try:
                cadre.remove_widget(tquantite)
            except:
                pass
            lbv.text="[b]RESULTAT OpenIA[/b]"
            labvente.text='[b]SYSTEME EXPERT[/b]'

            try:
                cadre.remove_widget(bvente1)
            except:
                pass
            try:
                cadre.remove_widget(tabvente1)
            except:
                pass
        
            try:
                cadre.remove_widget(t1)
                cadre.remove_widget(t2)
                cadre.remove_widget(t3)
                cadre.remove_widget(t4)
                cadre.remove_widget(t5)
                cadre.remove_widget(t6)
                cadre.remove_widget(t7)
                cadre.remove_widget(t8)
            except:
                pass
            try:
                cadre.remove_widget(tabventejournal)
            except:
                pass
            try:
                cadre.remove_widget(bsuprimercoupon)
                cadre.remove_widget(bvalidercoupon)
                cadre.remove_widget(bretireelementcoupon)
            except:
                pass

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select distinct traite from produit")
                listeplainte=self.cursor.fetchall()
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Le module expert n a pas été chargé correctement , veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                cadre.remove_widget(btirehaut)
            except:
                pass
        
            try:
                cadre.remove_widget(bvueclaire)
            except:
                pass
                
    def tirehaut(self,instance):
        global verifsel
            
        if instance.background_normal=="configuration.ico":
      
            verifsel=1

            try:
                cadre.remove_widget(indicateurindice)
            except:
                pass

            try:
                cadre.remove_widget(labindice)
            except:
                pass

            try:
                cadre.remove_widget(bcommutadmin)
            except:
                pass

            try:
                cadre.remove_widget(labcodelocal)
            except:
                pass
                
            try:
                cadre.remove_widget(checkcodelocal)   
            except:
                pass

            try:
                cadre.remove_widget(bdemserveur)
            except:
                pass

            try:
                cadre.remove_widget(bscanneurannuler)
            except:
                pass
            
            if sepp==1:

                try:
                    cadre.remove_widget(imgtaux)
                except:
                    pass

                try:
                    cadre.add_widget(bpreforma)
                except:
                    pass

                imgtaux.pos_hint={'x':0.8,'y':0.88}
                imgtaux.size_hint=(0.1,0.1)
            
                try:
                    cadre.remove_widget(tabmod)
                except:
                    pass

                try:
                    cadre.add_widget(bclose)
                except:
                    pass

                    

                bclose.text='[b]Closing day ?[/b]'
                bclose.pos_hint={'x':0.9, 'y':0.85}

                bdeconn.pos_hint={'x':0.88, 'y':0.95}

                try:
                    cadre.remove_widget(bscanneur)
                except:
                    pass 

                try:
                    cadre.remove_widget(t1)
                    cadre.remove_widget(t2)
                    cadre.remove_widget(t3)
                    cadre.remove_widget(t4)
                except:
                    pass

                try:
                    cadre.add_widget(bcad1)
                    cadre.add_widget(bcad2)
                    cadre.add_widget(bcad3)
                except:
                    pass

                try:
                    cadre.remove_widget(btautorisermodtp)
                except:
                    pass

                try:
                    cadre.add_widget(labhaut1b)
                    cadre.add_widget(labhaut2b)
                    cadre.add_widget(labhaut3b)
                    cadre.add_widget(check1)
                    cadre.add_widget(check2)
                    cadre.add_widget(labcheck)

                    cadre.add_widget(btest)
                    cadre.add_widget(barret)
                    cadre.add_widget(bdemm)
                    
                    cadre.add_widget(labhaut1)
                    cadre.add_widget(labhaut2)
                    cadre.add_widget(labhaut3)
                    cadre.add_widget(combohaut1)
                    cadre.add_widget(combohaut2)
                    cadre.add_widget(combohaut3)
                except:
                    pass
                try:
                    cadre.add_widget(bdeconn)
                except:
                    pass
            
                try:
                    cadre.add_widget(bcorrection)
                except:
                    pass
                

            if labvente.text=="[b]SUPER PHARMA[/b]" and sepp==8:

                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select etat from autorisation where id='selecteur'")
                    resultetatautorisa=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    etat=0

                    if resultetatautorisa:
                        etat=resultetatautorisa[0]
                    
                    if etat==1:

                        try:
                            cadre.add_widget(btmodstockauto)
                        except:
                            pass

                    else:

                        try:
                            cadre.remove_widget(btmodstockauto)
                        except:
                            pass
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Errorr!!'),size_hint=(None, None), size=(400,200))
                    msg.open()

                    
                try:
                    cadre.add_widget(bpreforma)
                except:
                    pass

                try:
                    cadre.add_widget(bclose)
                except:
                    pass
                bclose.text="[b]Mode Commutation[/b]"
                bclose.pos_hint={'x':0.87, 'y':0.85}

                try:
                    cadre.add_widget(bcorrection)
                except:
                    pass

                try:
                    cadre.remove_widget(trechvente)
                    cadre.remove_widget(trechventlike)
                except:
                    pass

                try:
                    cadre.remove_widget(bscanneur)
                except:
                    pass 
                
                else:
                    try:
                        cadre.remove_widget(trechvente)
                        cadre.remove_widget(trechventlike)
                    except:
                        pass
                    try:
                        cadre.remove_widget(bcharger)
                    except:
                        pass
                    
                try:
                    pass
                    #bcoupcendr.background_color='gray'
                    #bsystem.background_color='gray'
                    #bjournal.background_color='gray'
                except:
                    pass
                
                try:
                    cadre.remove_widget(t1)
                    cadre.remove_widget(t2)
                    cadre.remove_widget(t3)
                    cadre.remove_widget(t4)
                except:
                    pass
                try:
                    cadre.remove_widget(labvente)
                except:
                    pass

                
                try:
                    cadre.add_widget(bcad1)
                    cadre.add_widget(bcad2)
                    cadre.add_widget(bcad3)
                except:
                    pass

                try:
                    cadre.add_widget(labhaut1b)
                    cadre.add_widget(labhaut2b)
                    cadre.add_widget(labhaut3b)
                    cadre.add_widget(check1)
                    cadre.add_widget(check2)
                    cadre.add_widget(labcheck)

                    cadre.add_widget(btest)
                    cadre.add_widget(barret)
                    cadre.add_widget(bdemm)
                    
                    cadre.add_widget(labhaut1)
                    cadre.add_widget(labhaut2)
                    cadre.add_widget(labhaut3)
                    cadre.add_widget(combohaut1)
                    cadre.add_widget(combohaut2)
                    cadre.add_widget(combohaut3)
                except:
                    pass
                try:
                    cadre.add_widget(bdeconn)
                except:
                    pass

                bdeconn.pos_hint={'x':0.86, 'y':0.95}
                bcorrection.pos_hint={'x':0.86, 'y':0.9}
                

            elif labvente.text=="[b]JOURNAL D'OPERATION[/b]" and sepp==8:
                
                try:
                    cadre.remove_widget(labvente)
                except:
                    pass

                try:
                    cadre.add_widget(bdeconn)
                except:
                    pass


                try:
                    cadre.add_widget(bcad1)
                    cadre.add_widget(bcad2)
                    cadre.add_widget(bcad3)
                except:
                    pass

                try:
                    bcoupcendr.background_color='gray'
                    bsystem.background_color='gray'
                    bjournal.background_color='gray'
                except:
                    pass
                
                try:
                    cadre.remove_widget(tabventejournal)
                except:
                    pass
                try:
                    cadre.add_widget(labhaut1b)
                    cadre.add_widget(labhaut2b)
                    cadre.add_widget(labhaut3b)
                    cadre.add_widget(check1)
                    cadre.add_widget(check2)
                    cadre.add_widget(labcheck)

                    cadre.add_widget(btest)
                    cadre.add_widget(barret)
                    cadre.add_widget(bdemm)
                    
                    cadre.add_widget(labhaut1)
                    cadre.add_widget(labhaut2)
                    cadre.add_widget(labhaut3)
                    cadre.add_widget(combohaut1)
                    cadre.add_widget(combohaut2)
                    cadre.add_widget(combohaut3)
                except:
                    pass
                
            elif labvente.text=='[b]SYSTEME EXPERT[/b]' and sepp==8:
                try:
                    cadre.remove_widget(labvente)
                except:
                    pass
                try:
                    cadre.add_widget(bdeconn)
                except:
                    pass

                try:
                    cadre.add_widget(bcad1)
                    cadre.add_widget(bcad2)
                    cadre.add_widget(bcad3)
                except:
                    pass

                try:
                    bcoupcendr.background_color='gray'
                    bsystem.background_color='gray'
                    bjournal.background_color='gray'
                except:
                    pass
                
                try:
                    cadre.remove_widget(labexp1)
                    cadre.remove_widget(texp1)
                except:
                    pass
                try:
                    cadre.add_widget(labhaut1b)
                    cadre.add_widget(labhaut2b)
                    cadre.add_widget(labhaut3b)
                    cadre.add_widget(check1)
                    cadre.add_widget(check2)
                    cadre.add_widget(labcheck)

                    cadre.add_widget(btest)
                    cadre.add_widget(barret)
                    cadre.add_widget(bdemm)
                    
                    cadre.add_widget(labhaut1)
                    cadre.add_widget(labhaut2)
                    cadre.add_widget(labhaut3)
                    cadre.add_widget(combohaut1)
                    cadre.add_widget(combohaut2)
                    cadre.add_widget(combohaut3)
                except:
                    pass
            try:
                instance.pos_hint={'x':0.88,'y':0.74}
                instance.background_normal="exit.jpg"
            except:
                pass

        elif instance.background_normal=="exit.jpg":
        
            verifsel=0

            if sepp==2:
                try:
                    cadre.add_widget(bscanneurannuler)
                except:
                    pass

            elif sepp==1:

                try:
                    cadre.add_widget(indicateurindice)
                except:
                    pass

                try:
                    cadre.add_widget(labindice)
                except:
                    pass
                

                try:
                    cadre.add_widget(btautorisermodtp)
                except:
                    pass

                try:
                    cadre.remove_widget(bpreforma)
                except:
                    pass

                try:
                    cadre.add_widget(bcommutadmin)
                except:
                    pass

                try:
                    cadre.add_widget(imgtaux)
                except:
                    pass

                imgtaux.pos_hint={'x':0.91,'y':0.5}
                imgtaux.size_hint=(0.09,0.15)

                try:
                    cadre.remove_widget(bclose)
                except:
                    pass

                try:
                    cadre.add_widget(labcodelocal)
                except:
                    pass
                    
                try:
                    cadre.add_widget(checkcodelocal)   
                except:
                    pass
                

                try:
                    cadre.add_widget(bdemserveur)
                except:
                    pass

                try:
                    cadre.add_widget(bscanneurannuler)
                except:
                    pass

                try:
                    cadre.add_widget(tabmod)
                except:
                    pass

                bdeconn.pos_hint={'x':0.5, 'y':0.3}

                try:
                    cadre.add_widget(bscanneur)
                except:
                    pass 
                
                try:
                    cadre.add_widget(t1)
                    cadre.add_widget(t2)
                    cadre.add_widget(t3)
                    cadre.add_widget(t4)
                except:
                    pass

                try:
                    cadre.remove_widget(bcad1)
                    cadre.remove_widget(bcad2)
                    cadre.remove_widget(bcad3)
                except:
                    pass

                try:
                    cadre.remove_widget(labhaut1b)
                    cadre.remove_widget(labhaut2b)
                    cadre.remove_widget(labhaut3b)
                    cadre.remove_widget(check1)
                    cadre.remove_widget(check2)
                    cadre.remove_widget(labcheck)

                    cadre.remove_widget(btest)
                    cadre.remove_widget(barret)
                    cadre.remove_widget(bdemm)
                    
                    cadre.remove_widget(labhaut1)
                    cadre.remove_widget(labhaut2)
                    cadre.remove_widget(labhaut3)
                    cadre.remove_widget(combohaut1)
                    cadre.remove_widget(combohaut2)
                    cadre.remove_widget(combohaut3)
                except:
                    pass

                try:
                    cadre.remove_widget(bdeconn)
                except:
                    pass

                bcorrection.pos_hint={'x':0.88, 'y':0.90}
                
                try:
                    cadre.remove_widget(bcorrection)

                except:
                    pass

            if labvente.text=="[b]SUPER PHARMA[/b]" and sepp==8:
                if sepp==8:

                    try:
                        cadre.remove_widget(btmodstockauto)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bpreforma)
                    except:
                        pass
                    
                    try:
                        cadre.remove_widget(bclose)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bcorrection)
                    except:
                        pass

                    try:
                        cadre.remove_widget(tabmod)
                    except:
                        pass
                try:
                    cadre.add_widget(bscanneur)
                    cadre.add_widget(trechvente)
                    cadre.add_widget(trechventlike)
                    cadre.add_widget(bcharger)
                except:
                    pass
                
                try:
                    cadre.add_widget(bscanneur)
                except:
                    pass 
                
                try:
                    cadre.remove_widget(bdeconn)
                except:
                    pass

                else:
                    try:
                        cadre.add_widget(trechvente)
                        cadre.add_widget(trechventlike)
                    except:
                        pass
                    try:
                        cadre.add_widget(labvente)
                    except:
                        pass
                    
                try:
                    pass
                    #bcoupcendr.background_color='seagreen'
                    #bsystem.background_color='seagreen'
                    #bjournal.background_color='seagreen'
                except:
                    pass
                
                try:
                    cadre.add_widget(t1)
                    cadre.add_widget(t2)
                    cadre.add_widget(t3)
                    cadre.add_widget(t4)
                except:
                    pass

                try:
                    cadre.remove_widget(bcad1)
                    cadre.remove_widget(bcad2)
                    cadre.remove_widget(bcad3)
                except:
                    pass

                try:
                    cadre.remove_widget(labhaut1b)
                    cadre.remove_widget(labhaut2b)
                    cadre.remove_widget(labhaut3b)
                    cadre.remove_widget(check1)
                    cadre.remove_widget(check2)
                    cadre.remove_widget(labcheck)

                    cadre.remove_widget(btest)
                    cadre.remove_widget(barret)
                    cadre.remove_widget(bdemm)
                    
                    cadre.remove_widget(labhaut1)
                    cadre.remove_widget(labhaut2)
                    cadre.remove_widget(labhaut3)
                    cadre.remove_widget(combohaut1)
                    cadre.remove_widget(combohaut2)
                    cadre.remove_widget(combohaut3)
                except:
                    pass

            elif labvente.text=="[b]JOURNAL D'OPERATION[/b]" and sepp==8:
                try:
                    cadre.remove_widget(bdeconn)
                except:
                    pass

                try:
                    cadre.remove_widget(bcad1)
                    cadre.remove_widget(bcad2)
                    cadre.remove_widget(bcad3)
                except:
                    pass
                
                try:
                    bcoupcendr.background_color='seagreen'
                    bsystem.background_color='seagreen'
                    bjournal.background_color='seagreen'
                except:
                    pass

                try:
                    cadre.add_widget(labvente)
                except:
                    pass

                try:
                    cadre.add_widget(tabventejournal)
                except:
                    pass
                try:
                    cadre.remove_widget(labhaut1b)
                    cadre.remove_widget(labhaut2b)
                    cadre.remove_widget(labhaut3b)
                    cadre.remove_widget(check1)
                    cadre.remove_widget(check2)
                    cadre.remove_widget(labcheck)

                    cadre.remove_widget(btest)
                    cadre.remove_widget(barret)
                    cadre.remove_widget(bdemm)
                    
                    cadre.remove_widget(labhaut1)
                    cadre.remove_widget(labhaut2)
                    cadre.remove_widget(labhaut3)
                    cadre.remove_widget(combohaut1)
                    cadre.remove_widget(combohaut2)
                    cadre.remove_widget(combohaut3)
                except:
                    pass

            elif labvente.text=='[b]SYSTEME EXPERT[/b]' and sepp==8:
                try:
                    cadre.remove_widget(bdeconn)
                except:
                    pass
                try:
                    cadre.remove_widget(bcad1)
                    cadre.remove_widget(bcad2)
                    cadre.remove_widget(bcad3)
                except:
                    pass
                
                try:
                    bcoupcendr.background_color='seagreen'
                    bsystem.background_color='seagreen'
                    bjournal.background_color='seagreen'
                except:
                    pass
                
                try:
                    cadre.add_widget(labvente)
                except:
                    pass

                try:
                    cadre.add_widget(labexp1)
                    cadre.add_widget(texp1)
                except:
                    pass
                try:
                    cadre.remove_widget(labhaut1b)
                    cadre.remove_widget(labhaut2b)
                    cadre.remove_widget(labhaut3b)
                    cadre.remove_widget(check1)
                    cadre.remove_widget(check2)
                    cadre.remove_widget(labcheck)

                    cadre.remove_widget(btest)
                    cadre.remove_widget(barret)
                    cadre.remove_widget(bdemm)
                    
                    cadre.remove_widget(labhaut1)
                    cadre.remove_widget(labhaut2)
                    cadre.remove_widget(labhaut3)
                    cadre.remove_widget(combohaut1)
                    cadre.remove_widget(combohaut2)
                    cadre.remove_widget(combohaut3)
                except:
                    pass
            
            try:
                instance.pos_hint={'x':0.92,'y':0.92}
                instance.background_normal="configuration.ico"
            except:
                pass

    def changergestuser(self, instance):
        
        if btusernew.text=='[b]Enregistrer[/b]':

            btusernew.text='[b]Modifier[/b]'
            t1.disabled=True
            t1.password=False

        elif btusernew.text=='[b]Modifier[/b]':

            btusernew.text='[b]Enregistrer[/b]'
            t1.disabled=False
            t1.password=False

        t1.text=""
        t2.text=""
        t3.text=""
        t4.text=""
        t5.text=""
        t6.text=""

    def affitravail(self,instance_table,current_row):
            identid=""
            try:
                identid=str(current_row[4])
                self.cconnexion()
                cursor=con.cursor()
                query="select nom,postnom,prenom,sexe,id,pwd from compte where id='"+identid+"'"
                cursor.execute(query)
                results=cursor.fetchone()
                self.cursor.close()
                con.close()
                if results:
                    t2.text=str(results[0])
                    t3.text=str(results[1])
                    t4.text=str(results[2])
                    t5.text=str(results[3])
                    t1.text=str(results[4])
                    t6.text=str(results[5])
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            if identid=="":
                pass
            else:
                bgestionusernew.text='[b]Modifier[/b]'

    def gestionuserInsertUpdate(self,instance):

        #fondacceuil.background_normal='page_insert.jpg'

        
        if instance.text=='[b]Enregistrer[/b]':
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="insert into compte(nom,postnom,prenom,sexe,id,pwd,type,dates) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                dataa=(t2.text,t3.text,t4.text,t5.text,t1.text,int(t6.text),'user',datetime.now().strftime("%Y-%m-%d"))
                cursor.execute(query,dataa)
                con.commit()
                self.cursor.close()
                con.close()

                
                t1.text=""
                t2.text=""
                t3.text=""
                t4.text=""
                t5.text=""
                t6.text=""
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue'),size_hint=(None, None), size=(400,200))
                msg.open()
                
        elif instance.text=='[b]Modifier[/b]':
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="update compte set nom=%s,postnom=%s,prenom=%s,sexe=%s,pwd=%s where id=%s"
                cursor.execute(query,((t2.text),(t3.text),(t4.text),(t5.text),int(t6.text),t1.text))
                con.commit()
                self.cursor.close()
                con.close()

                msg=Popup(title="STATUT REQUETE",content=Button(text='Modification reussie'),size_hint=(None, None), size=(400,200))
                msg.open()
                t1.text=""
                t2.text=""
                t3.text=""
                t4.text=""
                t5.text=""
                t6.text=""

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue'),size_hint=(None, None), size=(400,200))
                msg.open()
            
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from compte order by dates DESC limit 10")
            results=self.cursor.fetchall()
            tabl.row_data=results
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def chargPageUnsermananger(self,instance):
        global openuser,msgg

        try:
            msgg.dismiss()
        except:
            pass

        openuser=1
        
        try:
            cadre.add_widget(retaccueil)
        except:
            pass


        try:
            cadre.remove_widget(bautomodiftravprod)
        except:
            pass
        
        try:
            cadre.remove_widget(indicateurindice)
        except:
            pass
        try:
            cadre.remove_widget(labindice)
        except:
            pass

        try:
            cadre.remove_widget(checkcodelocal)
        except:
            pass
        try:
            cadre.remove_widget(labcodelocal)
        except:
            pass

        try:
            cadre.remove_widget(bdemserveur)
        except:
            pass

        try:
            cadre.remove_widget(bscanneurannuler)
        except:
            pass

        try:
            cadre.remove_widget(photoproduit) 
        except:
            pass
        
        try:
            cadre.remove_widget(bscanneur)
        except:
            pass

        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            cadre.remove_widget(tabmod)
        except:
            pass
        try:
            tabmod.remove_widget(labmod)
        except:
            pass
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
        except:
            pass
        try:
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
            cadre.remove_widget(btenregistrer)
            cadre.remove_widget(btncamera)
            cadre.remove_widget(table)
        except:
            pass
            

        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass
        # la fin des outils de la page d insertion

        

        try:
            cadre.add_widget(labxx)
        except:
            pass
        
        try:
            cadre.add_widget(cadresuitchmode)
        except:
            pass
        
        try:
            cadre.add_widget(btusernew)
        except:
            pass

        try:
            cadre.add_widget(configserveur)
        except:
            pass

        configserveur.pos_hint={'x':0.9,'y':0.8}
        configserveur.size_hint=(0.07,0.1)

        try:
            cadre.add_widget(gesttrav)
        except:
            pass
        try:
            cadre.add_widget(gestmotif)
        except:
            pass
        

        btncamera.background_normal='refresh_arrow_1546.ico'

        try:
            cadre.add_widget(bgestionuserchanger)
        except:
            pass

        try:
            pass
            #btaction.background_normal="back.jpg"
        except:
            pass
        
        try:
            cadre.add_widget(t1)
            cadre.add_widget(t2)
            cadre.add_widget(t3)
            cadre.add_widget(t4)
            cadre.add_widget(t5)
            cadre.add_widget(t6)
        except:
            pass

        t1.dissabled=False
        t1.hint_text="Id travailleur"
        t2.hint_text="Nom"
        t3.hint_text="postnom"                    
        t4.hint_text="Prenom"
        t5.hint_text="Sexe"
        t6.hint_text="Pwd"
        
        t1.helper_text=""
        t2.helper_text=""
        t3.helper_text=""
        t4.helper_text=""
        t5.helper_text=""
        t6.helper_text=""

        t1.pos_hint={'x':0.14, 'y':0.86}
        t3.pos_hint={'x':0.14, 'y':0.78}
        t5.pos_hint={'x':0.14, 'y':0.68}
        t7.pos_hint={'x':0.14, 'y':0.58}
        t9.pos_hint={'x':0.14, 'y':0.48} 
        
        labmod.text="[b]Gestion des travailleurs[b]"
        labmod.pos_hint={'x':0.3,'y':0.5}
        instance.text='[b]Enregistrer[/b]'
        #table.size_hint=(0.9,0.4)
        #table.pos_hint={'x':0.05,'y':0.05}
        try:
            cadre.add_widget(tabl)
        except:
            pass
        
        try:
            cadre.remove_widget(bdeconn)
        except:
            pass
        try:
            cadre.add_widget(labmod)
        except:
            pass
        try:
            cadre.remove_widget(table)
            table.row_data=[]
        except:
            pass
        
        t1.dissabled=True

        
        
    def retour(self,instance):

        try:
            cadre.add_widget(configserveur)
        except:
            pass
       
        configserveur.pos_hint={'x':0.01,'y':0.8}
        configserveur.size_hint=(0.15,0.18)

        try:
            buser.pos_hint={'x':0.6, 'y':0.3}
            cadre.add_widget(buser)
        except:
            pass
        try:
            badmin.pos_hint={'x':0.2, 'y':0.3}
            cadre.add_widget(badmin)
        except:
            pass
        try:
            cadre.remove_widget(bretour)
        except:
            pass
        try:
            cadre.add_widget(ptitre)
            cadre.add_widget(plabadmin)
            cadre.add_widget(plabuser)
        except:
            pass 
        try:
            cadre.remove_widget(btnconn)
            cadre.remove_widget(tidconn)
            cadre.remove_widget(tpwdconn)
            cadre.remove_widget(imggconn)
            cadre.remove_widget(labconn)
        except:
            pass

    
    def deconnsimple(self):
        global msgdec,pwdvrai,idmach,msgg,cadrehautnewvieux

        try:
            cadrehautnewvieux.remove_widget(cadrehautnew)
        except:
            pass

        #msgg.dismiss()

        #msgdec.dismiss()

        Window.size=(500,400)
        
        t1.pos_hint={'x':0.14, 'y':0.86}
        t3.pos_hint={'x':0.14, 'y':0.78}
        t5.pos_hint={'x':0.14, 'y':0.68}
        t7.pos_hint={'x':0.14, 'y':0.58}
        t9.pos_hint={'x':0.14, 'y':0.48}


        try:
            cadre.remove_widget(iccon2)
            cadre.remove_widget(iccon1)

        except:
            pass

        try:
            cadre.add_widget(btfond)
        except:
            pass

        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass

        try:
            cadre.remove_widget(fondpagevente)
        except:
            pass

        try:
            cadre.remove_widget(checkchangecdf)
        except:
            pass
        try:
            cadre.remove_widget(labchange)
        except:
            pass

        try:
            cadre.remove_widget(btmodstockauto)
        except:
            pass

        try:
            cadre.remove_widget(bpreforma)
        except:
            pass

        try:
            cadre.remove_widget(bimpressionpreforma)
        except:
            pass
        try:
            cadre.remove_widget(labnetpayer)
        except:
            pass
        
        try:
            cadre.remove_widget(bimpression)
        except:
            pass

        try:
            cadre.add_widget(bquiter)
        except:
            pass

        try:
            cadre.remove_widget(btsignale)
        except:
            pass
        try:
            cadre.remove_widget(btaide)
        except:
            pass

        try:
            cadre.remove_widget(bclose)
        except:
            pass

        try:
            cadre.remove_widget(imgtaux)
        except:
            pass
        try:
            cadre.remove_widget(taux)
        except:
            pass

        try:
        
            self.cconnexion()
            cursor=con.cursor()
            cursor.execute("delete from session where ids='"+tidconn.text+"'")
            con.commit()
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
            msg.open()
        
        try:
            cadre.remove_widget(labnet)
        except:
            pass
        try:
            cadre.remove_widget(bvalidercoupon)
            cadre.remove_widget(bsuprimercoupon)
            cadre.remove_widget(bretireelementcoupon)
        except:
            pass

        try:
            cadre.remove_widget(bcharg)
        except:
            pass

        try:
            cadre.remove_widget(tabmod)
        except:
            pass

        try:
            cadre.remove_widget(tquantite)
        except:
            pass

        try:
            b1.size_hint=(0,0.1)
            b1.text=""

            b2.size_hint=(0,0.1)
            b2.text=""

            b3.size_hint=(0,0.1)
            b3.text=""

            b4.size_hint=(0,0.1)
            b4.text=""
            
            b5.size_hint=(0,0.1)
            b5.text=""
        except:
            pass

        try:
            cadre.remove_widget(b1)
            cadre.remove_widget(b2)
            cadre.remove_widget(b3)
            cadre.remove_widget(b4)
            cadre.remove_widget(b5)
        except:
            pass

        try:
            cadre.remove_widget(btaction)
        except:
            pass

        try:
            tabv.remove_widget(lbv)
            cadre.remove_widget(tabv)
            cadre.remove_widget(tabvente1)
            cadre.remove_widget(bvente1)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn)
            
        except:
            pass
        labmod.pos_hint={'x':0.5,'y':0.5}
        try:
            cadre.remove_widget(labmod)
        except:
            pass
        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        
        try:
            cadre.add_widget(buser)
            buser.pos_hint={'x':0.6, 'y':0.3}
        except:
            pass
        try:
            cadre.add_widget(badmin)
            badmin.pos_hint={'x':0.2, 'y':0.3}
        except:
            pass


        try:
            cadre.add_widget(ptitre)
            cadre.add_widget(plabadmin)
            cadre.add_widget(plabuser)
        except:
            pass
        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)
        except:
            pass
        try:
            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)
        except:
            pass
        try:
            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)
        except:
            pass
        try:
            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)
        except:
            pass
        try:
            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass
        
        try:
            cadre.remove_widget(bsystem)
            cadre.remove_widget(bjournal)
            cadre.remove_widget(bcoupcendr)
        except:
            pass
        try:
            cadre.remove_widget(labvente)
        except:
            pass
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
        except:
            pass
        try:
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
        except:
            pass
        try:
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
        except:
            pass

        try:
            cadre.remove_widget(btncamera)
        except:
            pass
        try:
            cadre.remove_widget(table)
        except:
            pass
        try:
            cadre.remove_widget(btenregistrer)
        except:
            pass

        try:
            cadregauche.remove_widget(btaction)
        except:
            pass
        
        #page vente 
        try:
            btirehaut.pos_hint={'x':0.92,'y':0.92}
        except:
            pass
        try:
            btirehaut.background_normal="configuration.ico"
        except:
            pass
        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            cadre.remove_widget(bscanneur)
            cadre.remove_widget(trechvente)
            cadre.remove_widget(trechventlike)
            cadre.remove_widget(bcharger)
        except:
            pass
        
        try:
            bcoupcendr.background_color='seagreen'
            bsystem.background_color='seagreen'
            bjournal.background_color='seagreen'
        except:
            pass

        try:
            cadre.remove_widget(bcad1)
            cadre.remove_widget(bcad2)
            cadre.remove_widget(bcad3)
        except:
            pass

        try:
            cadre.remove_widget(labhaut1b)
            cadre.remove_widget(labhaut2b)
            cadre.remove_widget(labhaut3b)
            cadre.remove_widget(check1)
            cadre.remove_widget(check2)
            cadre.remove_widget(labcheck)

            cadre.remove_widget(btest)
            cadre.remove_widget(barret)
            cadre.remove_widget(bdemm)
            
            cadre.remove_widget(labhaut1)
            cadre.remove_widget(labhaut2)
            cadre.remove_widget(labhaut3)
            cadre.remove_widget(combohaut1)
            cadre.remove_widget(combohaut2)
            cadre.remove_widget(combohaut3)
        except:
            pass
        try:
            cadre.remove_widget(labtot2)
        except:
            pass
        try:
            cadre.remove_widget(labtot1)
        except:
            pass

        try:
            cadre.remove_widget(bcorrection)
        except:
            pass

        try:
            cadre.remove_widget(labtot1)
        except:
            pass
        try:
            cadre.remove_widget(labtot2)
        except:
            pass
        
        try:
            cadre.remove_widget(bvueclaire)
        except:
            pass
        
        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass

        

        tpwdconn.text=""

        tpwdconn.text=""
        tidconn.text=""

        pwdvrai=""
        idmach=""

        # arreter le programme 

        self.stop()

    def deconnok(self,instance):

        global msgdec,pwdvrai,idmach,msgg,cadrehautnewvieux

        try:
            cadrehautnewvieux.remove_widget(cadrehautnew)
        except:
            pass

        msgg.dismiss()

        msgdec.dismiss()

        Window.size=(500,400)
        
        t1.pos_hint={'x':0.14, 'y':0.86}
        t3.pos_hint={'x':0.14, 'y':0.78}
        t5.pos_hint={'x':0.14, 'y':0.68}
        t7.pos_hint={'x':0.14, 'y':0.58}
        t9.pos_hint={'x':0.14, 'y':0.48}


        try:
            cadre.remove_widget(iccon2)
            cadre.remove_widget(iccon1)

        except:
            pass

        try:
            cadre.add_widget(btfond)
        except:
            pass

        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass

        try:
            cadre.remove_widget(fondpagevente)
        except:
            pass

        try:
            cadre.remove_widget(checkchangecdf)
        except:
            pass
        try:
            cadre.remove_widget(labchange)
        except:
            pass

        try:
            cadre.remove_widget(btmodstockauto)
        except:
            pass

        try:
            cadre.remove_widget(bpreforma)
        except:
            pass

        try:
            cadre.remove_widget(bimpressionpreforma)
        except:
            pass
        try:
            cadre.remove_widget(labnetpayer)
        except:
            pass
        
        try:
            cadre.remove_widget(bimpression)
        except:
            pass

        try:
            cadre.add_widget(bquiter)
        except:
            pass

        try:
            cadre.remove_widget(btsignale)
        except:
            pass
        try:
            cadre.remove_widget(btaide)
        except:
            pass

        try:
            cadre.remove_widget(bclose)
        except:
            pass

        try:
            cadre.remove_widget(imgtaux)
        except:
            pass
        try:
            cadre.remove_widget(taux)
        except:
            pass

        try:
        
            self.cconnexion()
            cursor=con.cursor()
            cursor.execute("delete from session where ids='"+tidconn.text+"'")
            con.commit()
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
            msg.open()
        
        try:
            cadre.remove_widget(labnet)
        except:
            pass
        try:
            cadre.remove_widget(bvalidercoupon)
            cadre.remove_widget(bsuprimercoupon)
            cadre.remove_widget(bretireelementcoupon)
        except:
            pass

        try:
            cadre.remove_widget(bcharg)
        except:
            pass

        try:
            cadre.remove_widget(tabmod)
        except:
            pass

        try:
            cadre.remove_widget(tquantite)
        except:
            pass

        try:
            b1.size_hint=(0,0.1)
            b1.text=""

            b2.size_hint=(0,0.1)
            b2.text=""

            b3.size_hint=(0,0.1)
            b3.text=""

            b4.size_hint=(0,0.1)
            b4.text=""
            
            b5.size_hint=(0,0.1)
            b5.text=""
        except:
            pass

        try:
            cadre.remove_widget(b1)
            cadre.remove_widget(b2)
            cadre.remove_widget(b3)
            cadre.remove_widget(b4)
            cadre.remove_widget(b5)
        except:
            pass

        try:
            cadre.remove_widget(btaction)
        except:
            pass

        try:
            tabv.remove_widget(lbv)
            cadre.remove_widget(tabv)
            cadre.remove_widget(tabvente1)
            cadre.remove_widget(bvente1)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn)
            
        except:
            pass
        labmod.pos_hint={'x':0.5,'y':0.5}
        try:
            cadre.remove_widget(labmod)
        except:
            pass
        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        
        try:
            cadre.add_widget(buser)
            buser.pos_hint={'x':0.6, 'y':0.3}
        except:
            pass
        try:
            cadre.add_widget(badmin)
            badmin.pos_hint={'x':0.2, 'y':0.3}
        except:
            pass


        try:
            cadre.add_widget(ptitre)
            cadre.add_widget(plabadmin)
            cadre.add_widget(plabuser)
        except:
            pass
        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)
        except:
            pass
        try:
            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)
        except:
            pass
        try:
            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)
        except:
            pass
        try:
            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)
        except:
            pass
        try:
            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass
        
        try:
            cadre.remove_widget(bsystem)
            cadre.remove_widget(bjournal)
            cadre.remove_widget(bcoupcendr)
        except:
            pass
        try:
            cadre.remove_widget(labvente)
        except:
            pass
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
        except:
            pass
        try:
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
        except:
            pass
        try:
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
        except:
            pass

        try:
            cadre.remove_widget(btncamera)
        except:
            pass
        try:
            cadre.remove_widget(table)
        except:
            pass
        try:
            cadre.remove_widget(btenregistrer)
        except:
            pass

        try:
            cadregauche.remove_widget(btaction)
        except:
            pass
        
        #page vente 
        try:
            btirehaut.pos_hint={'x':0.92,'y':0.92}
        except:
            pass
        try:
            btirehaut.background_normal="configuration.ico"
        except:
            pass
        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            cadre.remove_widget(bscanneur)
            cadre.remove_widget(trechvente)
            cadre.remove_widget(trechventlike)
            cadre.remove_widget(bcharger)
        except:
            pass
        
        try:
            bcoupcendr.background_color='seagreen'
            bsystem.background_color='seagreen'
            bjournal.background_color='seagreen'
        except:
            pass

        try:
            cadre.remove_widget(bcad1)
            cadre.remove_widget(bcad2)
            cadre.remove_widget(bcad3)
        except:
            pass

        try:
            cadre.remove_widget(labhaut1b)
            cadre.remove_widget(labhaut2b)
            cadre.remove_widget(labhaut3b)
            cadre.remove_widget(check1)
            cadre.remove_widget(check2)
            cadre.remove_widget(labcheck)

            cadre.remove_widget(btest)
            cadre.remove_widget(barret)
            cadre.remove_widget(bdemm)
            
            cadre.remove_widget(labhaut1)
            cadre.remove_widget(labhaut2)
            cadre.remove_widget(labhaut3)
            cadre.remove_widget(combohaut1)
            cadre.remove_widget(combohaut2)
            cadre.remove_widget(combohaut3)
        except:
            pass
        try:
            cadre.remove_widget(labtot2)
        except:
            pass
        try:
            cadre.remove_widget(labtot1)
        except:
            pass

        try:
            cadre.remove_widget(bcorrection)
        except:
            pass

        try:
            cadre.remove_widget(labtot1)
        except:
            pass
        try:
            cadre.remove_widget(labtot2)
        except:
            pass
        
        try:
            cadre.remove_widget(bvueclaire)
        except:
            pass
        
        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass

        

        tpwdconn.text=""

        tpwdconn.text=""
        tidconn.text=""

        pwdvrai=""
        idmach=""

        # arreter le programme 

        self.stop()

    def decvide(self,instance):
        global msgdec

        msgdec.dismiss()
        
    def pageconnexion(self):

        try:
            cadre.add_widget(btnconn)
            cadre.add_widget(tidconn)
            cadre.add_widget(tpwdconn)
            cadre.add_widget(imggconn)
            cadre.add_widget(labconn)
        except:
            pass
        
        
        try: 
            cadre.remove_widget(ptitre)
            cadre.remove_widget(plabadmin)
            cadre.remove_widget(plabuser)
        except:
            pass

        if typee=='1':
            try: 
                cadre.add_widget(badmin)
                badmin.pos_hint={'x':0.8, 'y':0.8}
            except:
                pass
        elif typee=='0':
            try:
                cadre.add_widget(buser)
                buser.pos_hint={'x':0.8, 'y':0.8}
            except:
                pass

        try:
            cadre.add_widget(bretour)
        except:
            pass
        
    
    def deconnverfie(self,instance):
        global sepp

        v1=0
        v2=0

        if tablravmultiple.row_data:
            v1=1

            lbnomdec=Label(text="[b]Impossible de vous deconnecter car le controleur systeme\ndetecte les données dont le traitement n a pas été finalisé\nNB:Dans la page de ravitaillement multiple [b]",font_size='14sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.9,0.6),markup=True)
        
        if tabvente1.row_data:
            v2=1

            lbnomdec=Label(text="[b]Impossible de vous deconnecter car le controleur systeme\ndetecte les données dont le traitement n a pas été finalisé\nNB:Dans la page de Vente (coté Travailleur) [b]",font_size='14sp',pos_hint={'center_x':0.5,'center_y':0.6},color='black',size_hint=(0.9,0.6),markup=True)
        
        if v1==1 or v2==1:
            cadd=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

            bbval1dec=Builder.load_string('''
Button:
    text:"[b]Close[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'x':0.75,'y':0.1}
    size_hint:0.2,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
            
            ''')

            bbval1dec.bind(on_release=lambda x: msggb.dismiss())

            try:
                cadd.add_widget(bbval1dec)
                cadd.add_widget(lbnomdec)

                msggb=Popup(title="CONTROLEUR SYSTEME",content=cadd,size_hint=(.6,.3))
                msggb.open()

            except:
                pass
        else:

            self.deconnsimple()

    def deconnexion(self,instance):

        global msgdec

        cadddec=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

        lbnomdec=Label(text="[b]Voulez-vous vraiment vous deconnecter? cette opération\nimplique la fermeture immmediate de la session et\nassurez-vous d avoir tout fini les opérations encours[b]",font_size='14sp',pos_hint={'x':0.4,'y':0.5},color='black',size_hint=(0.1,0.1),markup=True)
        
        bbval1dec=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.75,'center_y':0.1}
    size_hint:0.15,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')
        
        bbval1dec.bind(on_release=self.deconnverfie)#deconnok)

        bbval2dec=Builder.load_string('''

Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.1,'center_y':0.1}
    size_hint:0.15,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        
        ''')
        
        bbval2dec.bind(on_release=self.decvide)

        cadddec.add_widget(lbnomdec)
        cadddec.add_widget(bbval1dec)
        cadddec.add_widget(bbval2dec)

        msgdec=Popup(title="NOTIFICATION",content=cadddec,size_hint=(None, None), size=(600,200),background_color='blue')
        msgdec.open()  
    
    def deconnexionforcer(self,*args):

        global msgdec 

        cadddec=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint:{'x':0,'y':0}

    canvas.before:
        Color:
            rgb:1,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
        
        ''')

        lbnomdec=Label(text="[b]Voulez-vous vraiment vous deconnecter? cette opération\nimplique la fermeture immmediate de la session et\nassurez-vous d avoir tout fini les opérations encours[b]",font_size='14sp',pos_hint={'x':0.4,'y':0.5},color='black',size_hint=(0.1,0.1),markup=True)
        
        bbval1dec=Builder.load_string('''
Button:
    text:"[b]Oui[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.75,'center_y':0.1}
    size_hint:0.15,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')
        
        bbval1dec.bind(on_release=self.deconnverfie)#deconnok)

        bbval2dec=Builder.load_string('''

Button:
    text:"[b]Non[/b]"
    background_color:[0,0,0,0]
    pos_hint:{'center_x':0.1,'center_y':0.1}
    size_hint:0.15,0.12
    markup:True
    color:'white'

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        
        ''')
        
        bbval2dec.bind(on_release=self.decvide)

        cadddec.add_widget(lbnomdec)
        cadddec.add_widget(bbval1dec)
        cadddec.add_widget(bbval2dec)

        msgdec=Popup(title="NOTIFICATION.",content=cadddec,size_hint=(None,None),size=(500,300),background_color='blue')
        msgdec.open()

        return True
    
    def userpage(self,instance):
        global typee
        typee='0'

        try:
            cadre.remove_widget(configserveur)
        except:
            pass

        try: 
            cadre.remove_widget(instance)
        except:
            pass
        try:
            cadre.remove_widget(badmin)
        except:
            pass
            
        self.pageconnexion()

    def adminpage(self,instance):
        global typee
        typee='1'

        try:
            cadre.remove_widget(configserveur)
        except:
            pass
       
        try: 
            cadre.remove_widget(instance)
        except:
            pass
        try:
            cadre.remove_widget(buser)
        except:
            pass
        self.pageconnexion()

    def camparersecurite(self,instance):
        #datancienne='0000-00-00 00:00:00'
        
        global pwdvrai,idmach,tlicence

        datecontrol='0000-00-00'

        f1=os.path.join("C:\\","Windows","demshet.txt")
        f2=os.path.join("C:\\","Windows","win","time.txt")
        f3=os.path.join("C:\\","Windows","win","val.txt")


        if os.path.exists(f1)==True and os.path.exists(f2)==True and os.path.exists(f3)==True:
        
        
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select datess from controleur where id='"+ tidconn.text +"'")
                contro=self.cursor.fetchone()
                self.cursor.close()
                con.close()
                

                if contro:
                    datecontrol=str(contro[0])

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la verification via le controleur\n Vuillez redemarrer le systeme pour corriger les erreurs'),size_hint=(None, None), size=(400,200))
                msg.open()

            
            try:

                if datecontrol == '0000-00-00' or datecontrol < datetime.now().strftime('%Y-%m-%d'):

                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("delete from controleur where id='"+ tidconn.text +"'")
                        con.commit()
                        self.cursor.close()
                        con.close()
                        if resuu:
                            datancienne=str(resuu[0])

                    except:
                        pass
                    
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select ddats from commande where etat='1'")
                        resuu=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()
                        if resuu:
                            datancienne=str(resuu[0])

                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                        msg.open()
                        
                    try:
                        if datancienne < datetime.now().strftime('%Y-%m-%d %H:%M:%S'):
                            
                            
                            try:
                                self.cconnexion()
                                cursor=con.cursor()
                                query="update commande set ddats=%s,borne=%s where etat=%s"
                                cursor.execute(query,(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d'),'1'))
                                con.commit()
                                self.cursor.close()
                                con.close()

                                if tpwdconn.text=="" or tidconn.text=="":
                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Saisie erronnée '),size_hint=(None, None), size=(400,200))
                                    msg.open()
                                else:
                                    pwdvrai=""
                                    idmach=""
                                    content=""

                                    if typee=="1":
                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select pwd from compte where id='"+tidconn.text+"'and type='admin'")
                                            results=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()
                                            if results:
                                                pwdvrai=str(results[0])
                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                            msg.open()

                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                            ress=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()
                                            if ress:
                                                idmachine=str(ress[0])
                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                            msg.open()
                                        
                                        try:
                                            idmach=str(idmachine)
                                        except:
                                            pass

                                        datnow=datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                                        if idmach=="":
                                            try:
                                                
                                                try:
                                                    if pwdvrai==tpwdconn.text:

                                                        with open('xyz.txt','w') as file:
                                                            file.write(str(datnow))

                                                        try:
                                                            self.cconnexion()
                                                            cursor=con.cursor()
                                                            query="insert into session(ids,date_tim) values(%s,%s)"
                                                            cursor.execute(query,(tidconn.text,datnow))
                                                            con.commit()
                                                            self.cursor.close()
                                                            con.close()
                                                        except:
                                                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la signalisation de la session '),size_hint=(None, None), size=(400,200))
                                                            msg.open()


                                                        try:
                                                            cadre.remove_widget(btnconn)
                                                            cadre.remove_widget(tidconn)
                                                            cadre.remove_widget(tpwdconn)
                                                            cadre.remove_widget(imggconn)
                                                            cadre.remove_widget(labconn)
                                                        except:
                                                            pass
                                                        
                                                        try:
                                                            cadre.remove_widget(bretour)
                                                        except:
                                                            pass
                                                        try:
                                                            cadre.remove_widget(badmin)
                                                        except:
                                                            pass

                                                        try:
                                                            cadre.remove_widget(btfond)
                                                        except:
                                                            pass

                                                        try:
                                                            cadre.add_widget(fondacceuil)
                                                        except:
                                                            pass

                                                        self.pageaccueilvide()

                                                    else:
                                                        msg=Popup(title="STATUT REQUETE",content=Button(text='Mot de passe incorrect '),size_hint=(None, None), size=(400,200))
                                                        msg.open()
                                                        tpwdconn.text=""
                                                        tidconn.text=""
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur inattendue lors de la comparaision de données '),size_hint=(None, None), size=(400,200))
                                                    msg.open()

                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur inattendue lors de la comparaision de données '),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                        else:
                                            try:
                                                with open('xyz.txt','r') as fil:
                                                    content=fil.read()
                                            except:
                                                pass
                                                
                                            if content==idmach:
                                                try:
                                                    cadre.remove_widget(btnconn)
                                                    cadre.remove_widget(tidconn)
                                                    cadre.remove_widget(tpwdconn)
                                                    cadre.remove_widget(imggconn)
                                                    cadre.remove_widget(labconn)
                                                except:
                                                    pass
                                                
                                                try:
                                                    cadre.remove_widget(bretour)
                                                except:
                                                    pass
                                                try:
                                                    cadre.remove_widget(badmin)
                                                except:
                                                    pass

                                                try:
                                                    cadre.remove_widget(btfond)
                                                except:
                                                    pass

                                                try:
                                                    cadre.add_widget(fondacceuil)
                                                except:
                                                    pass
                                    
                                                self.pageaccueilvide()
                                            else:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Desolé car cet ID a deja sa session ouverte '),size_hint=(None, None), size=(400,200))
                                                msg.open()

                                    elif typee=="0":
                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select pwd from compte where id='"+tidconn.text+"'and type='user'")
                                            results=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()
                                            if results:
                                                pwdvrai=str(results[0])
                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                            msg.open()

                                        try:
                                            self.cconnexion()
                                            self.cursor=con.cursor()
                                            self.cursor.execute("select date_tim from session where ids='"+tidconn.text+"'")
                                            ress=self.cursor.fetchone()
                                            self.cursor.close()
                                            con.close()
                                            if ress:
                                                idmachine=str(ress[0])
                                        except:
                                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                            msg.open()
                                        
                                        try:
                                            idmach=str(idmachine)
                                        except:
                                            pass

                                        datnow=datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                                        if idmach=="":
                                            try:
                                            
                                                try:
                                                    if pwdvrai==tpwdconn.text:

                                                        with open('xy.txt','w') as file:
                                                            file.write(str(datnow))

                                                        try:
                                                            self.cconnexion()
                                                            cursor=con.cursor()
                                                            query="insert into session(ids,date_tim) values(%s,%s)"
                                                            cursor.execute(query,(tidconn.text,datnow))
                                                            con.commit()
                                                            self.cursor.close()
                                                            con.close()
                                                        except:
                                                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                                            msg.open()
                                                            
                                                        try:
                                                            cadre.remove_widget(btnconn)
                                                            cadre.remove_widget(tidconn)
                                                            cadre.remove_widget(tpwdconn)
                                                            cadre.remove_widget(imggconn)
                                                            cadre.remove_widget(labconn)
                                                        except:
                                                            pass
                                                        try:
                                                            cadre.remove_widget(bretour)
                                                        except:
                                                            pass
                                                        try:
                                                            cadre.remove_widget(buser)
                                                        except:
                                                            pass
                                                        try:
                                                            cadre.remove_widget(bquiter)
                                                        except:
                                                            pass

                                                        try:
                                                            cadre.remove_widget(btfond)
                                                        except:
                                                            pass

                                                        try:
                                                            pass
                                                            #cadre.add_widget(fondpagevente)
                                                        except:
                                                            pass

                                                        self.pagevente()

                                                        
                                                    else:
                                                        msg=Popup(title="STATUT REQUETE",content=Button(text='Mot de passe incorrect '),size_hint=(None, None), size=(400,200))
                                                        msg.open()
                                                        tpwdconn.text=""
                                                        tidconn.text=""
                                                except:
                                                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                                    msg.open()
                                            except:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                                msg.open()
                                        else:
                                            try:
                                                with open('xy.txt','r') as fil:
                                                    content=fil.read()
                                            except:
                                                pass
                                                
                                            if content==idmach:
                                                try:
                                                    cadre.remove_widget(btnconn)
                                                    cadre.remove_widget(tidconn)
                                                    cadre.remove_widget(tpwdconn)
                                                    cadre.remove_widget(imggconn)
                                                    cadre.remove_widget(labconn)
                                                except:
                                                    pass
                                                try:
                                                    cadre.remove_widget(bretour)
                                                except:
                                                    pass
                                                try:
                                                    cadre.remove_widget(buser)
                                                except:
                                                    pass

                                                try:
                                                    cadre.remove_widget(btfond)
                                                except:
                                                    pass

                                                try:
                                                    pass
                                                    #cadre.add_widget(fondpagevente)
                                                except:
                                                    pass

                                                self.pagevente()
                                            else:
                                                msg=Popup(title="STATUT REQUETE",content=Button(text='Desolé car cet ID a deja sa session ouverte '),size_hint=(None, None), size=(400,200))
                                                msg.open()
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(None, None), size=(400,200))
                                msg.open()
                        else: 
                            msg=Popup(title="STATUT REQUETE",content=Button(text='L horloge  n est pas à jour, veuillez bien regler\nla date et l heure, puis ressayer plus tard '),size_hint=(None, None), size=(400,200))
                            msg.open()
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard '),size_hint=(None, None), size=(400,200))
                        msg.open()
                else:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Ce travailleur a été supposé cloturé ses activités du jour\nVeuillez venir demain Stp !!'),size_hint=(None, None), size=(400,200))
                    msg.open()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='La comparaison de données a echoué !!\nVeuillez redemarrer si ca persite !'),size_hint=(None, None), size=(400,200))
                msg.open()
        else:

            cad=MDFloatLayout()

            labb1=Label(text="[b]CLE[/b]",markup=True,font_size='18sp',pos_hint={'x':0.1,'center_y':0.6},color='white',size_hint=(0.1,0.15))
            tlicence=TextInput(text="XXXX-XXXX-XXXX",font_size='15sp',pos_hint={'x':0.3,'center_y':0.6},size_hint=(0.5,0.15))
            tlicence.bind(focus=self.renitialisationcle)
            tlicence.bind(text=self.ajouttrait)

            bb2=Button(text="[b]Confirmer[/b]", background_color='blue',pos_hint={'center_x':0.8,'center_y':0.25},size_hint=(0.2,0.04),markup=True,color='white')
            bb2.bind(on_release=self.verifcle)

            bb3=Button(text="[b]Contactez ![/b]", background_color='blue',pos_hint={'center_x':0.8,'center_y':0.1},size_hint=(0.21,0.04),markup=True,color='white')
            bb3.bind(on_release=self.contactprogrammeur)
            

            try:  
                cad.add_widget(labb1)
                cad.add_widget(bb2)
                cad.add_widget(tlicence)
                cad.add_widget(bb3)
            except:
                pass

            msg=Popup(title="LICENCE DU PRODUIT",background_color='red',content=cad,size_hint=(None, None), size=(400,300))
            msg.open()

    def verifcle(self,instance):
        global tlicence

        if tlicence.text=="XXXX-XXXX-XXXX":
            pass

        else:
            tlicence.foreground_color='red'

            motextraire=tlicence.text

            deb1=motextraire[:6]
            
            deb3=motextraire[6:]

            movraii=deb1+" - "+deb3

            tlicence.text=movraii
        

    def ajouttrait(self,instance,value):
    
        if len(instance.text)<12:
            #instance.select_all()
            pass
            
        else:
            pass

    def renitialisationcle(self,instance,value):
        if instance.text=="XXXX-XXXX-XXXX":
            instance.text=""
        

    def pagevente(self):
        global sepp,datemodel

        bscanneur.pos_hint={'x':0.57,'y':0.92}

        imgtaux.pos_hint={'x':0.002,'y':0.5}
        imgtaux.size_hint=(0.1,0.14)

        sepp=8

        bcorrection.text='[b]Correction d erreur ?[/b]'

        try:
            cadre.add_widget(iccon2)
            cadre.add_widget(iccon1)
        except:
            pass

        try:
            cadre.add_widget(btaide)
        except:
            pass

        try:
            cadre.add_widget(btsignale)
        except:
            pass

        try:
            cadre.add_widget(imgtaux)
        except:
            pass

        try:
            cadre.add_widget(taux)
        except:
            pass

        try:
            cadre.remove_widget(bquiter)
        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select ddats from commande where etat='1'")
            resulone=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if resulone:
                datemodel=resulone[0]
                

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue car le Dictionnaoire de Date n a pas été chargé correctment, veuillez redemarrer le systeme pour eviter les erreurs'),size_hint=(None, None), size=(400,200))
            msg.open()

            datemodel=datetime.strptime('0000-00-00','%H:%m:%s')

        try:
            cadre.add_widget(photoproduit) 
        except:
            pass

        try:
            cadre.add_widget(bvueclaire)
        except:
            pass

        try:
            cadre.add_widget(labnet)
            cadre.add_widget(labnetpayer)
        except:
            pass

        try:
            cadre.add_widget(bretireelementcoupon)
            cadre.add_widget(bsuprimercoupon)
            cadre.add_widget(bvalidercoupon)
        except:
            pass

        try:
            t1.password=True
        except:
            pass
        
        try:
            cadre.add_widget(bscanneur)
            cadre.add_widget(trechvente)
            cadre.add_widget(trechventlike)
            cadre.add_widget(bcharger)
        except:
            pass

        try:
            cadre.add_widget(btirehaut)
        except:
            pass
        try:
            cadre.add_widget(tquantite)
        except:
            pass
        try:
            cadregauche.remove_widget(btaction)
        except:
            pass

        try:
            #bdeconn.pos_hint={'x':0.82, 'y':0.95}
            #bdeconn.background_color="white"
            #bdeconn.color='seagreen'
            #bdeconn.background_normal=''
            #bdeconn.background_down=''
            #bdeconn.border=(0,0,0,0)
            pass
        except:
            pass

        try:
            tabv.add_widget(lbv)
            cadre.add_widget(tabv)
            cadre.add_widget(bvente1)
        except:
            pass
        try:
            cadre.add_widget(tabvente1)
        except:
            pass
        try:
            t1.text=''
            t2.text=''
            t3.text=''
            t4.text=''
            t5.text=''
            t6.text=''
            t7.text=''
            t8.text=''
        except:
            pass

        try:
            t1.helper_text=''
            t2.helper_text=''
            t3.helper_text=''
            t4.helper_text=''
            t5.helper_text=''
            t6.helper_text=''
            t7.helper_text=''
            t8.helper_text=''
        except:
            pass
        try:
            t1.disabled=True
            t2.disabled=True
            t3.disabled=True
            t4.disabled=True
            t5.disabled=True
            t6.disabled=True
            t7.disabled=True
            t8.disabled=True
        except:
            pass
        try:
            cadre.add_widget(bsystem)
            cadre.add_widget(bjournal)
            cadre.add_widget(bcoupcendr)
        except:
            pass
        try:
            cadre.add_widget(labvente)
        except:
            pass
        try:
            Window.size=(1100,680)
        except:
            pass

        try:
            cadre.add_widget(t1)
            cadre.add_widget(t2)
            cadre.add_widget(t3)
            cadre.add_widget(t4)
            cadre.add_widget(t5)
            cadre.add_widget(t6)
            cadre.add_widget(t7)
            cadre.add_widget(t8)
        except:
            pass
        try:
            cadre.remove_widget(btaction)
        except:
            pass

    def capturerproduit(self, instance):
        if instance.background_normal=='2956596.png':
            import cv2 as cv
            import os 
            capture = cv.VideoCapture(0)
            while capture.isOpened():
                ret, frame = capture.read()
                if ret==True:
                    cv.imshow('Video', frame)
                    if cv.waitKey(20) & 0xFF==ord('d'):
                        break
                else:
                    break
            capture.release()
            cv.destroyAllWindows()
            os.system('pause')
        else:
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                table.row_data=results
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la synchronisation et affichage systeme, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def modravitaillerfin(self,instance):
        global ravcombannee,ravcombmois,ravcombjour,idprodrav
        
        if ravcombannee.text=="[b]Annee[/b]" or ravcombmois.text=="[b]Mois[/b]":
            pass
        else:
            if ravcombjour.text=="[b]Jour[/b]":
                datf=ravcombannee.text+"-"+ravcombmois.text+"-30"

            else:

                datf=ravcombannee.text+"-"+ravcombmois.text+"-"+ravcombjour.text


            try:

                datev=datetime.strptime(datf,'%Y-%m-%d').date()

                try:
                    j=int(tb8.text)

                    try:
                        self.cconnexion()
                        cursor=con.cursor()
                        query="update produit set stock=%s,dats=%s,stock_p=%s where nom=%s"
                        cursor.execute(query,(int(tb4.text)+int(tb8.text),datetime.now().strftime('%Y-%m-%d'),int(tb3.text)+int(tb8.text),tb1.text))
                        con.commit()
                        self.cursor.close()
                        con.close()

                        if query:

                            try:

                                self.cconnexion()
                                cursor=con.cursor()
                                query="insert into expiration(id_exp,date_exp)values(%s,%s)"
                                cursor.execute(query,(idprodrav,datev))
                                con.commit()
                                self.cursor.close()
                                con.close()
                            except:
                                pass

                            try:

                                self.cconnexion()
                                cursor=con.cursor()
                                query="update expiration,produit set date_exp=%s where nom=%s and matricule=id_exp"
                                cursor.execute(query,(datev,tb1.text))
                                con.commit()
                                self.cursor.close()
                                con.close()
                            except:
                                msg=Popup(title="STATUT REQUETE",content=Button(text='L actualisation de la date d expiration a echoué'),size_hint=(None, None), size=(400,200))
                                msg.open()

                        msg=Popup(title="STATUT REQUETE",content=Button(text='Le Ravitaillement realisé avec succes'),size_hint=(None, None), size=(400,200))
                        msg.open()

                        tb4.text=""
                        tb8.text=""
                        tb3.text=""
                        tb2.text=""
                        tb1.text=""
                    
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la mise à jour, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

                except:

                    msg=Popup(title="ERROR",content=Button(text='La valeur saisie n est pas un chiffre '),size_hint=(None, None), size=(400,200))
                    msg.open()
            except:
                msg=Popup(title="ERROR",content=Button(text='Date NOT FOUND !! '),size_hint=(None, None), size=(400,200))
                msg.open()

    def modquantproduit(self,instance):
        global identid,ravcombannee,ravcombmois,ravcombjour

        if tb8.text!="":

            cadclos=MDFloatLayout()

            lb=Label(text="Veuillez choisir la date d expiration de ce produit !!",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.7},color='white',size_hint=(0.7,0.15))
            bb1=Button(text="[b]Valider[/b]", background_color='red',pos_hint={'x':0.8,'y':0.15},size_hint=(0.15,0.05),markup=True,color='white')
            bb1.bind(on_release=self.modravitaillerfin)

            ravcombannee=Spinner(text="2025",markup=True,pos_hint={'x':0.2, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
            ravcombannee.bind(on_release=self.chargerannee)

            ravcombmois=Spinner(text="[b]Mois[/b]",markup=True,pos_hint={'x':0.4, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
            ravcombmois.bind(on_release=self.chargemois)

            ravcombjour=Spinner(text="[b]Jour[/b]",markup=True,pos_hint={'x':0.6, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
            ravcombjour.bind(on_release=self.chargejour)
            
            try:
                cadclos.add_widget(ravcombannee)
                cadclos.add_widget(ravcombmois)
                cadclos.add_widget(ravcombjour)
            except:
                pass

            try:
                cadclos.add_widget(lb)
                cadclos.add_widget(bb1)
            
            except:
                pass

            msg=Popup(title="CONTROLEUR D EXPIRATION DE PRODUIT",content=cadclos,size_hint=(None, None), size=(600,200))
            msg.open()
    
        else:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Inserez une quantité'),size_hint=(None, None), size=(400,200))
            msg.open()    

    def traiterdater(self,instance,value):

        global listventecombine
        
        if combohaut3.text=='Graphique':
            
            if checkgobal.active==True:

                datss=combo1.text
                if datss=="Toutes": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from achat order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from achat")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

            elif checkgobal.active==False:

                datss=combo1.text
                if datss=="Toutes": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from historique order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from historique")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

        elif combohaut3.text=='Libre Export':

            if checkgobal.active==True:

                datss=combo1.text
                if datss=="Toutes": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from achat order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        #tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from achat")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

            elif checkgobal.active==False:

                datss=combo1.text
                if datss=="Toutes": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from historique order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        #tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from historique")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()


    def traiteridtrav(self,instance,value):

        global listventecombine

        if combohaut3.text=='Graphique':

            if checkgobal.active==True:

                if instance.text=="Tous":

                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from achat order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from achat")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])

                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

            elif checkgobal.active==False:

                if instance.text=="Tous":

                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from historique order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from historique")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])

                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

        elif combohaut3.text=='Libre Export': 

            if checkgobal.active==True:

                if instance.text=="Tous":

                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from achat order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        #tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from achat")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])

                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

            elif checkgobal.active==False:

                if instance.text=="Tous":

                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from historique order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        #tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from historique")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])

                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()


    def traiterId(self,instance,value):

        global listventecombine

        if combohaut3.text=='Graphique':

            if checkgobal.active==True:

                datss=combo2.text
                if datss=="Tous": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from achat order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from achat")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])

                        
                        #qt.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                        #self.cconnexion()
                        #self.cursor=con.cursor()
                        #self.cursor.execute("select SUM(PT) from achat")
                        #results=self.cursor.fetchall()
                        #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                        #self.cursor.close()
                        #con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

            elif checkgobal.active==False:

                datss=combo2.text
                if datss=="Tous": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from historique order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from historique")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

        elif combohaut3.text=='Libre Export': 

            if checkgobal.active==True:

                datss=combo2.text
                if datss=="Tous": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from achat order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        #tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from achat")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])

                        
                        #qt.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                        #self.cconnexion()
                        #self.cursor=con.cursor()
                        #self.cursor.execute("select SUM(PT) from achat")
                        #results=self.cursor.fetchall()
                        #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                        #self.cursor.close()
                        #con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

            elif checkgobal.active==False:

                datss=combo2.text
                if datss=="Tous": 
                    tablegestionvente.row_data=[]
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select * from historique order by Dats_id DESC")
                        results=self.cursor.fetchall()
                        listventecombine=results
                        #tablegestionvente.row_data=results
                        self.cursor.close()
                        con.close()
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()
                    try:
                        self.cconnexion()
                        self.cursor=con.cursor()
                        self.cursor.execute("select SUM(Qte),SUM(PT) from historique")
                        results=self.cursor.fetchone()
                        self.cursor.close()
                        con.close()

                        if results:
                            qt.text=str(results[0])
                            tot.text=str(results[1])
                        
                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

    def affichId(self,instance):
        global listventecombine

        if combohaut3.text=='Graphique': 

            if checkgobal.active==True:
        
                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat where ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+combo2.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])

                    #qt.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where ID_Produit='"+combo2.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:

                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique where ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from historique where ID_Produit='"+combo2.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])

                    #qt.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where ID_Produit='"+combo2.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

        elif combohaut3.text=='Libre Export':

            if checkgobal.active==True:
        
                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat where ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    #tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from achat where ID_Produit='"+combo2.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])

                    #qt.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where ID_Produit='"+combo2.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:

                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique where ID_Produit='"+combo2.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    #tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from historique where ID_Produit='"+combo2.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])

                    #qt.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where ID_Produit='"+combo2.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de du calcul system, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

    def affichdate(self,instance):
        global listventecombine

        self.cconnexion()
        tablegestionvente.row_data=[]
    
        if combohaut3.text=='Graphique': 

            if checkgobal.active==True:
                                
                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat where Dates='"+combo1.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from achat where Dates='"+combo1.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()
                    
                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])


                    #.replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where Dates='"+combo1.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:

                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique where Dates='"+combo1.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from historique where Dates='"+combo1.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()
                    
                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])


                    #.replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where Dates='"+combo1.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

        elif combohaut3.text=='Libre Export':

            if checkgobal.active==True:
                                
                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat where Dates='"+combo1.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    #tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from achat where Dates='"+combo1.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()
                    
                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])


                    #.replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where Dates='"+combo1.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:

                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique where Dates='"+combo1.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    #tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from historique where Dates='"+combo1.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()
                    
                    if results:
                        qt.text=str(results[0])
                        tot.text=str(results[1])


                    #.replace("[(Decimal('","").replace("'),)]","")
                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where Dates='"+combo1.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()


    def rechidtrav(self,instance):
        global listventecombine
        
        if combohaut3.text=='Graphique': 
            
            if checkgobal.active==True:

                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:

                        qt.text=str(results[0])
                        tot.text=str(results[1])
                        
                        #replace("[(Decimal('","").replace("'),)]","")

                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+combotrav.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:

                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:

                        qt.text=str(results[0])
                        tot.text=str(results[1])
                        
                        #replace("[(Decimal('","").replace("'),)]","")

                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+combotrav.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

        elif combohaut3.text=='Libre Export':

            if checkgobal.active==True:

                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat where id_travailleur='"+combotrav.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    #tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from achat where id_travailleur='"+combotrav.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:

                        qt.text=str(results[0])
                        tot.text=str(results[1])
                        
                        #replace("[(Decimal('","").replace("'),)]","")

                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+combotrav.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:

                tablegestionvente.row_data=[]
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique where id_travailleur='"+combotrav.text+"' order by Dats_id DESC")
                    results=self.cursor.fetchall()
                    listventecombine=results
                    #tablegestionvente.row_data=results
                    self.cursor.close()
                    con.close()
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select SUM(Qte),SUM(PT) from historique where id_travailleur='"+combotrav.text+"'")
                    results=self.cursor.fetchone()
                    self.cursor.close()
                    con.close()

                    if results:

                        qt.text=str(results[0])
                        tot.text=str(results[1])
                        
                        #replace("[(Decimal('","").replace("'),)]","")

                    #self.cconnexion()
                    #self.cursor=con.cursor()
                    #self.cursor.execute("select SUM(PT) from achat where id_travailleur='"+combotrav.text+"'")
                    #results=self.cursor.fetchall()
                    #tot.text=str(results).replace("[(Decimal('","").replace("'),)]","")
                    #self.cursor.close()
                    #con.close()
                    
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()


    def affidtravailleur(self,instance):

        combotrav.text="choisir" 

        if checkgobal.active==True:

            combotrav.values=("")
            j="Tous"
            combotrav.values.append(j)

            self.cconnexion()

            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct id_travailleur from achat")
                resultss=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                for  i in  resultss:
                    combotrav.values.append(str(i).replace("(","").replace(")","").replace("'","").replace(",",""))
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        elif checkgobal.active==False:

            combotrav.values=("")
            j="Tous"

            self.cconnexion()

            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct id_travailleur from historique")
                resultss=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                for  i in  resultss:
                    combotrav.values.append(str(i).replace("(","").replace(")","").replace("'","").replace(",",""))
                    
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            
            combotrav.values.append(j)

    def rechdate(self,instance):

        global datdeb,datefin    

        combo1.text="choisir"
        
        if pasconnette.text=="Pas":

            if checkgobal.active==True:

                combo1.values=("")
                j="Toutes"
                combo1.values.append(j)
                self.cconnexion()

                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Dates from achat order by Dates ASC")
                    results=self.cursor.fetchall()
                    datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                    self.cursor.close()
                    con.close()
                    for  i in  datat:
                        combo1.values.append(str(i))
                            
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:
                combo1.values=("")
                j="Toutes"

                self.cconnexion()

                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Dates from historique order by Dates ASC")
                    results=self.cursor.fetchall()
                    datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                    self.cursor.close()
                    con.close()
                    for  i in  datat:
                        combo1.values.append(str(i))
                            
                            #str(i)[15:27:1].replace(",","-"))
                                            #replace("(datetime.date(","").replace("),)","").replace(",","-"))
                                            #replace(")","").replace("'",""))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                
                combo1.values.append(j)
        else:

            if checkgobal.active==True:

                combo1.values=("")
                j="Toutes"
                combo1.values.append(j)
                self.cconnexion()

                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Dates from achat where Dates>='"+str(datdeb)+"' and Dates <='"+str(datefin)+"' order by Dates ASC") 
                    results=self.cursor.fetchall()
                    datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                    self.cursor.close()
                    con.close()
                    for  i in  datat:
                        combo1.values.append(str(i))
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

            elif checkgobal.active==False:
                combo1.values=("")
                j="Toutes"

                self.cconnexion()

                try:
                    self.cursor=con.cursor()
                    self.cursor.execute("select distinct Dates from historique where Dates>='"+str(datdeb)+"' and Dates <='"+str(datefin)+"' order by Dates ASC")
                    results=self.cursor.fetchall()
                    datat=[resulat[0].strftime('%Y-%m-%d') for resulat in results]
                    self.cursor.close()
                    con.close()
                    for  i in  datat:
                        combo1.values.append(str(i))
                        
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                
                combo1.values.append(j)
                
    def rechId(self,instance):
        global textregaleidpro

        combo2.text="choisir" 

        if checkgobal.active==True:

            combo2.values=("")
            j="Tous"
            combo2.values.append(j)
            
            self.cconnexion()

            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct ID_Produit from achat where ID_Produit LIKE'%"+textregaleidpro.text+"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                
                for  i in  results:
                    combo2.values.append(str(i).replace("(","").replace(")","").replace("'","").replace(",",""))
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        elif checkgobal.active==False:

            combo2.values=("")
            j="Tous"
            
            self.cconnexion()

            try:
                self.cursor=con.cursor()
                self.cursor.execute("select distinct ID_Produit from historique where ID_Produit LIKE'%"+textregaleidpro.text+"%'")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()
                
                for  i in  results:
                    combo2.values.append(str(i).replace("(","").replace(")","").replace("'","").replace(",",""))
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            
            combo2.values.append(j)
    
    def on_symbols(self,instance):
        pass
        #Myapp().run()
    def affravatail(self,instance_table,current_row):
        global identid,idprodrav
        if hautlab1.text=="[b]RAVITAILLEMENT PRODUIT[/b]":
            msg=Popup(title="Attention !!",content=Button(text='Au moment de ravitailler le stock du produit,\nrassures toi de données que tu enregistres'),size_hint=(None, None), size=(400,200))
            msg.open()

            try:
                identid=str(current_row[0])
                idprodrav=identid

                self.cconnexion()
                cursor=con.cursor()
                query="select nom,pu,stock,stock_p from produit where matricule='"+identid+"'"
                cursor.execute(query)
                results=cursor.fetchone()
                self.cursor.close()
                con.close()
                if results:
                    tb1.text=str(results[0])
                    tb2.text=str(results[1])
                    tb4.text=str(results[2])
                    tb3.text=str(results[3])
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

    def afficheviaclicpagestock(self,instance_table,current_row):
        ident=str(current_row[0])
        try:
            self.cconnexion()
            cursor=con.cursor()
            query="select SUM(Qte) as qt from achat where ID_Produit='"+ident+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()
            if results:
                tb8.text=str(results[0])
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur la sommation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
        try:
            self.cconnexion()
            cursor=con.cursor()
            query="select matricule,nom,categorie,pu,stock,dats,stock_p from produit where matricule='"+ident+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                tb1.text=results[0]
                tb2.text=results[1]
                tb3.text=results[2]
                tb4.text=str(results[3])
                tb6.text=str(results[4])
                tb7.text=str(results[5])
                tb5.text=str(results[6])
                
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue sur le recuperation, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

    def afficheviaclic(self,instance_table,current_row):
        global tauxjour

        if btenregistrer.text=="[b]Modifier[/b]":
            ident=str(current_row[0])
            try:
                self.cconnexion()
                cursor=con.cursor()
                query="select * from produit where matricule='"+ident+"'"
                cursor.execute(query)
                results=cursor.fetchone()
                self.cursor.close()
                con.close()

                if results:
                    t1.text=results[0]
                    t2.text=results[1]
                    t3.text=results[2]
                    t4.text=results[3]
                    t5.text=results[4]
                    t6.text=results[5]
                    t7.text=results[6]
                    t8.text=str(results[7]*tauxjour)
                    t9.text=str(results[8])
                    t10.text=str(results[9])
                    ab=str(results[10])

                
                    try:
                        cadre.add_widget(photoproduit) 
                    except:
                        pass
                    

                    try:
                        discourant=os.path.dirname(__file__)
                        disprod=os.path.join(discourant,"ftx",t1.text)

                        photoproduit.source= disprod + ".jpg"
                        
                    except:
                        pass
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
        
            t10.disabled=True  
            t9.disabled=True  
            t1.disabled=True
            t1.helper_text=""
            t10.helper_text=""
            t9.helper_text=""
        else:
            pass

    def chargerannee(self,instance):
        global interval

        instance.values=""

        lisannee=['2024','2025','2026','2027','2028','2029','2030']
        ianne=0
        for ianne in range(len(lisannee)):
            instance.values.append(lisannee[ianne])
        
        interval=1

    def chargemois(self,instance):
        global interval

        instance.values=""

        imois=1
        for imois in range(13):
            instance.values.append(str(imois))

        interval=1

    def chargejour(self,instance):
        global interval

        instance.values=""

        ijour=1
        for ijour in range(32):
            instance.values.append(str(ijour))

        interval=1

    def operationfin2(self,instance):
        global pudollar

        pu=t8.text
        stock=t9.text

        controleur1=""
        controleur2=""
        t8.line_color_normal='black'
        t9.line_color_normal='black'
        
        try:
            float(pu)
        except:
            t8.line_color_normal='red'
            controleur1="1"
        try:
            int(stock)
        except:
            t9.line_color_normal='red'
            controleur2="1"
        
        if controleur2=="1" or controleur1=="1":
            pass
        else:

            try:
                self.cconnexion()
                cursor=con.cursor()
                query="update produit set nom=%s,categorie=%s,anti=%s,traite=%s,posologie=%s,age_utilisation=%s,pu=%s where matricule=%s"
                cursor.execute(query,(t2.text,t3.text,t4.text,t5.text,t6.text,t7.text,pudollar,t1.text))
                con.commit()
                self.cursor.close()
                con.close()

                msg=Popup(title="STATUT REQUETE",content=Button(text='La madification realisée avec succes'),size_hint=(None, None), size=(400,200))
                msg.open()

                photoproduit.background_normal=''

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue, veuillez ressayer plus tard'),size_hint=(None, None), size=(600,200))
                msg.open()            
            
            if query:
                t1.text=""
                t2.text=""
                t3.text=""
                t4.text=""
                t5.text=""
                t6.text=""
                t7.text=""
                t8.text=""
                t9.text=""
                t10.text=""


    def operation(self, instance):
        global combjour,combmois,combannee,msgexp,tauxjour,pudollar,indicevaleur

        #or t3.text=="" or t4.text=="" or t5.text=="" or t6.text=="" or t7.text==""

        if t1.text=="" or t2.text==""  or t8.text=="":
            msg=Popup(title="STATUT REQUETE",content=Button(text='Champs obligatoire !! '),size_hint=(None, None), size=(400,200))
            msg.open()  
        else:

            #t10.text=str(datetime.now().strftime('%Y-%m-%d'))
            t10.text=str(datetime.now().strftime('%Y-%m-%d'))

            if btnchangeCdfUsd.active==True:
                pass
            else:
                try:
                    t8.text=str(int(t8.text)/tauxchangenew)
                except:
                    pass

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select valeur from indice where id_ind='indice'")
                results=self.cursor.fetchone()
                self.cursor.close()
                con.close()
                if results:
                    indicevaleur=results[0]          
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur NOT READ INDICE SYSTEM, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            pudollar=0.0
            
            if indicateurindice.active==True:
                
                if instance.text=="[b]Modifier[/b]":

                    try:
                        puv=t8.text.replace(',','.')

                        nbrd=str(float(puv)*float(indicevaleur))

                        idol=nbrd.split(".")
                        entier=idol[0]
                        decimal=idol[1]

                        if len(decimal)<=2:

                            pudollar=float(nbrd)

                        else:
                            
                            partdebut=decimal[0:2]
                            
                            valfin=int(decimal[2])

                            if (valfin<9):
                                valfin +=1

                                decimcorrect=partdebut+str(valfin)

                                valok=entier +'.'+ decimcorrect

                                pudollar=float(valok)
                                
                            elif valfin==9:
                                partdebut=decimal[0:1]
                                valfin=int(decimal[1])+1

                                decimcorrect=partdebut+str(valfin)

                                valok=entier +'.'+ decimcorrect

                                pudollar=float(valok)

                    except:
                        pass

                    cadclos=MDFloatLayout()

                    lb=Label(text="Total converti de ce produit !! $ =>[ "+str(pudollar)+" ]",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.7},color='white',size_hint=(0.7,0.15))
                    bb1=Button(text="[b]Suivant[/b]", background_color='red',pos_hint={'x':0.8,'y':0.15},size_hint=(0.15,0.05),markup=True,color='white')
                    bb1.bind(on_release=self.operationfin2)

                    try:
                        cadclos.add_widget(lb)
                        cadclos.add_widget(bb1)
                    except:
                        msgexp=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                        msgexp.open()

                    msg=Popup(title="CONTROLEUR D EXPIRATION DE PRODUIT",content=cadclos,size_hint=(None, None), size=(600,200))
                    msg.open()

                elif instance.text=="[b]Enregistrer[/b]":

                    try:
                        puv=t8.text.replace(',','.')

                        nbrd=str(float(puv)*float(indicevaleur))

                        idol=nbrd.split(".")
                        entier=idol[0]
                        decimal=idol[1]

                        if len(decimal)<=2:

                            pudollar=float(nbrd)

                        else:
                            
                            partdebut=decimal[0:2]
                            
                            valfin=int(decimal[2])

                            if (valfin<9):
                                valfin +=1

                                decimcorrect=partdebut+str(valfin)

                                valok=entier +'.'+ decimcorrect

                                pudollar=float(valok)
                                
                            elif valfin==9:
                                partdebut=decimal[0:1]
                                valfin=int(decimal[1])+1

                                decimcorrect=partdebut+str(valfin)

                                valok=entier +'.'+ decimcorrect

                                pudollar=float(valok)

                    except:
                        pass


                    cadclos=MDFloatLayout()

                    lb=Label(text="Veuillez choisir la date d expiration de ce produit !! $ =>[ "+str(pudollar)+" ]",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.7},color='white',size_hint=(0.7,0.15))
                    bb1=Button(text="[b]Suivant[/b]", background_color='red',pos_hint={'x':0.8,'y':0.15},size_hint=(0.15,0.05),markup=True,color='white')
                    bb1.bind(on_release=self.operationfin)

                    combannee=Spinner(text="2026",markup=True,pos_hint={'x':0.2, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
                    combannee.bind(on_release=self.chargerannee)

                    combmois=Spinner(text="[b]Mois[/b]",markup=True,pos_hint={'x':0.4, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
                    combmois.bind(on_release=self.chargemois)

                    combjour=Spinner(text="[b]Jour[/b]",markup=True,pos_hint={'x':0.6, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
                    combjour.bind(on_release=self.chargejour)
                    
                    try:
                        cadclos.add_widget(combannee)
                        cadclos.add_widget(combmois)
                        cadclos.add_widget(combjour)
                    except:
                        msg=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                        msg.open()

                    try:
                        cadclos.add_widget(lb)
                        cadclos.add_widget(bb1)
                    
                    except:
                        msgexp=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                        msgexp.open()

                    msg=Popup(title="CONTROLEUR D EXPIRATION DE PRODUIT",content=cadclos,size_hint=(None, None), size=(600,200))
                    msg.open()
                
            else:

                try:
                    puv=t8.text.replace(',','.')

                    nbrd=str(float(puv))

                    idol=nbrd.split(".")
                    entier=idol[0]
                    decimal=idol[1]

                    if len(decimal)<=2:

                        pudollar=float(nbrd)

                    else:
                        
                        partdebut=decimal[0:2]
                        
                        valfin=int(decimal[2])

                        if (valfin<9):
                            valfin +=1

                            decimcorrect=partdebut+str(valfin)

                            valok=entier +'.'+ decimcorrect

                            pudollar=float(valok)
                            
                        elif valfin==9:
                            partdebut=decimal[0:1]
                            valfin=int(decimal[1])+1

                            decimcorrect=partdebut+str(valfin)

                            valok=entier +'.'+ decimcorrect

                            pudollar=float(valok)
                except:
                    pass

                if instance.text=="[b]Modifier[/b]":

                    cadclos=MDFloatLayout()

                    lb=Label(text="Total converti de ce produit !! $ =>[ "+str(pudollar)+" ]",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.7},color='white',size_hint=(0.7,0.15))
                    bb1=Button(text="[b]Suivant[/b]", background_color='red',pos_hint={'x':0.8,'y':0.15},size_hint=(0.15,0.05),markup=True,color='white')
                    bb1.bind(on_release=self.operationfin2)

                    try:
                        cadclos.add_widget(lb)
                        cadclos.add_widget(bb1)
                    except:
                        msgexp=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                        msgexp.open()

                    msg=Popup(title="CONTROLEUR D EXPIRATION DE PRODUIT",content=cadclos,size_hint=(None, None), size=(600,200))
                    msg.open()

                elif instance.text=="[b]Enregistrer[/b]":

                    cadclos=MDFloatLayout()

                    lb=Label(text="Veuillez choisir la date d expiration de ce produit !! $ =>[ "+str(pudollar)+" ]",font_size='15sp',pos_hint={'center_x':0.5,'center_y':0.7},color='white',size_hint=(0.7,0.15))
                    bb1=Button(text="[b]Suivant[/b]", background_color='red',pos_hint={'x':0.8,'y':0.15},size_hint=(0.15,0.05),markup=True,color='white')
                    bb1.bind(on_release=self.operationfin)

                    combannee=Spinner(text="2026",markup=True,pos_hint={'x':0.2, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
                    combannee.bind(on_release=self.chargerannee)

                    combmois=Spinner(text="[b]Mois[/b]",markup=True,pos_hint={'x':0.4, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
                    combmois.bind(on_release=self.chargemois)

                    combjour=Spinner(text="[b]Jour[/b]",markup=True,pos_hint={'x':0.6, 'center_y':0.45},size_hint=(0.1,0.04),background_color="seagreen", color="white")
                    combjour.bind(on_release=self.chargejour)
                    
                    try:
                        cadclos.add_widget(combannee)
                        cadclos.add_widget(combmois)
                        cadclos.add_widget(combjour)
                    except:
                        msg=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                        msg.open()

                    try:
                        cadclos.add_widget(lb)
                        cadclos.add_widget(bb1)
                    
                    except:
                        msgexp=Popup(title="ETAT REQUETE",content=Button(text=' Error '),size_hint=(None, None), size=(400,200))
                        msgexp.open()

                    msg=Popup(title="CONTROLEUR D EXPIRATION DE PRODUIT",content=cadclos,size_hint=(None, None), size=(600,200))
                    msg.open()
        
    
    def operationfin(self,instance):
        global combjour,combmois,combannee,msgexp,tauxjour,pudollar

        discourant=os.path.dirname(__file__)
        discrec=os.path.join(discourant,"ft")
        disprod=os.path.join(discourant,"ftx")

        if combannee.text=="[b]Annee[/b]" or combmois.text=="[b]Mois[/b]":
            pass
        else:

            id=t1.text
            nom=t2.text
            categorie=t3.text
            anti=t4.text
            traite=t5.text
            posologie=t6.text
            age=t7.text
            pu=t8.text

            if t9.text=="":
                t9.text="0"
            
            stock=t9.text
            datss=t10.text

            controleur1=""
            controleur2=""
            t8.line_color_normal='black'
            t9.line_color_normal='black'
            
            try:
                float(pu)
            except:
                t8.line_color_normal='red'
                controleur1="1"

            try:
                int(stock)
            except:
                t9.line_color_normal='red'
                controleur2="1"

            if controleur1=="1" or controleur2=="1":
                msg=Popup(title="ERROR",content=Button(text='Saisie erronée, Veuillez remplir correctement les champs'),size_hint=(None, None), size=(400,200))
                msg.open()
            else:
                if combjour.text=="[b]Jour[/b]":
                    dats=combannee.text+"-"+combmois.text+"-"+"30"
                else:
                    dats=combannee.text+"-"+combmois.text+"-"+combjour.text
                
                try:

                    datexp=datetime.strptime(dats,'%Y-%m-%d').date()

                    try:
                        pu=int(pu)
                        stock=int(stock)
                    except:
                        pass

                    try:
                        self.cconnexion()
                        cursor=con.cursor()
                        query="insert into produit(matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,dats,stock_p) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                        dataa=(id,nom,categorie,anti,traite,posologie,age,pudollar,stock,datss,stock)
                        cursor.execute(query,dataa)
                        con.commit()
                        self.cursor.close()
                        con.close()

                        msg=Popup(title="STATUT REQUETE",content=Button(text='Le produit a été ajouté avec succes'),size_hint=(None, None), size=(400,200))
                        msg.open()

                        try:
                            self.cconnexion()
                            cursor=con.cursor()
                            query="insert into expiration(id_exp,date_exp) values(%s,%s)"
                            dataa=(id,datexp)
                            cursor.execute(query,dataa)
                            con.commit()
                            self.cursor.close()
                            con.close()

                            t1.text=""
                            t2.text=""
                            t3.text=""
                            t4.text=""
                            t5.text=""
                            t6.text=""
                            t7.text=""
                            t8.text=""
                            t9.text=""
                            t10.text=""

                        except:
                            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de l insertion de la date d expiration, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                            msg.open()

                        try:

                            for fichier in os.listdir(discrec):
                                f=os.path.join(discrec,fichier)
                                if os.path.isfile(f):
                                    try: 
                                        shutil.move(f,disprod)
                                        
                                        photoproduit.background_normal=''
                            
                                    except:
                                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la liberation des instances systeme, veuillez cliquez sur "RESET" pour remedier ce cas avant le prochain enregistrement '),size_hint=(None, None), size=(400,200))
                                        msg.open()
                        except:
                            pass
                            #msg=Popup(title="STATUT REQUETE",content=Button(text='La photo n a pas été recupérée,tu pourras l ajouter via la page de modification de données'),size_hint=(None, None), size=(400,200))
                            #msg.open()


                    except:
                        msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de l insertion de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                        msg.open()

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Date NOT FOUND !!'),size_hint=(None, None), size=(400,200))
                    msg.open()

                    
            #try:
             #   self.cconnexion()
              #  self.cursor=con.cursor()
               # self.cursor.execute("select * from produit")
            #    results=self.cursor.fetchall()
            #    self.cursor.close()
            #    con.close()

             #   table.row_data=results
            #except:
            #    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la synchronisation et affichage systeme, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            #    msg.open()
            
    def eff(self,instance, value):
        if instance.text=="Rechercher":
            instance.text=""
        else:
            pass

    def eff2(self,instance, value):
        if instance.text=="Rechercher":
            trechvente.text=""
        else:
            pass

    def pageprisecharge(self,instance):
        global sepp,cadregauche,cadreprischarge

        sepp=5

        if tablprise.row_data==[]:

            self.affichprise()
        
        try:
            cadregauche.add_widget(cadreprischarge)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenue)
        except:
            pass
        
        try:
            cadregauche.remove_widget(cadremenueIcon)
        except:
            pass

        try:
            cadre.remove_widget(tablstocktotal)
        except:
            pass

        try:
            cadre.remove_widget(tablstockfini)
        except:
            pass


        try:
            cadre.remove_widget(labstockfini)
        except:
            pass

        try:
            cadre.remove_widget(bflechhaut)
        except:
            pass
        
        try:
            cadre.remove_widget(bflechbas)
        except:
            pass

        try:
            cadre.remove_widget(bflech0)
        except:
            pass

        try:
            cadre.remove_widget(bdemserveur)
        except:
            pass

        try:
            cadre.remove_widget(bscanneurannuler)
        except:
            pass

        try:
            cadre.remove_widget(photoproduit) 
        except:
            pass

        try:
            cadre.remove_widget(bscanneur)
        except:
            pass
        
        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn) 
        except:
            pass

        try:
            cadre.remove_widget(btnstock1)
            cadre.remove_widget(btnstock2)
            cadre.remove_widget(btnravitail)
        except:
            pass

        try:
            cadre.remove_widget(bperemption)
        except:
            pass

        try:
            #cadre.remove_widget(bflechhaut)
            #cadre.remove_widget(bflechbas)
            #cadre.remove_widget(bflech0)

            cadre.remove_widget(cadrebtfleche)
            
        except:
            pass
        
        try:
            pass

        except:
            pass

        hautlab1.text="[b]GESTION DE STOCK[/b]"
        
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
            cadre.remove_widget(btenregistrer)
            cadre.remove_widget(btncamera)
            cadre.remove_widget(table)            
        except:
            pass
        try:
           pass
        except:
            pass
        try:
            cadre.remove_widget(btnrechimg)
            cadre.remove_widget(btnrechimgdirrect)
            cadre.remove_widget(trech)
        except:
            pass
        try:
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)
        except:
            pass
        try:
            cadre.remove_widget(btrierdate)
            cadre.remove_widget(btrid)
            cadre.remove_widget(tablegestionvente)
        except:
            pass
        try:
            tabunitiltete.remove_widget(hautlab1)
            cadre.remove_widget(tabunitiltete)
            
        except:
            pass
        
        try:
            cadre.remove_widget(labtot)
            cadre.remove_widget(labqt)
            cadre.remove_widget(tot)
            cadre.remove_widget(qt)
            cadre.remove_widget(hlab2)
            cadre.remove_widget(hlab1)
            cadre.remove_widget(combo1)
            cadre.remove_widget(combo2)
        except:
            pass
        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)

            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)

            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)

            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)

            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass
        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass

        try:
            cadre.remove_widget(labstockfini)
            cadre.remove_widget(tablstockfini)
            cadre.remove_widget(tablstocktotal)
        except:
            pass
        

        try:

            tablstocktotal.row_data=[]
            tablstockfini.row_data=[]
            tablstock.row_data=[]

        except:
            pass

        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass
        
        try:
            cadre.remove_widget(tabmod)
        except:
            pass

        try:
            cadre.remove_widget(bautomodiftravprod)
        except:
            pass
        
        
        try:
            cadre.remove_widget(bexport)
        except:
            pass

        try:
            cadre.remove_widget(tablstockperime)
        except:
            pass

        try:
            cadre.remove_widget(trecravitail)
            cadre.remove_widget(combravitail)
        except:
            pass
        
        try:
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb8)
        except:
            pass
        try:
            cadre.remove_widget(btnmodqt)
        except:
            pass
        
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass

        try:
            cadre.remove_widget(bperemption)
        except:
            pass

       
        try:
            cadre.remove_widget(labstockfini)
            cadre.remove_widget(tablstockfini)
            cadre.remove_widget(tablstocktotal)
        except:
            pass


    def ravitaillement(self,instance):
        global sepp,selid,separstock,listproravitail

        selid="a"

        try:
            cadre.add_widget(btopenravmult)
        except:
            pass

        try:
            cadre.remove_widget(bexport)
        except:
            pass

        try:
            cadre.remove_widget(tablstockperime)
        except:
            pass

        try:
            cadre.add_widget(trecravitail)
            cadre.add_widget(combravitail)
        except:
            pass

        try:
            cadre.remove_widget(labstockfini)
            cadre.remove_widget(tablstockfini)
            cadre.remove_widget(tablstocktotal)
        except:
            pass

        try:
            cadre.remove_widget(bflechhaut)
            cadre.remove_widget(bflechbas)
            cadre.remove_widget(bflech0)
        except:
            pass
        
        try:
            tb1.hint_text="Nom"
            tb2.hint_text="PU"
            tb3.hint_text="Stock Courant"
            tb4.hint_text="Stock Initial"
            tb8.hint_text="Ajout"
            tb8.disabled=False
            tb8.line_color_normal="blue"
        except:
            pass
        try:
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.add_widget(tb1)
            cadre.add_widget(tb2)
            cadre.add_widget(tb3)
            cadre.add_widget(tb4)
            cadre.add_widget(tb8)
        except:
            pass
        try:
            cadre.add_widget(btnmodqt)
        except:
            pass
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass

        try:
            cadre.remove_widget(bperemption)
        except:
            pass

        hautlab1.text="[b]RAVITAILLEMENT PRODUIT[/b]"

        try:
            tablstock.pos_hint={'x':0.05,'y':0.28}
            tablstock.size_hint=(0.9,0.58)
        except:
            pass

        try:
            cadre.add_widget(tablstock)
            
        except:
            pass
    
        btnstock1.pos_hint={'x':0.52, 'y':0.05}
        btnstock2.pos_hint={'x':0.77, 'y':0.05}
        instance.pos_hint={'x':0.3, 'y':0.05}

        tablstock.row_data=[]

        if combohaut3.text=='Graphique':                                        

            try: 
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75")
                listproravitail=self.cursor.fetchall()
                tablstock.row_data=listproravitail
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de chargement des produits epuisés '),size_hint=(None, None), size=(400,200))
                msg.open()

        elif combohaut3.text=='Libre Export':
            try: 
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75")
                listproravitail=self.cursor.fetchall()
                #tablstock.row_data=listproravitail
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur de chargement des produits epuisés '),size_hint=(None, None), size=(400,200))
                msg.open()

        sepp=4
        separstock=1
    
    def peremption(self,instance):
        global separstock,resultsperime,selid

        selid=""

        tablstockperime.row_data=[]

        try:
            cadre.remove_widget(btopenravmult)
        except:
            pass

        try:
            cadre.add_widget(bexport)
        except:
            pass

        try:
            cadre.add_widget(tablstockperime)
        except:
            pass

        if combohaut3.text=='Graphique':
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,date_exp,stock_p from produit,expiration,commande where id_exp=matricule and DATEDIFF(date_exp,borne)<=150")
                resultsperime=self.cursor.fetchall()
                tablstockperime.row_data=resultsperime
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            
        elif combohaut3.text=='Libre Export':
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,date_exp,stock_p from produit,expiration,commande where id_exp=matricule and DATEDIFF(date_exp,borne)<=150")
                resultsperime=self.cursor.fetchall()
                #tablstockperime.row_data=resultsperime
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            
        try:
            nbrexpiratio=0

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select COUNT(*) from produit,expiration,commande where id_exp=matricule and DATEDIFF(date_exp,borne)<=150")
            resultscont=self.cursor.fetchone()
            self.cursor.close()
            con.close()

            if resultscont:
                nbrexpiratio=resultscont[0]
                
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            cadre.remove_widget(trecravitail)
            cadre.remove_widget(combravitail)
        except:
            pass
        
        try:
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb8)
        except:
            pass
        try:
            cadre.remove_widget(btnmodqt)
        except:
            pass
        
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass

       
        hautlab1.text="[b]PRODUITS EN VOIE DE PEREMPTION [/b]"+ "[ "+ str(nbrexpiratio)+"  ]"

        try:
            cadre.add_widget(labstockfini)
            cadre.add_widget(tablstockfini)
            cadre.add_widget(tablstocktotal)
        except:
            pass
   
        try:
            cadre.remove_widget(bflechhaut)
            cadre.remove_widget(bflechbas)
            cadre.remove_widget(bflech0)
        except:
            pass
        
        try:
            btnstock1.pos_hint={'x':0.52, 'y':0.05}
            btnstock2.pos_hint={'x':0.77, 'y':0.05}
            btnravitail.pos_hint={'x':0.3, 'y':0.05}
        except:
            pass


        try:
            cadre.remove_widget(tablstock)
        except:
            pass

        try:
            cadre.remove_widget(tablstocktotal)
        except:
            pass
        try:
            cadre.remove_widget(tablstockfini)
        except:
            pass
        
        separstock=0

    def stock(self, instance):
        global sepp,selid,dfadmin,modcommutationadmin,dfv,separstock,listfini,listproravitail

        selid="b"

        try:
            cadre.remove_widget(btopenravmult)
        except:
            pass

        try:
            cadre.add_widget(bexport)
        except:
            pass

        try:
            cadre.remove_widget(tablstockperime)
        except:
            pass

        try:
            cadre.remove_widget(trecravitail)
            cadre.remove_widget(combravitail)
        except:
            pass
        
        try:
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb8)
        except:
            pass
        try:
            cadre.remove_widget(btnmodqt)
        except:
            pass
        
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass

        try:
            cadre.add_widget(bperemption)
        except:
            pass

       
        hautlab1.text="[b]GESTION DE STOCK [/b]"

        instance.text ="[b]Stock Produit[/b]"+" [ "+str(len(dfadmin))+" ]"

        try:
            cadre.add_widget(labstockfini)
            cadre.add_widget(tablstockfini)
            cadre.add_widget(tablstocktotal)
        except:
            pass
   
        try:
            cadre.add_widget(bflechhaut)
            cadre.add_widget(bflechbas)
            cadre.add_widget(bflech0)
        except:
            pass
        
        try:
            btnstock1.pos_hint={'x':0.52, 'y':0.05}
            instance.pos_hint={'x':0.77, 'y':0.05}
            btnravitail.pos_hint={'x':0.3, 'y':0.05}
        except:
            pass
        try:
            tablstocktotal.row_data=[]
            tablstockfini.row_data=[]
        except:
            pass
        
        if combohaut3.text=='Graphique': 
        
            if modcommutationadmin==0:

                try:
                    pass
                    #dfv=pd.DataFrame(dfadmin)

                except:
                    pass
                
                try:
                    #tablstocktotal.row_data=dfv.values.tolist()
                    pass

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

                try:
                    tablstockfini.row_data=listproravitail
                except:
                    pass

            else:

                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75")
                    results=self.cursor.fetchall()
                    listfini=results
                    tablstockfini.row_data=results
                    self.cursor.close()
                    con.close()

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from produit")
                    results=self.cursor.fetchall()
                    tablstocktotal.row_data=results
                    self.cursor.close()
                    con.close()
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

                try:
                    cadre.remove_widget(tablstock)
                except:
                    pass
        
        elif combohaut3.text=='Libre Export':

            if modcommutationadmin==0:

                pass

            else:

                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75")
                    results=self.cursor.fetchall()
                    listfini=results
                    #tablstockfini.row_data=results
                    self.cursor.close()
                    con.close()

                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()
                
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from produit")
                    results=self.cursor.fetchall()
                    #tablstocktotal.row_data=results
                    self.cursor.close()
                    con.close()
                except:
                    msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                    msg.open()

                try:
                    cadre.remove_widget(tablstock)
                except:
                    pass

        sepp=4
        separstock=3

        try:
            cadre.remove_widget(tablstock) 
        except:
            pass

    def analyseurstock(self, instance):
        global sepp,separstock,listecritique,listenormale,selid

        selid=""

        try:
            cadre.remove_widget(btopenravmult)
        except:
            pass

        try:
            cadre.add_widget(bexport)
        except:
            pass

        try:
            cadre.remove_widget(tablstockperime)
        except:
            pass

        try:
            cadre.remove_widget(bperemption)
        except:
            pass

        try:
            cadre.remove_widget(trecravitail)
            cadre.remove_widget(combravitail)
        except:
            pass

        try:
            cadre.remove_widget(bflechhaut)
            cadre.remove_widget(bflechbas)
            cadre.remove_widget(bflech0)
        except:
            pass

        try:
            cadre.remove_widget(tablstocktotal)
        except:
            pass

        try:
            cadre.remove_widget(labstockfini)
        except:
            pass

        try: 
            cadre.remove_widget(tablstockfini)
        except:
            pass

        try:
            tb1.text=""
            tb2.text=""
            tb4.text=""
            tb3.text=""
        except:
            pass
        try:
            cadre.remove_widget(tablstock)
        except:
            pass

        try:
            instance.pos_hint={'x':0.52, 'y':0.23}
            btnstock2.pos_hint={'x':0.77, 'y':0.23}
            btnravitail.pos_hint={'x':0.27, 'y':0.23}
        except:
            pass
        try:
            cadre.remove_widget(btnmodqt)
        except:
            pass
        
        try:
            tb1.hint_text="ID"
            tb2.hint_text="Nom"
            tb3.hint_text="Catégorie"
            tb4.hint_text="Prix Unitaire"
            tb8.hint_text="Quantité vendue"
            tb8.line_color_normal="black"
            tb8.disabled=True
        except:
            pass
        try:
            cadre.add_widget(tb5)
            cadre.add_widget(tb6)
            cadre.add_widget(tb7)
            cadre.add_widget(ldetail)
        except:
            pass
        try:
            cadre.add_widget(tb1)
            cadre.add_widget(tb2)
            cadre.add_widget(tb3)
            cadre.add_widget(tb4)
            cadre.add_widget(tb8)
        except:
            pass
        
        try:
            cadre.add_widget(tabstock1)
            cadre.add_widget(labstock1)
        except:
            pass
        try:
            cadre.add_widget(tabstock2)
            cadre.add_widget(labstock2)
        except:
            pass

        
        if combohaut3.text=='Graphique':      
            
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,categorie,pu,dats,stock,stock_p from produit,commande where DATEDIFF(borne,dats)<=10 and (stock-stock_p)*100/stock>=12")
                results=self.cursor.fetchall()
                listenormale=results
                tabstock1.row_data=results
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,categorie,pu,dats,stock,stock_p from produit,commande where DATEDIFF(borne,dats)>10 and (stock-stock_p)*100/stock<12")
                results=self.cursor.fetchall()
                listecritique=results
                tabstock2.row_data=results
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
         
        elif combohaut3.text=='Libre Export':

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,categorie,pu,dats,stock,stock_p from produit,commande where DATEDIFF(borne,dats)<=10 and (stock-stock_p)*100/stock>=12")
                results=self.cursor.fetchall()
                listenormale=results
                #tabstock1.row_data=results
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,categorie,pu,dats,stock,stock_p from produit,commande where DATEDIFF(borne,dats)>10 and (stock-stock_p)*100/stock<12")
                results=self.cursor.fetchall()
                listecritique=results
                #tabstock2.row_data=results
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
   
        hautlab1.text="[b]ANALYSEUR DE PERFORMANCE[/b]"
        sepp=4
        separstock=2

    def gestionstock(self,instance):
        global sepp,modcommutation,dfadmin,proepuisedirrect,listprofini,selid

        fondacceuil.background_normal='page_STOCK.jpg'

        selid="b"


        try:
            cadre.remove_widget(btopenravmult)
        except:
            pass

        try:
            cadregauche.remove_widget(cadreprischarge)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenue)
        except:
            pass
        
        try:
            cadregauche.remove_widget(cadremenueIcon)
        except:
            pass

        try:
            cadre.add_widget(tablstocktotal)
        except:
            pass

        try:
            cadre.add_widget(tablstockfini)
        except:
            pass


        try:
            cadre.add_widget(labstockfini)
        except:
            pass

        try:
            cadre.add_widget(bflechhaut)
        except:
            pass
        
        try:
            cadre.add_widget(bflechbas)
        except:
            pass

        try:
            cadre.add_widget(bflech0)
        except:
            pass

        try:
            cadre.remove_widget(bdemserveur)
        except:
            pass

        try:
            cadre.remove_widget(bscanneurannuler)
        except:
            pass

        try:
            cadre.remove_widget(photoproduit) 
        except:
            pass

        try:
            cadre.remove_widget(bscanneur)
        except:
            pass
        
        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn) 
        except:
            pass

        try:
            cadre.add_widget(btnstock1)
            cadre.add_widget(btnstock2)
            cadre.add_widget(btnravitail)
        except:
            pass

        try:
            cadre.add_widget(bperemption)
        except:
            pass

        try:
            #cadre.add_widget(bflechhaut)
            #cadre.add_widget(bflechbas)
            #cadre.add_widget(bflech0)

            cadre.add_widget(cadrebtfleche)
            
        except:
            pass
        
        try:
            pass

        except:
            pass

        hautlab1.text="[b]GESTION DE STOCK[/b]"
        
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
            cadre.remove_widget(btenregistrer)
            cadre.remove_widget(btncamera)
            cadre.remove_widget(table)            
        except:
            pass
        try:
           pass
        except:
            pass
        try:
            cadre.remove_widget(btnrechimg)
            cadre.remove_widget(btnrechimgdirrect)
            cadre.remove_widget(trech)
        except:
            pass
        try:
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)
        except:
            pass
        try:
            cadre.remove_widget(btrierdate)
            cadre.remove_widget(btrid)
            cadre.remove_widget(tablegestionvente)
        except:
            pass
        try:
            tabunitiltete.add_widget(hautlab1)
            cadre.add_widget(tabunitiltete)
            
        except:
            pass
        hautlab1.text="[b]GESTION DE STOCK[/b]"
        try:
            cadre.remove_widget(labtot)
            cadre.remove_widget(labqt)
            cadre.remove_widget(tot)
            cadre.remove_widget(qt)
            cadre.remove_widget(hlab2)
            cadre.remove_widget(hlab1)
            cadre.remove_widget(combo1)
            cadre.remove_widget(combo2)
        except:
            pass
        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)

            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)

            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)

            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)

            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass
        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass

        try:
            cadre.add_widget(labstockfini)
            cadre.add_widget(tablstockfini)
            cadre.add_widget(tablstocktotal)
        except:
            pass
        

        try:

            tablstocktotal.row_data=[]
            tablstockfini.row_data=[]
            tablstock.row_data=[]

        except:
            pass
        

        
        if modcommutationadmin==0:

            

            try:
                pass
                #dfv=pd.DataFrame(dfadmin)
            except:
                pass
            
            try:
                pass
                #tablstocktotal.row_data=tablstock.row_data=dfadmin
                #dfv.values.tolist()
                #tablstock.row_data=dfadmin
                #dfv.values.tolist()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                pass
                #tablstockfini.row_data=proepuisedirrect

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit")
                results=self.cursor.fetchall()
                tablstock.row_data=results
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75")
                results=self.cursor.fetchall()
                listprofini=results
                tablstockfini.row_data=results
                self.cursor.close()
                con.close()

            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()
            
            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit")
                results=self.cursor.fetchall()
                tablstocktotal.row_data=results
                self.cursor.close()
                con.close()
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données generales, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        sepp=4
        
        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass
        
        try:
            cadre.remove_widget(tabmod)
        except:
            pass

        try:
            cadre.remove_widget(bautomodiftravprod)
        except:
            pass
        
        
        try:
            cadre.add_widget(bexport)
        except:
            pass

        try:
            cadre.remove_widget(tablstockperime)
        except:
            pass

        try:
            cadre.remove_widget(trecravitail)
            cadre.remove_widget(combravitail)
        except:
            pass
        
        try:
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb8)
        except:
            pass
        try:
            cadre.remove_widget(btnmodqt)
        except:
            pass
        
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass

        try:
            cadre.add_widget(bperemption)
        except:
            pass

       
        try:
            cadre.add_widget(labstockfini)
            cadre.add_widget(tablstockfini)
            cadre.add_widget(tablstocktotal)
        except:
            pass
   
        
        try:
            btnstock1.pos_hint={'x':0.52, 'y':0.05}
            btnstock2.pos_hint={'x':0.77, 'y':0.05}
            btnravitail.pos_hint={'x':0.3, 'y':0.05}
            bperemption.pos_hint:{'x':0.07, 'y':0.05}
        except:
            pass
        try:
            tablstocktotal.row_data=[]
            tablstockfini.row_data=[]
        except:
            pass
        
        tablstocktotal.size_hint=(0.9,0.46)
    
        try:
            cadre.remove_widget(btaction)
        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from produit where (stock-stock_p)*100/stock>75 order by dats DESC limit 10")
            results=self.cursor.fetchall()
            #listfini=results
            tablstockfini.row_data=results
            self.cursor.close()
            con.close()

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la recupération de données des produit tendant à sa fin, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from produit order by dats DESC limit 10")
            results=self.cursor.fetchall()
            tablstocktotal.row_data=results
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue '),size_hint=(0.4,0.3))
            msg.open()
        

    def gestionventes(self,instance):
        global sepp
        sepp=3

        fondacceuil.background_normal='page_tableau.jpg' 

        try:
            cadregauche.remove_widget(cadreprischarge)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenue)
        except:
            pass
    
        try:
            cadregauche.remove_widget(cadremenueIcon)
        except:
            pass

        try:
            cadre.add_widget(labcombine)
        except:
            pass
        try:
            cadre.add_widget(checkcombine)
        except:
            pass
        try:
            cadre.add_widget(btrechcombine)
        except:
            pass

        try:
            cadre.remove_widget(bdemserveur)
        except:
            pass

        try:
            cadre.remove_widget(bscanneurannuler)
        except:
            pass
        
        try:
            cadre.remove_widget(photoproduit) 
        except:
            pass
        
        try:
            cadre.remove_widget(bscanneur)
        except:
            pass
        

        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn)
        except:
            pass

        try:
            cadre.remove_widget(btnstock1)
            cadre.remove_widget(btnstock2)
            cadre.remove_widget(btnravitail)
        except:
            pass
        try:
            cadre.remove_widget(tablstock)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(tb8)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass
        try:
            pass

        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la récupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass

        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
            cadre.remove_widget(btenregistrer)
            cadre.remove_widget(btncamera)
            cadre.remove_widget(table)
        except:
            pass
        try:
            #btaction.size_hint=(0.05,0.1)
            #btaction.pos_hint={'x':0,'top':0.86}
            
            pass

        except:
            pass
            
        try:
            cadre.remove_widget(btnrechimg)
            cadre.remove_widget(btnrechimgdirrect)
            cadre.remove_widget(trech)
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)
        except:
            pass
        try:
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)
            
        except:
            pass
        try:
            tabunitiltete.add_widget(hautlab1)
            cadre.add_widget(tabunitiltete)
        except:
            pass
        try:
            cadre.add_widget(btrierdate)
            cadre.add_widget(btrid)

    
        except:
            pass
        
        try:
            pass#cadre.add_widget(btridtrav)
        except:
            pass

        try:
            pass#cadre.add_widget(hlab3)
        except:
            pass

        try:
            pass
            #cadre.add_widget(combotrav)
        except:
            pass

        try:
            #cadre.add_widget(combo1)
            #cadre.add_widget(combo2)
            pass
        except:
            pass
        try:
            #cadre.add_widget(hlab2)
            #cadre.add_widget(hlab1)
            pass
        except:
            pass

        try:
            
            cadre.add_widget(tablegestionvente)
            #cadre.add_widget(tabunitilbas) iciiiiiiiiiiiiiiiiiiiiiiiiiii
            cadre.add_widget(labtot)
            cadre.add_widget(labqt)
            cadre.add_widget(tot)
            cadre.add_widget(qt)
            
            hautlab1.text="[b]TABLEAU DE BORD[/b]"
        except:
            pass

        
        if tablegestionvente.row_data==[]:

            try:
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from achat order by Dats_id DESC limit 10")
                results=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                tablegestionvente.row_data=results
                
            except:
                msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la récupération de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
                msg.open()

        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)

            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)

            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)

            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)

            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass

        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass
        
        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass
        
        try:
            cadre.remove_widget(tabmod)
        except:
            pass

        try:
            cadre.remove_widget(tablstockperime)
            cadre.remove_widget(tablstocktotal)
            cadre.remove_widget(tablstockfini)
            cadre.remove_widget(tablstock)
        except:
            pass

        try:
            cadre.remove_widget(bautomodiftravprod)
        except:
            pass
        
        try:
            cadre.add_widget(cadbttablbord)
        except:
            pass
        
        try:
            cadre.add_widget(cadbttablbordhaut)
        except:
            pass
        
        try:
            cadre.add_widget(bcanetterelage)
        except:
            pass

        try:
            cadre.add_widget(combanneintervalvente)
            cadre.add_widget(combmoisintervalveny)
            cadre.add_widget(combjourintervalvente)
        except:
            pass

        
        try:
            cadre.add_widget(bexport)
        except:
            pass

        try:
            cadre.remove_widget(btaction)
        except:
            pass

    def pagemodif(self,instance):
        global sepp,indicevaleur
        
        sepp=2

        fondacceuil.background_normal='page_insert.jpg'

        try:
            cadregauche.remove_widget(cadreprischarge)
        except:
            pass

        try:
            cadre.add_widget(trechlikemodif)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenue)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenueIcon)
        except:
            pass


        try:
            cadre.add_widget(bdemserveur)
        except:
            pass

        try:
            photoproduit.pos_hint={'x':0.2,'y':0.33}
            photoproduit.size_hint=(0.2,0.13)
        except:
            pass

        try:
            cadre.add_widget(bscanneurannuler)
        except:
            pass
        
        try:
            cadre.add_widget(photoproduit) 
        except:
            pass

        try:
            photoproduit.source=''
        except:
            pass


        try:
            cadre.remove_widget(bscanneur)
        except:
            pass

        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            t1.password=True
        except:
            pass
        try:  
            btncamera.background_normal='refresh_arrow_1546.ico'
        except:
            pass
        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn)
        except:
            pass

        try:
            cadre.remove_widget(btnstock1)
            cadre.remove_widget(btnstock2)
            cadre.remove_widget(btnravitail)
        except:
            pass
        try:
            cadre.remove_widget(tablstock)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(tb8)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass
        
        try:
            tabunitiltete.remove_widget(hautlab1)
            cadre.remove_widget(btrierdate)
            cadre.remove_widget(btrid)
            cadre.remove_widget(tabunitiltete)
            cadre.remove_widget(tablegestionvente)
            cadre.remove_widget(tot)
            cadre.remove_widget(qt)
            cadre.remove_widget(labtot)
            cadre.remove_widget(labqt)
            cadre.remove_widget(hlab2)
            cadre.remove_widget(hlab1)
            cadre.remove_widget(combo1)
            cadre.remove_widget(combo2)
        except:
            pass
        try:
            #btaction.size_hint=(0.05,0.1)
            #btaction.pos_hint={'x':0,'top':0.86}
            
            
            btenregistrer.text="[b]Modifier[/b]"

            t1.pos_hint={'x':0.2, 'y':0.88}
            t3.pos_hint={'x':0.2, 'y':0.78}
            t5.pos_hint={'x':0.2, 'y':0.68}
            t7.pos_hint={'x':0.2, 'y':0.58}
            t9.pos_hint={'x':0.2, 'y':0.48} 
            t2.size_hint=(0.2,0.1)

        except:
            pass
        try:
            labmod.text="[b]MODIFICATION DE DONNEES[/b]"
        except:
            pass
        try:
            cadre.add_widget(tabmod)
        except:
            pass

        try:
            tabmod.add_widget(labmod)
        except:
            pass

        try:
            cadre.add_widget(t1)
            cadre.add_widget(t2)
            cadre.add_widget(t3)
            cadre.add_widget(t4)
            cadre.add_widget(t5)
            cadre.add_widget(t6)
            cadre.add_widget(t7)
            cadre.add_widget(t8)
            cadre.add_widget(t9)
            cadre.add_widget(t10)
            
            cadre.add_widget(btncamera)
            cadre.add_widget(table)
            
        except:
            pass
        
        
        try:            
            cadre.add_widget(btnrechimg)
            cadre.add_widget(btnrechimgdirrect)
            cadre.add_widget(labremarque)
            cadre.add_widget(labremarque0)
            cadre.add_widget(trech) 

        except:
            pass
        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)

            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)

            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)

            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)

            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass

        try:
            cadre.add_widget(bvueclaireadmin)
        except:
            pass

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select valeur from indice where id_ind='indice'")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()
            if results:
                indicevaleur=results[0]
                      
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur NOT INDICE SYSTEM, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
        
        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass
        
        try:
            cadre.add_widget(cadbtsave)
        except:
            pass
    
        try:
            cadre.remove_widget(btaction)
        except:
            pass
        try:

            if table.row_data==[]:

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit order by dats DESC limit 10")
                results=self.cursor.fetchall()
                table.row_data=results
                self.cursor.close()
                con.close()
        except:
            pass


    def pageinsert(self, instance):
        global sepp,indicevaleur

        sepp=1

        #threading.Thread(target=self.handle_client_connection).start()

        try:
            cadregauche.remove_widget(cadreprischarge)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenue)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenueIcon)
        except:
            pass

        try:
            #fondacceuil.background_normal='page_insert.jpg' 
            cadre.remove_widget(fondacceuil)
        except:
            pass

        #bdeconn.background_color='white'
        #bdeconn.color='seagreen'
        #bdeconn.background_normal=''
        #bdeconn.background_down=''

        try:
            cadre.add_widget(indicateurindice)
        except:
            pass
        try:
            cadre.add_widget(labindice)
        except:
            pass

        try:
            pass
            #cadre.add_widget(bcommutadmin)
        except:
            pass

        try:
            cadre.add_widget(checkcodelocal)
        except:
            pass
        try:
            cadre.add_widget(labcodelocal)
        except:
            pass

        try:
            cadre.add_widget(bdemserveur)
        except:
            pass

        try:
            photoproduit.pos_hint={'x':0.2,'y':0.33}
            photoproduit.size_hint=(0.2,0.13)
        except:
            pass

        try:
            cadre.add_widget(bscanneurannuler)
        except:
            pass

        try:
            cadre.add_widget(photoproduit) 
        except:
            pass

        try:
            photoproduit.source=''
        except:
            pass
        
        try:
            cadre.add_widget(bscanneur)
        except:
            pass
        try:
            bscanneur.pos_hint={'x':0.11, 'y':0.87}
        except:
            pass

        try:
            cadre.add_widget(btirehaut)
        except:
            pass

        try:
            t1.password=True
        except:
            pass
        try:
            t1.disabled=True
        except:
            pass
        try:
            btncamera.background_normal='2956596.png'
        except:
            pass
        try:
            cadre.remove_widget(bgestionuser)
        except:
            pass
        try:
            cadre.remove_widget(bdeconn)
        except:
            pass

        try:
            cadre.remove_widget(btnstock1)
            cadre.remove_widget(btnstock2)
            cadre.remove_widget(btnravitail)
        except:
            pass
        try:
            cadre.remove_widget(tablstock)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(tb8)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass
        
        try:
            tabunitiltete.remove_widget(hautlab1)
            cadre.remove_widget(btrierdate)
            cadre.remove_widget(btrid)
            cadre.remove_widget(tabunitiltete)
            cadre.remove_widget(tablegestionvente)
            cadre.remove_widget(tot)
            cadre.remove_widget(qt)
            cadre.remove_widget(labtot)
            cadre.remove_widget(labqt)
            cadre.remove_widget(hlab2)
            cadre.remove_widget(hlab1)
            cadre.remove_widget(combo1)
            cadre.remove_widget(combo2)
            btaction.size_hint=(0.1,0.1)
            
        except:
            pass
        try:
            labmod.text="[b]INSERTION DE DONNEES[/b]"
        except:
            pass
        try:
            cadre.add_widget(tabmod)
        except:
            pass
        try:
            tabmod.add_widget(labmod)
        except:
            pass
        try:
            cadre.add_widget(t1)
            cadre.add_widget(t2)
            cadre.add_widget(t3)
            cadre.add_widget(t4)
        except:
            pass
        try:
            cadre.add_widget(t5)
            cadre.add_widget(t6)
            cadre.add_widget(t7)
            cadre.add_widget(t8)
            cadre.add_widget(t9)
            cadre.add_widget(t10)
            
            cadre.add_widget(btncamera)
            cadre.add_widget(table)
        except:
            pass
            
        try:
            cadre.remove_widget(btnrechimg)
            cadre.remove_widget(btnrechimgdirrect)
            cadre.remove_widget(trech)
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)

            #b1.size_hint=(0,0.1)
            #b1.text=""
            #b2.size_hint=(0,0.1)
            #b2.text=""
            #b3.size_hint=(0,0.1)
            #b3.text=""
            #b4.size_hint=(0,0.1)
            #b4.text=""
            #b5.size_hint=(0,0.1)
            #b5.text=""

            #btaction.size_hint=(0.05,0.1)
            #btaction.pos_hint={'x':0,'top':0.86}
             
            btenregistrer.text="[b]Enregistrer[/b]"
            t10.text=str(datetime.now().strftime('%Y-%m-%d'))
            t10.disabled=True

            t1.pos_hint={'x':0.2, 'y':0.88}
            t3.pos_hint={'x':0.2, 'y':0.78}
            t5.pos_hint={'x':0.2, 'y':0.68}
            t7.pos_hint={'x':0.2, 'y':0.58}
            t9.pos_hint={'x':0.2, 'y':0.48}
            t2.size_hint=(0.4,0.1)
        except:
            pass
        try:
            taccueil.remove_widget(laccueil)
            cadre.remove_widget(taccueil)
            cadre.remove_widget(imgaccuel)

            cadre.remove_widget(imgacc1)
            cadre.remove_widget(imgacc2)
            cadre.remove_widget(imgacc3)

            accueilcad2.remove_widget(lacc2)
            accueilcad1.remove_widget(lacc1)
            accueilcad3.remove_widget(lacc3)

            cadre.remove_widget(accueilcad1)
            cadre.remove_widget(accueilcad2)
            cadre.remove_widget(accueilcad3)

            cadre.remove_widget(ladmin)
            cadre.remove_widget(luser)
        except:
            pass

        try:
            cadre.add_widget(bvueclaireadmin)
        except:
            pass
        
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select valeur from indice where id_ind='indice'")
            results=self.cursor.fetchone()
            self.cursor.close()
            con.close()
            if results:
                indicevaleur=results[0]
                #str(math.ceil(results[0]))+" Fc"      
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur NOT INDICE SYSTEM, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
        
        try:
            cadre.add_widget(bautomodiftravprod)
        except:
            pass
        
        try:
            cadre.remove_widget(fondacceuil)
        except:
            pass
        
        try:
            cadre.add_widget(cadbtsave)
            
        except:
            pass
        
        try:
            cadre.remove_widget(btaction)
        except:
            pass

        try:

            if table.row_data==[]:

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from produit order by dats DESC limit 10")
                results=self.cursor.fetchall()
                table.row_data=results
                self.cursor.close()
                con.close()
        except:
            pass
    def refreshProduit(self,instance):

        try:

            table.row_data=[]

            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select * from produit order by dats DESC limit 10")
            results=self.cursor.fetchall()
            table.row_data=results
            self.cursor.close()
            con.close()

            msgg=Popup(title="Reading",content=Button(text="Termine",color='white',background_color='blue',background_normal=''),size_hint=(.4,.25))
            msgg.open()
        except:
            msgg=Popup(title="Reading",content=Button(text="Error!",color='white',background_color='blue',background_normal=''),size_hint=(.4,.25))
            msgg.open()

    def pageaccueilvide(self):
        global sepp,tauxjour

        sepp=0
        Window.size=(1100,680)
        

        cadre.size_hint=(.98,.93)
        cadre.pos_hint={'center_x':.5,'y':.0}

        bcorrection.text='[b]Analyseur d erreur[/b]'

        #bcorrection.pos_hint={'x':0.88, 'y':0.90}
                
        #bdeconn.pos_hint={'x':0.8, 'y':0.02}

        try:
            cadregauche.add_widget(barrmenu)
        except:
            pass

        try:
            cadre.remove_widget(bquiter)
        except:
            pass
        
        try:
            cadre.remove_widget(btaide)
        except:
            pass

        try:
            cadre.remove_widget(btsignale)
        except:
            pass

        try:
            cadre.remove_widget(bvueclaire)
        except:
            pass

        try:
            cadre.remove_widget(bscanneur)
        except:
            pass
        
        try:
            cadre.remove_widget(bcharg)
        except:
            pass

        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            t1.helper_text='ID Produit'
            t2.helper_text='Nom Medicament'
            t3.helper_text='Catégorie Médicament'
            t4.helper_text='Maladie qu il ne supporte'
            t5.helper_text='Maladie à guerrir'
            t6.helper_text='Mode d utilisation'
            t7.helper_text='Decallage d age'
            t8.helper_text='Prix unitaire'
        except:
            pass

        try:
            t1.disabled=False
            t2.disabled=False
            t3.disabled=False
            t4.disabled=False
            t5.disabled=False
            t6.disabled=False
            t7.disabled=False
            t8.disabled=False
        except:
            pass
        
        try:
            labmod.text="[b]INSERTION DE DONNEES[/b]"
            bgestionuser.text='[b]Gestion des travailleurs[/b]'
            bgestionuser.pos_hint={'x':0.5, 'y':0.02}
            table.size_hint=(0.9,0.3)
            table.pos_hint={'x':0.036,'y':0.01}
        except:
            pass
                
        try:
            t1.hint_text="ID "
            t1.helper_text="ID Medicament"
            t2.hint_text="Nom"
            t2.helper_text="Nom Medicament"
            t3.hint_text="Catégorie"
            t3.helper_text="Catégorie médicament"
            t4.hint_text="Anti"
            t4.helper_text="Maladie qu'il ne supporte"
            t5.hint_text="Ca traite"
            t5.helper_text="Maladie à guerir"
            t6.hint_text="Posologie"
            t6.helper_text="Mode d'utilisation"

        except:
            pass
        try:
            pass
            #cadre.add_widget(bgestionuser)
        except:
            pass
        try:
            #cadregauche.add_widget(btaction)
            #cadregauche.add_widget(b1)
            #cadregauche.add_widget(b2)
            #cadregauche.add_widget(b3)
            #cadregauche.add_widget(b4)
            #cadregauche.add_widget(b5)
            cadre.add_widget(cadregauche)

        except:
            pass
        try:
            cadre.add_widget(bdeconn)
        except:
            pass
        try:
            cadre.remove_widget(table)
        except:
            pass
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
        except:
            pass

        try:
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
            cadre.remove_widget(btenregistrer)
            cadre.remove_widget(btncamera)          
        except:
            pass
        
        try:
            cadre.remove_widget(btnrechimg)
            cadre.remove_widget(btnrechimgdirrect)
            cadre.remove_widget(trech)
        except:
            pass
        try:
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)
        except:
            pass
        try:
            cadre.remove_widget(btrierdate)
            cadre.remove_widget(btrid)
            cadre.remove_widget(tablegestionvente)
        except:
            pass
        
        try:
            cadre.remove_widget(btnstock1)
            cadre.remove_widget(btnstock2)
            cadre.remove_widget(btnravitail)
        except:
            pass
        try:
            cadre.remove_widget(tablstock)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(tb8)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass
        
        try:
            tabunitiltete.remove_widget(hautlab1)
            cadre.remove_widget(tabunitiltete)
            btaction.size_hint=(0.05,0.1)
            
        except:
            pass
        try:
            cadre.remove_widget(labtot)
            cadre.remove_widget(labqt)
            cadre.remove_widget(tot)
            cadre.remove_widget(qt)
            cadre.remove_widget(hlab2)
            cadre.remove_widget(hlab1)
            cadre.remove_widget(combo1)
            cadre.remove_widget(combo2)
        except:
            pass
        try:
            cadre.add_widget(imglogo)
        except: 
            pass
        try:
            taccueil.add_widget(laccueil)
            cadre.add_widget(taccueil)
            cadre.add_widget(imgaccuel)

            cadre.add_widget(imgacc1)
            cadre.add_widget(imgacc2)
            cadre.add_widget(imgacc3)

            accueilcad2.add_widget(lacc2)
            accueilcad1.add_widget(lacc1)
            accueilcad3.add_widget(lacc3)

            cadre.add_widget(accueilcad1)
            cadre.add_widget(accueilcad2)
            cadre.add_widget(accueilcad3)

            cadre.add_widget(ladmin)
            cadre.add_widget(luser)
        except:
            pass
        try:
            labmod.pos_hint={'x':0.5,'y':0.5}
        except:
            pass
        try:
            cadre.remove_widget(labmod)
        except:
            pass
        
        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select taux from tauxchange where num=1")
            resultsstaux=self.cursor.fetchone()
            self.cursor.close()
            con.close()
        except:
            msg=Popup(title="ETAT REQUETE",content=Button(text=' Erreur lors du mappage taux-jour  '),size_hint=(None, None), size=(400,200))
            msg.open()
        
        try:
            cadre.remove_widget(btaction)
        except:
            pass
        

        if resultsstaux:
            tauxjour=resultsstaux[0]
        
    def pageaccueil(self,instance):
        global sepp
        sepp=0

        #bdeconn.pos_hint={'x':0.8, 'y':0.02}

        #bdeconn.background_color='blue'
        #bdeconn.color='white'

        try:
            cadregauche.remove_widget(cadreprischarge)
        except:
            pass

        try:
            cadregauche.remove_widget(cadremenue)
        except:
            pass
        
        try:
            cadregauche.remove_widget(cadremenueIcon)
        except:
            pass

        try:
            cadre.remove_widget(btaction)
        except:
            pass


        try: 
            cadre.add_widget(fondacceuil)
        except:
            pass

        fondacceuil.background_normal='page_accueil.jpg'

        try:
            cadre.remove_widget(bdemserveur)
        except:
            pass

        try:
            cadre.remove_widget(bscanneurannuler)
        except:
            pass

        try:
            cadre.remove_widget(photoproduit) 
        except:
            pass

        try:
            cadre.remove_widget(bvueclaire)
        except:
            pass

        try:
            cadre.remove_widget(bscanneur)
        except:
            pass

        try:
            cadre.remove_widget(bcharg)
        except:
            pass
        try:
            cadre.remove_widget(btirehaut)
        except:
            pass

        try:
            t1.helper_text='ID Produit'
            t2.helper_text='Nom Medicament'
            t3.helper_text='Catégorie Médicament'
            t4.helper_text='Maladie qu il ne supporte'
            t5.helper_text='Maladie à guerrir'
            t6.helper_text='Mode d utilisation'
            t7.helper_text='Decallage d age'
            t8.helper_text='Prix unitaire'
        except:
            pass

        try:
            t1.disabled=False
            t2.disabled=False
            t3.disabled=False
            t4.disabled=False
            t5.disabled=False
            t6.disabled=False
            t7.disabled=False
            t8.disabled=False
        except:
            pass
        
        try:
            pass
            #cadre.add_widget(bgestionuser)
        except:
            pass
        try:
            btaction.background_normal='c1.PNG'
        except:
            pass
        try:
            
            cadre.add_widget(cadregauche)
        except:
            pass
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
            cadre.remove_widget(t7)
            cadre.remove_widget(t8)
        except:
            pass
        try:
            cadre.remove_widget(t9)
            cadre.remove_widget(t10)
            cadre.remove_widget(btenregistrer)
            cadre.remove_widget(btncamera)
            cadre.remove_widget(table)            
        except:
            pass
        try:
            #btaction.size_hint=(0.05,0.1)
            #btaction.pos_hint={'x':0,'top':0.86}
            pass
        except:
            pass
        try:
            cadre.add_widget(bdeconn)
        except:
            pass

        try:
            cadre.remove_widget(btnrechimg)
            cadre.remove_widget(btnrechimgdirrect)
            cadre.remove_widget(trech)
        except:
            pass
        try:
            cadre.remove_widget(labremarque)
            cadre.remove_widget(labremarque0)
        except:
            pass
        try:
            cadre.remove_widget(btrierdate)
            cadre.remove_widget(btrid)
            cadre.remove_widget(tablegestionvente)
        except:
            pass
        
        try:
            cadre.remove_widget(btnstock1)
            cadre.remove_widget(btnstock2)
            cadre.remove_widget(btnravitail)
        except:
            pass
        try:
            cadre.remove_widget(tablstock)
        except:
            pass
        try:
            cadre.remove_widget(tb1)
            cadre.remove_widget(tb2)
            cadre.remove_widget(tb3)
            cadre.remove_widget(tb4)
            cadre.remove_widget(tb5)
            cadre.remove_widget(tb6)
            cadre.remove_widget(tb7)
            cadre.remove_widget(tb8)
            cadre.remove_widget(ldetail)
        except:
            pass
        try:
            cadre.remove_widget(tabstock1)
            cadre.remove_widget(labstock1)
        except:
            pass
        try:
            cadre.remove_widget(tabstock2)
            cadre.remove_widget(labstock2)
        except:
            pass
        
        try:
            tabunitiltete.remove_widget(hautlab1)
            cadre.remove_widget(tabunitiltete)
            #btaction.size_hint=(0.05,0.1)
            
        except:
            pass
        try:
            cadre.remove_widget(labtot)
            cadre.remove_widget(labqt)
            cadre.remove_widget(tot)
            cadre.remove_widget(qt)
            cadre.remove_widget(hlab2)
            cadre.remove_widget(hlab1)
            cadre.remove_widget(combo1)
            cadre.remove_widget(combo2)
        except:
            pass
        try:
            cadre.add_widget(imglogo)
        except: 
            pass
        try:
            taccueil.add_widget(laccueil)
            cadre.add_widget(taccueil)
            cadre.add_widget(imgaccuel)

            cadre.add_widget(imgacc1)
            cadre.add_widget(imgacc2)
            cadre.add_widget(imgacc3)

            accueilcad2.add_widget(lacc2)
            accueilcad1.add_widget(lacc1)
            accueilcad3.add_widget(lacc3)

            cadre.add_widget(accueilcad1)
            cadre.add_widget(accueilcad2)
            cadre.add_widget(accueilcad3)

            cadre.add_widget(ladmin)
            cadre.add_widget(luser)
        except:
            pass

        try:
            cadre.remove_widget(bvueclaireadmin)
        except:
            pass
    
        try:
            cadre.remove_widget(btaction)
        except:
            pass
        
        
        
    def insertion(self, instance):
        pass
    def rechinfo(self, instance):
        global tauxjour

        try:
            t1.text=""
            t2.text=""
            t3.text=""
            t4.text=""
            t5.text=""
            t6.text=""
            t7.text=""
            t8.text=""
            t9.text=""
            t10.text=""

            self.cconnexion()
            cursor=con.cursor()
            query="select * from produit where nom='"+trech.text+"'"
            cursor.execute(query)
            results=cursor.fetchone()
            self.cursor.close()
            con.close()

            if results:
                t1.text=results[0]
                t2.text=results[1]
                t3.text=results[2]
                t4.text=results[3]
                t5.text=results[4]
                t6.text=results[5]
                t7.text=results[6]
                t8.text=str(results[7]*tauxjour)
                t9.text=str(results[8])
                t10.text=str(results[9])

                try:
                    cadre.add_widget(photoproduit) 
                except:
                    pass

                try:
                    discourant=os.path.dirname(__file__)
                    disprod=os.path.join(discourant,"ftx",t1.text)

                    photoproduit.source= disprod + ".jpg"
                    
                except:
                    pass

            t10.disabled=True  
            t9.disabled=True  
            t1.disabled=True
            t1.helper_text=""
            t10.helper_text=""
            t9.helper_text=""
            
        except:
            msg=Popup(title="STATUT REQUETE",content=Button(text='Erreur survenue lors de la lecture de données, veuillez ressayer plus tard'),size_hint=(None, None), size=(400,200))
            msg.open()
    def cconnexion(self):

        global con,choixconn,adrip

        if choixconn==1:
            try:
                con=mysql.connector.connect(
                host="localhost",
                user="askyas",
                password="askyas",
                database="pharma"
                )
                return con
            except:
                msg=Popup(title="STATUT CONNEXION",content=Button(text='Erreur survenue lors de la connexion au serveur'),size_hint=(None, None), size=(400,200))
                msg.open()

        else:

            adrip=adrip.replace("@",".").replace("w","1")

            try:
                con=mysql.connector.connect(
                host=adrip,
                #"localhost",
                user="askyas",
                password="askyas",
                database="pharma"
                )
                return con

            except:
                msg=Popup(title="STATUT CONNEXION",content=Button(text='Erreur survenue lors de la connexion au serveur'),size_hint=(None, None), size=(400,200))
                msg.open()


    def retouracceuil(self,instance):
        global openuser

        openuser=0

        trecravitail.hint_text="Recheche"
        combravitail.text="Choisir"

        

        try:
            cadre.remove_widget(configserveur)
        except:
            pass

        try:
            cadre.remove_widget(bgestionuserchanger)
        except:
            pass
        
        try:
            cadre.remove_widget(gesttrav)
        except:
            pass
        
        try:
            cadre.remove_widget(gestmotif)
        except:
            pass

        try:
            cadre.remove_widget(tablmotiftravil)
        except:
            pass
        
        

        try:
            cadre.remove_widget(tabl)
        except:
            pass

        try:
            cadre.remove_widget(labdatmotif)
        except:
            pass
        try:
            cadre.remove_widget(combdatmotif)
        except:
            pass
        try:
            cadre.remove_widget(labidmotif)
        except:
            pass
        try:
            cadre.remove_widget(combidmotif)
        except:
            pass

        try:
            cadre.remove_widget(tabtotmotif)
        except:
            pass
        try:
            tabtotmotif.remove_widget(labtotmotif)
        except:
            pass

        try:
            cadre.remove_widget(labcombinmotif)
        except:
            pass
        try:
            cadre.remove_widget(checkmotif)
        except:
            pass
        
        # supression des outils de page des travalleur

        try:
            cadre.remove_widget(labxx)
        except:
            pass
        
        try:
            cadre.remove_widget(cadresuitchmode)
        except:
            pass
        
        try:
            cadre.remove_widget(btusernew)
        except:
            pass

        try:
            cadre.remove_widget(configserveur)
        except:
            pass

        
        try:
            cadre.remove_widget(gesttrav)
        except:
            pass
        try:
            cadre.remove_widget(gestmotif)
        except:
            pass
    
        try:
            cadre.remove_widget(bgestionuserchanger)
        except:
            pass

        
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
        except:
            pass

        try:
            cadre.remove_widget(tabl)
        except:
            pass
        
        try:
            cadre.remove_widget(labmod)
        except:
            pass
        try:
            
            table.row_data=[]
        except:
            pass


        try:
            cadre.remove_widget(retaccueil)
        except:
            pass

        try:
            cadre.remove_widget(labxx)
        except:
            pass
        
        try:
            cadre.remove_widget(cadresuitchmode)
        except:
            pass
        
        try:
            cadre.remove_widget(btusernew)
        except:
            pass

        try:
            cadre.remove_widget(configserveur)
        except:
            pass


        try:
            cadre.remove_widget(gesttrav)
        except:
            pass
        try:
            cadre.remove_widget(gestmotif)
        except:
            pass
        


        try:
            cadre.remove_widget(bgestionuserchanger)
        except:
            pass
        
        try:
            cadre.remove_widget(t1)
            cadre.remove_widget(t2)
            cadre.remove_widget(t3)
            cadre.remove_widget(t4)
            cadre.remove_widget(t5)
            cadre.remove_widget(t6)
        except:
            pass

        try:
            cadre.remove_widget(tabl)
        except:
            pass
        
        try:
            cadre.remove_widget(labmod)
        except:
            pass

        try:
            cadre.add_widget(fondacceuil)
        except:
            pass

        fondacceuil.background_normal='page_accueil.jpg'

        try:
            cadre.remove_widget(cadbtsave)
            
        except:
            pass
        
        
        
        
        self.pageaccueilvide()


    def sepliernew(self,instance):
        global etat,sepp,selid,openuser

        if openuser==1:
            pass
        else:

            try:
                cadre.remove_widget(btopenravmult)
            except:
                pass

            try:
                cadre.remove_widget(cadbtsave)
            except:
                pass

            try:
                cadre.remove_widget(cadbttablbordhaut)
            except:
                pass

            try:
                cadre.remove_widget(cadbttablbord)
            except:
                pass

            try:
                cadre.remove_widget(cadrebtfleche)
            except:
                pass

            try:
                cadre.remove_widget(labglobal)
            except:
                pass
            try:
                cadre.remove_widget(checkgobal)
            except:
                pass

            try:
                cadre.remove_widget(bexport)
            except:
                pass

            try:
                cadre.remove_widget(bcommutadmin)
            except:
                pass

            try:
                cadre.remove_widget(bperemption)
            except:
                pass

            try:
                cadre.remove_widget(imgtaux)
            except:
                pass

            try:
                cadre.remove_widget(btautorisermodtp)
            except:
                pass

            if etat==0:

                try:
                    cadregauche.add_widget(cadremenue)
                except:
                    pass

                try:
                    cadregauche.add_widget(cadremenueIcon)
                except:
                    pass

                
                #instance.pos_hint={'x':0.33,'top':0.86}
                #instance.size_hint=(0.1,0.1)

                t1.pos_hint={'x':0,'y':0}
                t3.pos_hint={'x':0,'y':0}
                t5.pos_hint={'x':0,'y':0}
                t7.pos_hint={'x':0,'y':0}
                t9.pos_hint={'x':0,'y':0}

                try:
                    cadre.remove_widget(combanneintervalvente)
                    cadre.remove_widget(combmoisintervalveny)
                    cadre.remove_widget(combjourintervalvente)
                except:
                    pass

                try:
                    cadre.remove_widget(bcalcbenefice)
                except:
                    pass
                
                if sepp==0:
                    try:
                        cadre.remove_widget(imgacc2)
                        cadre.remove_widget(imgacc1)
                        cadre.remove_widget(ladmin)
                        cadre.remove_widget(accueilcad1)
                        cadre.remove_widget(accueilcad2)
                    except:
                        pass

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass
            
                if sepp==1:

                    try:
                        cadre.remove_widget(labchange)
                    except:
                        pass

                    try:
                        cadre.remove_widget(checkchangecdf)
                    except:
                        pass

                    try:
                        cadre.remove_widget(indicateurindice)
                    except:
                        pass
                    try:
                        cadre.remove_widget(labindice)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bscanneur)
                    except:
                        pass

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass
                    
                    try:
                        cadre.remove_widget(checkcodelocal)
                    except:
                        pass
                    try:
                        cadre.remove_widget(labcodelocal)
                    except:
                        pass
                    
            
                if sepp==4:
                    try:
                        cadre.remove_widget(trecravitail)
                        cadre.remove_widget(combravitail)
                    except:
                        pass

                    try:
                        cadre.remove_widget(imgacc1)
                        cadre.remove_widget(ladmin)
                        cadre.remove_widget(accueilcad1)
                        cadre.remove_widget(accueilcad2)
                    except:
                        pass
                        
                    try:
                        cadre.remove_widget(btnmodqt)
                    except:
                        pass   

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass  
                
                
                if sepp==4:

                    if hautlab1.text=="[b]GESTION DE STOCK[/b]" or hautlab1.text=="[b]STOCK EPUISE[/b]":
                        
                        if selid=="a":
                            try:
                                cadre.remove_widget(tablstock)
                            except:
                                pass
                        elif selid=="b":

                            try:
                                cadre.remove_widget(tablstocktotal)
                            except:
                                pass
                            
                            try:
                                cadre.remove_widget(tablstockfini)
                            except:
                                pass

                            try:
                                cadre.remove_widget(labstockfini)
                            except:
                                pass

                            try:
                                cadre.remove_widget(bflech0)
                            except:
                                pass

                            try:
                                cadre.remove_widget(bflechbas)
                            except:
                                pass

                            try:
                                cadre.remove_widget(bflechhaut)
                            except:
                                pass
                        
                    elif hautlab1.text=="[b]ANALYSEUR DE PERFORMANCE[/b]":
                        try:
                            cadre.remove_widget(tabstock1)
                            cadre.remove_widget(labstock1)
                            cadre.remove_widget(ldetail)
                        except:
                            pass
                    elif hautlab1.text=="[b]RAVITAILLEMENT PRODUIT[/b]":
                        
                        try:
                            cadre.remove_widget(tablstock)
                        except:
                            pass
            
                
                try:
                    t1.text=""
                    t2.text=""
                    t3.text=""
                    t4.text=""
                    t5.text=""
                    t6.text=""
                    t7.text=""
                    t8.text=""
                    t9.text=""
                    t10.text=""
                        
                    cadre.remove_widget(labremarque)
                    cadre.remove_widget(labremarque0)
                
                    trech.text="Rechercher"
                    t10.disabled=False  
                    t9.disabled=False  
                    t1.disabled=False
                    t1.helper_text="ID Produit"
                    t10.helper_text="Date"
                    t9.helper_text="Stock Produit"
                except:
                    pass
                try:
                    if hautlab1.text=="[b]GESTION DE STOCK[/b]":
                        cadre.remove_widget(tabstock1)
                        cadre.remove_widget(labstock1)
                except:
                    pass

                try:
                    if hautlab1.text=="[b]TABLEAU DE BORD[/b]":
                        cadre.remove_widget(tablegestionvente)
                except:
                    pass

                if sepp==1:
                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bscanneurannuler)
                    except:
                        pass
            

                elif sepp==2:
                    
                    try:
                        cadre.remove_widget(labchange)
                    except:
                        pass

                    try:
                        cadre.remove_widget(checkchangecdf)
                    except:
                        pass

                    try:
                        cadre.remove_widget(trechlikemodif)
                    except:
                        pass

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bscanneurannuler)
                    except:
                        pass
                
                elif sepp==3:

                    try:
                        cadre.remove_widget(cadcanette)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bcanetterelage)
                    except:
                        pass
                    try:
                        cadre.remove_widget(labcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(checkcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(btrechcombine)
                    except:
                        pass


                    try:
                        cadre.remove_widget(labcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(checkcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(btrechcombine)
                    except:
                        pass

                    
                    try:
                        cadre.remove_widget(btridtrav)
                    except:
                        pass

                    try:
                        cadre.remove_widget(hlab3)
                    except:
                        pass
                    
                    try:
                        cadre.remove_widget(combotrav)
                    except:
                        pass

                etat = 1
                
            else:

                try:
                    cadregauche.remove_widget(cadremenue)
                except:
                    pass

                try:
                    cadregauche.remove_widget(cadremenueIcon)
                except:
                    pass
                
                if sepp==1:

                    try:
                        cadre.add_widget(indicateurindice)
                    except:
                        pass
                    try:
                        cadre.add_widget(labindice)
                    except:
                        pass

                    try:
                        cadre.add_widget(bscanneur)
                    except:
                        pass

                    try:
                        cadre.add_widget(checkcodelocal)
                    except:
                        pass
                    try:
                        cadre.add_widget(labcodelocal)
                    except:
                        pass
                    
                
                if sepp==4:

                    try:
                        cadre.add_widget(bexport)
                    except:
                        pass

                    if hautlab1.text=="[b]GESTION DE STOCK[/b]" or hautlab1.text=="[b]STOCK EPUISE[/b]":
                        
                        if selid=="a":
                            try:
                                cadre.add_widget(tablstock)
                            except:
                                pass

                        elif selid=="b":

                            try:
                                cadre.add_widget(bperemption)
                            except:
                                pass
                            try:
                                cadre.add_widget(tablstocktotal)
                            except:
                                pass
                            
                            try:
                                cadre.add_widget(tablstockfini)
                            except:
                                pass

                            try:
                                cadre.add_widget(labstockfini)
                            except:
                                pass

                            try:
                                cadre.add_widget(bflech0)
                            except:
                                pass

                            try:
                                cadre.add_widget(bflechbas)
                            except:
                                pass

                            try:
                                cadre.add_widget(bflechhaut)
                            except:
                                pass
                            
                    elif hautlab1.text=="[b]ANALYSEUR DE PERFORMANCE[/b]":
                        try:
                            cadre.add_widget(tabstock1)
                            cadre.add_widget(labstock1)
                            cadre.add_widget(ldetail)
                        except:
                            pass

                    elif hautlab1.text=="[b]RAVITAILLEMENT PRODUIT[/b]":

                        try:
                            cadre.add_widget(trecravitail)
                            cadre.add_widget(combravitail)
                        except:
                            pass

                        try:
                            cadre.add_widget(tablstock)
                        except:
                            pass

                        try:
                            cadre.add_widget(btnmodqt)
                        except:
                            pass
                

                if sepp==1:
                    try:
                        cadre.add_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.add_widget(bscanneurannuler)
                    except:
                        pass

                elif sepp==2:

                    try:
                        cadre.add_widget(labchange)
                    except:
                        pass

                    try:
                        cadre.add_widget(checkchangecdf)
                    except:
                        pass

                    try:
                        cadre.add_widget(trechlikemodif)
                    except:
                        pass

                    try:
                        cadre.add_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.add_widget(bscanneurannuler)
                    except:
                        pass

                elif sepp==3:

                    
                    try:
                        pass # cadre.add_widget(bcanetterelage)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(labglobal)
                    except:
                        pass
                    try:
                        pass # cadre.add_widget(checkgobal)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(combanneintervalvente)
                        #cadre.add_widget(combmoisintervalveny)
                        #cadre.add_widget(combjourintervalvente)
                    except:
                        pass

                    try:
                        pass #cadre.add_widget(bcalcbenefice)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(bexport)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(labcombine)
                    except:
                        pass
                    try:
                        pass # cadre.add_widget(checkcombine)
                    except:
                        pass
                    try:
                        pass  # cadre.add_widget(btrechcombine)
                    except:
                        pass

                    try:
                        cadre.add_widget(tablegestionvente)
                    except:
                        pass
                    
                    try:
                        pass # cadre.add_widget(btridtrav)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(hlab3)
                    except:
                        pass
                    
                    try:
                        pass # cadre.add_widget(combotrav)
                    except:
                        pass

                
                if sepp==0:
                    try:
                        cadre.add_widget(imgacc2)
                        cadre.add_widget(imgacc1)
                        cadre.add_widget(ladmin)
                        cadre.add_widget(accueilcad1)
                        cadre.add_widget(accueilcad2)
                    except:
                        pass

                #instance.pos_hint={'x':0,'top':0.86} 
                #instance.size_hint=(0.05,0.1)
                
                etat = 0
                t1.pos_hint={'x':0.14, 'y':0.86}
                t3.pos_hint={'x':0.14, 'y':0.78}
                t5.pos_hint={'x':0.14, 'y':0.68}
                t7.pos_hint={'x':0.14, 'y':0.58}
                t9.pos_hint={'x':0.14, 'y':0.48}

                try:
                    t1.text=""
                    t2.text=""
                    t3.text=""
                    t4.text=""
                    t5.text=""
                    t6.text=""
                    t7.text=""
                    t8.text=""
                    t9.text=""
                    t10.text=""
                    t10.disabled= False  
                    t9.disabled=False
                    trech.text="Rechercher"
                    
                    t10.disabled=False  
                    t9.disabled=False  
                    t1.disabled=False
                    t1.helper_text="ID Produit"
                    t10.helper_text="Date"
                    t9.helper_text="Stock Produit"

                except:
                    pass


    def seplier(self, instance): 
        global etat,sepp,selid

        if instance.background_normal=="back.jpg":
            
            trecravitail.hint_text="Recheche"
            combravitail.text="Choisir"

            fondacceuil.background_normal='page_accueil.jpg'

            try:
                cadre.remove_widget(configserveur)
            except:
                pass

            try:
                cadre.remove_widget(bgestionuserchanger)
            except:
                pass
            
            try:
                cadre.remove_widget(gesttrav)
            except:
                pass
            
            try:
                cadre.remove_widget(gestmotif)
            except:
                pass

            try:
                cadre.remove_widget(tablmotiftravil)
            except:
                pass
            
            instance.background_normal='c1.PNG'

            try:
                cadre.remove_widget(tabl)
            except:
                pass

            try:
                cadre.remove_widget(labdatmotif)
            except:
                pass
            try:
                cadre.remove_widget(combdatmotif)
            except:
                pass
            try:
                cadre.remove_widget(labidmotif)
            except:
                pass
            try:
                cadre.remove_widget(combidmotif)
            except:
                pass

            try:
                cadre.remove_widget(tabtotmotif)
            except:
                pass
            try:
                tabtotmotif.remove_widget(labtotmotif)
            except:
                pass

            try:
                cadre.remove_widget(labcombinmotif)
            except:
                pass
            try:
                cadre.remove_widget(checkmotif)
            except:
                pass
            
            # supression des outils de page des travalleur

            try:
                cadre.remove_widget(labxx)
            except:
                pass
            
            try:
                cadre.remove_widget(cadresuitchmode)
            except:
                pass
            
            try:
                cadre.remove_widget(btusernew)
            except:
                pass

            try:
                cadre.remove_widget(configserveur)
            except:
                pass

            
            try:
                cadre.remove_widget(gesttrav)
            except:
                pass
            try:
                cadre.remove_widget(gestmotif)
            except:
                pass
        
            try:
                cadre.remove_widget(bgestionuserchanger)
            except:
                pass

            
            try:
                cadre.remove_widget(t1)
                cadre.remove_widget(t2)
                cadre.remove_widget(t3)
                cadre.remove_widget(t4)
                cadre.remove_widget(t5)
                cadre.remove_widget(t6)
            except:
                pass

            try:
                cadre.remove_widget(tabl)
            except:
                pass
            
            try:
                cadre.remove_widget(labmod)
            except:
                pass
            try:
                
                table.row_data=[]
            except:
                pass
            

            self.pageaccueilvide()
        else:

            try:
                cadre.remove_widget(cadbtsave)
            except:
                pass

            try:
                cadre.remove_widget(cadbttablbordhaut)
            except:
                pass

            try:
                cadre.remove_widget(cadbttablbord)
            except:
                pass

            try:
                cadre.remove_widget(cadrebtfleche)
            except:
                pass

            try:
                cadre.remove_widget(labglobal)
            except:
                pass
            try:
                cadre.remove_widget(checkgobal)
            except:
                pass

            try:
                cadre.remove_widget(bexport)
            except:
                pass

            try:
                cadre.remove_widget(bcommutadmin)
            except:
                pass

            try:
                cadre.remove_widget(bperemption)
            except:
                pass

            try:
                cadre.remove_widget(imgtaux)
            except:
                pass

            try:
                cadre.remove_widget(btautorisermodtp)
            except:
                pass

            if etat==0:
                b1.size_hint=(0.5,0.1)
                b1.text="[b]Accueil         [/b]"
                b1.pos_hint={'x':-0.13,'top':0.86}

                b2.size_hint=(0.5,0.1)
                b2.text="[b]Ajout Produit [/b]"
                b2.pos_hint={'x':-0.13,'top':0.76}

                b3.size_hint=(0.5,0.1)
                b3.text="[b]Mise à jour   [/b]"
                b3.pos_hint={'x':-0.135,'top':0.66}

                b4.size_hint=(0.5,0.1)
                b4.text="[b]Gestion Ventes[/b]"
                b4.pos_hint={'x':-0.13,'top':0.56}

                b5.size_hint=(0.5,0.1)
                b5.text="[b]Gestion Stock[/b]"
                b5.pos_hint={'x':-0.13,'top':0.46}

                instance.pos_hint={'x':0.33,'top':0.86}
                instance.size_hint=(0.1,0.1)

                t1.pos_hint={'x':0,'y':0}
                t3.pos_hint={'x':0,'y':0}
                t5.pos_hint={'x':0,'y':0}
                t7.pos_hint={'x':0,'y':0}
                t9.pos_hint={'x':0,'y':0}

                try:
                    cadre.remove_widget(combanneintervalvente)
                    cadre.remove_widget(combmoisintervalveny)
                    cadre.remove_widget(combjourintervalvente)
                except:
                    pass

                try:
                    cadre.remove_widget(bcalcbenefice)
                except:
                    pass
                
                if sepp==0:
                    try:
                        cadre.remove_widget(imgacc2)
                        cadre.remove_widget(imgacc1)
                        cadre.remove_widget(ladmin)
                        cadre.remove_widget(accueilcad1)
                        cadre.remove_widget(accueilcad2)
                    except:
                        pass

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass
            
                if sepp==1:

                    try:
                        cadre.remove_widget(labchange)
                    except:
                        pass

                    try:
                        cadre.remove_widget(checkchangecdf)
                    except:
                        pass

                    try:
                        cadre.remove_widget(indicateurindice)
                    except:
                        pass
                    try:
                        cadre.remove_widget(labindice)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bscanneur)
                    except:
                        pass

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass
                    
                    try:
                        cadre.remove_widget(checkcodelocal)
                    except:
                        pass
                    try:
                        cadre.remove_widget(labcodelocal)
                    except:
                        pass
                    
            
                if sepp==4:
                    try:
                        cadre.remove_widget(trecravitail)
                        cadre.remove_widget(combravitail)
                    except:
                        pass

                    try:
                        cadre.remove_widget(imgacc1)
                        cadre.remove_widget(ladmin)
                        cadre.remove_widget(accueilcad1)
                        cadre.remove_widget(accueilcad2)
                    except:
                        pass
                        
                    try:
                        cadre.remove_widget(btnmodqt)
                    except:
                        pass   

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass  
                
                
                if sepp==4:

                    if hautlab1.text=="[b]GESTION DE STOCK[/b]" or hautlab1.text=="[b]STOCK EPUISE[/b]":
                        
                        if selid=="a":
                            try:
                                cadre.remove_widget(tablstock)
                            except:
                                pass
                        elif selid=="b":

                            try:
                                cadre.remove_widget(tablstocktotal)
                            except:
                                pass
                            
                            try:
                                cadre.remove_widget(tablstockfini)
                            except:
                                pass

                            try:
                                cadre.remove_widget(labstockfini)
                            except:
                                pass

                            try:
                                cadre.remove_widget(bflech0)
                            except:
                                pass

                            try:
                                cadre.remove_widget(bflechbas)
                            except:
                                pass

                            try:
                                cadre.remove_widget(bflechhaut)
                            except:
                                pass
                        
                    elif hautlab1.text=="[b]ANALYSEUR DE PERFORMANCE[/b]":
                        try:
                            cadre.remove_widget(tabstock1)
                            cadre.remove_widget(labstock1)
                            cadre.remove_widget(ldetail)
                        except:
                            pass
                    elif hautlab1.text=="[b]RAVITAILLEMENT PRODUIT[/b]":
                        
                        try:
                            cadre.remove_widget(tablstock)
                        except:
                            pass
            
                
                try:
                    t1.text=""
                    t2.text=""
                    t3.text=""
                    t4.text=""
                    t5.text=""
                    t6.text=""
                    t7.text=""
                    t8.text=""
                    t9.text=""
                    t10.text=""
                        
                    cadre.remove_widget(labremarque)
                    cadre.remove_widget(labremarque0)
                
                    trech.text="Rechercher"
                    t10.disabled=False  
                    t9.disabled=False  
                    t1.disabled=False
                    t1.helper_text="ID Produit"
                    t10.helper_text="Date"
                    t9.helper_text="Stock Produit"
                except:
                    pass
                try:
                    if hautlab1.text=="[b]GESTION DE STOCK[/b]":
                        cadre.remove_widget(tabstock1)
                        cadre.remove_widget(labstock1)
                except:
                    pass

                try:
                    if hautlab1.text=="[b]TABLEAU DE BORD[/b]":
                        cadre.remove_widget(tablegestionvente)
                except:
                    pass

                if sepp==1:
                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bscanneurannuler)
                    except:
                        pass
            

                elif sepp==2:
                    
                    try:
                        cadre.remove_widget(labchange)
                    except:
                        pass

                    try:
                        cadre.remove_widget(checkchangecdf)
                    except:
                        pass

                    try:
                        cadre.remove_widget(trechlikemodif)
                    except:
                        pass

                    try:
                        cadre.remove_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bscanneurannuler)
                    except:
                        pass
                
                elif sepp==3:

                    try:
                        cadre.remove_widget(cadcanette)
                    except:
                        pass

                    try:
                        cadre.remove_widget(bcanetterelage)
                    except:
                        pass
                    try:
                        cadre.remove_widget(labcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(checkcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(btrechcombine)
                    except:
                        pass


                    try:
                        cadre.remove_widget(labcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(checkcombine)
                    except:
                        pass
                    try:
                        cadre.remove_widget(btrechcombine)
                    except:
                        pass

                    
                    try:
                        cadre.remove_widget(btridtrav)
                    except:
                        pass

                    try:
                        cadre.remove_widget(hlab3)
                    except:
                        pass
                    
                    try:
                        cadre.remove_widget(combotrav)
                    except:
                        pass

                etat = 1
                
            else:
                
                if sepp==1:

                    try:
                        cadre.add_widget(indicateurindice)
                    except:
                        pass
                    try:
                        cadre.add_widget(labindice)
                    except:
                        pass

                    try:
                        cadre.add_widget(bscanneur)
                    except:
                        pass

                    try:
                        cadre.add_widget(checkcodelocal)
                    except:
                        pass
                    try:
                        cadre.add_widget(labcodelocal)
                    except:
                        pass
                    
                
                if sepp==4:

                    try:
                        cadre.add_widget(bexport)
                    except:
                        pass

                    if hautlab1.text=="[b]GESTION DE STOCK[/b]" or hautlab1.text=="[b]STOCK EPUISE[/b]":
                        
                        if selid=="a":
                            try:
                                cadre.add_widget(tablstock)
                            except:
                                pass

                        elif selid=="b":

                            try:
                                cadre.add_widget(bperemption)
                            except:
                                pass
                            try:
                                cadre.add_widget(tablstocktotal)
                            except:
                                pass
                            
                            try:
                                cadre.add_widget(tablstockfini)
                            except:
                                pass

                            try:
                                cadre.add_widget(labstockfini)
                            except:
                                pass

                            try:
                                cadre.add_widget(bflech0)
                            except:
                                pass

                            try:
                                cadre.add_widget(bflechbas)
                            except:
                                pass

                            try:
                                cadre.add_widget(bflechhaut)
                            except:
                                pass
                            
                    elif hautlab1.text=="[b]ANALYSEUR DE PERFORMANCE[/b]":
                        try:
                            cadre.add_widget(tabstock1)
                            cadre.add_widget(labstock1)
                            cadre.add_widget(ldetail)
                        except:
                            pass

                    elif hautlab1.text=="[b]RAVITAILLEMENT PRODUIT[/b]":

                        try:
                            cadre.add_widget(trecravitail)
                            cadre.add_widget(combravitail)
                        except:
                            pass

                        try:
                            cadre.add_widget(tablstock)
                        except:
                            pass

                        try:
                            cadre.add_widget(btnmodqt)
                        except:
                            pass
                

                if sepp==1:
                    try:
                        cadre.add_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.add_widget(bscanneurannuler)
                    except:
                        pass

                elif sepp==2:

                    try:
                        cadre.add_widget(labchange)
                    except:
                        pass

                    try:
                        cadre.add_widget(checkchangecdf)
                    except:
                        pass

                    try:
                        cadre.add_widget(trechlikemodif)
                    except:
                        pass

                    try:
                        cadre.add_widget(photoproduit)
                    except:
                        pass

                    try:
                        cadre.add_widget(bscanneurannuler)
                    except:
                        pass

                elif sepp==3:

                    
                    try:
                        pass # cadre.add_widget(bcanetterelage)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(labglobal)
                    except:
                        pass
                    try:
                        pass # cadre.add_widget(checkgobal)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(combanneintervalvente)
                        #cadre.add_widget(combmoisintervalveny)
                        #cadre.add_widget(combjourintervalvente)
                    except:
                        pass

                    try:
                        pass #cadre.add_widget(bcalcbenefice)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(bexport)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(labcombine)
                    except:
                        pass
                    try:
                        pass # cadre.add_widget(checkcombine)
                    except:
                        pass
                    try:
                        pass  # cadre.add_widget(btrechcombine)
                    except:
                        pass

                    try:
                        cadre.add_widget(tablegestionvente)
                    except:
                        pass
                    
                    try:
                        pass # cadre.add_widget(btridtrav)
                    except:
                        pass

                    try:
                        pass # cadre.add_widget(hlab3)
                    except:
                        pass
                    
                    try:
                        pass # cadre.add_widget(combotrav)
                    except:
                        pass

                
                if sepp==0:
                    try:
                        cadre.add_widget(imgacc2)
                        cadre.add_widget(imgacc1)
                        cadre.add_widget(ladmin)
                        cadre.add_widget(accueilcad1)
                        cadre.add_widget(accueilcad2)
                    except:
                        pass

                b1.size_hint=(0,0.1)
                b1.text=""

                b2.size_hint=(0,0.1)
                b2.text=""

                b3.size_hint=(0,0.1)
                b3.text=""

                b4.size_hint=(0,0.1)
                b4.text=""
                
                b5.size_hint=(0,0.1)
                b5.text=""

                instance.pos_hint={'x':0,'top':0.86} 
                instance.size_hint=(0.05,0.1)
                
                etat = 0
                t1.pos_hint={'x':0.14, 'y':0.86}
                t3.pos_hint={'x':0.14, 'y':0.78}
                t5.pos_hint={'x':0.14, 'y':0.68}
                t7.pos_hint={'x':0.14, 'y':0.58}
                t9.pos_hint={'x':0.14, 'y':0.48}

                try:
                    t1.text=""
                    t2.text=""
                    t3.text=""
                    t4.text=""
                    t5.text=""
                    t6.text=""
                    t7.text=""
                    t8.text=""
                    t9.text=""
                    t10.text=""
                    t10.disabled= False  
                    t9.disabled=False
                    trech.text="Rechercher"
                    
                    t10.disabled=False  
                    t9.disabled=False  
                    t1.disabled=False
                    t1.helper_text="ID Produit"
                    t10.helper_text="Date"
                    t9.helper_text="Stock Produit"

                except:
                    pass

    def demarrerserviceonline(self,instance):

        self.demarrenew


        btcl=Builder.load_string('''
Button:
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')

        try:
            cred = credentials.Certificate("superpharma-firebase-adminsdk-tud39-476d7ea145.json")
            firebase_admin.initialize_app(cred,{'databaseURL':'https://superpharma-default-rtdb.firebaseio.com/'})

            btcl.text="Cloud disponible"

        except Exception as ex:

            btcl.text=str(ex)
            btcl.font_size='9sp'
        
        msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
        msg.open()


    def lectureonlignProduit(self,instance):

        global msgtrasfertok,msgg,cadhistoCloud,lba,btclosravnew,btvaliderannulercloud,icenvois,typecloud

        typecloud=2

        try:
            msgg.dismiss()
        except:
            pass
        
        cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        lba=Label(text="Voulez-vous vraiment confirmer cette operation ?\nNB:Cette derniere implique la lecture rapide CLOUD,\nVos données actuelles de la table Medicaments seront remplacées par celles du CLOUD  !",color='black',bold=True,pos_hint={'center_x':.5,'center_y':.6},size_hint=(1,.6))

        icenvois=Builder.load_string('''
MDIcon:
    icon:'cloud-refresh'
    size_hint:.1,.1
    pos_hint:{'center_x':.5,'center_y':.5}
    theme_text_color:'Custom'
    text_color:'blue'

        ''')


        btvaliderannulercloud=Builder.load_string('''
Button:
    text:"Valider"
    size_hint:.2,.12
    pos_hint:{'x':.75,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')
        
        btvaliderannulercloud.bind(on_release=self.transiteProgress) #transfereonlinefin)

        btclosravnew=Builder.load_string('''
Button:
    text:"Annuler"
    size_hint:.2,.12
    pos_hint:{'x':.05,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btclosravnew.bind(on_release=lambda x:msgtrasfertok.dismiss())

        try:
            cadhistoCloud.add_widget(lba)
            cadhistoCloud.add_widget(btclosravnew)
            cadhistoCloud.add_widget(btvaliderannulercloud)
        except:
            pass

        try:
            msgtrasfertok=Popup(title="SYSTEME",content=cadhistoCloud,size_hint=(.6,.4))  
        except:
            pass
        
        msgtrasfertok.open()
    
    def backUpProduitsimple(self,instance):

        if instance.active==False:
            
            btcl=Builder.load_string('''
Button:
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
''')

            try:
                    
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,pu,stock,date_exp from produit,expiration where id_exp=matricule")
                listproduitbackUp=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatbackUpp=self.exportBackUp(listproduitbackUp)

                if etatbackUpp==True:

                    btcl.text="BackUp terminé"
                    msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                    msg.open()
                
                else:

                    btcl.text="ERROR BackUp, veuillez recommencer"
                    msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                    msg.open()
            except Exception as e:
                print(e)

    def lecturelonlinProduit(self):

        global msgg,msgtrasfertok

        btcl=Builder.load_string('''
Button:
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
''')

        onlin=Online(idonline,dateonline)
        etatabon=onlin.verifieabonnement()

        if etatabon==True:

            if checkmodecloaud.active==True:
                
                try:
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select matricule,nom,pu,stock,date_exp from produit,expiration where id_exp=matricule")
                    listproduit=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    etatenvoicloudProduit=onlin.envoiecloud(listproduit)

                    if etatenvoicloudProduit==True:

                        btcl.text="Envois CLOUD terminé"
                        msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                        msg.open()
                
                except Exception as e:
                    print(e)

            else:

                try:

                    listdata=onlin.lecturecloudProduit() #lectureclous()

                    self.cconnexion()
                    cursor=con.cursor()

                    for lin in listdata:

                        a,b,c,d,e=lin

                        try:
                            query="insert into produit(matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,dats,stock_p) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,"-","-","-","-","-",float(c),int(d),datetime.now().strftime('%Y-%m-%d'),0)
                            cursor.execute(query,dataa)
                            con.commit()

                            query="insert into expiration(id_exp,date_exp) values(%s,%s)"
                            dataa=(a,datetime.now().strftime('%Y-%m-%d'))
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass
                    
                    query="insert into registrefluxonline(dateheure,datee,idtrav,operation) values(%s,%s,%s,%s)"
                    dataa=(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d'),tidconn.text,"Telechargement CLOUD Produit")
                    cursor.execute(query,dataa)
                    con.commit()

                    con.close()
                    
                    btcl.text="Telechargement CLOUD terminé"
                    msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                    msg.open()

                except Exception as e:

                    print(e)

                    btcl.text="ERROR!!!"
                    msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                    msg.open()
                else:

                    btcl.text="Impossible de continuer car le BackUp a échoué !\nVeuillez recommancer"
                    msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                    msg.open()

        elif etatabon==False:

            cad=Builder.load_string('''
FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15,15,1,1]          
            
            ''')
            btcl=Label(color='black',size_hint=(.8,.1),pos_hint={'center_x':.5,'center_y':.6},bold=True,font_size='15sp')
            btcl.text="Echec, Abonnement insuffisant\n Veuillez vous Réabonner SVP!!"

            btreabonn=Builder.load_string('''
Button:
    text:"Me Reabonner"
    color:'white'
    background_color:[0,0,0,0]
    bold:True
    size_hint:.3,.15
    pos_hint:{'x':.65,'y':.05}

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
            btreabonn.bind(on_release=self.reabonnementCloud)

            try:
                cad.add_widget(btcl)
                cad.add_widget(btreabonn)
            except:
                pass
                
            try:
                msgg.dismiss()
            except:
                pass

            msgg=Popup(title="CONNEXION CLOUD",content=cad,size_hint=(.5,.3))
            msgg.open()

        else:

            btcl.text="ERROR!! erreur Inconnue"
            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()


        try:
            msgtrasfertok.dismiss()
        except:
            pass

    def lectureonlign(self,instance):
        global msgtrasfertok,msgg,cadhistoCloud,lba,btclosravnew,btvaliderannulercloud,icenvois,typecloud

        typecloud=3

        try:
            msgg.dismiss()
        except:
            pass
        
        cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        lba=Label(text="Voulez-vous vraiment confirmer cette operation ?\nNB:Cette derniere implique la lecture CLOUD,\nVos données actuelles seront remplacées par celles du CLOUD  !",color='black',bold=True,pos_hint={'center_x':.5,'center_y':.6},size_hint=(1,.6))

        icenvois=Builder.load_string('''
MDIcon:
    icon:'cloud-download'
    size_hint:.1,.1
    pos_hint:{'center_x':.5,'center_y':.5}
    theme_text_color:'Custom'
    text_color:'blue'

        ''')


        btvaliderannulercloud=Builder.load_string('''
Button:
    text:"Valider"
    size_hint:.2,.12
    pos_hint:{'x':.75,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')
        
        btvaliderannulercloud.bind(on_release=self.transiteProgress) #transfereonlinefin)

        btclosravnew=Builder.load_string('''
Button:
    text:"Annuler"
    size_hint:.2,.12
    pos_hint:{'x':.05,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btclosravnew.bind(on_release=lambda x:msgtrasfertok.dismiss())

        try:
            cadhistoCloud.add_widget(lba)
            cadhistoCloud.add_widget(btclosravnew)
            cadhistoCloud.add_widget(btvaliderannulercloud)
        except:
            pass

        try:
            msgtrasfertok=Popup(title="SYSTEME",content=cadhistoCloud,size_hint=(.6,.4))  
        except:
            pass
        
        msgtrasfertok.open()


    def lecturcloudfin(self):

        global msgg,msgtrasfertok

        btcl=Builder.load_string('''
Button:
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos
            radius:[15,15,1,1]
''')

        onlin=Online(idonline,dateonline)
        etatabon=onlin.verifieabonnement()

        etatExportGen=False

        if etatabon==True:
        
            try:

                try: 

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select matricule,nom,pu,stock,date_exp from produit,expiration where id_exp=matricule")
                    listproduit=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listCompte=[]
                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from compte")
                    listCompte=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listchat=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from achat")
                    listchat=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listhisto=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from historique")
                    listhisto=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listprisecharge=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from prisecharge")
                    listprisecharge=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listprescription=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from prescription")
                    listprescription=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listfluxcloud=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from registrefluxonline")
                    listfluxcloud=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listcommande=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from commandefacture")
                    listcommande=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    
                    listmotif=[]

                    self.cconnexion()
                    self.cursor=con.cursor()
                    self.cursor.execute("select * from motif_signaler")
                    listmotif=self.cursor.fetchall()
                    self.cursor.close()
                    con.close()

                    etatExportGen=self.exportBackUpGeneral(listCompte,listproduit,listhisto,listchat,listcommande,listmotif,listprescription,listprisecharge,listfluxcloud)

                except:
                    etatExportGen=False


                if etatExportGen==True:

                    listcompte=onlin.lecturecloudCompte()

                    listdata=onlin.lecturecloudProduit()

                    listahistogramme=onlin.lecturecloudHistogramme()

                    listachat=onlin.lecturecloudAchat()

                    listcommandefacture=onlin.lecturecloudCommandeFacture()

                    listMotifsignaler=onlin.lecturecloudMotifSignaler()

                    listPresceiption=onlin.lecturecloudPresciption()

                    listPrisecharge=onlin.lecturecloudPrisecharge()

                    listRgistreFlux=onlin.lecturecloudRegistreCommande()

                    self.cconnexion()
                    cursor=con.cursor()

                    for lin in listdata:

                        a,b,c,d,e=lin

                        try:
                            expirdate=datetime.strptime(e,'%Y-%m-%d')
                        except:
                            expirdate='0000-00-00'

                        try:
                            query="insert into produit(matricule,nom,categorie,anti,traite,posologie,age_utilisation,pu,stock,dats,stock_p) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,"-","-","-","-","-",float(c),int(d),datetime.now().strftime('%Y-%m-%d'),0)
                            cursor.execute(query,dataa)
                            con.commit()

                            query="insert into expiration(id_exp,date_exp) values(%s,%s)"
                            dataa=(a,expirdate)
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass
                    

                    for ele in listRgistreFlux:
                        a,b,c,d=ele

                        try:
                            query="insert into registrefluxonline(dateheure,datee,idtrav,operation) values(%s,%s,%s,%s)"
                            dataa=(datetime.strptime(a,'%Y-%m-%d %H:%M:%S'),datetime.strptime(b,'%Y-%m-%d'),c,d)
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass


                    for ele in listPrisecharge:
                        a,b,c,d,e,f,g,h=ele

                        try:
                            query="insert into prisecharge(gmail,nom,prenom,sexe,tel,adresse,dates,trav) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,c,d,e,f,datetime.strptime(g,'%Y-%m-%d'),h)
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass

                    for ele in listPresceiption:
                        a,b,c,d=ele

                        try:
                            query="insert into prescription(id_prise,id_achat,docteur,datees) values(%s,%s,%s,%s)"
                            dataa=(a,b,c,datetime.strptime(d,'%Y-%m-%d'))
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass

                    for ele in listMotifsignaler:
                        a,b,c,d,e,f=ele

                        try:
                            query="insert into motif_signaler(nom_motif,detail_motif,id_trav,date_motif,date_timemotif,montant) values(%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,c,datetime.strptime(d,'%Y-%m-%d'),datetime.strptime(e,'%Y-%m-%d %H:%M:%S'),int(f))
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass

                    for ele in listcommandefacture:
                        a,b,c,d,e,f,g,h=ele

                        try:
                            query="insert into commandefacture(id_commande,id_prod,ajout,pucdf,IdTrav,date,date_heure,impactprix) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,int(c),int(d),e,datetime.strptime(f,'%Y-%m-%d'),datetime.strptime(g,'%Y-%m-%d %H:%M:%S'),int(h))
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass

                    for ele in listcompte:
                        a,b,c,d,e,f,g,h=ele

                        try:
                            query="insert into compte(nom,postnom,prenom,sexe,id,pwd,type,dates) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,c,d,e,f,g,datetime.strptime(h,'%Y-%m-%d'))
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass
                    
                    for ele in listahistogramme:
                        a,b,c,d,e,f,g,h=ele

                        try:
                            query="insert into historique(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,c,d,e,datetime.strptime(f,'%Y-%m-%d'),datetime.strptime(g,'%Y-%m-%d %H:%M:%S'),h)
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass
                        
                    for ele in listachat:
                        a,b,c,d,e,f,g,h=ele
                        try:
                            query="insert into achat(ID_Produit,PU,Qte,PT,Nom_client,Dates,Dats_id,id_travailleur) values(%s,%s,%s,%s,%s,%s,%s,%s)"
                            dataa=(a,b,c,d,e,datetime.strptime(f,'%Y-%m-%d'),datetime.strptime(g,'%Y-%m-%d %H:%M:%S'),h)
                            cursor.execute(query,dataa)
                            con.commit()
                        except:
                            pass
                    
                    query="insert into registrefluxonline(dateheure,datee,idtrav,operation) values(%s,%s,%s,%s)"
                    dataa=(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d'),tidconn.text,"Telechargement CLOUD")
                    cursor.execute(query,dataa)
                    con.commit()

                    con.close()
                    
                    btcl.text="Telechargement CLOUD terminé"
                    msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                    msg.open()

                else:

                    btcl.text="ERROR du finissage BackUP !"
                    msg=Popup(title="INFO",content=btcl,size_hint=(.5,.3))
                    msg.open()
                        
            except Exception as e:

                btcl.text="ERROR!!!"
                msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                msg.open()

        elif etatabon==False:

            cad=Builder.load_string('''
FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15,15,1,1]          
            
            ''')
            btcl=Label(color='black',size_hint=(.8,.1),pos_hint={'center_x':.5,'center_y':.6},bold=True,font_size='15sp')
            btcl.text="Echec, Abonnement insuffisant\n Veuillez vous Réabonner SVP!!"

            btreabonn=Builder.load_string('''
Button:
    text:"Me Reabonner"
    color:'white'
    background_color:[0,0,0,0]
    bold:True
    size_hint:.3,.15
    pos_hint:{'x':.65,'y':.05}

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
            btreabonn.bind(on_release=self.reabonnementCloud)

            try:
                cad.add_widget(btcl)
                cad.add_widget(btreabonn)
            except:
                pass
                
            try:
                msgg.dismiss()
            except:
                pass

            msgg=Popup(title="CONNEXION CLOUD",content=cad,size_hint=(.5,.3))
            msgg.open()

            

        else:

            btcl.text="ERROR!! Erreur inconnue"
            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

        try:
            msgtrasfertok.dismiss()
        except:
            pass    

    def transfertOnline(self,instance):
        global msgtrasfertok,msgg,cadhistoCloud,lba,btclosravnew,btvaliderannulercloud,icenvois,typecloud

        typecloud=1

        try:
            msgg.dismiss()
        except:
            pass
        
        cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        lba=Label(text="Voulez-vous vraiment confirmer cette operation ?\nNB:Cette derniere implique le transfert CLOUD  !",color='black',bold=True,pos_hint={'center_x':.5,'center_y':.6},size_hint=(1,.6))

        icenvois=Builder.load_string('''
MDIcon:
    icon:'cloud-upload'
    size_hint:.1,.1
    pos_hint:{'center_x':.5,'center_y':.5}
    theme_text_color:'Custom'
    text_color:'blue'

        ''')


        btvaliderannulercloud=Builder.load_string('''
Button:
    text:"Valider"
    size_hint:.2,.12
    pos_hint:{'x':.75,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')
        
        btvaliderannulercloud.bind(on_release=self.transiteProgress) #transfereonlinefin)

        btclosravnew=Builder.load_string('''
Button:
    text:"Annuler"
    size_hint:.2,.12
    pos_hint:{'x':.05,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btclosravnew.bind(on_release=lambda x:msgtrasfertok.dismiss())

        try:
            cadhistoCloud.add_widget(lba)
            cadhistoCloud.add_widget(btclosravnew)
            cadhistoCloud.add_widget(btvaliderannulercloud)
        except:
            pass

        try:
            msgtrasfertok=Popup(title="SYSTEME",content=cadhistoCloud,size_hint=(.6,.4))  
        except:
            pass
        
        msgtrasfertok.open()
    

    def transiteProgress(self,instance):
        global Cloudminuteur,nb,cadhistoCloud,lba,btclosravnew,btvaliderannulercloud,icenvois

        try:
            cadhistoCloud.remove_widget(btclosravnew)
            cadhistoCloud.remove_widget(btvaliderannulercloud)
        except:
            pass

        try:
            cadhistoCloud.add_widget(icenvois)
        except:
            pass

        lba.text="Veuillez patienter ...."

        nb=1
        
        Cloudminuteur=Clock.schedule_interval(lambda dt: self.update_progressProgresCloud(nb), 0.1)
                
    def update_progressProgresCloud(self,progress_bar):

        global labb,nb,Cloudminuteur,typecloud
        
        try:

            if progress_bar < 20:
                progress_bar += 2

                nb=progress_bar

                labb.text="Traitement encours ..."

            else:

                if typecloud==1:
                
                    self.transfereonlinefin()

                    Clock.unschedule(Cloudminuteur)
                
                elif typecloud==2:
                    
                    self.lecturelonlinProduit()

                    Clock.unschedule(Cloudminuteur)
                
                elif typecloud==3:
                    
                    self.lecturcloudfin()

                    Clock.unschedule(Cloudminuteur)

        except:
            pass    

    def transfereonlinefin(self):
        global msgg,msgtrasfertok
        
        btcl=Builder.load_string('''
Button:
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')
        
        onlin=Online(idonline,dateonline)

        etatabon=onlin.verifieabonnement()

        if etatabon==True:
            listproduit=[]

            try:

                # envoi produit 

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select matricule,nom,pu,stock,date_exp from produit,expiration where id_exp=matricule")
                listproduit=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudProduit=onlin.envoiecloud(listproduit)

                # envois info compte utilisateur
                listCompte=[]
                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from compte")
                listCompte=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudUtilisateur=onlin.envoiecloudUtilisateur(listCompte)

                # envoi info achat

                listchat=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from achat")
                listchat=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudachat=onlin.envoiecloudUachat(listchat)

                # envoi info historique

                listhisto=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from historique")
                listhisto=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudhisto=onlin.envoiecloudHistorique(listhisto)

                # envois info prise en charge
                
                listprisecharge=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from prisecharge")
                listprisecharge=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudprisecharge=onlin.envoiecloudPrisecharge(listprisecharge)

                # envois info prescription

                listprescription=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from prescription")
                listprescription=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudprescrption=onlin.envoiecloudPrescription(listprescription)

                # envois info fluxCloud

                listfluxcloud=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from registrefluxonline")
                listfluxcloud=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudfluxcloud=onlin.envoiecloudFluxcloud(listfluxcloud)

                # envois info facturecommande

                listcommande=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from commandefacture")
                listcommande=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudcommandefact=onlin.envoiecloudfactureCommande(listcommande)

                # envoi info motifsignale
                
                listmotif=[]

                self.cconnexion()
                self.cursor=con.cursor()
                self.cursor.execute("select * from motif_signaler")
                listmotif=self.cursor.fetchall()
                self.cursor.close()
                con.close()

                etatenvoicloudmotif=onlin.envoiecloudmotifsignaler(listmotif)


                if etatenvoicloudProduit==True and etatenvoicloudUtilisateur==True and etatenvoicloudachat==True and etatenvoicloudhisto==True and etatenvoicloudprisecharge==True and etatenvoicloudprescrption==True and etatenvoicloudfluxcloud==True and etatenvoicloudcommandefact==True and etatenvoicloudmotif==True:

                    try:

                        self.cconnexion()
                        self.cursor=con.cursor()
                        query="insert into registrefluxonline(dateheure,datee,idtrav,operation) values(%s,%s,%s,%s)"
                        dataa=(datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d'),tidconn.text,"Envois CLOUD")
                        self.cursor.execute(query,dataa)
                        con.commit()
                        con.close()

                        btcl.text="Les données envoyées sur CLOUD avec succes"

                        msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                        msg.open()

                    except:

                        btcl.text="Les données envoyées sur CLOUD avec succes\nnéamoins la souche n a été laissée dans le registre local"
                        msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                        msg.open()

            except Exception as e:

                print(e)

                btcl.text="Error!! Read not found!!"

                msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
                msg.open()


        elif etatabon==False:

            cad=Builder.load_string('''
FloatLayout:
    size_hint:1,1

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            pos:self.pos
            size:self.size
            radius:[15,15,1,1]          
            
            ''')
            btcl=Label(color='black',size_hint=(.8,.1),pos_hint={'center_x':.5,'center_y':.6},bold=True,font_size='15sp')
            btcl.text="Echec, Abonnement insuffisant\n Veuillez vous Réabonner SVP!!"

            btreabonn=Builder.load_string('''
Button:
    text:"Me Reabonner"
    color:'white'
    background_color:[0,0,0,0]
    bold:True
    size_hint:.3,.15
    pos_hint:{'x':.65,'y':.05}

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]
''')
            btreabonn.bind(on_release=self.reabonnementCloud)

            try:
                cad.add_widget(btcl)
                cad.add_widget(btreabonn)
            except:
                pass
                
            try:
                msgg.dismiss()
            except:
                pass

            msgg=Popup(title="CONNEXION CLOUD",content=cad,size_hint=(.5,.3))
            msgg.open()

        else:

            btcl.text="ERROR!! erreur inconnue "
            
            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()
        
        try:
            msgtrasfertok.dismiss()
        except:
            pass

    def affichtousflux(self,instance):
        global tablhistocloud

        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select datee,dateheure,idtrav,operation from registrefluxonline order by dateheure DESC")
            tablhistocloud.row_data=self.cursor.fetchall()
            self.cursor.close()
            con.close()
        except:
            pass

    
    def annuleroperationcloud(self,instance):

        global msgg

    
        try:
            msgg.dismiss()
        except:
            pass
        
        cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        lba=Label(text="Voulez-vous vraiment annuler le Telechargement CLOUD recemment effectuée ??\nNB: Votre clique sur Valider Restaurera les informations tres anciennes !",color='black',bold=True,pos_hint={'center_x':.5,'center_y':.6},size_hint=(1,.6))

        btvaliderannulercloud=Builder.load_string('''
Button:
    text:"Valider"
    size_hint:.2,.12
    pos_hint:{'x':.75,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btclosravnew=Builder.load_string('''
Button:
    text:"Annuler"
    size_hint:.2,.12
    pos_hint:{'x':.05,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btclosravnew.bind(on_release=lambda x:msgannuleropencloud.dismiss())

        try:
            cadhistoCloud.add_widget(lba)
            cadhistoCloud.add_widget(btclosravnew)
            cadhistoCloud.add_widget(btvaliderannulercloud)
        except:
            pass

        try:
            msgannuleropencloud=Popup(title="SYSTEME",content=cadhistoCloud,size_hint=(.6,.4))  
        except:
            pass
        
        msgannuleropencloud.open()


    def openhistoriqueCloud(self,instance):

        global msgg,tablhistocloud

        listflux=[]

        try:
            msgg.dismiss()
        except:
            pass

        cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

        btclosravnew=Builder.load_string('''
Button:
    text:"Close"
    size_hint:.15,.05
    pos_hint:{'x':.83,'y':.93}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btclosravnew.bind(on_release=lambda x:msgopencloud.dismiss())

        btafftous=Builder.load_string('''
Button:
    text:"Afficher tous"
    size_hint:.25,.05
    pos_hint:{'x':.73,'y':.05}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

        btafftous.bind(on_release=self.affichtousflux)

        lab=Label(text="REGISTRE DE FLUX CLOUD",bold=True,font_size='20sp',color='black',pos_hint={'center_x':.5,'y':.9},size_hint=(.1,.1))


        try:
            self.cconnexion()
            self.cursor=con.cursor()
            self.cursor.execute("select datee,dateheure,idtrav,operation from registrefluxonline order by dateheure DESC limit 10 ")
            listflux=self.cursor.fetchall()
            self.cursor.close()
            con.close()
        except:
            pass

        tablhistocloud=MDDataTable(column_data=[
            ("DATE",dp(40)),
            ("DATE & HEURE",dp(40)),
            ("TRAVAILLEUR",dp(40)),
            ("OPERATION",dp(70))
            
            ], row_data=listflux,size_hint=(0.98,0.72),pos_hint={'center_x':0.5,'y':0.15},check=True,rows_num=2000,use_pagination=True)

        
        try:
            cadhistoCloud.add_widget(btclosravnew)
            cadhistoCloud.add_widget(tablhistocloud)
            cadhistoCloud.add_widget(lab)
            cadhistoCloud.add_widget(btafftous)
        except:
            pass
    
        msgopencloud=Popup(title="HISTORIQUE FLUX CLOUD",content=cadhistoCloud,size_hint=(.7,.8))
        msgopencloud.open()


    def openadresssite(self,instance):
        global adressweb

        try:
            webbrowser.open(adressweb)
        except:
            pass


    def envoiepreuvefin(self,instance):
        global msgopencloud

        try:
            msgopencloud.dismiss()
        except:
            pass
            
        btconffin=Builder.load_string('''
Button:
    size_hint:1,1
    pos_hint:{'center_x':.5,'y':.1}
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]

        ''')


        btconffin.text="Requete  envoyée avec succes !!\nvous serez notifié des que fini son examination!!"

        msgopencloud=Popup(title="ACCUSE RECEPTION", content=btconffin,size_hint=(.5,.3))
        msgopencloud.open()

    def confirmertransId(self,instance):
        global msgopencloud,transid

        if transid.text !="":

            try:
                msgopencloud.dismiss()
            except:
                pass

            cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

            btconffin=Builder.load_string('''
Button:
    text:"Oui j'ai fait déposé la somme"
    size_hint:.5,.12
    pos_hint:{'center_x':.5,'y':.1}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

            btconffin.bind(on_release=self.envoiepreuvefin)

            lab=Label(text="Etes-vous sur d avoir transféré la somme demandée au\nnumero mobile procedement affiché ??\nSi oui cliquez sur le boutton dessous!!",pos_hint={'center_x':.5,'center_y':.5},size_hint=(.8,.4),font_size='14sp',bold=True,color='black')

            try:
                cadhistoCloud.add_widget(btconffin)
                cadhistoCloud.add_widget(lab)
            except:
                pass

            msgopencloud=Popup(title="CONFIRMATION PREUVE DE PAIEMENT", content=cadhistoCloud,size_hint=(.5,.3))
            msgopencloud.open()

    def reabonnementCloud(self,instance):

        global msgg,tablhistocloud,adressweb,msgopencloud,transid

        listflux=[]
        try:
            msgg.dismiss()
        except:
            pass

        
        try:
            onlin=Online(idonline,dateonline)
            numero=""
            adressweb=""
            montant=""

            idpharma=""
            adresspharma=""
            nomresppharma=""

            ref=db.reference('systeme/infopaie')
            donness=ref.get()

            if donness:
                numero=donness['numero']
                adressweb=donness['siteweb']

            ref=db.reference('systeme/paie')

            donnessnew=ref.child(idonline).get()

            if donnessnew:
                montant=donnessnew['montant']
                nomresppharma=donnessnew['responsable']
                adresspharma=donnessnew['adresse']


            cadhistoCloud=Builder.load_string('''
FloatLayout:
    size_hint:1,1
    pos_hint: {'x':0,'y':0}  
                                                                                                        
    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos 
            radius:[15]
                
        ''') 

            btclosravnew=Builder.load_string('''
Button:
    text:"Close"
    size_hint:.15,.05
    pos_hint:{'x':.83,'y':.93}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:1,0,0,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

            btclosravnew.bind(on_release=lambda x:msgopencloud.dismiss())

            btconfitransid=Builder.load_string('''
Button:
    text:"Confirmer"
    size_hint:.2,.05
    pos_hint:{'center_x':.85,'y':.1}
    color:'white'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgba:0,0,1,1
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15]

        ''')

            btconfitransid.bind(on_release=self.confirmertransId)

            lab=Label(text="REABONNEMENT CLOUD",bold=True,font_size='20sp',color='blue',pos_hint={'center_x':.5,'y':.9},size_hint=(.1,.1))
            
            labidpharma=Label(text="Identiant  :  "+str(idonline),bold=True,font_size='18sp',color='black',pos_hint={'center_x':.5,'center_y':.8},size_hint=(.1,.1))
            
            labadressepharma=Label(text="Adresse  :  "+str(adresspharma),bold=True,font_size='18sp',color='black',pos_hint={'center_x':.5,'center_y':.7},size_hint=(.1,.1))

            labresppharma=Label(text="RESPONSABLE  :  "+str(nomresppharma),bold=True,font_size='18sp',color='black',pos_hint={'center_x':.5,'center_y':.6},size_hint=(.1,.1))

            
            labnumero=Label(text="Numero Mobile  :  "+str(numero),bold=True,font_size='20sp',color='black',pos_hint={'center_x':.5,'center_y':.3},size_hint=(.1,.1))
            
            labmontant=Label(text=str(montant)+"  /Mois",bold=True,font_size='20sp',color='red',pos_hint={'center_x':.5,'center_y':.4},size_hint=(.1,.1))
            
            transid=MDTextField(pos_hint={'center_x':.4,'y':.1},size_hint=(.5,.1),hint_text="ID Transation",icon_right='text',line_color_normal='black',font_size='22sp')
            
            btopensite=Builder.load_string('''
Button:
    text:"Comment se Réabonner?"
    size_hint:.3,.05
    pos_hint:{'x':.7,'y':.01}
    color:'red'
    background_color:[0,0,0,0]
    bold:True

        ''')

            btopensite.bind(on_release=self.openadresssite)

            try:
                cadhistoCloud.add_widget(btclosravnew)
                cadhistoCloud.add_widget(labnumero)
                cadhistoCloud.add_widget(lab)
                cadhistoCloud.add_widget(btopensite)
                cadhistoCloud.add_widget(labmontant)

                cadhistoCloud.add_widget(labidpharma)
                cadhistoCloud.add_widget(labadressepharma)
                cadhistoCloud.add_widget(labresppharma)

                
                cadhistoCloud.add_widget(transid)
                cadhistoCloud.add_widget(btconfitransid)

            except:
                pass
        
            msgopencloud=Popup(title="HISTORIQUE FLUX CLOUD",content=cadhistoCloud,size_hint=(.7,.8))
            msgopencloud.open()

        except:
            
            msgopencloud=Popup(title="HISTORIQUE FLUX CLOUD",content=Button(text="ERROR"),size_hint=(.5,.3))

            msgopencloud.open()
    
    def demarrer(self,instance):
        
        compteur=0

        Clock.schedule_interval(lambda dt: self.update_progressBar(compteur), 0.1)
    
    def demarrenew(self):

        compteur=0

        Clock.schedule_interval(lambda dt: self.update_progressBar(compteur), 0.1)


    def update_progressBar(self, progress_bar):
        
        if progress_bar < 100:
            progress_bar += 2
            
            #cadbtnonligne.opacity=progress_bar/100

            #btcompte.text=str(progress_bar)+" Ko/s"

            print(progress_bar)


        else:
            progress_bar = 0
            
            self.demarrenew

class Online:

    global etatabonnement,nbrabonn

    etatabonnement=False
    nbrabonn=0

    def __init__(self,idonline,dateonline):

        global nbrabonn,btcl,idpharma

        idpharma=idonline

        btcl=Builder.load_string('''
Button:
    color:'black'
    background_color:[0,0,0,0]
    bold:True

    canvas.before:
        Color:
            rgb:202/255,202/255,202/255
        RoundedRectangle:
            size:self.size
            pos:self.pos

            radius:[15,15,1,1]
''')
      
        try:

            ref=db.reference('config')

            donness=ref.get()
            conf=[]

            for i,j in donness.items():
            
                date=j
                conf.append(date)
            
            dateheureserveur=conf[0]
            dateserveur=conf[1]

            dateserveur=datetime.strptime(dateserveur,'%Y-%m-%d')

            abonn=dateserveur-dateonline

            abonn=str(abonn).split(" ")

            nbrabonn=int(abonn[0])

        except:

            pass

    def verifieabonnement(self):
        global nbrabonn
        
        if nbrabonn<32:
            etatabonnement=True

        else:

            etatabonnement=False

        return etatabonnement


    def lecturecloudCommandeFacture(self): 
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/commandefacture')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['idfacture']
                k2=ele['idproduit']
                k3=ele['ajout']
                k4=ele['pu']
                k5=ele['travailleur']
                k6=ele['dates']
                k7=ele['dateheure']
                k8=ele['impactprix']

                data=(k1,k2,k3,k4,k5,k6,k7,k8)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudMotifSignaler(self): 
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/motifsignaler')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['motif']
                k2=ele['detail']
                k3=ele['travailleur']
                k4=ele['dates']
                k5=ele['dateheure']
                k6=ele['montant']

                data=(k1,k2,k3,k4,k5,k6)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudPresciption(self): 
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/prescription')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['idclient']
                k2=ele['idachat']
                k3=ele['docteur']
                k4=ele['dates']

                data=(k1,k2,k3,k4)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudPrisecharge(self):  
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/prisecharge')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['id']
                k2=ele['nom']
                k3=ele['prenom']
                k4=ele['sexe']
                k5=ele['tel']
                k6=ele['adresse']
                k7=ele['dates']
                k8=ele['travailleur']

                data=(k1,k2,k3,k4,k5,k6,k7,k8)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudRegistreCommande(self):  
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/regitrefluxcloud')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['dateheure']
                k2=ele['dates']
                k3=ele['Travailleur']
                k4=ele['operation']
               
                data=(k1,k2,k3,k4)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudAchat(self): 
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/achat')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['id']
                k2=ele['pu']
                k3=ele['qte']
                k4=ele['pt']
                k5=ele['client']
                k6=ele['dates']
                k7=ele['dateheure']
                k8=ele['travailleur']

                data=(k1,k2,k3,k4,k5,k6,k7,k8)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudHistogramme(self):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/historique')     

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                
                k1=ele['id']
                k2=ele['pu']
                k3=ele['qte']
                k4=ele['pt']
                k5=ele['client']
                k6=ele['dates']
                k7=ele['dateheure']
                k8=ele['travailleur']

                data=(k1,k2,k3,k4,k5,k6,k7,k8)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()


    def lecturecloudProduit(self):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/produit')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                a=i
                b=ele['nom']
                c=ele['pu']
                d=ele['stock']
                e=ele['expiration']

                data=(a,b,c,d,e)

                listdata.append(data)

            return listdata


        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def lecturecloudCompte(self):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/compte')

        try:
            listdata=[]

            donness=ref.get()

            for i,ele in donness.items():
                n5=i
                n1=ele['nom']
                n2=ele['postnom']
                n3=ele['prenom']
                n4=ele['sexe']
                n6=ele['pwd']
                n7=ele['type']
                n8=ele['datte']

                data=(n1,n2,n3,n4,n5,n6,n7,n8)

                listdata.append(data)

            return listdata

        except:

            btcl.text="ARROR!! Operation interrompue !!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

    def envoiecloudmotifsignaler(self,listmotif):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/motifsignaler')

        try:
            ii=0

            for lin in listmotif:

                a,b,c,d,e,f=lin

                ii+=1

                datta={"A"+str(ii):{
                    
                    'motif':str(a),
                    'detail':str(b),
                    'travailleur':str(c),
                    'dates':str(d),
                    'dateheure':str(e),
                    'montant':str(f)
                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous

    def envoiecloudfactureCommande(self,listcommfact):

        global idpharma

        ref=db.reference('pharma/'+idpharma+'/commandefacture')

        try:
            ii=0

            for lin in listcommfact:

                a,b,c,d,e,f,g,h=lin

                ii+=1

                datta={"A"+str(ii):{
                    'idfacture':str(a),
                    'idproduit':str(b),
                    'ajout':str(c),
                    'pu':str(d),
                    'travailleur':str(e),
                    'dates':str(f),
                    'dateheure':str(g),
                    'impactprix':str(h)

                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous
    
    def envoiecloudFluxcloud(self,listfluxcloud):

        global idpharma

        ref=db.reference('pharma/'+idpharma+'/regitrefluxcloud')

        try:
            ii=0
            for lin in listfluxcloud:

                a,b,c,d=lin

                ii+=1

                datta={"A"+str(ii):{
                    'dateheure':str(a),
                    'dates':str(b),
                    'Travailleur':str(c),
                    'operation':str(d)

                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous

    def envoiecloudPrescription(self,listprescription):

        global idpharma

        ref=db.reference('pharma/'+idpharma+'/prescription')

        try:
            ii=0

            for lin in listprescription:

                a,b,c,d=lin

                ii+=1

                datta={"A"+str(ii):{
                    'idclient':str(a),
                    'idachat':str(b),
                    'docteur':str(c),
                    'dates':str(d)

                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous

    def envoiecloudPrisecharge(self,listprise):

        global idpharma

        ref=db.reference('pharma/'+idpharma+'/prisecharge')

        try:
            ii=0
            for lin in listprise:

                a,b,c,d,e,f,g,h=lin

                ii+=1

                datta={"A"+str(ii):{
                    'id':str(a),
                    'nom':str(b),
                    'prenom':str(c),
                    'sexe':str(d),
                    'tel':str(e),
                    'adresse':str(f),
                    'dates':str(g),
                    'travailleur':str(h)
                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous

    def envoiecloudHistorique(self,listhisto):

        global idpharma

        ref=db.reference('pharma/'+idpharma+'/historique')

        try:
            ii=0

            for lin in listhisto:

                a,b,c,d,e,f,g,h=lin

                ii+=1

                datta={"A"+str(ii):{
                    'id':str(a),
                    'pu':str(b),
                    'qte':str(c),
                    'pt':str(d),
                    'client':str(e),
                    'dates':str(f),
                    'dateheure':str(g),
                    'travailleur':str(h)
                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous

    def envoiecloudUachat(self,listachat):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/achat')

        try:
            ii=0

            for lin in listachat:

                a,b,c,d,e,f,g,h=lin

                ii+=1

                datta={"A"+str(ii):{

                    'id':str(a),
                    'pu':str(b),
                    'qte':str(c),
                    'pt':str(d),
                    'client':str(e),
                    'dates':str(f),
                    'dateheure':str(g),
                    'travailleur':str(h)
                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous
    
    def envoiecloudUtilisateur(self,listUser):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/compte')

        try:

            for lin in listUser:

                a,b,c,d,e,f,g,h=lin

                datta={str(e):{
                    'nom':str(a),
                    'postnom':str(b),
                    'prenom':str(c),
                    'sexe':str(d),
                    'pwd':str(f),
                    'type':str(g),
                    'datte':str(h)
                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous
    
    def envoiecloud(self,listproduit):
        global idpharma

        ref=db.reference('pharma/'+idpharma+'/produit')

        try:

            for lin in listproduit:
                a,b,c,d,e=lin

                datta={str(a):{
                    'nom':str(b),
                    'pu':str(c),
                    'stock':str(d),
                    'expiration':str(e)
                    }
                }

                ref.update(datta)

            etatenvoiclous=True

        except:

            btcl.text="Error!! Interrumption CLOUD Innatendue!!"

            msg=Popup(title="CONNEXION CLOUD",content=btcl,size_hint=(.5,.3))
            msg.open()

            etatenvoiclous=False

        return etatenvoiclous

        #ref=db.reference('pharma/compte')

Pharma().run()


        

         

        









             