from kivymd.app import MDApp
from kivy.lang import Builder
from pyzbar.pyzbar import ZBarSymbol
from kivymd.uix.snackbar import snackbar
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.floatlayout import MDFloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.core.window import Window
from kivy.uix.popup import Popup
from kivymd.uix.textfield import MDTextField
from kivymd.uix.datatables import MDDataTable
from kivy.uix.image import Image
import socket
from kivy.uix.camera import Camera
import os
from kivy.resources import resource_find
import psutil
from kivy_garden.zbarcam import ZBarCam


global host,port,sock

KV="""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
#:import ZBarSymbol pyzbar.pyzbar.ZBarSymbol

ZBarCam
    id:zbarcam
    pos_hint:{'center_x':0.5,'center_y':0.62}
    code_types:ZBarSymbol.QRCODE.value,ZBarSymbol.EAN13.value
    on_symbols:app.on_symbols(*args)
"""

Window.size=(300,500)
class Vide(MDApp):
    def build(self):
        #form=Myapp()
        cads=MDFloatLayout()
        #cads.add_widget(form)

        return cads

class Myapp(MDApp):
    def build(self):
        global camera,etat,lab,datat,t1,labb,labtitre,imglogo,labtitre,bidentif
        
        global btcamera,cameraphot,btqr,cadre,lab,labb,t1,camera,btsend,etachager,btsend0,imgproduit,indiceph,newnom
        
        cadre=MDFloatLayout(md_bg_color='white')

        datat=""
        etat="0"
        indiceph=0
        etachager=0
        camera=Builder.load_string(KV)
        
        bt=Button(text="[b]Tester la connexion[/b]",pos_hint={'x':0.6,'y':0.3},size_hint=(0.2,0.08),markup=True)
        cadtitre=MDDataTable(pos_hint={'center_x':0.5,'y':0.88},size_hint=(0.8,0.1))
        labtitre=Label(text="[b]SCANNEUR PHARMA[/b]",markup=True,pos_hint={'center_x':0.5,'y':0.9},font_size="20sp",size_hint=(0.5,0.1),color='blue')
        imglogo=Image(source="mon logoo.png", size_hint=(0.2,0.2), pos_hint={'center_x':0.9,'y':0})        
        
        lab=Label(text="[b]Etat[/b]",markup=True,pos_hint={'x':0.5,'y':0.3},size_hint=(0.1,0.1),color='black')
        labb=Label(text="[b].[/b]",markup=True,pos_hint={'x':0.7,'y':0.3},size_hint=(0.1,0.1),color='black')
        t1=MDTextField(hint_text="Coding",pos_hint={'center_x':0.5,'y':0.22},size_hint=(0.9,0.1),font_size="15sp",password=False)
        #t1.bind(text=self.recherchephoto)

        imgproduit=Image(source='junio.jpg',size_hint=(0.2,0.2), pos_hint={'x':0.8,'y':0})

        
        bidentif=Button(text="[b]Admin[/b]",pos_hint={'x':0.05,'y':0.32},size_hint=(0.2,0.05),markup=True,color='white',background_color="red")
        bidentif.bind(on_release=self.echangeur)

        btqr=Button(text="[b]Basculer Code QR[/b]", pos_hint={'x':0.05,'y':0.17},size_hint=(0.5,0.05),font_size='15sp',color='white',background_color='blue', markup=True)
        btqr.bind(on_press=self.codeqr)

        btsend=Button(text="[b]Send[/b]", pos_hint={'x':0.8,'y':0.17},size_hint=(0.15,0.05),font_size='15sp',color='white',background_color='blue', markup=True)
        btsend.bind(on_press=self.testerphoto)

        try:
            cadre.add_widget(bidentif)
            
            cadre.add_widget(lab)
            
            cadre.add_widget(labb)
       
            cadre.add_widget(t1)

            cadre.add_widget(imglogo)

            cadtitre.add_widget(labtitre)
            cadre.add_widget(cadtitre)

            cadre.add_widget(camera)

            cadre.add_widget(btqr)
            
            cadre.add_widget(btsend)
            
        except:
            pass


        return cadre
    def echangeur(self,instance):
        if instance.text=="[b]Admin[/b]": 

            instance.text="[b]User[/b]"

        elif instance.text=="[b]User[/b]":

            instance.text="[b]Admin[/b]"

    def actualise(self,instance):
        global imgproduit
    
    def xxxxxxxcodeqr(self,instance):
        global camera

        for proc in psutil.process_iter(['pid','name',]):
            if 'zbarcam' in proc.info['name']:
                pid=proc.info['pid']
                psutil.Process(pid).terminate()

                break
    
    def testerphoto(self,instance):
        global etachager,newpho,imgproduit,indiceph,camera,newpho,newnom

        try:
            camera.add_widget(imgproduit)
        except:
            pass
        try:

            if indiceph<100:
                try:
                    dossierapp=os.path.dirname(__file__)
                    fich=[f for f in os.listdir(dossierapp) if f.endswith('.jpg')]
                    ph=fich[0]

                    newnom='junio'+str(indiceph)+'.jpg'
                    newpho=os.rename(ph,newnom)
                    
                    imgproduit.source=newnom
                    
            
                except:
                    msg=Popup(title="COMMUTATION",content=Button(text="Erreur survenue, veuillez redemarrer le programme stp"),size_hint=(None, None), size=(300,200))
                    msg.open()

                indiceph=indiceph+1
        except:
            pass
            #dossierapp=os.path.dirname(__file__)
            #fich=[f for f in os.listdir(dossierapp) if f.endswith('.jpg')]
            #for k in range(len(fich)):
             #   try:
             #       os.remove(fich[k])
              #  except:
              #      pass
        
    def codeqr(self,instance):
        global camera,etachager,imgproduit,indiceph
        k=0
        
        try:
            camera.remove_widget(imgproduit)
        except:
            pass

        try:
            dossierapp=os.path.dirname(__file__)
            fich=[f for f in os.listdir(dossierapp) if f.endswith('.jpg')]
            for k in range(len(fich)):
                try:
                    os.remove(fich[k])
                except:
                    pass
        except:
            msg=Popup(title="COMMUTATION",content=Button(text="Erreur survenue, veuillez redemarrer le programme stp"),size_hint=(None, None), size=(300,200))
            msg.open()

        try:
            camera=Builder.load_string(KV)  
        except:
           pass

        try:
            cadre.add_widget(camera)
        except:
            pass


    def op(self,instance):
        global sock
        testeur=""
        try:
            sock.connect((host,port))
            msg=Popup(title="COMMUTATION",content=Button(text="Communication favorable au serveur"),size_hint=(None, None), size=(300,200))
            msg.open()
            
        except:
            msg=Popup(title="COMMUTATION",content=Button(text="Communication echouée"),size_hint=(None, None), size=(300,200))
            msg.open()
    def virus(self,instance):

        dossierapp=os.path.dirname(resource_find('.'))
        fich=[f for f in os.listdir(dossierapp) if f.endswith('.jpg')]
        print("voila le ficher trouver ",fich)

            
    def recherchephoto(self,instance,value):

        dossierapp=os.path.dirname(__file__)
        fich=[f for f in os.listdir(dossierapp) if f.endswith('.jpg')]
        
    def on_symbols(self,instance,symbols):
        global datat,newpho,imgproduit
            
        if not symbols=="":
            for symbol in symbols:
                datat=str(symbol.data.decode())
                if datat=="":
                    pass
                else:
                    #print("deja ton code est : ",datat)

                    if bidentif.text=="[b]Admin[/b]": 

                        t1.text=datat

                        host,port=('localhost',5566)
                        sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                        try:
                            sock.connect((host,port))
                    
                            data=datat
                            data=data.encode("utf8")
                            sock.sendall(data)

                            msg=Popup(title="STATUT",content=Button(text='Commutation\nréussie!!!'),size_hint=(None, None), size=(250,200))
                            msg.open()
                            labb.text="Reussi"
                        except:
                            labb.text="Echec"
                            msg=Popup(title="ERROR",content=Button(text='Commutation\nechouée'),size_hint=(None, None), size=(250,200))
                            msg.open()
                    
                        finally:

                            pass
                        
                        try:
                            with open(newnom,'rb') as f:
                                codageimage=f.read()
                                sock.sendall(len(codageimage).to_bytes(4,byteorder='big'))
                                sock.sendall(codageimage)

                            sock.close()
                        
                        except:
                            msg=Popup(title="STATUT",content=Button(text='erreur lors de l envoie de la photo!!!'),size_hint=(None, None), size=(250,200))
                            msg.open()
                    elif bidentif.text=="[b]User[/b]":

                        t1.text=datat

                        host,port=('localhost',5566)
                        sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                        try:
                            sock.connect((host,port))
                    
                            data=datat
                            data=data.encode("utf8")
                            sock.sendall(data)

                            msg=Popup(title="STATUT",content=Button(text='Commutation\nréussie!!!'),size_hint=(None, None), size=(250,200))
                            msg.open()
                            labb.text="Reussi"
                        except:
                            labb.text="Echec"
                            msg=Popup(title="ERROR",content=Button(text='Commutation\nechouée'),size_hint=(None, None), size=(250,200))
                            msg.open()
                    
                        finally:

                            sock.close()
                        

                    
Myapp().run()


#fich=[f for f in os.listdir(discrec) if f.endswith('.jpg')]
    #    for k in range(len(fich)-1): "\ft\clora.jpg" clora
            #try:
        #    os.remove(fich[k])
        