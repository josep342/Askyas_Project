import mysql.connector
import datetime

from datetime import datetime

from kivymd.app import MDApp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.popup import Popup

class Ecol(MDApp):
    def build(self):

        cadre=BoxLayout()

        bt=Button(text="essayer")
        bt.bind(on_release=self.essayer)

        cadre.add_widget(bt)


        return cadre

    def essayer(self,instance):

        ecol=EcoleApp

        conn=self.connexion()

        if conn:

            # les tables sautées
          
            # les operation de la table classe
            
            #etatverifie=ecol.classAjout("3300","2e",datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1,conn)
            #etatverifie=ecol.classUpdate('60secon',datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'1',conn)
            #etatconn=ecol.classRecherche(conn)
            #etatverifie=etatconn[0]
            #listss=etatconn[1]

            # les operation de la table annees

            #etatverifie=ecol.AnneSColaireAjout(8,"12SEC",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1,conn)
            #etatverifie=ecol.AnneSColaireUpdate("12neewSEC",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),8,conn)
            #etatverifie=ecol.AnnScolaireDelete(8,conn)
            #etatverifie=ecol.Anne_ScolaireRecherche(conn)

            # les operaton de pa tabmle communique 

            #etatverifie=ecol.CommuniqueAjout(50,"titre 12SEC","content 12SEC","file 12SEC",2,conn)
            #etatverifie=ecol.CommuniqueUpdate(50,"titile new","content nex","file new",1,conn)
            #etatverifie=ecol.CommuniqueDelete(50,conn)
            #etatverifie=ecol.CommuniqueRecherche(conn)

            # les operation de la table cours

            #etatverifie=ecol.CoursAjout(50,"name",2,2,1,conn)
            #etatverifie=ecol.CoursUpdate(50,"name new",1,1,2,conn)
            #etatverifie=ecol.CoursDelete(50,conn)
            #etatverifie=ecol.CoursRecherche(conn)

            # les operation de la table cours_enseignant

            #etatverifie=ecol.CoursEnseignantAjout(50,1,1,1,conn)
            #etatverifie=ecol.CoursEnseignantUpdate(50,1,1,1,conn)
            #etatverifie=ecol.CoursEnseignantRecherche(conn)


            # les operation de la table devise

            #etatverifie=ecol.DevisetAjout(11,"FC new",conn)
            #etatverifie=ecol.DeviseUpdate(11,"FC nvvvea",conn)
            #etatverifie=ecol.DeviseDelete(11,conn)
            #etatverifie=ecol.DeviseRecherche(conn)

            # les operation de la table eleve

            #etatverifie=ecol.EleveAjout(11,"KATAMINA","ntumba","freddy","005","eleve genie",2,2,2,1,conn)
            #etatverifie=ecol.ElveUpdate(11,"KATAMINA new","ntumba new ","freddy new","005 new","eleve genie new",1,1,1,1,conn)
            #etatverifie=ecol.EleveDelete(11,conn)
            #etatverifie=ecol.EleveRecherche(conn)

            # les operation de la table Fair-Travail
            
            #etatverifie=ecol.FaireTravailDelete(1,conn)
            #etatverifie=ecol.FaireTravailRecherche(conn)

            # les operation de la table de fonction 

            #etatverifie=ecol.FonctionAjout(11,"sentinnemlle pro max",conn)
            #etatverifie=ecol.FonctionUpdate(11,"sentinnemlle new",conn)
            #etatverifie=ecol.FonctionDelete(11,conn)
            #etatverifie=ecol.FonctionRecherche(conn)

            # les operation de la table de fonction 
            #etatverifie=ecol.HoraireAjout(11,"tirle new","img.png new",2,2,2,conn)
            #etatverifie=ecol.HoraireUpdate(11,"tirle new","img.png new",2,2,2,conn)
            #etatverifie=ecol.HoraireDelete(11,conn)
            #etatverifie=ecol.HoraireRecherche(conn)

            # les opeation de la table d inscription
            
            #datenaiss="2020-02-20"

            #etatverifie=ecol.InscriptionAjout(11,"t1","t2","t3","t4","t5","t6",1,1,1,datenaiss,"tt2","tt3","tt4","tt5",conn)
            #etatverifie=ecol.InscriptionUpdate(11,"t1 new","t2 new","t3new","t4new","t5new","t6new",2,2,2,datenaiss,"tt2 new","tt3new","tt4new","tt5new",conn)
            #etatverifie=ecol.InscriptionDelete(11,conn)
            #etatverifie=ecol.InscriptionRecherche(conn)

            # les operation de la table de motif

            #etatverifie=ecol.MotifAjout(11,"paiement dounae",conn)
            #etatverifie=ecol.MotifUpdate(11,"paiement dounae new seck",conn)
            #etatverifie=ecol.MotifDelete(11,conn)
            #etatverifie=ecol.MotifRecherche(conn)

            # les operaiton de pa table de option

            #etatverifie=ecol.OptionAjout(11,"PEDA",1,conn)
            #etatverifie=ecol.OptionUpdate(11,"PEDA new",2,conn)
            #etatverifie=ecol.OptionDelete(11,conn)
            #etatverifie=ecol.OptionRecherche(conn)

            # les operation de la table de paiement 

            #etatverifie=ecol.PaiementAjout(12,5000,1,1,1,1,1,1,1,conn)
            #etatverifie=ecol.PaiementUpdate(12,555,2,2,2,2,2,2,2,conn)
            #etatverifie=ecol.PaiementRecherche(conn)
        
            # les operation de la table PERIODE 

            #etatverifie=ecol.PeriodeAjout(11,"DUCAP",conn)
            #etatverifie=ecol.PeriodeUpdate(11,"DUCAP new",conn)
            #etatverifie=ecol.PeriodeDelete(11,conn)
            #etatverifie=ecol.PeriodeRecherche(conn)

            # les operation de la table section 

            #etatverifie=ecol.SectionAjout(11,"DUCAP",conn)
            #etatverifie=ecol.SectionUpdate(11,"DUCAP new",conn)
            #etatverifie=ecol.SectionDelete(11,conn)Periode
            #etatverifie=ecol.SectionRecherche(conn)

            # les operation de la table tranche 

            #etatverifie=ecol.TrancheAjout(11,"DUCAP",conn)
            #etatverifie=ecol.TrancheUpdate(11,"DUCAP new",conn)
            #etatverifie=ecol.TrancheDelete(11,conn)
            #etatverifie=ecol.TrancheRecherche(conn)

            # les operation de la table Travail

            #etatverifie=ecol.TravailAjout(11,"title1","descr1",'2020-02-02',1,1,1,"photo.png",conn)
            #etatverifie=ecol.TravailUpdate(11,"title1 new","descr1 new",'2020-05-05',2,2,2,"photo new.png",conn)
            #etatverifie=ecol.TravailDelete(11,conn)
            #etatverifie=ecol.TravailRecherche(conn)
            
            # les operation de la table typeTravail

            #etatverifie=ecol.TypeTravailAjout(11,"DUCAP",conn)
            #etatverifie=ecol.TypeTravailUpdate(11,"DUCAP new",conn)
            #etatverifie=ecol.TypeTravailDelete(11,conn)
            #etatverifie=ecol.TypeTravailRecherche(conn)

            # les operations de la table User

            #etatverifie=ecol.UserAjout(10,"name1","Gmail 1","pwd1","NTUMBA","NTUMBA","Kga","082","f.png",1,"Homme",conn)
            #etatverifie=ecol.UserUpdate(10,"name1 new","Gmail 1 new","pwd1 new","NTUMBA new","NTUMBA new","Kga new","082 nwe","f.png new",2,"Femme",conn)
            #etatverifie=ecol.UserDelete(10,conn)
            etatverifie=ecol.UserRecherche(conn)

            print(etatverifie)


            #etatverifie=ecol.classAjout("3300","2e",datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1,conn)

            if etatverifie==True:
                msg=Popup(title="TITRE",content=Button(text="reusii"),size_hint=(.4,.3))
                msg.open()
        
        else:
            print('Error')

    def connexion(self):
        
        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con
        
        except:
            pass
    
class EcoleApp:

    def __init__(self):
        
        pass
    

    def UserAjout(v1,v2,gmail,v4,v6,v7,v8,v9,v10,v11,v12,con):
        
        try:
            cursor=con.cursor()
            query="insert into users(id,name,email,email_verified_at,password,remember_token,created_at,updated_at,first_name,last_name,address,phone,file,fonction_id,status,sexe) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,gmail,"0000-00-00",v4,"",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v6,v7,v8,v9,v10,v11,1,v12)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def UserRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from users where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def UserUpdate(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,con):

        try:
            cursor=con.cursor()
            query="update users set name=%s,email=%s,password=%s,updated_at=%s,first_name=%s,last_name=%s,address=%s,phone=%s,file=%s,fonction_id=%s,sexe=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v5,v6,v7,v8,v9,v10,v11,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def UserDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update users set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def TypeTravailAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into type_travails(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TypeTravailRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from type_travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TypeTravailUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update type_travails set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TypeTravailDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update type_travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def TravailAjout(v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="insert into travails(id,title,description,date_de_remise,cours_id,type_travails_id,annee_id,created_at,updated_at,file,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TravailRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TravailUpdate(v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="update travails set title=%s,description=%s,date_de_remise=%s,cours_id=%s,type_travails_id=%s,annee_id=%s,updated_at=%s,file=%s where id=%s"
            dataa=(v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TravailDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def TrancheAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into tranches(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def TrancheRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from tranches where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TrancheUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update tranches set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TrancheDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update tranches set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def SectionAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into sections(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def SectionRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from sections where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def SectionUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update sections set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def SectionDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update sections set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def PeriodeAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into periodes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def PeriodeRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from periodes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PeriodeUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update periodes set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def PeriodeDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update periodes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat




    def PaiementAjout(v1,v2,v3,v4,v5,v6,v7,v8,v9,con):
        
        try:
            cursor=con.cursor()
            query="insert into paiements(id,montant,devises_id,motifs_id,eleves_id,classes_id,tranches_id,annee_id,created_at,updated_at,users_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def PaiementRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from paiements")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PaiementUpdate(v1,v2,v3,v4,v5,v6,v7,v8,v9,con):

        try:
            cursor=con.cursor()
            query="update paiements set montant=%s,devises_id=%s,motifs_id=%s,eleves_id=%s,classes_id=%s,tranches_id=%s,annee_id=%s,updated_at=%s,users_id=%s where id=%s"
            dataa=(float(v2),v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    
    def OptionAjout(v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="insert into options(id,name,section_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def OptionRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from options where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def OptionUpdate(v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="update options set name=%s,section_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def OptionDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update options set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat




    def MotifAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into motifs(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def MotifRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from motifs where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def MotifUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update motifs set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def MotifDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update motifs set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat





    def InscriptionAjout(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datenaiss,v12,v13,v14,v15,con):

        try:
            cursor=con.cursor()
            query="insert into inscriptions(id,name,first_name,last_name,ecole_provenance,percent,phone,classes_id,options_id,annee_id,created_at,updated_at,status,date_naissance,lieu_de_naissance,nationalite,nom_parent,postnom_parent) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1,datenaiss,v12,v13,v14,v15)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def InscriptionRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from inscriptions where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def InscriptionUpdate(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,con):
        try:
            cursor=con.cursor()
            query="update inscriptions set name=%s,first_name=%s,last_name=%s,ecole_provenance=%s,percent=%s,phone=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s,date_naissance=%s,lieu_de_naissance=%s,nationalite=%s,nom_parent=%s,postnom_parent=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v11,v12,v13,v14,v15,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def InscriptionDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update inscriptions set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def HoraireAjout(v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="insert into horaires(id,title,image,classes_id,options_id,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def HoraireRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from horaires where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def HoraireUpdate(v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="update horaires set title=%s,image=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def HoraireDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update horaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def FonctionAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into fonctions(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def FonctionRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from fonctions where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FonctionUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update fonctions set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def FonctionDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update fonctions set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat



    def FaireTravailRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from faire_travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FaireTravailDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update faire_travails set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def EleveAjout(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="insert into eleves(id,name,first_name,last_name,matricule,description,users_id,classes_id,options_id ,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    

    def EleveRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from eleves where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def ElveUpdate(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="update eleves set name=%s,first_name=%s,last_name=%s,matricule=%s,description=%s,users_id=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def EleveDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update eleves set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat


    def DeviseRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from devises where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def DeviseUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update devises set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def DeviseDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update devises set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def DevisetAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into devises(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    



    def CoursEnseignantRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cour_enseigners")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursEnseignantUpdate(v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="update cour_enseigners set cours_id=%s,users_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursEnseignantAjout(v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="insert into cour_enseigners(id,cours_id,users_id,annee_id,created_at,updated_at) values(%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat

    def CoursRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cours where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursUpdate(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update cours set name=%s,ponderation=%s,classes_id=%s,options_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update cours set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CoursAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into cours(id,name,ponderation,classes_id,options_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat


    def CommuniqueRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from communiques where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CommuniqueUpdate(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update communiques set title=%s,content=%s,file=%s,users_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CommuniqueDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update communiques set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CommuniqueAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into communiques(id,title,content,file,users_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat



    def Anne_ScolaireRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from anne_scolaires where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def AnneSColaireUpdate(v1,vdate,v4,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set name=%s,updated_at=%s where id=%s"
            dataa=(v1,vdate,v4)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def AnnScolaireDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def AnneSColaireAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into anne_scolaires(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,int(v5))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from classes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
        


    def classAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into classes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,int(v5))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classUpdate(v1,vdate,v4,con):

        try:
            cursor=con.cursor()
            query="update classes set name=%s,updated_at=%s where id=%s"#,updated_at=%s
            dataa=(v1,vdate,v4)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def classDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update classes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def connecteBD():

        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con

        except:
            pass


Ecol().run()