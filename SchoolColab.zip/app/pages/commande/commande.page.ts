import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commande',
  templateUrl: './commande.page.html',
  styleUrls: ['./commande.page.scss'],
  standalone:false
})
export class CommandePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
