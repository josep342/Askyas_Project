import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MescannauxPage } from './mescannaux.page';

describe('MescannauxPage', () => {
  let component: MescannauxPage;
  let fixture: ComponentFixture<MescannauxPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MescannauxPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
