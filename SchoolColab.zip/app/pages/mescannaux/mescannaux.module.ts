import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MescannauxPageRoutingModule } from './mescannaux-routing.module';

import { MescannauxPage } from './mescannaux.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MescannauxPageRoutingModule
  ],
  declarations: [MescannauxPage]
})
export class MescannauxPageModule {}
