import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mescannaux',
  templateUrl: './mescannaux.page.html',
  styleUrls: ['./mescannaux.page.scss'],
  standalone:false
})
export class MescannauxPage implements OnInit {

  public etat=0;

  constructor() { 
   

  }

  ngOnInit() {
  }

  tester(){
    
    alert(document.getElementById('item2')!.innerText);
  }

  consultation(){

    document.getElementById('cadremodification')!.style.display="none";
    document.getElementById('cadresuppression')!.style.display="none";
    document.getElementById('cadreconsultation')!.style.display="block";

    document.getElementById('menu0')!.style.height="50px";
    document.getElementById('menu0')!.style.width="50px";

    document.getElementById('menu1')!.style.height="0%";
    document.getElementById('menu1')!.style.width="0%";

    document.getElementById('menu1')!.style.display="none";

    document.getElementById('menu2')!.style.height="100%";
    document.getElementById('menu2')!.style.width="100%";

    document.getElementById('unitilmenu2')!.style.width="0%";
    document.getElementById('unitilmenu2')!.style.height="0%";

    this.etat=0;

  }

  modification(){

    document.getElementById('cadremodification')!.style.display="block";
    document.getElementById('cadresuppression')!.style.display="none";
    document.getElementById('cadreconsultation')!.style.display="none";
    
    document.getElementById('menu0')!.style.height="50px";
    document.getElementById('menu0')!.style.width="50px";

    document.getElementById('menu1')!.style.height="0%";
    document.getElementById('menu1')!.style.width="0%";

    document.getElementById('menu1')!.style.display="none";

    document.getElementById('menu2')!.style.height="100%";
    document.getElementById('menu2')!.style.width="100%";

    document.getElementById('unitilmenu2')!.style.width="0%";
    document.getElementById('unitilmenu2')!.style.height="0%";

    this.etat=0;
    
  }

  supression(){
    
    document.getElementById('cadremodification')!.style.display="none";
    document.getElementById('cadresuppression')!.style.display="block";
    document.getElementById('cadreconsultation')!.style.display="none";

    document.getElementById('menu0')!.style.height="50px";
    document.getElementById('menu0')!.style.width="50px";

    document.getElementById('menu1')!.style.height="0%";
    document.getElementById('menu1')!.style.width="0%";

    document.getElementById('menu1')!.style.display="none";

    document.getElementById('menu2')!.style.height="100%";
    document.getElementById('menu2')!.style.width="100%";

    document.getElementById('unitilmenu2')!.style.width="0%";
    document.getElementById('unitilmenu2')!.style.height="0%";

    this.etat=0;
  }

  valider(){

    //document.getElementById('menuu')!.style.backgroundColor="red";

    if(this.etat==1){

      document.getElementById('menu0')!.style.height="50px";
      document.getElementById('menu0')!.style.width="50px";

      document.getElementById('menu1')!.style.height="0%";
      document.getElementById('menu1')!.style.width="0%";

      document.getElementById('menu1')!.style.display="none";

      document.getElementById('menu2')!.style.height="100%";
      document.getElementById('menu2')!.style.width="100%";

      document.getElementById('unitilmenu2')!.style.width="0%";
      document.getElementById('unitilmenu2')!.style.height="0%";

      this.etat=0;
    }

    else{

      document.getElementById('menu0')!.style.height="50%";
      document.getElementById('menu0')!.style.width="98%";

      document.getElementById('menu1')!.style.height="100%";
      document.getElementById('menu1')!.style.width="74%";

      document.getElementById('menu1')!.style.display="inline-block";
      document.getElementById('menu2')!.style.display="inline-block";

      document.getElementById('menu2')!.style.height="100%";
      document.getElementById('menu2')!.style.width="25%";

      document.getElementById('unitilmenu2')!.style.width="100%";
      document.getElementById('unitilmenu2')!.style.height="80%";

      //document.getElementById('menu2')!.style.display="block";

      this.etat=1;
    }
  }

}
