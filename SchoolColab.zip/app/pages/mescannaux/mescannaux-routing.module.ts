import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MescannauxPage } from './mescannaux.page';

const routes: Routes = [
  {
    path: '',
    component: MescannauxPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MescannauxPageRoutingModule {}
