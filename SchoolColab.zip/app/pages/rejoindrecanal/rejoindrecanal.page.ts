import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejoindrecanal',
  templateUrl: './rejoindrecanal.page.html',
  styleUrls: ['./rejoindrecanal.page.scss'],
  standalone:false
})
export class RejoindrecanalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
