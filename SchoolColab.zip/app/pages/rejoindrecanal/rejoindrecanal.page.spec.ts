import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RejoindrecanalPage } from './rejoindrecanal.page';

describe('RejoindrecanalPage', () => {
  let component: RejoindrecanalPage;
  let fixture: ComponentFixture<RejoindrecanalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(RejoindrecanalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
