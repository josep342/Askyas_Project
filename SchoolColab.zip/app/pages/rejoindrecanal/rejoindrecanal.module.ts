import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RejoindrecanalPageRoutingModule } from './rejoindrecanal-routing.module';

import { RejoindrecanalPage } from './rejoindrecanal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RejoindrecanalPageRoutingModule
  ],
  declarations: [RejoindrecanalPage]
})
export class RejoindrecanalPageModule {}
