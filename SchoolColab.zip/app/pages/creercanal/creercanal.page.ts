import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creercanal',
  templateUrl: './creercanal.page.html',
  styleUrls: ['./creercanal.page.scss'],
  standalone:false
})
export class CreercanalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
