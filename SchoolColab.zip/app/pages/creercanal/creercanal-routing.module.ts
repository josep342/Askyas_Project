import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreercanalPage } from './creercanal.page';

const routes: Routes = [
  {
    path: '',
    component: CreercanalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreercanalPageRoutingModule {}
