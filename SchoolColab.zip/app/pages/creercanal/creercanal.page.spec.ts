import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CreercanalPage } from './creercanal.page';

describe('CreercanalPage', () => {
  let component: CreercanalPage;
  let fixture: ComponentFixture<CreercanalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CreercanalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
