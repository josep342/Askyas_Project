import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreercanalPageRoutingModule } from './creercanal-routing.module';

import { CreercanalPage } from './creercanal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreercanalPageRoutingModule
  ],
  declarations: [CreercanalPage]
})
export class CreercanalPageModule {}
