import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CreatecomptePageRoutingModule } from './createcompte-routing.module';

import { CreatecomptePage } from './createcompte.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CreatecomptePageRoutingModule
  ],
  declarations: [CreatecomptePage]
})
export class CreatecomptePageModule {}
