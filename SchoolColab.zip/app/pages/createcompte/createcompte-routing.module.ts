import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreatecomptePage } from './createcompte.page';

const routes: Routes = [
  {
    path: '',
    component: CreatecomptePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CreatecomptePageRoutingModule {}
