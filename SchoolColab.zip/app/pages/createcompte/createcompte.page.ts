import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createcompte',
  templateUrl: './createcompte.page.html',
  styleUrls: ['./createcompte.page.scss'],
  standalone:false
})
export class CreatecomptePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
