import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gerercanal',
  templateUrl: './gerercanal.page.html',
  styleUrls: ['./gerercanal.page.scss'],
  standalone:false
})
export class GerercanalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
