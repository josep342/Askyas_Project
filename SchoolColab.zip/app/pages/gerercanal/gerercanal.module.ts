import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GerercanalPageRoutingModule } from './gerercanal-routing.module';

import { GerercanalPage } from './gerercanal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GerercanalPageRoutingModule
  ],
  declarations: [GerercanalPage]
})
export class GerercanalPageModule {}
