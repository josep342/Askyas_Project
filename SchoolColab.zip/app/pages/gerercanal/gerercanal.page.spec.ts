import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GerercanalPage } from './gerercanal.page';

describe('GerercanalPage', () => {
  let component: GerercanalPage;
  let fixture: ComponentFixture<GerercanalPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(GerercanalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
