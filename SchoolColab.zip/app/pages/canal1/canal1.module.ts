import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Canal1PageRoutingModule } from './canal1-routing.module';

import { Canal1Page } from './canal1.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Canal1PageRoutingModule
  ],
  declarations: [Canal1Page]
})
export class Canal1PageModule {}
