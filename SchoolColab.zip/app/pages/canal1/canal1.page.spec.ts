import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Canal1Page } from './canal1.page';

describe('Canal1Page', () => {
  let component: Canal1Page;
  let fixture: ComponentFixture<Canal1Page>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Canal1Page);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
