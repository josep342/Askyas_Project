import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-canal1',
  templateUrl: './canal1.page.html',
  styleUrls: ['./canal1.page.scss'],
  standalone:false
})
export class Canal1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
