import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  {
    path:'',
    redirectTo:'home',
    pathMatch:'full'
  },

  {
    path: 'home',

    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
    
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'accueil',
    loadChildren: () => import('./pages/accueil/accueil.module').then( m => m.AccueilPageModule)
  },
  {
    path: 'createcompte',
    loadChildren: () => import('./pages/createcompte/createcompte.module').then( m => m.CreatecomptePageModule)
  },
  {
    path: 'profil',
    loadChildren: () => import('./pages/profil/profil.module').then( m => m.ProfilPageModule)
  },
  {
    path: 'commande',
    loadChildren: () => import('./pages/commande/commande.module').then( m => m.CommandePageModule)
  },
  {
    path: 'canal1',
    loadChildren: () => import('./pages/canal1/canal1.module').then( m => m.Canal1PageModule)
  },
  {
    path: 'creercanal',
    loadChildren: () => import('./pages/creercanal/creercanal.module').then( m => m.CreercanalPageModule)
  },
  {
    path: 'rejoindrecanal',
    loadChildren: () => import('./pages/rejoindrecanal/rejoindrecanal.module').then( m => m.RejoindrecanalPageModule)
  },
  {
    path: 'gerercanal',
    loadChildren: () => import('./pages/gerercanal/gerercanal.module').then( m => m.GerercanalPageModule)
  },
  {
    path: 'mescannaux',
    loadChildren: () => import('./pages/mescannaux/mescannaux.module').then( m => m.MescannauxPageModule)
  },

  
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
