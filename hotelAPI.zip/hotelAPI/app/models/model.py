from pydantic import BaseModel,EmailStr,Field

class Avertissement(BaseModel):
    idLogin:int
    detail:str

class Bloc(BaseModel):

    detail:str

class Chambre(BaseModel):
   
    idCouloir:int
    detail:str
    dimension:str
    prix:int

class ChambreAffecter(BaseModel):
    idChambre:int
    idClient:int

class ChambreAffecterHisto(BaseModel):
    idChambre:int
    idClient:int

class Client(BaseModel):
    nom:str
    postnom:str
    prenom:str
    sexe:str

    tel:str
    pays:str
    ville:str

    sejour:int

class Commande(BaseModel):
    idClient:int
    idProduit:int
    qt:int
    
class Couloir(BaseModel):
   
    idBloc:int
    detail:str

class MotifPaiement(BaseModel):
  
    detail:str

class Notification(BaseModel):
    idLogin:int
    detail:str

class Paiement(BaseModel):
    idClient:int
    idMotif:int
    montant:int

class PaiementHisto(BaseModel):
    idClient:int
    idMotif:int
    montant:int

class Produit(BaseModel):
   
    nom:str
    detail:str

    prix:int
    

class Regime(BaseModel):
    
    detail:str

class RegimeClient(BaseModel):
    idClient:int
    idRegime:int

class RegimeProduit(BaseModel):
    idProduit:int
    idRegime:int

class Session(BaseModel):
    idLogin:int
    userAgent:str

class Taux(BaseModel):
    idTaux:int
    name:str
    taux:int

class Login(BaseModel):
    idClient:int
    pwd:str

'''
def calculer(data:dict):

    # validation testing
    try:
        inputs=Avertissement(**data)

       
        return {"status":True,"somme":data}
        
    except:

        return {"status":False,"somme":"NUll"}


data={"idlogin":5,"detail":"juniorcd"}

print(calculer(data))
'''