from fastapi import FastAPI
import asyncio
from pydantic import BaseModel

from schema import schema

app=FastAPI()

