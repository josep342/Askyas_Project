from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy import text
from sqlalchemy import Table,MetaData,Column,Integer,String,DateTime,select
from sqlalchemy import and_
from sqlalchemy import or_

import random

from datetime import datetime

class Bd():

    def __init__(self):

        global urlBAse,engine,sessionLocal,metadata,date

        date=datetime.strptime('2024-01-01 20:22:10','%Y-%m-%d %H:%M:%S')
        
        urlBAse="mysql+mysqlconnector://askyas:askyas@localhost:3306/hotel"

        engine=create_engine(urlBAse)

        sessionLocal=sessionmaker(autocommit=False,autoflush=False,bind=engine)

        metadata=MetaData()

    def testBase(self):  

        try:

            with sessionLocal() as session:
                res=session.execute(text("SELECT DATABASE()"))

                print(res.fetchone())  

        except Exception as e:

            print(e)


    #testBase()

    # lecture speciifique

    def lectureBD(self,n1):

        tabval=[]

        client=Table("bloc",metadata,autoload_with=engine)

        with sessionLocal() as session:

            res=session.execute(client.select().where(client.c.idBloc==n1))

            if res:

                for i,j in res:

                    print({i,j})



                    
                    #tabval.append(ligne)

                
            else:
                tabval=[]

            return tabval

    def avertissementSelect(self,n1):

        table=Table("avertissement",metadata,autoload_with=engine)
        
        with engine.connect() as con:

            res=con.execute(select(table).where(table.c.id_login==n1))

            tabval=res.mappings().all()

            if tabval:

                etat=True
            else:

                etat=False

                tabval=[]
            
            return tabval,etat
    
    def blocSelect(self,n1):

        table=Table("bloc",metadata,autoload_with=engine)
        
        with engine.connect() as con:

            res=con.execute(select(table).where(table.c.idBloc==n1))

            tabval=res.mappings().all()

            if tabval:

                etat=True
            else:

                etat=False

                tabval=[]
            
            return tabval,etat

    def chambreaffectehistoSelectClient(self,n1):

        table1=Table("chambreAffecterHistos",metadata,autoload_with=engine)
        table2=Table("chambres",metadata,autoload_with=engine)
        table3=Table("clients",metadata,autoload_with=engine)

        table4=Table("couloirs",metadata,autoload_with=engine)
        table5=Table("bloc",metadata,autoload_with=engine)
        
        with engine.connect() as con:

            res=con.execute(select(table2.c.idChambre,table2.c.detail,table2.c.dimension,table2.c.prix,table4.c.idCouloir ,table4.c.detail,table5.c.idBloc,table5.c.detail).join(table2,table1.c.id_chambre==table2.c.idChambre).join(table3,table1.c.id_client==table3.c.IdClient).join(table4,table2.c.idCouloir==table4.c.idCouloir).join(table5,table4.c.id_bloc==table5.c.idBloc).where(and_(table1.c.id_client==n1,table2.c.status==1,table3.c.status==1,table4.c.status==1,table5.c.status==1)))
            res=res.mappings().all()

            if res:

                tabval=res

                etat=True

            else:

                etat=False

                tabval=[]
            
            return tabval,etat

    def chambreaffecteSelectClient(self,n1):

        table1=Table("chambreAffectes",metadata,autoload_with=engine)
        table2=Table("chambres",metadata,autoload_with=engine)
        table3=Table("clients",metadata,autoload_with=engine)

        table4=Table("couloirs",metadata,autoload_with=engine)
        table5=Table("bloc",metadata,autoload_with=engine)
        
        with engine.connect() as con:

            #table1,table3,table2,table4,table5

            res=con.execute(select(table2.c.idChambre,table2.c.detail,table2.c.dimension,table2.c.prix,table4.c.idCouloir ,table4.c.detail,table5.c.idBloc,table5.c.detail).join(table2,table1.c.id_chambre==table2.c.idChambre).join(table3,table1.c.id_client==table3.c.IdClient).join(table4,table2.c.idCouloir==table4.c.idCouloir).join(table5,table4.c.id_bloc==table5.c.idBloc).where(table1.c.id_client==n1).order_by(table2.c.updateDate.desc()).limit(1).order_by(table4.c.updateDate.desc()).limit(1).order_by(table5.c.updateDate.desc()).limit(1))

            res=res.mappings().all()

            if res:

                tabval=res

                etat=True

            else:

                etat=False

                tabval=[]
            
            return tabval,etat

    def chambreaffectehistoSelect(self):

        table1=Table("chambreAffecterHistos",metadata,autoload_with=engine)
        table2=Table("chambres",metadata,autoload_with=engine)
        table3=Table("clients",metadata,autoload_with=engine)

        table4=Table("couloirs",metadata,autoload_with=engine)
        table5=Table("bloc",metadata,autoload_with=engine)
        
        try:

            with engine.connect() as con:

                res=con.execute(select(table1.c.id_client,table3.c.Nom,table3.c.Postnom,table3.c.Prenom,table3.c.Sexe,table2.c.idChambre,table2.c.detail,table4.c.idCouloir,table4.c.detail,table5.c.idBloc,table5.c.detail,table1.c.date).join(table3,table1.c.id_client==table3.c.IdClient).join(table2,table1.c.id_chambre==table2.c.idChambre).join(table4,table2.c.idCouloir==table4.c.idCouloir).join(table5,table4.c.id_bloc==table5.c.idBloc).where(and_(table3.c.status==1,table2.c.status==1,table4.c.status==1,table5.c.status==1)))

                res=res.mappings().all()

                if res:

                    tabval=res

                    etat=True

                else:

                    etat=False

                    tabval=[]
                
                return tabval,etat

        except Exception as e:

            etat=e
            tabval=[]
            
            return tabval,etat

    def chambreaffecteSelect(self):

        table1=Table("chambreAffectes",metadata,autoload_with=engine)
        table2=Table("chambres",metadata,autoload_with=engine)
        table3=Table("clients",metadata,autoload_with=engine)

        table4=Table("couloirs",metadata,autoload_with=engine)
        table5=Table("bloc",metadata,autoload_with=engine)
        
        try:

            with engine.connect() as con:

                res=con.execute(select(table1.c.id_client,table3.c.Nom,table3.c.Postnom,table3.c.Prenom,table3.c.Sexe,table2.c.idChambre,table2.c.detail,table4.c.idCouloir,table4.c.detail,table5.c.idBloc,table5.c.detail,table1.c.date).join(table3,table1.c.id_client==table3.c.IdClient).join(table2,table1.c.id_chambre==table2.c.idChambre).join(table4,table2.c.idCouloir==table4.c.idCouloir).join(table5,table4.c.id_bloc==table5.c.idBloc).where(and_(table3.c.status==1,table2.c.status==1,table4.c.status==1,table5.c.status==1)))

                res=res.mappings().all()

                if res:

                    tabval=res

                    etat=True

                else:

                    etat=False

                    tabval=[]
                
                return tabval,etat

        except Exception as e:

            etat=e
            tabval=[]
            
            return tabval,etat

    def chambreSelect(self):

        table2=Table("chambres",metadata,autoload_with=engine)

        table4=Table("couloirs",metadata,autoload_with=engine)
        
        with engine.connect() as con:

            #table1,table3,table2,table4,table5

            res=con.execute(select(table2.c.idChambre,table2.c.detail,table2.c.dimension,table2.c.prix,table4.c.idCouloir ,table4.c.detail,table2.c.updateDate).join(table4,table2.c.idCouloir==table4.c.idCouloir).where(table2.c.status==1,table4.c.status==1).order_by(table2.c.updateDate.desc()))

            res=res.mappings().all()

            if res:

                tabval=res

                etat=True

            else:

                etat=False

                tabval=[]
            
            return tabval,etat
    
    def clientSelect(self):
       
        table3=Table("clients",metadata,autoload_with=engine)
        
        try:

            with engine.connect() as con:

                res=con.execute(select(table3.c.IdClient,table3.c.Nom,table3.c.Postnom,table3.c.Prenom,table3.c.Sexe,table3.c.Tel,table3.c.Pays,table3.c.Ville,table3.c.Sejour,table3.c.status,table3.c.updateDate))

                res=res.mappings().all()

                if res:

                    tabval=res

                    etat=True

                else:

                    etat=False

                    tabval=[]
                
                return tabval,etat

        except Exception as e:

            etat=e
            tabval=[]
            
            return tabval,etat
        
    def inserB(self):

        datte=datetime.strptime('2024-01-01 20:22:10','%Y-%m-%d %H:%M:%S')

        t_bloc=Table("tauxx",metadata,
            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('idTaux',Integer),
            Column('name',String),
            Column('taux',Integer),
            Column('date',DateTime)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert().values(idTaux=2,name="USD",taux=350,date=datte))

                session.commit()

                print('ressus')

        except Exception as e:

            print(e)
    
    
    def avertissementInsert(self,n1,n2):

        t_bloc=Table("avertissement",metadata,
            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('id_login',Integer),
            Column('detail',String),
            Column('etat',Integer),
            Column('dateHeure',DateTime)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert().values(id_login=n1,detail=n2,etat=1,dateHeure=date))

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return etatReq,error

    def blocInsert(self,n1):

        t_bloc=Table("bloc",metadata,
            Column('id',Integer,primary_key=True,autoincrement=True),
            Column('idBloc',Integer),
            Column('detail',String),
            Column('createDate',DateTime),
            Column('updateDate',DateTime),
            Column('status',Integer)
        )

        try:

            with sessionLocal() as session:

                session.execute(t_bloc.insert().values(idBloc=random.randint(1,5000),detail=n1,createDate=date,updateDate=date,status=1))

                session.commit()

                etatReq=True

                error=""

        except Exception as e:

            etatReq=False
            error=e
        
        return etatReq,error
    
bd=Bd()

#rep=bd.blocInsert('blocMabeh')

#print(rep)

print(bd.clientSelect())