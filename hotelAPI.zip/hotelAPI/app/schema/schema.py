from pydantic import BaseModel,EmailStr,Field

class AddtionValidattion(BaseModel):
    n1:int
    n2:int

def calculer(data:dict):

    # validation testing
    try:
        inputs=AddtionValidattion(**data)

        res=inputs.n1+inputs.n2

        return {"status":True,"somme":res}
        
    except:

        return {"status":False,"somme":"NUll"}


data={"n1":5,"n2":10}

print(calculer(data))