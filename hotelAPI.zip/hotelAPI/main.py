"""from fastapi import FastAPI
import asyncio
from pydantic import BaseModel

app=FastAPI()


from app.core.database import lectureBD

data=lectureBD()

print(data)

"""
# module de validation de données

from app.models.model import *

nom="Bloc VIP"

data={
    'detail':"piratage simple duo",
    'idLogin':300

}

bloc=Avertissement(**data)

print(bloc)
