import mysql.connector
import datetime

from datetime import datetime

from kivymd.app import MDApp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.popup import Popup

class Ecol(MDApp):
    def build(self):

        cadre=BoxLayout()

        bt=Button(text="essayer")
        bt.bind(on_release=self.essayer)

        cadre.add_widget(bt)


        return cadre

    def essayer(self,instance):

        ecol=EcoleApp

        conn=self.connexion()

        if conn:

            # les tables sautées
          
            # les operation de la table classe
            
            #etatverifie=ecol.classAjout("3300","2e",datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1,conn)
            #etatverifie=ecol.classUpdate('60secon',datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'1',conn)
            #etatconn=ecol.classRecherche(conn)
            #etatverifie=etatconn[0]
            #listss=etatconn[1]

            # les operation de la table annees

            #etatverifie=ecol.AnneSColaireAjout(8,"12SEC",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),datetime.now().strftime('%Y-%m-%d %H:%M:%S'),1,conn)
            #etatverifie=ecol.AnneSColaireUpdate("12neewSEC",datetime.now().strftime('%Y-%m-%d %H:%M:%S'),8,conn)
            #etatverifie=ecol.AnnScolaireDelete(8,conn)
            #etatverifie=ecol.Anne_ScolaireRecherche(conn)

            # les operaton de pa tabmle communique 

            #etatverifie=ecol.CommuniqueAjout(50,"titre 12SEC","content 12SEC","file 12SEC",2,conn)
            #etatverifie=ecol.CommuniqueUpdate(50,"titile new","content nex","file new",1,conn)
            #etatverifie=ecol.CommuniqueDelete(50,conn)
            #etatverifie=ecol.CommuniqueRecherche(conn)

            # les operation de la table cours

            #etatverifie=ecol.CoursAjout(50,"name",2,2,1,conn)
            #etatverifie=ecol.CoursUpdate(50,"name new",1,1,2,conn)
            #etatverifie=ecol.CoursDelete(50,conn)
            #etatverifie=ecol.CoursRecherche(conn)

            # les operation de la table cours_enseignant

            #etatverifie=ecol.CoursEnseignantAjout(50,1,1,1,conn)
            #etatverifie=ecol.CoursEnseignantUpdate(50,1,1,1,conn)
            #etatverifie=ecol.CoursEnseignantRecherche(conn)


            # les operation de la table devise

            #etatverifie=ecol.DevisetAjout(11,"FC new",conn)
            #etatverifie=ecol.DeviseUpdate(11,"FC nvvvea",conn)
            #etatverifie=ecol.DeviseDelete(11,conn)
            #etatverifie=ecol.DeviseRecherche(conn)

            # les operation de la table eleve

            #etatverifie=ecol.EleveAjout(12,"NTUMBA","NTUMBA ","JOSEOH","N001","ELeve genie",1,1,1,1,conn)
            #etatverifie=ecol.EleveUpdate(12,"NTUMBA new","NTUMBA new","JOSEOH new","N001 new","ELeve genie new",2,2,2,1,conn)
            #etatverifie=ecol.EleveDelete(12,conn)
            etatverifie=ecol.EleveRecherche(conn)

            print(etatverifie)

            #etatverifie=ecol.classAjout("3300","2e",datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1,conn)

            if etatverifie==True:
                msg=Popup(title="TITRE",content=Button(text="reusii"),size_hint=(.4,.3))
                msg.open()
            

        else:
            print('Error')

    def connexion(self):
        
        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con
        
        except:
            pass
    
class EcoleApp:

    def __init__(self):
        
        pass
    

    def EleveRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from eleves where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def EleveUpdate(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="update eleves set name=%s,first_name=%s,last_name=%s,matricule=%s,description=%s,users_id=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def EleveDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update eleves set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def EleveAjout(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="insert into eleves(id,name,first_name,last_name,matricule,description,users_id,classes_id,options_id ,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat


    def DeviseRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from devises where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def DeviseUpdate(v1,v2,con):

        try:
            cursor=con.cursor()
            query="update devises set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def DeviseDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update devises set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def DevisetAjout(v1,v2,con):

        try:
            cursor=con.cursor()
            query="insert into devises(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    



    def CoursEnseignantRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cour_enseigners")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursEnseignantUpdate(v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="update cour_enseigners set cours_id=%s,users_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursEnseignantAjout(v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="insert into cour_enseigners(id,cours_id,users_id,annee_id,created_at,updated_at) values(%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat

    def CoursRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from cours where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursUpdate(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update cours set name=%s,ponderation=%s,classes_id=%s,options_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update cours set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CoursAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into cours(id,name,ponderation,classes_id,options_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat


    def CommuniqueRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from communiques where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CommuniqueUpdate(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update communiques set title=%s,content=%s,file=%s,users_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CommuniqueDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update communiques set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def CommuniqueAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into communiques(id,title,content,file,users_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d'),datetime.now().strftime('%Y-%m-%d'),1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat



    def Anne_ScolaireRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from anne_scolaires where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def AnneSColaireUpdate(v1,vdate,v4,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set name=%s,updated_at=%s where id=%s"
            dataa=(v1,vdate,v4)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def AnnScolaireDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def AnneSColaireAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into anne_scolaires(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,int(v5))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classRecherche(con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from classes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
        


    def classAjout(v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="insert into classes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            dataa=(v1,v2,v3,v4,int(v5))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()
            etat=True

        except:
            etat=False

        return etat
    
    def classUpdate(v1,vdate,v4,con):

        try:
            cursor=con.cursor()
            query="update classes set name=%s,updated_at=%s where id=%s"#,updated_at=%s
            dataa=(v1,vdate,v4)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def classDelete(v1,con):

        try:
            cursor=con.cursor()
            query="update classes set status=%s where id=%s"
            dataa=(0,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat
    
    def connecteBD():

        try:
            con=mysql.connector.connect(
            host="localhost",
            user="askyas",
            password="askyas",
            database="EcolApp"
            )

            return con

        except:
            pass


Ecol().run()